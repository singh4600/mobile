package com.appypie.bitbar;

import java.io.IOException;
import java.net.URL;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.appypie.pages.NavigationPage;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public abstract class BaseAndroidTest extends BaseTest {

	private NavigationPage navigationPage;
	@Override
	protected void setAppiumDriver() throws IOException {
	    logger.debug("Setting up AndroidDriver");
		this.driver = new AndroidDriver<MobileElement>(new URL(getAppiumServerAddress() + "/wd/hub"),
				capabilities);
	}

    @Override
    protected String getServerSideApplicationPath() {
        return System.getProperty("user.dir") + "/application.apk";
    }

    @Override
    protected String getDesiredCapabilitiesPropertiesFileName() { 
        if (isClientSideTestRun()){
            return "desiredCapabilities.android.clientside.properties";
        } else {
            return "desiredCapabilities.android.serverside.properties";
        }
    }

	
	@BeforeSuite
    public void setUp() throws Exception {
        setUpTest();
    }
    @AfterSuite
    public void tearDown()
    {
        quitAppiumSession();
    }
    
    @BeforeClass
    public void navigateTo(){
    	navigationPage= new NavigationPage(driver);
    	navigationPage.navigateToPage();
    }

    @AfterClass
    public void restartApp() {
        driver.resetApp();
        driver.context("NATIVE_APP");
    }
}
