package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieTwitterPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieTwitterTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieTwitterPage twpage;

	@BeforeTest
	@Override
	public void pageSetUp() {
		twpage = new AppypieTwitterPage(driver);
	}

	@Test
	public void verifyTwitterPage() {
		Logger.info("********Test Method Starts: verifyTwitterPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			twpage.openTwitterPage();
			boolean Open = twpage.identifyTwitterOpen();
			if (Open) {
				String Header = PageElement.getPageHeader(driver);
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertEquals(PageElement.getAppName(driver), "Automate",
						"BackButton is not working on Twitter Page");
				asser.assertEquals(Header, "Twitter");
			} else {
				Logger.info("Twitter Page is not open from main menu");
			}
			asser.assertTrue(Open, "Twitter Page is not Open by clicking the main menu icon");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Twitter page", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyTwitterAccount() {
		Logger.info("********Test Method Starts: verifyTwitterAccount********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			twpage.openTwitterPage();
			twpage.openTwitterAccount();
			boolean info = twpage.checkFeeds();
			asser.assertTrue(info, "Twitter account is not opening or feeds are not present in the facebook url");
			if (!info) {
				boolean nodata = PageElement.checkNoDataOptionInUrl(driver);
				if (nodata)
					Logger.info("No data icon is showing in the Twitter account");
				asser.assertTrue(nodata, "No data icon is not visible and feeds are not present in Twitter account");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Twitter account", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyInvalidTwitterAccount() {
		Logger.info("Test Method Starts: verifyInvalidTwitterAccount");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			twpage.openTwitterPage();
			twpage.clickInvalidUrl();
			String tweet= twpage.getTweets();
			asser.assertTrue(tweet.contains("NaN"), "Twitter account is not opening and no data icon is also not visible on screen");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the invalid Twitter account", e);
			exception = true;
		}
		Assert.assertFalse(exception, " Exception occurs while opening the invalid  Twitter account");
		asser.assertAll();
	}

	@Test
	public void verifyLikeandFollows() {
		Logger.info("********Test Method Starts: verifyLikeandFollows********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			twpage.openTwitterPage();
			twpage.openTwitterAccount();
			String tweet = twpage.getTweets();
			String followers = twpage.getFollowers();
			asser.assertNotNull(tweet, "Twitter tweets are not present in the facebook url");
			asser.assertNotNull(followers, "Twitter followers are not present in the facebook url");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the tweets and followers in twitter account", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyTwitterFeedInNative() {
		Logger.info("********Test Method Starts: verifyTwitterFeedInNative********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			twpage.openTwitterPage();
			twpage.openTwitterAccount();
			boolean open = twpage.checkTwitterFeedInNative();
			asser.assertTrue(open, " Twitter feeds is not open in native browser");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Twitter feeds in native", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
