package com.appypie.tests.logintests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieFBLoginTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieLoginPage login;
	
	
	@Override
	@BeforeTest
	public void pageSetUp() {
		login= new AppypieLoginPage(driver);	
	}
	
	@Test
	public void verifyFBLogin() {
		Logger.info("********Test Method Starts: verifyFBLogin********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openfbLoginPage();
				asser.assertTrue(login.isFBOpen(), "Facebook login page is not open from login page");		
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying facebook Login functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


}
