package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.AppypieReligiousPage;
import com.appypie.pages.AppypieTextPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieReligiousTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	AppypieReligiousPage religious;
	AppypieMenuPage menu;
	SoftAssert asser;

	@Override
	@BeforeTest
	public void pageSetUp() {
		religious = new AppypieReligiousPage(driver);
		menu = new AppypieMenuPage(driver);
	}

	@Test
	public void verifyReligiousPageAndBackBtn() {
		Logger.info("Test Methods start: verifyReligiousPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("religious");
			boolean pageOpen = religious.isReligiousPageOpen();
			asser.assertTrue(pageOpen, "religious page is not open from main menu");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "backButton on religious page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the religious page from main menu", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyBible() {
		Logger.info("Test Methods start: verifyBible");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("religious");
			boolean pageOpen = religious.isReligiousPageOpen();
			asser.assertTrue(pageOpen, "religious page is not open from main menu");
			if (pageOpen) {
				religious.openReligiousBooks("bible");
				asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "bible is not open in native");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the bible in native", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuran() {
		Logger.info("Test Methods start: verifyQuran");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("religious");
			boolean pageOpen = religious.isReligiousPageOpen();
			asser.assertTrue(pageOpen, "religious page is not open from main menu");
			if (pageOpen) {
				religious.openReligiousBooks("Quran");
				asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "Quran is not open in native");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Quran in native", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyGeeta() {
		Logger.info("Test Methods start: verifyGeeta");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("religious");
			boolean pageOpen = religious.isReligiousPageOpen();
			asser.assertTrue(pageOpen, "religious page is not open from main menu");
			if (pageOpen) {
				religious.openReligiousBooks("geeta");
				asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "Geeta is not open in native");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Geeta in native", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
