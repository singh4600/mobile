package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieCouponPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class AndroidCouponPageTest extends TestSetup {
	AppypieCouponPage coupon; 
	private static final Logger Logger= Log.createLogger();
	//------------------------------------------------------------------------------------------------------
	By getHeaderCouponpage=By.xpath("//div[@class='navbar']/div[2]/div[2]");  // verify header title 
	//By get=By.xpath("");
	By getfirstcouponsummaryhomepage=By.xpath("//*[@id='coupon-flip0']//h2[@class='copTitle arial largeHeading;']"); 
	By getsecondcouponsummaryhomepage=By.xpath("//*[@id='coupon-flip1']//h2[@class='copTitle arial largeHeading;']"); 
	By getfirstcouponvaliditydatehomepage=By.xpath("//*[@id='coupon-flip0']//div[@class='info-wrapper-second']/span/strong");
	By getsecondcouponvaliditydatehomepage=By.xpath("//*[@id='coupon-flip1']//div[@class='info-wrapper-second']/span/strong"); 
	By getfirstcoupontermandconditiondetailshomepage=By.xpath("//*[@id='coupon-flip0']//div[@class='copDescription terms-text arial mediumContent']"); 
	By getfirstcoupontermandconditiondetailstitlehomepage=By.xpath("//*[@id='coupon-flip0']//h2[@class='arial largeHeading']");
	By getsecondscoupontermandconditiondetailshomepage=By.xpath("//*[@id='coupon-flip1']//div[@class='copDescription terms-text arial mediumContent']");
	By getsecondscoupontermandconditiondetailstitlehomepage=By.xpath("//*[@id='coupon-flip1']//h2[@class='arial largeHeading']");

	By getsummarycoupondetailpage=By.xpath("//*[@id='couponDetail-flip']//h1[@class='heading-title arial largeHeading']");
	By getDateOfIssuecoupondetailpage=By.xpath("//div[contains(@class,'dateInfo infoLeft')]");
	By getValidTillcoupondetailpage=By.xpath("//div[contains(@class,'dateInfo infoRight')]"); 
	By getcouponcodecoupondetailpage=By.xpath("//*[@class='couponCode']");
	By gettermandconditiondetailscoupondetailpage=By.xpath("//*[@class='terms-text terms-text2 copDescription arial mediumContent']"); 



	static SoftAssert softassert;


	public static String verifyvalue(AppiumDriver<MobileElement> driver, By gettext){
		String Actual;
		Actual=ElementWait.waitForOptionalElement(driver,gettext,50).getText();
		Logger.info("Actual value:  "+Actual);
		return Actual;
	}

	public static String verifyAttributevalue(AppiumDriver<MobileElement> driver, By getAttribute){
		String Actual;
		Actual=ElementWait.waitForOptionalElement(driver,getAttribute,50).getAttribute("value");
		Logger.info("Actual value:  "+Actual);
		return Actual;
	}
	//--------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		coupon= new AppypieCouponPage(driver);
	}

	//---------------------------------------------------------------------------------------------------- 
	@Test(priority=0, description="TestCases_1: To check coupon Module is open.")
	public void Check_Open_coupon_Module()   //throws BiffException, IOException, InterruptedException
	{	
		Logger.info("To check open coupon module");
		coupon.opencouponmodule();
	}

	@Test(priority=1, description="TestCases_2: To check Home Page header Title. // "
			+ "TestCases_3: To check first coupon code summary. // "
			+ "TestCases_4: To check first coupon code validity date.  // "
			+ "TestCases_5: To check second coupon code summary. //"
			+ "TestCases_6: To check second coupon code validate date.  ")
	public void CheckCouponHomePage()  //throws BiffException, IOException, InterruptedException
	{	
		softassert= new SoftAssert();
		coupon.opencouponmodule();
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Logger.info("To check Header title");

		softassert.assertEquals(verifyvalue(driver, getHeaderCouponpage), "Coupon");

		Logger.info("To check first coupon code summary");

		softassert.assertEquals(verifyvalue(driver, getfirstcouponsummaryhomepage), "Coupon Code Take 10% Off");
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Logger.info("To check first coupon code validity date");

		softassert.assertEquals(verifyvalue(driver, getfirstcouponvaliditydatehomepage), "01-Feb-2018");

		Logger.info("To check second coupon code summary");

		softassert.assertEquals(verifyvalue(driver, getsecondcouponsummaryhomepage), "Coupon Code Take 20% off");

		Logger.info("To check second coupon code validate date");

		softassert.assertEquals(verifyvalue(driver, getsecondcouponvaliditydatehomepage), "01-Feb-2018");

		softassert.assertAll();
	}

	@Test(priority=2, description="TestCases_7: To check first coupon code Header title. // "
			+ "TestCases_8: To check get term and condition for first coupon. // "
			+ "TestCases_9: To check for fist coupon code close term and condition. //"
			+ "TestCases_10: To check second coupon code Header title. //"
			+ "TestCases_11: To check get term and condition for second coupon. //"
			+ "TestCases_12: To check for second coupon code close term and condition.")
	public void Checktermandconditiondetailshomepage()   //throws BiffException, IOException, InterruptedException
	{	
		softassert= new SoftAssert();
		coupon.opencouponmodule();
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		coupon.openfirstcoupontermandcondition();

		Logger.info("To check first coupon code Header title");

		softassert.assertEquals(verifyvalue(driver, getfirstcoupontermandconditiondetailstitlehomepage), "Terms & Conditions");
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.info("To check get term and condition for first coupon");

		//softassert.assertEquals(Actual, "Terms & Conditions");
		Logger.info("Terms & Conditions:  "+verifyvalue(driver, getfirstcoupontermandconditiondetailshomepage));
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.info("To check for fist coupon code close term and condition");
		coupon.closedfirstcoupontermandcondition();
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		coupon.opensecondcoupontermandcondition();
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Logger.info("To check second coupon code Header title");

		softassert.assertEquals(verifyvalue(driver, getsecondscoupontermandconditiondetailstitlehomepage), "Terms & Conditions");
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Logger.info("To check get term and condition for second coupon");

		//softassert.assertEquals(Actual, "Terms & Conditions");
		Logger.info("Terms & Conditions:  "+verifyvalue(driver, getsecondscoupontermandconditiondetailshomepage));
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.info("To check for second coupon code close term and condition");
		coupon.closedsecondcoupontermandcondition();

		softassert.assertAll();
	}

	@Test(priority=3, description="TestCases_13: To check Header title on coupon detials page. // "
			+ "TestCases_14: To check get Date Of Issue of first coupon. //"
			+ "TestCases_15: To check get valid till date of first coupon. //"
			+ "TestCases_16: To check term and condition. //"
			+ "TestCases_17: To check get term and condition details. //"
			+ "TestCases_18: To check get coupon code number. //"
			+ "TestCases_19: To check close term and condition. ")
	public void Checkfirstcoupondetailspage()  //throws BiffException, IOException, InterruptedException
	{	
		softassert= new SoftAssert();
		coupon.opencouponmodule();
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		coupon.openfirstcoupon();

		Logger.info("To check Header title on coupon detials page");

		softassert.assertEquals(verifyvalue(driver, getHeaderCouponpage), "Coupon Code Take 10% Off");

		Logger.info("To check get Date Of Issue of first coupon");
		verifyvalue(driver, getDateOfIssuecoupondetailpage);
		//softassert.assertEquals(Actual.toString(), "Date Of Issue 12-Jun-2017");
		//Logger.info(Actual);

		Logger.info("To check get valid till date of first coupon");
		verifyvalue(driver, getValidTillcoupondetailpage);
		//softassert.assertEquals(Actual, "Valid Till 01-Feb-2018");
		//Logger.info(Actual);

		Logger.info("To check get coupon code number");

		softassert.assertEquals(verifyvalue(driver, getcouponcodecoupondetailpage), "L36FPY");

		Logger.info("To check term and condition");
		coupon.opentermandconditioncoupondetailpage();

		Logger.info("To check get term and condition details");

		//softassert.assertEquals(Actual, "Terms & Conditions");
		Logger.info("Terms & Conditions:  "+verifyvalue(driver, gettermandconditiondetailscoupondetailpage));

		Logger.info("To check close term and condition");
		coupon.closedtermandconditioncoupondetailpage();

		softassert.assertAll();
	}

	@Test(priority=4, description="TestCases_20: To check Header title on coupon detials page. // "
			+ "TestCases_21: To check get Date Of Issue of second coupon. //"
			+ "TestCases_22: To check get valid till date of second coupon. //"
			+ "TestCases_23: To check term and condition. //"
			+ "TestCases_24: To check get term and condition details. //"
			+ "TestCases_25: To check get coupon code number. //"
			+ "TestCases_26: To check close term and condition.")
	public void Checksecondcoupondetailspage()   //throws BiffException, IOException, InterruptedException
	{	
		softassert= new SoftAssert();
		coupon.opencouponmodule();
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		coupon.opensecondcoupon();

		Logger.info("To check Header title on coupon detials page");

		softassert.assertEquals(verifyvalue(driver, getHeaderCouponpage), "Coupon Code Take 20% off");

		Logger.info("To check get Date Of Issue of second coupon");
		verifyvalue(driver, getDateOfIssuecoupondetailpage);
		//softassert.assertEquals(Actual, "12-Jun-2017");
		//Logger.info(Actual);

		Logger.info("To check get valid till date of second coupon");
		verifyvalue(driver, getValidTillcoupondetailpage);


		Logger.info("To check get coupon code number");

		softassert.assertEquals(verifyvalue(driver, getcouponcodecoupondetailpage), "A93B6K");


		Logger.info("To check term and condition");
		coupon.opentermandconditioncoupondetailpage();

		Logger.info("To check get term and condition details");

		//softassert.assertEquals(Actual, "Terms & Conditions");
		Logger.info("Terms & Conditions:  "+verifyvalue(driver, gettermandconditiondetailscoupondetailpage));

		Logger.info("To check close term and condition");
		coupon.closedtermandconditioncoupondetailpage();

		softassert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VerifyScratchAndWin()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyScratchAndWin()");
		boolean exception = false;
		try {

			Boolean couponmodule=coupon.Openlinks(coupon.opencouponmodule);
			if (couponmodule) {
				coupon.Getactualtext(coupon.header_gettext);

				coupon.Getactualtext(coupon.scrtchHeading_get);
				coupon.Getactualtext(coupon.validDatescrtch_get);
				coupon.Getactualtext(coupon.descriptionscrtch_get);

				Boolean scratchwin=coupon.Openlinks(coupon.scratchwinlink);
				if (scratchwin) {

					Boolean ifalert=coupon.IselementPresent(coupon.AlertOkButton);
					if (ifalert) {
						coupon.IfAlertpresent();
					}
					else {
						coupon.Getactualtext(coupon.header_gettext);
						coupon.Getactualtext(coupon.issueDatescratchwin_get);
						coupon.Getactualtext(coupon.validDatescrtch_get);

						Boolean sharelinkscratch=coupon.Openlinks(coupon.sharelinkscratchwin);
						if (sharelinkscratch) {
							coupon.sharelink(coupon.getsharebyItem_getlink);
						}
						s_assert.assertTrue(sharelinkscratch, "sharelinkscratch  is not open"); 

						Boolean TCscratch=coupon.Openlinks(coupon.TCscratchwin);
						if (TCscratch) {
							Boolean closeTCscratch=coupon.Openlinks(coupon.closeTCscratchwin);
							s_assert.assertTrue(closeTCscratch, "close TC scratch is not open"); 
						}
						s_assert.assertTrue(TCscratch, "TCscratch is not open"); 
					}
				}
				s_assert.assertTrue(scratchwin, "scratch win link is not open");
			}
			s_assert.assertTrue(couponmodule, "coupon module is not open"); 
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + coupon.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VerifyLoot()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyLoot()");
		boolean exception = false;
		try {

			Boolean couponmodule=coupon.Openlinks(coupon.opencouponmodule);
			if (couponmodule) {
				coupon.Getactualtext(coupon.header_gettext);

				coupon.Getactualtext(coupon.lootHeading_get);
				coupon.Getactualtext(coupon.validDateloot_get);
				coupon.Getactualtext(coupon.descriptionloot_get);

				Boolean loot=coupon.Openlinks(coupon.lootlink);
				if (loot) {
					coupon.Getactualtext(coupon.header_gettext);
					coupon.Getactualtext(coupon.headingfrntLoot_get);
					coupon.Getactualtext(coupon.lootcoupon_get);
					coupon.Getactualtext(coupon.issueDateLoot_get);

					Boolean sharelink=coupon.Openlinks(coupon.sharelinkLoot);
					if (sharelink) {

						if (globledeviceName.equals("iPhone")) {
							//coupon.sharelink(coupon.i_share);
							driver.context("NATIVE_APP");
							Boolean cancleBtn=coupon.Openlinks(coupon.i_cancelBtn);
							s_assert.assertTrue(cancleBtn, "Cancle Button is not working on ios app");

							PageElement.changeContextToWebView(driver);
						}
						else {
							coupon.sharelink(coupon.getsharebyItem_getlink);
						}
					}
					s_assert.assertTrue(sharelink, "share link  is not open"); 

					Boolean TC=coupon.Openlinks(coupon.TCLoot);
					if (TC) {
						Boolean closeTCscratch=coupon.Openlinks(coupon.closeTCscratchwin);
						s_assert.assertTrue(closeTCscratch, "close TC scratch is not open"); 

					}
					s_assert.assertTrue(TC, "TC is not open"); 


					Boolean redeemBtn=coupon.Openlinks(coupon.redeemBtnLoot);
					if (redeemBtn) {
						Boolean mainalert=coupon.IselementPresent(coupon.AlertHeader_gettext);
						if (mainalert) {
						coupon.IfAlertpresent();
						}
						else {
						Boolean backBtn=coupon.Openlinks(coupon.backBtnAfterRedeem);
						if (backBtn) {
							Boolean redeemBtn1=coupon.Openlinks(coupon.redeemBtnLoot);
							if (redeemBtn) {

								Boolean codeEnter=coupon.TextField(coupon.entercodeLoot, "5UYXGD");
								if (codeEnter) {

									Boolean alert=coupon.IselementPresent(coupon.AlertHeader_gettext);
									if (alert) {
										coupon.IfAlertpresent();
										Boolean alert1=coupon.IselementPresent(coupon.AlertHeader_gettext);
										if (alert1) {
											coupon.IfAlertpresent();
										}
										s_assert.assertTrue(alert1,"Alert1 is not present");
									}

									else {
										Boolean validateBtn=coupon.Openlinks(coupon.validateBtnLoot);
										if (validateBtn) {
											coupon.IfAlertpresent();
										}
										s_assert.assertTrue(validateBtn, "validate Btn is not open");
									}
									s_assert.assertTrue(alert,"Alert is not present");
								}
								s_assert.assertTrue(codeEnter, "codeEnter is not working");

							}
							s_assert.assertTrue(redeemBtn1, "redeem Btn again open is not open"); 
						}
						s_assert.assertTrue(backBtn, "back Btn after redeem btn  is not open"); 
						}
						s_assert.assertTrue(mainalert, "Alert is present before click on Redeem button");
						
					}
					s_assert.assertTrue(redeemBtn, "redeem Btn is not open"); 
				}
				s_assert.assertTrue(loot, "loot link is not open");
			}
			s_assert.assertTrue(couponmodule, "coupon module is not open"); 
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + coupon.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

}


















