package com.appypie.tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.NavigationPage;
import com.appypie.pages.SocialNetwork.CommanClassSocialNetwork;
import com.appypie.pages.SocialNetwork.SocialNetworkPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class SocialNetworkTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();

	SocialNetworkPage sn;
	CommanClassSocialNetwork comm;

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		sn=new SocialNetworkPage(driver);
		comm=new CommanClassSocialNetwork(driver);

	}


	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VerifySocialNetworkHomePage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkHomePage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}
				
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Social Network");

				Boolean postwithoutstatus=comm.Openlinks(sn.clickpost);
				TimeUnit.SECONDS.sleep(10);
				if (postwithoutstatus) {
					comm.IfAlertpresent();
				}
				s_assert.assertTrue(postwithoutstatus, "Post button is not working");

				Boolean enteryourmind=comm.TextField(sn.clickwhatyourmindtext, "Appy Pie is the fastest growing cloud based Mobile Apps Builder Software (App Maker) that allows users with no programming skills, "
						+ "to create Android & iPhone applications for mobiles and smartphones; and publish to Google Play & iTunes");
				s_assert.assertTrue(enteryourmind, "What's on your mind text is not present");

				Boolean checkpost=comm.Openlinks(sn.clickpost);
				TimeUnit.SECONDS.sleep(10);
				if (checkpost) {
					comm.IfAlertpresent();
				}
				s_assert.assertTrue(checkpost, "Post button is not working");

				Boolean likebtn=comm.Openlinks(sn.clicklikepost);
				TimeUnit.SECONDS.sleep(10);
				s_assert.assertTrue(likebtn, "like link isnot working");

				Boolean comment=comm.Openlinks(sn.clickcommentpost);
				TimeUnit.SECONDS.sleep(10);
				if (comment) {
					
					Boolean commenttering=comm.TextField(sn.commentEnter, "Hi Appypie");
					if (commenttering) {
						Boolean sent=comm.Openlinks(sn.commentSent);
						if (sent) {
							Boolean menucomment=comm.Openlinks(sn.commentmenu);
							if (menucomment) {
								Boolean delete=comm.Openlinks(sn.deleteComment);
								s_assert.assertTrue(delete, "Delete comment is not working");
							}
							s_assert.assertTrue(menucomment, "menu comment is not working");
						}
						s_assert.assertTrue(sent, "Comment Send is not working");
					}
					s_assert.assertTrue(commenttering, "Comment Enter is not working");
			
					
									
					Boolean backbtn=comm.Openlinks(comm.BackButton1);
					s_assert.assertTrue(backbtn,"Back Button is  ot wokring after comment page");
					
				}
				s_assert.assertTrue(comment, "Comment link is not working");

				String user=comm.Getactualtext(sn.getUserwhopost);
				s_assert.assertNotNull(user, "User who post is getting Null Value");

				String posttime=comm.Getactualtext(sn.getPostTime);
				s_assert.assertNotNull(posttime, "Post time is getting Null Value");

				String postedtext=comm.Getactualtext(sn.getPost);
				s_assert.assertNotNull(postedtext, "Post text is getting Null Value");

				String likecount=comm.Getactualtext(sn.getLike);
				s_assert.assertNotNull(likecount, "like count is getting Null Value");

				String commentcount=comm.Getactualtext(sn.getComment);
				s_assert.assertNotNull(commentcount, "Comment count is getting Null Value");

				Boolean deletepostmenu=comm.Openlinks(sn.clickdeletmenu);
				if (deletepostmenu) {
					Boolean deletepost=comm.Openlinks(sn.clickdeletepost);
					s_assert.assertTrue(deletepost, "Delete post link is not working");
				}
				s_assert.assertTrue(deletepostmenu, "Delete post menu is not open");

				Boolean backbtnhome=comm.Openlinks(comm.BackButtonHome);
				s_assert.assertTrue(backbtnhome, "back Btn at home is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifySocialNetworkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					String UN=comm.Getactualtext(sn.getUsernamemenu);
					s_assert.assertNotNull(UN, "User Name on menu page is getting Null Value");

					Boolean menulist=comm.getListofLink(sn.getMenuList);
					s_assert.assertTrue(menulist, "menu list is not present");

					Boolean closemenupage=comm.Openlinks(sn.closedMenupage);
					s_assert.assertTrue(closemenupage, "Closed Menu page link is not working");
				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifySocialNetworkMainMenuLinkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkMainMenuLinkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					Boolean mainmenu=comm.Openlinks(sn.clickmainmenu);
					if (mainmenu) {
						Boolean menulink=comm.Openlinks(sn.clickmenu);
						s_assert.assertTrue(menulink, "menu link is not working");
					}
					s_assert.assertTrue(mainmenu, "Main menu link is not present on menu page");
				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifySocialNetworkStatusTABMyprofileLinkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkStatusTABMyprofileLinkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					Boolean myprofile=comm.Openlinks(sn.clickmyprofile);
					if (myprofile) {
						String UNMP=comm.Getactualtext(sn.getUsernameMP);
						s_assert.assertNotNull(UNMP, "User name is getting Null value on my profile page");

						String followers=comm.Getactualtext(sn.getFollowersMP);
						s_assert.assertNotNull(followers, "followers is getting Null value on my profile page");

						String following=comm.Getactualtext(sn.getFollowingMP);
						s_assert.assertNotNull(following, "following is getting Null value on my profile page");

						Boolean statuslink=comm.Openlinks(sn.statuslinkMP);
						if (statuslink) {
							String postcount=comm.Getactualtext(sn.getStatusPostCountMp);
							s_assert.assertNotNull(postcount, "post count is getting Null value on my profile page");

							String un=comm.Getactualtext(sn.getPostUserNameMP);
							s_assert.assertNotNull(un, "User name is getting Null value on my profile page");

							String time=comm.Getactualtext(sn.getPostTimeMP);
							s_assert.assertNotNull(time, "post Time is getting Null value on my profile page");

						}
						s_assert.assertTrue(statuslink, "Status link is not working");

					}
					s_assert.assertTrue(myprofile, "My profile link is not working");
				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VerifySocialNetworklikeTABMyprofileLinkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworklikeTABMyprofileLinkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					Boolean myprofile=comm.Openlinks(sn.clickmyprofile);
					if (myprofile) {
						String UNMP=comm.Getactualtext(sn.getUsernameMP);
						s_assert.assertNotNull(UNMP, "User name is getting Null value on my profile page");

						String followers=comm.Getactualtext(sn.getFollowersMP);
						s_assert.assertNotNull(followers, "followers is getting Null value on my profile page");

						String following=comm.Getactualtext(sn.getFollowingMP);
						s_assert.assertNotNull(following, "following is getting Null value on my profile page");

						Boolean likepost=comm.Openlinks(sn.likeLinkMP);
						if (likepost) {
							Boolean listunpost=comm.TwoValueReturn(sn.getlikePostTitleListMP, sn.getlikeposttextMP);
							s_assert.assertTrue(listunpost, "User name and post text is not present");
						}
						s_assert.assertTrue(likepost, "like link is not working");

					}
					s_assert.assertTrue(myprofile, "My profile link is not working");
				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VerifySocialNetworkCameraTABMyprofileLinkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkCameraTABMyprofileLinkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					Boolean myprofile=comm.Openlinks(sn.clickmyprofile);
					if (myprofile) {
						Boolean camera=comm.Openlinks(sn.cameralinkMP);
						if (camera) {
							Boolean openphoto=comm.Openlinks(sn.cameraphotoMP);
							if (openphoto) {
								String un=comm.Getactualtext(sn.getcameraUserNameMP);
								s_assert.assertNotNull(un, "user name is getting Null value in camera link on my profile page");

								String time=comm.Getactualtext(sn.getcameraPostTimeMP);
								s_assert.assertNotNull(time, "time is getting Null value in camera link on my profile page");

								String post=comm.Getactualtext(sn.getcameraPostTextMP);
								s_assert.assertNotNull(post, "post text is getting Null value in camera link on my profile page");

								Boolean likebtncamera=comm.Openlinks(sn.likecameralinkMP);
								s_assert.assertTrue(likebtncamera, "Like button is not working on camera on my profile page");

								
								
								
								Boolean sharelink=comm.Openlinks(sn.sharelinkcameraMP);
								if (sharelink) {
									if (!globledeviceName.equals("iPhone")) {
										driver.context("NATIVE_APP");
										Boolean sharelist=comm.getListofLink(sn.getsharelistcameraMP);
										s_assert.assertTrue(sharelist, "Share list is not present");
										driver.navigate().back();
										PageElement.changeContextToWebView(driver);
									}
									else {
										driver.context("NATIVE_APP");
										Boolean cancleBtn=comm.Openlinks(sn.i_cancelBtn);
										s_assert.assertTrue(cancleBtn, "Cancle Button is not working on ios app");
										PageElement.changeContextToWebView(driver);
									}
								}
								s_assert.assertTrue(sharelink, "Share link is not working");

								/*Boolean backbtn=comm.Openlinks(comm.BackButton);--
								s_assert.assertTrue(backbtn, "back button is not working on camera my profile page");*/
								driver.context("NATIVE_APP");
								driver.navigate().back();
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(openphoto, "Open photo is not open on my profile page");
						}
						s_assert.assertTrue(camera, "Camera link is not wolriong on my profile page");
					}
					s_assert.assertTrue(myprofile, "My profile link is not working");
				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 7, description = "")
	public void VerifySocialNetworkSettingTABMyprofileLinkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkSettingTABMyprofileLinkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					Boolean myprofile=comm.Openlinks(sn.clickmyprofile);
					if (myprofile) {
						Boolean setting=comm.Openlinks(sn.settinglinkMP);
						if (setting) {
							Boolean listsetting=comm.getListofLink(sn.getsettinglistMP);
							s_assert.assertTrue(listsetting, "List is not present on seeting on my profile page");

							Boolean editprofile=comm.Openlinks(sn.editprofilelikSettingMP);
							if (editprofile) {
								comm.Getactualtext(comm.header_gettext);

								Boolean UN=comm.TextField(sn.usernameEditProfile, "QA");
								s_assert.assertTrue(UN, "User name text filed is not working");

								Boolean gender=comm.Openlinks(sn.genderEditProfile);
								if (gender) {

									driver.context("NATIVE_APP");
									if (!globledeviceName.equals("iPhone")) {
										Boolean male=comm.Openlinks(sn.gendernative);
										s_assert.assertTrue(male,"Male radio button is not working");
									}
									else {
										Boolean iDonebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(iDonebtn,"iDone Button is not wokring");
										
									}
									PageElement.changeContextToWebView(driver);

									Boolean genderpublic=comm.Openlinks(sn.genderPublicCheckBox);
									s_assert.assertTrue(genderpublic, "Gender check box is not working");
								}
								s_assert.assertTrue(gender, "gender is not working");

								Boolean date=comm.Openlinks(sn.dateEditProfile);
								if (date) {
									driver.context("NATIVE_APP");
									if (!globledeviceName.equals("iPhone")) {
										Boolean dateset=comm.Openlinks(sn.datenative);
										s_assert.assertTrue(dateset,"dateset button is not working");
									}
									else {
										Boolean iDonebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(iDonebtn,"iDone Button is not wokring");
									}
									
									PageElement.changeContextToWebView(driver);

									Boolean datepublic=comm.Openlinks(sn.datePublicCheckBox);
									s_assert.assertTrue(datepublic, "Date check box is not working");
								}
								s_assert.assertTrue(date, "date is not working");

								Boolean country=comm.Openlinks(sn.countryEditProfile);
								if (country) {
									driver.context("NATIVE_APP");
									
									if (!globledeviceName.equals("iPhone")) {
									comm.countryselect();
									}else {
										Boolean iDonebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(iDonebtn,"iDone Button is not wokring");
									}
									PageElement.changeContextToWebView(driver);

									Boolean countrypublic=comm.Openlinks(sn.countryPublicCheckBox);
									s_assert.assertTrue(countrypublic, "country check box is not working");
								}
								s_assert.assertTrue(country, "country is not working");


								Boolean phone=comm.TextField(sn.phoneEditProfile, "1234567890");
								if (phone) {
									Boolean phonepublic=comm.Openlinks(sn.phonePublicCheckBox);
									s_assert.assertTrue(phonepublic, "phone check box is not working");
								}
								s_assert.assertTrue(phone, "phone text filed is not working");

								Boolean biography=comm.TextField(sn.biographyEditProfile, "Appypie ");
								if (biography) {
									Boolean biopublic=comm.Openlinks(sn.biographyPublicCheckBox);
									s_assert.assertTrue(biopublic, "Biography check box is not working");
								}
								s_assert.assertTrue(biography, "biography text filed is not working");

								Boolean save=comm.Openlinks(sn.saveEditProfile);
								if (save) {
									comm.IfAlertpresent();
								}
								s_assert.assertTrue(save, "Save button is not working");

							}
							s_assert.assertTrue(editprofile, "Edit profile link is not working");

							Boolean emailnotification=comm.Openlinks(sn.emialNotificationlinkSettingMP);
							if (emailnotification) {
								comm.Getactualtext(comm.header_gettext);

								Boolean followsmee=comm.Openlinks(sn.followsme);
								s_assert.assertTrue(followsmee, "followsme button is not working");

								Boolean commentsmypostt=comm.Openlinks(sn.commentsmypost);
								s_assert.assertTrue(commentsmypostt, "commentsmypost button is not working");

								Boolean likemypostt=comm.Openlinks(sn.likemypost);
								s_assert.assertTrue(likemypostt, "likemypost button is not working");

								Boolean emaillistt=comm.getListofLink(sn.emaillist);
								s_assert.assertTrue(emaillistt, "emaillist list is not getting");

							Boolean backbtnemailNoti=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtnemailNoti,"Bac Button is not working on Email Notification page");

							}
							s_assert.assertTrue(emailnotification, "email notification link is not working");

							Boolean logoutt=comm.Openlinks(sn.logout);
							s_assert.assertTrue(logoutt, "logout link is not getting");

						}
						s_assert.assertTrue(setting, "Setting link is not working my profile page");
					}
					s_assert.assertTrue(myprofile, "My profile link is not working");
				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 8, description = "")
	public void VerifySocialNetworkBlockedUserLinkMenuPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkBlockedUserLinkMenuPage()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
					TimeUnit.SECONDS.sleep(3);
				}

				Boolean menu=comm.Openlinks(sn.clickmenu);
				if (menu) {
					Boolean blockuser=comm.Openlinks(sn.clickblockuser);
					if (blockuser) {

				//-----UnBlock User-----
						Boolean unblockpresent=comm.IselementPresent(sn.unblockMenuPage);
						if (unblockpresent) {
							Boolean unblock=comm.Openlinks(sn.unblockMenuPage);
							s_assert.assertTrue(unblock, "Unblock link is not wokring on blocked user menu page");
						}
						else {
							System.out.println("There is no any Blocked user in the Blocked List");
						}

						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "back button link is not working on blockedUser menu page");
					}
					s_assert.assertTrue(blockuser, "blocked users link is not working");

				}
				s_assert.assertTrue(menu, "Menu link is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 9, description = "")
	public void VerifySocialNetworkVideoUpload() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkVideoUpload()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}
				Boolean videolink=comm.Openlinks(sn.clickvideos);
				if (videolink) {
					Boolean addvideo=comm.Openlinks(sn.clickaddvideolink);
					if (addvideo) {
						Boolean videogallerylink=comm.Openlinks(sn.clickvideogallerylink);
						if (videogallerylink) {
							driver.context("NATIVE_APP");
							
							if (!globledeviceName.equals("iPhone")) {
								Boolean menunative= comm.Openlinks(sn.clickmenuNative);
								if (menunative) {
									Boolean menulistnative=comm.getListofLink(sn.clickmenulistNative);
									if (menulistnative) {
										Boolean videoopetion=comm.Openlinks(sn.clickvideoOptionNative);
										if (videoopetion) {
											TimeUnit.SECONDS.sleep(4);
											Boolean selectvideoNative=comm.Openlinks(sn.clickselectvideoNative);
											if (selectvideoNative) {
												TimeUnit.SECONDS.sleep(4);
												Boolean selectvideoNative1=comm.Openlinks(sn.clickselectvideoNative1);
												s_assert.assertTrue(selectvideoNative1, "Video is not selected");
												TimeUnit.SECONDS.sleep(4);
											}
											s_assert.assertTrue(selectvideoNative, "Video is not selected");
										}
										s_assert.assertTrue(videoopetion, "Video option is not selected");
									}
									s_assert.assertTrue(menulistnative, "Menu list native is not present");
								}
								s_assert.assertTrue(menunative, "Menu native link is not working");
							}
							else {
								
								List<WebElement> list=ElementWait.waitForAllOptionalElements(driver, sn.i_videos, 20);
								if (list != null) {
									list.get(2).click();
									try {
									PageElement.tapOnScreen(driver, 41,86);
									}catch (Exception e) {
										System.out.println("Error in Video Selection on Ios native");
									}
									Boolean choosephoto=comm.Openlinks(sn.i_choose);
									s_assert.assertTrue(choosephoto, "i_choose photo is not selected");
								}
								else {
									System.out.println("List is getting Null value");
								}
							}

							PageElement.changeContextToWebView(driver);

							Boolean checkboxprivate=comm.Openlinks(sn.clickPrivateCheckBox);
							s_assert.assertTrue(checkboxprivate, "Private check box is not check");

							Boolean enteryourmind1=comm.TextField(sn.clickwhatyourmindtext, "Appy Pie is the fastest growing cloud based Mobile Apps Builder Software (App Maker) that allows users with no programming skills, "
									+ "to create Android & iPhone applications for mobiles and smartphones; and publish to Google Play & iTunes");
							s_assert.assertTrue(enteryourmind1, "What's on your mind text is not present after video upload");

							Boolean checkpost1=comm.Openlinks(sn.clickpost);
							TimeUnit.SECONDS.sleep(50);
							if (checkpost1) {
								comm.IfAlertpresent();
								Boolean playvideo=comm.Openlinks(sn.playvideoonpost);
								if (playvideo) {
									driver.context("NATIVE_APP");
									
									if (!globledeviceName.equals("iPhone")) {
										Boolean playnative=comm.Openlinks(sn.playstopvideoNative);
										s_assert.assertTrue(playnative, "Play native video");

										Boolean stopnative=comm.Openlinks(sn.playstopvideoNative);
										s_assert.assertTrue(stopnative, "stop native video");

										Boolean backbtn=comm.Openlinks(comm.BackButtonNative);
										s_assert.assertTrue(backbtn, "back Button is not working after play video");
									}
									else {
										TimeUnit.SECONDS.sleep(50);
										
										Boolean videoclose=comm.Openlinks(sn.i_closeVideo);
										s_assert.assertTrue(videoclose, "Video Close btn is not working");
										
										Boolean backbtn=comm.Openlinks(comm.i_BackButtonNative);
										s_assert.assertTrue(backbtn, "back Button is not working after play video on ios");
									}
									
									PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(playvideo, "Play video is not play on post");
							}
							s_assert.assertTrue(checkpost1, "Post button is not working after video upload");
						}
						s_assert.assertTrue(videogallerylink, "Video Gallery Link is not working");
					}
					s_assert.assertTrue(addvideo, "Add video link is nott working");
				}
				s_assert.assertTrue(videolink, "Video link is not working");


			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 10, description = "")
	public void VerifySocialNetworkCameraPhotoupload() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkCameraPhotoupload()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean Checkpostbycamera=comm.Openlinks(sn.clickphotos);
				if (Checkpostbycamera) {
					Boolean addphoto=comm.Openlinks(sn.clickaddphotolink);
					if (addphoto) {
						Boolean clickcamera=comm.Openlinks(sn.clickcameralink);
						if (clickcamera) {
							
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissions(driver);

								Boolean clickphoto=comm.Openlinks(sn.clickcameraphotoNative);
								TimeUnit.SECONDS.sleep(10);
								s_assert.assertTrue(clickphoto,"camera photo click is not working");

								PageElement.changeContextToWebView(driver);

								Boolean enteryourmind1=comm.TextField(sn.clickwhatyourmindtext, "Appy Pie is the fastest growing cloud based Mobile Apps Builder Software (App Maker) that allows users with no programming skills, "
										+ "to create Android & iPhone applications for mobiles and smartphones; and publish to Google Play & iTunes");
								s_assert.assertTrue(enteryourmind1, "What's on your mind text is not present after camera photo upload");

								Boolean checkpost1=comm.Openlinks(sn.clickpost);
								TimeUnit.SECONDS.sleep(30);
								if (checkpost1) {
									comm.IfAlertpresent();
								}
								s_assert.assertTrue(checkpost1, "Post button is not working after camera photo upload");
							}
							else {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissionsCamera(driver);
								
								Boolean i_takephoto=comm.Openlinks(sn.i_clickcameraphotoNative);
								if (i_takephoto) {
									
									Boolean i_use=comm.Openlinks(sn.i_UsePhotocameraphotoNative);
									s_assert.assertTrue(i_use,"in ios , click to is not select use photo ");
									
								}
								s_assert.assertTrue(i_takephoto, "In ios Camera is not click photo");
								PageElement.changeContextToWebView(driver);
							}
						}
						s_assert.assertTrue(clickcamera, "Camera link is not working");
					}
					s_assert.assertTrue(addphoto, "Add Photo Link is not working");
				}
				s_assert.assertTrue(Checkpostbycamera, "Photos link is not working");

			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 11, description = "")
	public void VerifySocialNetworkgalleryphoto() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkgalleryphoto()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean galleryphoto=comm.Openlinks(sn.clickphotos);
				if (galleryphoto) {
					Boolean addphoto=comm.Openlinks(sn.clickaddphotolink);
					if (addphoto) {
						Boolean gallery=comm.Openlinks(sn.clickgallerylink);
						if (gallery) {
							
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissions(driver);
								Boolean selectphoto=comm.Openlinks(sn.clickselectphoto);
								if (selectphoto) {
									Boolean ok=comm.Openlinks(sn.clickuploadOkbutton);
									TimeUnit.SECONDS.sleep(20);
									s_assert.assertTrue(ok, "Ok button of photo upload is not working");
								}
								s_assert.assertTrue(selectphoto, "Select photo is not select");

								PageElement.changeContextToWebView(driver);
								
							}
							else {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissionsCamera(driver);
								Boolean cameraroll=comm.Openlinks(sn.i_openCameraRoll);
								if (cameraroll) {
									Boolean selectpic=comm.Openlinks(sn.i_selectPhoto);
									if (selectpic) {
										Boolean donebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(donebtn, "Done button is not working");
									}
									s_assert.assertTrue(selectpic, "Selected Photo is not selected");
								}
								s_assert.assertTrue(cameraroll, "Camera Roll link is not working");
								PageElement.changeContextToWebView(driver);
							}
								

								Boolean enteryourmind1=comm.TextField(sn.clickwhatyourmindtext, "Appy Pie is the fastest growing cloud based Mobile Apps Builder Software (App Maker) that allows users with no programming skills, "
										+ "to create Android & iPhone applications for mobiles and smartphones; and publish to Google Play & iTunes");
								s_assert.assertTrue(enteryourmind1, "What's on your mind text is not present after photo upload");

								Boolean checkpost1=comm.Openlinks(sn.clickpost);
								TimeUnit.SECONDS.sleep(30);
								if (checkpost1) {
									comm.IfAlertpresent();
								}
								s_assert.assertTrue(checkpost1, "Post button is not working after photo upload");

								Boolean openpost=comm.Openlinks(sn.newlyPostOpen);
								TimeUnit.SECONDS.sleep(10);
								if (openpost) {
									driver.context("NATIVE_APP");
									
									if (!globledeviceName.equals("iPhone")) {
										driver.navigate().back();
										comm.SwipeBottomToTop();
										comm.SwipeBottomToTop();
										comm.SwipeBottomToTop();
									}
									else
									{
										Boolean backbtn=comm.Openlinks(comm.i_BackButtonNative1);
										s_assert.assertTrue(backbtn, "i_back button is not working on open post page");
									}
									PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(openpost, "Newly post open is not working after photo upload");
						}
						s_assert.assertTrue(gallery, "gallery link is not working");
					}
					s_assert.assertTrue(addphoto, "Add Photo link is not working");
				}
				s_assert.assertTrue(galleryphoto, "Photos link is not working for gallery photo.");

			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 12, description = "")
	public void VerifySocialNetworkCanclephoto() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkCanclephoto()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean galleryphoto=comm.Openlinks(sn.clickphotos);
				if (galleryphoto) {
					Boolean addphoto=comm.Openlinks(sn.clickaddphotolink);
					if (addphoto) {
						Boolean gallery=comm.Openlinks(sn.clickgallerylink);
						if (gallery) {

							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissions(driver);
								Boolean selectphoto=comm.Openlinks(sn.clickselectphoto);
								if (selectphoto) {
									Boolean ok=comm.Openlinks(sn.clickuploadOkbutton);
									TimeUnit.SECONDS.sleep(20);
									s_assert.assertTrue(ok, "Ok button of photo upload is not working");
								}
								s_assert.assertTrue(selectphoto, "Select photo is not select");

								PageElement.changeContextToWebView(driver);
								
							}
							else {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissionsCamera(driver);
								Boolean cameraroll=comm.Openlinks(sn.i_openCameraRoll);
								if (cameraroll) {
									Boolean selectpic=comm.Openlinks(sn.i_selectPhoto);
									if (selectpic) {
										Boolean donebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(donebtn, "Done button is not working");
									}
									s_assert.assertTrue(selectpic, "Selected Photo is not selected");
								}
								s_assert.assertTrue(cameraroll, "Camera Roll link is not working");
								PageElement.changeContextToWebView(driver);
							}

							Boolean canclephoto=comm.Openlinks(sn.clickCanclePhotoVideoOnStatus);
							if (canclephoto) {
								Boolean addphoto1=comm.Openlinks(sn.clickaddphotolink);
								if (addphoto1) {
									Boolean gallery1=comm.Openlinks(sn.clickgallerylink);
									if (gallery1) {
										if (!globledeviceName.equals("iPhone")) {
											driver.context("NATIVE_APP");
											NavigationPage.verifyrunTimePermissions(driver);
											Boolean selectphoto=comm.Openlinks(sn.clickselectphoto);
											if (selectphoto) {
												Boolean ok=comm.Openlinks(sn.clickuploadOkbutton);
												TimeUnit.SECONDS.sleep(20);
												s_assert.assertTrue(ok, "Ok button of photo upload is not working");
											}
											s_assert.assertTrue(selectphoto, "Select photo is not select");

											PageElement.changeContextToWebView(driver);
											
										}
										else {
											driver.context("NATIVE_APP");
											NavigationPage.verifyrunTimePermissionsCamera(driver);
											Boolean cameraroll=comm.Openlinks(sn.i_openCameraRoll);
											if (cameraroll) {
												Boolean selectpic=comm.Openlinks(sn.i_selectPhoto);
												if (selectpic) {
													Boolean donebtn=comm.Openlinks(sn.i_Done);
													s_assert.assertTrue(donebtn, "Done button is not working");
												}
												s_assert.assertTrue(selectpic, "Selected Photo is not selected");
											}
											s_assert.assertTrue(cameraroll, "Camera Roll link is not working");
											PageElement.changeContextToWebView(driver);
										}
									}
									s_assert.assertTrue(gallery1, "gallery link is not working");
								}
								s_assert.assertTrue(addphoto1, "Add Photo link is not working");	

								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(canclephoto, "Cancle photo link is not working");

							Boolean enteryourmind1=comm.TextField(sn.clickwhatyourmindtext, "Appy Pie is the fastest growing cloud based Mobile Apps Builder Software (App Maker) that allows users with no programming skills, "
									+ "to create Android & iPhone applications for mobiles and smartphones; and publish to Google Play & iTunes");
							s_assert.assertTrue(enteryourmind1, "What's on your mind text is not present after photo upload");

							Boolean checkpost1=comm.Openlinks(sn.clickpost);
							TimeUnit.SECONDS.sleep(30);
							if (checkpost1) {
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(checkpost1, "Post button is not working after photo upload");
						}
						s_assert.assertTrue(gallery, "gallery link is not working");
					}
					s_assert.assertTrue(addphoto, "Add Photo link is not working");
				}
				s_assert.assertTrue(galleryphoto, "Photos link is not working for gallery photo.");

			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 13, description = "")
	public void VerifySearch() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySearch()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean searchEnterr=comm.TextField(sn.searchEnter,"Test");
				if (searchEnterr) {
					
					PageElement.tapDeviceOk(driver);

					Boolean post=comm.Openlinks(sn.postTAB);
					s_assert.assertTrue(post, "post TAB is not working");

					Boolean user=comm.Openlinks(sn.userTAB);
					if (user) {
						Boolean follow_Unfollow=comm.Openlinks(sn.follow_UnfollowBtn);
						s_assert.assertTrue(follow_Unfollow, "follow_Unfollow Button is not working");

						Boolean follow_Unfollow1=comm.Openlinks(sn.follow_UnfollowBtn);
						s_assert.assertTrue(follow_Unfollow1, "follow_Unfollow2 Button is not working");

						Boolean userlink=comm.Openlinks(sn.userclick);
						if (userlink) {
							TimeUnit.SECONDS.sleep(10);



							//Boolean following=comm.Openlinks(sn.followingTAB);
							//if (following) {
							comm.Getactualtext(sn.followingTAB);
							//}
							//s_assert.assertTrue(following, "following TAB is not working");

							//Boolean followers=comm.Openlinks(sn.followersTAB);
							//if (followers) {
							comm.Getactualtext(sn.followersTAB);

							Boolean UserTABb=comm.Openlinks(sn.UserTAB);
							s_assert.assertTrue(UserTABb, "UserTAB is not working");

							Boolean camera=comm.Openlinks(sn.cameraTAB);
							s_assert.assertTrue(camera, "camera TAB is not working");

							Boolean like=comm.Openlinks(sn.likeTAB);
							s_assert.assertTrue(like, "like TAB is not working");

							Boolean edit=comm.Openlinks(sn.editTAB);
							if (edit) {
								comm.Getactualtext(sn.postCount_gettext);
							}
							s_assert.assertTrue(edit, "edit TAB is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "Back Button is not working");

							//}
							//s_assert.assertTrue(followers, "followers TAB is not working");
						}
						s_assert.assertTrue(userlink, "user link is not working");
					}
					s_assert.assertTrue(user, "user TAB is not working");
				}
				s_assert.assertTrue(searchEnterr, "searchEnter is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 14, description = "")
	public void VerifyBlockUnblock() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyBlockUnblock()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean searchEnterr=comm.TextField(sn.searchEnter,"Noor");
				if (searchEnterr) {
					driver.context("NATIVE_APP");
					PageElement.tapDeviceOk(driver);
					PageElement.changeContextToWebView(driver);

					Boolean user=comm.Openlinks(sn.userTAB);
					if (user) {

						Boolean userlink=comm.Openlinks(sn.userclick);
						if (userlink) {
							comm.Getactualtext(sn.user_get_search);
							Boolean edit=comm.Openlinks(sn.editTAB);
							if (edit) {

								comm.Getactualtext(sn.user_get_search);
								comm.Getactualtext(sn.totalPost);
								TimeUnit.SECONDS.sleep(2);
								Boolean openblock=comm.Openlinks(sn.openblockmenu);
								if (openblock) {
									TimeUnit.SECONDS.sleep(5);
									Boolean BU=comm.Openlinks(sn.blockUser);
									s_assert.assertTrue(BU, "Block User is not working");
									TimeUnit.SECONDS.sleep(5);
								}
								s_assert.assertTrue(openblock, "openblock is not working");

								Boolean backbtn=comm.Openlinks(comm.BackButton1);
								if (backbtn) {
									TimeUnit.SECONDS.sleep(5);
									Boolean backbtn1=comm.Openlinks(comm.BackButton1);
									if (backbtn1) {
										TimeUnit.SECONDS.sleep(5);
										Boolean menu=comm.Openlinks(sn.clickmenu);
										if (menu) {
											TimeUnit.SECONDS.sleep(5);
											Boolean BU=comm.Openlinks(sn.clickblockuser);
											if (BU) {
												TimeUnit.SECONDS.sleep(3);
												Boolean unblockk=comm.Openlinks(sn.unblock);
												if (unblockk) {
													Boolean backbtn4=comm.Openlinks(comm.BackButton1);
													s_assert.assertTrue(backbtn4, "backbtn1 is not working after Unblock user");
												}
												s_assert.assertTrue(unblockk, "unblock is not working");
											}
											s_assert.assertTrue(BU, "Block User is not working on menu page");

										}
										s_assert.assertTrue(menu, "menu is not working");

									}
									s_assert.assertTrue(backbtn1, "backbtn1 is not working");

								}
								s_assert.assertTrue(backbtn, "backbtn is not working");


							}
							s_assert.assertTrue(edit, "Edit TAB is not working");
						}
						s_assert.assertTrue(userlink, "user link is not working");
					}
					s_assert.assertTrue(user, "user TAB is not working");
				}
				s_assert.assertTrue(searchEnterr, "searchEnter is not working");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 15, description = "")
	public void VerifySocialNetworkUploadphotoSaveShareCancel() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkUploadphotoSaveShareCancel()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean galleryphoto=comm.Openlinks(sn.clickphotos);
				if (galleryphoto) {
					Boolean addphoto=comm.Openlinks(sn.clickaddphotolink);
					if (addphoto) {
						Boolean gallery=comm.Openlinks(sn.clickgallerylink);
						if (gallery) {
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissions(driver);
								Boolean selectphoto=comm.Openlinks(sn.clickselectphoto);
								if (selectphoto) {
									Boolean ok=comm.Openlinks(sn.clickuploadOkbutton);
									TimeUnit.SECONDS.sleep(20);
									s_assert.assertTrue(ok, "Ok button of photo upload is not working");
								}
								s_assert.assertTrue(selectphoto, "Select photo is not select");

								PageElement.changeContextToWebView(driver);
								
							}
							else {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissionsCamera(driver);
								Boolean cameraroll=comm.Openlinks(sn.i_openCameraRoll);
								if (cameraroll) {
									Boolean selectpic=comm.Openlinks(sn.i_selectPhoto);
									if (selectpic) {
										Boolean donebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(donebtn, "Done button is not working");
									}
									s_assert.assertTrue(selectpic, "Selected Photo is not selected");
								}
								s_assert.assertTrue(cameraroll, "Camera Roll link is not working");
								PageElement.changeContextToWebView(driver);
							}

							Boolean enteryourmind1=comm.TextField(sn.clickwhatyourmindtext, "Appy Pie is the fastest growing cloud based Mobile Apps Builder Software (App Maker) that allows users with no programming skills, "
									+ "to create Android & iPhone applications for mobiles and smartphones; and publish to Google Play & iTunes");
							s_assert.assertTrue(enteryourmind1, "What's on your mind text is not present after photo upload");

							Boolean checkpost1=comm.Openlinks(sn.clickpost);
							TimeUnit.SECONDS.sleep(30);
							if (checkpost1) {
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(checkpost1, "Post button is not working after photo upload");

							Boolean openpost=comm.Openlinks(sn.newlyPostOpen);
							TimeUnit.SECONDS.sleep(10);
							if (openpost) {
								
								if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								Boolean photomenu=comm.Openlinks(sn.photomenuOpen);
								if (photomenu) {
									Boolean savee=comm.Openlinks(sn.save);
									s_assert.assertTrue(savee, "Save btn is not working");
								}
								s_assert.assertTrue(photomenu, "photomenu is not working");

								Boolean photomenu1=comm.Openlinks(sn.photomenuOpen);
								if (photomenu1) {
									Boolean sharee=comm.Openlinks(sn.share);
									if (sharee) {
										driver.navigate().back();
									}
									s_assert.assertTrue(sharee, "Share btn is not working");
								}
								s_assert.assertTrue(photomenu1, "photomenu1 is not working");

								Boolean photomenu2=comm.Openlinks(sn.photomenuOpen);
								if (photomenu2) {
									Boolean cancell=comm.Openlinks(sn.cancel);
									s_assert.assertTrue(cancell, "cancel btn is not working");
								}
								s_assert.assertTrue(photomenu2, "photomenu2 is not working");

								driver.navigate().back();

								PageElement.changeContextToWebView(driver);
							
								}
								else {
									driver.context("NATIVE_APP");
									Boolean photomenu=comm.Openlinks(sn.i_photomenuOpen);
									if (photomenu) {
										Boolean savee=comm.Openlinks(sn.i_save);
										s_assert.assertTrue(savee, "Save btn is not working");
									}
									s_assert.assertTrue(photomenu, "photomenu is not working");

									Boolean photomenu1=comm.Openlinks(sn.i_photomenuOpen);
									if (photomenu1) {
										Boolean sharee=comm.Openlinks(sn.i_share);
										if (sharee) {
											//driver.navigate().back();
											Boolean canclesharebtn=comm.Openlinks(sn.i_shareCancle);
											s_assert.assertTrue(canclesharebtn,"Share cancle Button is not working");
											
										}
										s_assert.assertTrue(sharee, "Share btn is not working");
									}
									s_assert.assertTrue(photomenu1, "photomenu1 is not working");

									Boolean photomenu2=comm.Openlinks(sn.i_photomenuOpen);
									if (photomenu2) {
										Boolean cancell=comm.Openlinks(sn.i_cancel);
										s_assert.assertTrue(cancell, "cancel btn is not working");
									}
									s_assert.assertTrue(photomenu2, "photomenu2 is not working");

									driver.navigate().back();
									
									PageElement.changeContextToWebView(driver);
									
								}
							}
							s_assert.assertTrue(openpost, "Newly post open is not working after photo upload");
						}
						s_assert.assertTrue(gallery, "gallery link is not working");
					}
					s_assert.assertTrue(addphoto, "Add Photo link is not working");
				}
				s_assert.assertTrue(galleryphoto, "Photos link is not working for gallery photo.");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 16, description = "")
	public void VerifySocialNetworkTagPost() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySocialNetworkTagPost()");
		boolean exception = false;
		try {
			Boolean socialNetwork=comm.Openlinks(sn.opensocialnetworkmodule);
			TimeUnit.SECONDS.sleep(10);
			if (socialNetwork) {
				Boolean login=comm.IselementPresent(sn.username);
				if (login) {
					TimeUnit.SECONDS.sleep(3);
					sn.Login();
				}
				else{
					System.out.println("User is Already Ready");
				}

				Boolean galleryphoto=comm.Openlinks(sn.clickphotos);
				if (galleryphoto) {
					Boolean addphoto=comm.Openlinks(sn.clickaddphotolink);
					if (addphoto) {
						Boolean gallery=comm.Openlinks(sn.clickgallerylink);
						if (gallery) {
							
							/*
							driver.context("NATIVE_APP");
							NavigationPage.verifyrunTimePermissions(driver);
							Boolean selectphoto=comm.Openlinks(sn.clickselectphoto);
							if (selectphoto) {
								Boolean ok=comm.Openlinks(sn.clickuploadOkbutton);
								TimeUnit.SECONDS.sleep(20);
								s_assert.assertTrue(ok, "Ok button of photo upload is not working");
							}
							s_assert.assertTrue(selectphoto, "Select photo is not select");*/
							
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissions(driver);
								Boolean selectphoto=comm.Openlinks(sn.clickselectphoto);
								if (selectphoto) {
									Boolean ok=comm.Openlinks(sn.clickuploadOkbutton);
									TimeUnit.SECONDS.sleep(20);
									s_assert.assertTrue(ok, "Ok button of photo upload is not working");
								}
								s_assert.assertTrue(selectphoto, "Select photo is not select");

								PageElement.changeContextToWebView(driver);
								
							}
							else {
								driver.context("NATIVE_APP");
								NavigationPage.verifyrunTimePermissionsCamera(driver);
								Boolean cameraroll=comm.Openlinks(sn.i_openCameraRoll);
								if (cameraroll) {
									Boolean selectpic=comm.Openlinks(sn.i_selectPhoto);
									if (selectpic) {
										Boolean donebtn=comm.Openlinks(sn.i_Done);
										s_assert.assertTrue(donebtn, "Done button is not working");
									}
									s_assert.assertTrue(selectpic, "Selected Photo is not selected");
								}
								s_assert.assertTrue(cameraroll, "Camera Roll link is not working");
								PageElement.changeContextToWebView(driver);
							}

							

							Boolean enteryourmind1=comm.TextField(sn.clickwhatyourmindtext, "#test");
							s_assert.assertTrue(enteryourmind1, "What's on your mind text is not present after photo upload");

							Boolean checkpost1=comm.Openlinks(sn.clickpost);
							TimeUnit.SECONDS.sleep(30);
							if (checkpost1) {
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(checkpost1, "Post button is not working after photo upload");
							
							Boolean menuiclick=comm.Openlinks(sn.clickmenu);
							if (menuiclick) {
								Boolean menutag=comm.Openlinks(sn.clicktag);
								if (menutag) {
									Boolean searchtagg=comm.TextField(sn.searchTag, "#test");
									if (searchtagg) {
										PageElement.tapDeviceOk(driver);
										
											comm.getListofLink(sn.taglist);
											Boolean tagopen=comm.Openlinks(sn.openTag);
											if (tagopen) {
												Boolean menutag1=comm.Openlinks(sn.tagMenu);
												if (menutag1) {
													Boolean tagdelete=comm.Openlinks(sn.deleteTag);
													s_assert.assertTrue(tagdelete, "tagdelete is not working");
												}
												s_assert.assertTrue(menutag1, "menutag is not working");
												Boolean backbtn=comm.Openlinks(comm.BackButton2);
												s_assert.assertTrue(backbtn, "Back Button is not working on tag page");
										}
										s_assert.assertTrue(tagopen, "tagopen is not working");
									}
									s_assert.assertTrue(searchtagg, "searchtagg is not working");
								}
								s_assert.assertTrue(menutag, "tag Menu is not working");
							}
							s_assert.assertTrue(menuiclick, "menu is not click");
						}
						s_assert.assertTrue(gallery, "gallery link is not working");
					}
					s_assert.assertTrue(addphoto, "Add Photo link is not working");
				}
				s_assert.assertTrue(galleryphoto, "Photos link is not working for gallery photo.");
			}
			s_assert.assertTrue(socialNetwork, "Social Network module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



}
