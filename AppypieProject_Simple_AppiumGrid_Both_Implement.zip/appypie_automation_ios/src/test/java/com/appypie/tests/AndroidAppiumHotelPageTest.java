package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.NavigationPage;
import com.appypie.pages.Hotels.BookHotelPage;
import com.appypie.pages.Hotels.BookingDetailsPage;
import com.appypie.pages.Hotels.BookingStatusPage;
import com.appypie.pages.Hotels.CommanClassHotel;
import com.appypie.pages.Hotels.DeshboardPage;
import com.appypie.pages.Hotels.FilterPage;
import com.appypie.pages.Hotels.HotelDetailPage;
import com.appypie.pages.Hotels.MenuPage;
import com.appypie.pages.Hotels.MyBookingsPage;
import com.appypie.pages.Hotels.OfferPage;
import com.appypie.pages.Hotels.PayatHotelConfirmPage;
import com.appypie.pages.Hotels.RatingAndReviewPage;
import com.appypie.pages.Hotels.RoomAvailabilityPage;
import com.appypie.pages.Hotels.ShortByPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AndroidAppiumHotelPageTest extends TestSetup {
	DeshboardPage deshboard;
	CommanClassHotel comman;
	HotelDetailPage hoteldetail;
	RoomAvailabilityPage roomavailability;
	BookingDetailsPage bookingdetails;
	BookHotelPage bookhotel;
	PayatHotelConfirmPage payathotelconfirm;
	BookingStatusPage bookingstatus;
	ShortByPage shortBy;
	FilterPage filterpage;
	MenuPage menu;
	MyBookingsPage mybookings;
	OfferPage offerpage;
	RatingAndReviewPage ratingreview;

	private static final Logger Logger = Log.createLogger();



	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		comman =new CommanClassHotel(driver);
		hoteldetail=new HotelDetailPage(driver);
		roomavailability=new RoomAvailabilityPage(driver);
		bookingdetails=new BookingDetailsPage(driver);
		bookhotel=new BookHotelPage(driver);
		payathotelconfirm=new PayatHotelConfirmPage(driver);
		bookingstatus=new BookingStatusPage(driver);
		deshboard=new DeshboardPage(driver);
		shortBy=new ShortByPage(driver);
		filterpage=new FilterPage(driver);
		menu=new MenuPage(driver);
		mybookings =new MyBookingsPage(driver);
		offerpage=new OfferPage(driver);
		ratingreview=new RatingAndReviewPage(driver);

	}

	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VerifyOpenHotelModule() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyOpenHotelModule()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			if (hotelmodule) {
				TimeUnit.SECONDS.sleep(3);
				Boolean UN=comman.IselementPresent(deshboard.username);
				if (UN) {
					Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
					s_assert.assertTrue(email, "Email field is not enter value");

					Boolean pass=comman.TextField(deshboard.password, "12345678");
					s_assert.assertTrue(pass, "Pass field is not enter value");

					Boolean login=comman.Openlinks(deshboard.LoginBtn);
					s_assert.assertTrue(login, "login field is not click ");

					try{
						driver.findElement(deshboard.Acceptandcontinue).click();
					}catch (Exception e) {
						Logger.info("Accept and continue is Not present");
					}

					/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
					s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
				}
				else{
					Logger.info("User is Already Login");
				}

				TimeUnit.SECONDS.sleep(3);
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");
			}
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifyDeshBoardPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDeshBoardPage()");
		boolean exception = false;
		try {
			Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule1, "Hotel Module is not open");

			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");

				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

		/*		Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(3);

			Boolean hotellist=comman.IselementPresent(deshboard.listofHotel_gettext);
			if (hotellist) {
				comman.getListofLink(deshboard.listofHotel_gettext);
			}
			s_assert.assertTrue(hotellist, "Hotel List is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifySortByPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySortByPage()");
		boolean exception = false;
		try {

			Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule1, "Hotel Module is not open");

			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(3);


			Boolean shorthotel=comman.Openlinks(deshboard.shortBylink);
			if (shorthotel) {
				comman.Getactualtext(comman.header_gettext);
				Boolean reset=comman.Openlinks(shortBy.resetlink);
				if (reset) {
					Boolean shorthotel1=comman.Openlinks(deshboard.shortBylink);
					s_assert.assertTrue(shorthotel1, "Short link is not open after click on reset link");
				}
				s_assert.assertTrue(reset, "Reset is not working");

				Boolean cancel=comman.Openlinks(shortBy.cancellink);
				if (cancel) {
					Boolean shorthotel1=comman.Openlinks(deshboard.shortBylink);
					s_assert.assertTrue(shorthotel1, "Short link is not open after click on cancel link");
				}
				s_assert.assertTrue(cancel, "Cancel link is not working");

				Boolean sortbylist=comman.getListofLink(shortBy.sortBy_list_gettext);
				if (sortbylist) {
					Boolean HL=comman.Openlinks(shortBy.price_hightTolowlink);
					if (HL) {
						Boolean shorthotel1=comman.Openlinks(deshboard.shortBylink);
						s_assert.assertTrue(shorthotel1, "Short link is not open after click on High to Low link");
					}
					s_assert.assertTrue(HL, "Hight to Low link is not working");

					Boolean LH=comman.Openlinks(shortBy.price_lowTohighlink);
					if (LH) {
						Boolean shorthotel1=comman.Openlinks(deshboard.shortBylink);
						s_assert.assertTrue(shorthotel1, "Short link is not open after click on Low To High link");
					}
					s_assert.assertTrue(LH, "Low To High link is not working");

					Boolean popularity=comman.Openlinks(shortBy.popularitylink);
					if (popularity) {
						Boolean shorthotel1=comman.Openlinks(deshboard.shortBylink);
						s_assert.assertTrue(shorthotel1, "Short link is not open after click on popularity link");
					}
					s_assert.assertTrue(popularity, "popularity link is not working");

					Boolean offer=comman.Openlinks(shortBy.offerlink);
					s_assert.assertTrue(offer, "offer link is not working");
				}
				s_assert.assertTrue(sortbylist, "SortBy list is not present");
			}
			s_assert.assertTrue(shorthotel, "Short link is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyFilter() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFilter()");
		boolean exception = false;
		try {
			Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
			if (hotelmodule1) {
			s_assert.assertTrue(hotelmodule1, "Hotel Module is not open");

			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(5);

			Boolean filter=comman.Openlinks(deshboard.filterlink);
			if (filter) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");

				Boolean reset=comman.Openlinks(filterpage.resetlink);
				if (reset) {
					Boolean shorthotel1=comman.Openlinks(deshboard.filterlink);
					s_assert.assertTrue(shorthotel1, "filter link is not open after click on reset link");
				}
				s_assert.assertTrue(reset, "Reset is not working");

				Boolean cancel=comman.Openlinks(filterpage.cancellink);
				if (cancel) {
					Boolean shorthotel1=comman.Openlinks(deshboard.filterlink);
					s_assert.assertTrue(shorthotel1, "filter link is not open after click on cancel link");
				}
				s_assert.assertTrue(cancel, "Cancel link is not working");

				String pricerange=comman.Getactualtext(filterpage.priceRangeHeading_gettext);
				s_assert.assertNotNull(pricerange, "Price range is getting null value");

				String priceMin=comman.Getactualtext(filterpage.priceMin_gettext);
				s_assert.assertNotNull(priceMin, "Price min is getting null value");

				String priceMax=comman.Getactualtext(filterpage.priceMax_gettext);
				s_assert.assertNotNull(priceMax, "Price max is getting null value");

				try{
					comman.slider(filterpage.sliderrangelink);
				}catch (Exception e) {
					Logger.info("Slider is not working");
				}

				String accomoTypeheading=comman.Getactualtext(filterpage.accommodationTypeHeading_gettext);
				if (accomoTypeheading.contentEquals("Accommodation Type")) {
					Boolean accomotypelist=comman.getListofLink(filterpage.accommodationType_list_gettext);
					if (accomotypelist) {

						Boolean bungalow=comman.Openlinks(filterpage.bungalow_checkbox);
						s_assert.assertTrue(bungalow, "bungalow check box is not selected");

						Boolean guesthouse=comman.Openlinks(filterpage.guesthouse_checkbox);
						s_assert.assertTrue(guesthouse, "guesthouse check box is not selected");

						Boolean hotel=comman.Openlinks(filterpage.hotel_checkbox);
						s_assert.assertTrue(hotel, "hotel check box is not selected");

						Boolean villa=comman.Openlinks(filterpage.villa_checjbox);
						s_assert.assertTrue(villa, "villa check box is not selected");

					}
					s_assert.assertTrue(accomotypelist, "accommodation List is not present");
				}
				else{
					Logger.info("accommodation Type heading is not match ");
				}
				s_assert.assertNotNull(accomoTypeheading, "accommodation Type Heading getting Null value");


				Boolean ratinglist=comman.getListofLink(filterpage.rating_list_gettext);
				if (ratinglist) {
					Boolean firststar=comman.Openlinks(filterpage.rating_1_Starlink);
					s_assert.assertTrue(firststar, "1 star is not select");

					Boolean secondtstar=comman.Openlinks(filterpage.rating_2_Starlink);
					s_assert.assertTrue(secondtstar, "2 star is not select");

					Boolean thirdtstar=comman.Openlinks(filterpage.rating_3_Starlink);
					s_assert.assertTrue(thirdtstar, "3 star is not select");

					Boolean fourthtstar=comman.Openlinks(filterpage.rating_4_Starlink);
					s_assert.assertTrue(fourthtstar, "4 star is not select");

					Boolean fivethstar=comman.Openlinks(filterpage.rating_5_Starlink);
					s_assert.assertTrue(fivethstar, "5 star is not select");
				}
				s_assert.assertTrue(ratinglist, "Rating listbis not present");

				Boolean search=comman.Openlinks(filterpage.searchBtn);
				s_assert.assertTrue(search, "Search button is not working");
			}
			s_assert.assertTrue(filter, "Filter link is not working");
			}
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifySearch() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySearch()");
		boolean exception = false;
		try {
			Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
			if (hotelmodule1) {
		
			s_assert.assertTrue(hotelmodule1, "Hotel Module is not open");

			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(3);


			Boolean search=comman.Openlinks(deshboard.searchlink);
			if (search) {
				Boolean anywhere=comman.Openlinks(deshboard.anywherelink);
				if (anywhere) {
					Boolean searchnoida=comman.TextField(deshboard.searchNoida_text, "noida");
					if (searchnoida) {
						Boolean noida=comman.Openlinks(deshboard.noidaSelectlink);
						s_assert.assertTrue(noida, "Noida link is not selected");

						Boolean date=comman.Openlinks(deshboard.selectDatelink);
						if (date) {
							String month=comman.Getactualtext(deshboard.currentMonth_gettext);
							s_assert.assertNotNull(month, "date is getting null value");

							Boolean done=comman.Openlinks(deshboard.DoneClenderBtn);
							if (done) {
								String message=comman.Getactualtext(deshboard.messageRange_gettext);
								s_assert.assertNotNull(message, "Message is getting null value");

								Boolean gust=comman.Openlinks(deshboard.guestlink);
								s_assert.assertTrue(gust, "guest link is not working");

								Boolean backbtn=comman.Openlinks(roomavailability.backpageBtn);
								s_assert.assertTrue(backbtn, "back button is not wroking");
								Boolean filter=comman.Openlinks(deshboard.filterlink);
								if (filter) {
									Boolean resetbtn=comman.Openlinks(filterpage.resetlink);
									s_assert.assertTrue(resetbtn, "reset button is not working");
								}
								s_assert.assertTrue(filter, "Filter link is not working");
							}
							s_assert.assertTrue(done, "Done button is not click");
						}
						s_assert.assertTrue(date, "date link is not open");
					}
					s_assert.assertTrue(searchnoida, "search noida text field is not present");
				}
				s_assert.assertTrue(anywhere, "Any where link is nor working");
			}
			s_assert.assertTrue(search, "Search link is not working");
			}
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 5, description = "")
	public void VerifyMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu()");
		boolean exception = false;
		try {
			Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule1, "Hotel Module is not open");
			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}
			TimeUnit.SECONDS.sleep(7);

			Boolean menulink=comman.Openlinks(deshboard.menulink);
			if (menulink) {
				Boolean menulist=comman.getListofLink(menu.menuList_gettext);
				s_assert.assertTrue(menulist, "Menu list is not getting");

				/*Boolean home=comman.Openlinks(menu.homelink);
				if (home) {
					Boolean hotelmodule2=comman.Openlinks(deshboard.hotelmodulelink);
					s_assert.assertTrue(hotelmodule2, "Hotel Module is not open home menu");
					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for home menu");
				}
				s_assert.assertTrue(home, "Home link is not working");
				 */
				Boolean mainmenu=comman.Openlinks(menu.mainMenulink);
				if (mainmenu) {
					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for main menu");
				}
				s_assert.assertTrue(mainmenu, "mainmenu link is not working");

				Boolean myBoooking=comman.Openlinks(menu.myBoookinglink);
				if (myBoooking) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "My Bookings");

					Boolean upcomingtab=comman.Openlinks(mybookings.upComingTABlink);
					if (upcomingtab) {
						
						Boolean upcommingtabBlank=comman.IselementPresent(mybookings.cancelBtnUpcomingTABHotellink);
						if (upcommingtabBlank) {
							Boolean upcomingbooking=comman.getListofLink(mybookings.upComing_list_gettext);
							s_assert.assertTrue(upcomingbooking, "Upcoming hotel list is not getting");

							Boolean canbtn=comman.Openlinks(mybookings.cancelBtnUpcomingTABHotellink);
							if (canbtn) {
								comman.Getactualtext(comman.AlertHeader_gettext);
								comman.Getactualtext(comman.AlertText_gettext);
								comman.Openlinks(comman.AlertYes);
								TimeUnit.SECONDS.sleep(10);
								comman.IfAlertpresent();
							}
							TimeUnit.SECONDS.sleep(3);
							s_assert.assertTrue(canbtn, "Cancel Button is not working on Upcomming TAB");
						}
						else {
							System.out.println("up Coming Tab is Blank");
						}

					}
					s_assert.assertTrue(upcomingtab, "Upcoming TAB link is not working");

					Boolean completed=comman.Openlinks(mybookings.completedTablink);
					if (completed) {
						Boolean completedlist=comman.getListofLink(mybookings.completed_list_gettext);
						s_assert.assertTrue(completedlist, "completed TAB list is not getting");

						Boolean leavereview=comman.Openlinks(mybookings.leaveReviewlink);
						if (leavereview) {

							Boolean firststar=comman.Openlinks(ratingreview.rating_1_Starlink);
							s_assert.assertTrue(firststar, "1 star is not select");

							Boolean secondtstar=comman.Openlinks(ratingreview.rating_2_Starlink);
							s_assert.assertTrue(secondtstar, "2 star is not select");

							Boolean thirdtstar=comman.Openlinks(ratingreview.rating_3_Starlink);
							s_assert.assertTrue(thirdtstar, "3 star is not select");

							Boolean fourthtstar=comman.Openlinks(ratingreview.rating_4_Starlink);
							s_assert.assertTrue(fourthtstar, "4 star is not select");

							Boolean fivethstar=comman.Openlinks(ratingreview.rating_5_Starlink);
							s_assert.assertTrue(fivethstar, "5 star is not select");

							Boolean reviewtext=comman.TextField(ratingreview.reviewText, "Good to go live");
							s_assert.assertTrue(reviewtext, "Review Message text filed is not present");

							Boolean submit=comman.Openlinks(ratingreview.submitBtn);
							s_assert.assertTrue(submit, "Submit button is not working");
							comman.IfAlertpresent();

							Boolean reebook=comman.Openlinks(mybookings.rebooklink);
							if (reebook) {
								TimeUnit.SECONDS.sleep(10);
									Boolean iback=comman.Openlinks(comman.BackButton1);
									s_assert.assertTrue(iback,"i_Back button is not working on Rebooking page");
							}
							s_assert.assertTrue(reebook, "Reebook link is not working");
						}
						s_assert.assertTrue(leavereview, "Leave Review link is not working");

					}
					s_assert.assertTrue(completed, "Completed TAB link is not working");

					Boolean cancelledTab=comman.Openlinks(mybookings.cancelledTablink);
					if (cancelledTab) {
						Boolean completedlist=comman.getListofLink(mybookings.cancelled_gettext);
						s_assert.assertTrue(completedlist, "completed TAB list is not getting");

						Boolean reebooklinkcan=comman.Openlinks(mybookings.reebooklinkCanTAB);
						if (reebooklinkcan) {
							TimeUnit.SECONDS.sleep(10);
							Boolean iback=comman.Openlinks(comman.BackButton1);
							s_assert.assertTrue(iback,"Back button is not working on Rebooking page");
						}
						s_assert.assertTrue(reebooklinkcan, "Reebook link is not working on cancelled TAB");
					}
					s_assert.assertTrue(cancelledTab, "cancelled TAB link is not working");

					Boolean backbtnn=comman.Openlinks(mybookings.backBtn);
					s_assert.assertTrue(backbtnn, "back Button is not working on my bookings page");

					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for main menu");
				}
				s_assert.assertTrue(myBoooking, "myBoooking link is not working");

				Boolean myfav=comman.Openlinks(menu.myFavoriteslink);
				if (myfav) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "My Favorites");
					Boolean backbtnn=comman.Openlinks(mybookings.backBtn);
					s_assert.assertTrue(backbtnn, "back Button is not working on my Favorites page");

					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for main menu");
				}
				s_assert.assertTrue(myfav, "My favorities link is not working on menu page");

				Boolean offer=comman.Openlinks(menu.offerslink);
				if (offer) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Offers");
					Boolean hotellist=comman.getListofLink(offerpage.Hotellist_gettext);
					s_assert.assertTrue(hotellist, "Hotel list is not getting on offer page");

					Boolean backbtnn=comman.Openlinks(offerpage.backBtn);
					s_assert.assertTrue(backbtnn, "back Button is not working on Offer page");

					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for main menu");
				}
				s_assert.assertTrue(offer, "Offer link is not working on menu page");


				Boolean tc=comman.Openlinks(menu.termsConditionslink);
				if (tc) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Terms & Conditions");
					String tcmessage=comman.Getactualtext(deshboard.TC_gettext);
					s_assert.assertNotNull(tcmessage, "Terms Conditions desc getting null Value ");

					Boolean backbtnn=comman.Openlinks(deshboard.backBtn_TCpage);
					s_assert.assertTrue(backbtnn, "back Button is not working on T&C page");

					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for main menu");
				}
				s_assert.assertTrue(tc,"Terms Conditions link is not working");

				Boolean pp=comman.Openlinks(menu.privacypolicylink);
				if (pp) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Privacy Policy");
					String ppmessage=comman.Getactualtext(deshboard.PP_gettext);
					s_assert.assertNotNull(ppmessage, "Privacy Policy desc getting null Value ");

					Boolean backbtnn=comman.Openlinks(deshboard.backBtn_PPpage);
					s_assert.assertTrue(backbtnn, "back Button is not working on PP page");

					Boolean menulink1=comman.Openlinks(deshboard.menulink);
					s_assert.assertTrue(menulink1, "Menu link is not working for main menu");
				}
				s_assert.assertTrue(pp,"Terms Conditions link is not working");
			}
			s_assert.assertTrue(menulink, "Menu link is not working");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VerifyHotelDetailsPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyHotelDetailsPage()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");
			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(3);
			Boolean hiltonhotelopen=comman.Openlinks(deshboard.hiltonHotellink);
			if (hiltonhotelopen) {

				Boolean like=comman.Openlinks(hoteldetail.likelink);
				if (like) {
					comman.IfAlertpresent();
				}
				s_assert.assertTrue(like, "Like heart link is not working");

				Boolean unlike=comman.Openlinks(hoteldetail.likelink);
				if (unlike) {
					comman.IfAlertpresent();
				}
				s_assert.assertTrue(unlike, "Unlike heart link is not working");

				Boolean share=comman.Openlinks(hoteldetail.sharelink);
				if (share) {
					driver.context("NATIVE_APP");

					if (!globledeviceName.equals("iPhone")) {
						Boolean sharelist=comman.getListofLink(hoteldetail.getsharebyItem_native);
						s_assert.assertTrue(sharelist, "Share list is not present");
						driver.navigate().back();
					}
					else {
						Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
						s_assert.assertTrue(icancle,"icancle button is not working on Rebooking page");
					}
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(share, "Share link is not working");


				String hotelnameget=comman.Getactualtext(hoteldetail.hotelName_gettext);
				s_assert.assertNotNull(hotelnameget, "Hotel Name is getting null value");

				Boolean listpresent=comman.getListofLink(hoteldetail.listFacility_gettext);
				if (listpresent) {
					Boolean arrow=comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
					if (arrow) {
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						comman.getListofLink(hoteldetail.listFacility_gettext);
						comman.Openlinks(hoteldetail.listFacilityLeftarrow_link);
						comman.Openlinks(hoteldetail.listFacilityLeftarrow_link);
						comman.Openlinks(hoteldetail.listFacilityLeftarrow_link);
					}
					s_assert.assertTrue(arrow, "Arrow is not present");
				}
				s_assert.assertTrue(listpresent, "Facility List is not present");

				Boolean offer=comman.IselementPresent(hoteldetail.offerHeading_gettext);
				if (offer) {
					comman.Getactualtext(hoteldetail.offerHeading_gettext);
				}
				s_assert.assertTrue(offer, "Offer Heading is not present");

				Boolean hoteldescription=comman.IselementPresent(hoteldetail.hotelDescription_gettext);
				if (hoteldescription) {
					comman.Getactualtext(hoteldetail.hotelDescription_gettext);
				}
				s_assert.assertTrue(hoteldescription, "Hotel description is not present");

				Boolean honername=comman.IselementPresent(hoteldetail.honerName_gettext);
				if (honername) {
					//comman.IselementPresent(hoteldetail.honerName_gettext);

					Boolean ownerlink=comman.Openlinks(hoteldetail.ownerlink);
					if (ownerlink) {
						String ownerdesc=comman.Getactualtext(hoteldetail.ownerDescription_gettext);
						s_assert.assertNotNull(ownerdesc, "Owner Desc is getting Null value");

						Boolean closeownerDec=comman.Openlinks(hoteldetail.ownerCloselink);
						s_assert.assertTrue(closeownerDec, "Close button is not working on owner frame");

						Boolean img=comman.Openlinks(hoteldetail.ownerImglink);
						if (img) {
							String ownerdesc1=comman.Getactualtext(hoteldetail.ownerDescription_gettext);
							s_assert.assertNotNull(ownerdesc1, "Owner Desc is getting Null value after click on owner img link");

							Boolean closeownerDec1=comman.Openlinks(hoteldetail.ownerCloselink);
							s_assert.assertTrue(closeownerDec1, "Close button is not working after click on owner img link");
						}
						s_assert.assertTrue(img, "Owner Img link is not working");
					}
					s_assert.assertTrue(ownerlink, "Owner Link is not working");
				}
				s_assert.assertTrue(honername, "Honour name is not present");

				Boolean checkin=comman.IselementPresent(hoteldetail.checkInTime_gettext);
				if (checkin) {
					comman.Getactualtext(hoteldetail.checkInTime_gettext);
				}
				s_assert.assertTrue(checkin, "CheckIn time is not present");

				Boolean checkout=comman.IselementPresent(hoteldetail.checkOutTime_gettext);
				if (checkout) {
					comman.Getactualtext(hoteldetail.checkOutTime_gettext);
				}
				s_assert.assertTrue(checkout, "Check Out Time is not present");

				Boolean roomtypelist=comman.IselementPresent(hoteldetail.listoomType_gettext);
				if (roomtypelist) {
					Boolean roomtypelist1=comman.getListofLink(hoteldetail.listoomType_gettext);
					s_assert.assertTrue(roomtypelist1, "Room type list not getting");
				}
				s_assert.assertTrue(roomtypelist, "Room Type list is not present");

				Boolean viewall=comman.Openlinks(hoteldetail.viewAll_deluxRoom_link);
				if (viewall) {
					String amenties=comman.Getactualtext(hoteldetail.amenities_viewAll_Heading_gettext);
					if (amenties.contentEquals("Amenities")) {
						String amenitieslist=comman.Getactualtext(hoteldetail.amenities_viewAll_list_gettext);
						s_assert.assertNotNull(amenitieslist, "Amenities getting Null list");

						Boolean okbtn=comman.Openlinks(hoteldetail.Ok_btn_viewAll_popup);
						s_assert.assertTrue(okbtn, "Ok button is not present for view All popup");
					}
				}
				s_assert.assertTrue(viewall, "View all link is not working");



				String accomodationDetailsHeading=comman.Getactualtext(hoteldetail.accomodationDetails_heading_gettext);
				if (accomodationDetailsHeading.trim().equalsIgnoreCase("Details")){
					Boolean accomodationDetailslink=comman.Openlinks(hoteldetail.accomodationDetailslink);
					if (accomodationDetailslink) {
						String accomodationDesc=comman.Getactualtext(hoteldetail.accomodationDetailsDescription_gettext);
						s_assert.assertNotNull(accomodationDesc, "Accomodation Desc is getting Null value");
						Boolean closeaccomodationDetails=comman.Openlinks(hoteldetail.closedBtn_accomodationDetails);
						s_assert.assertTrue(closeaccomodationDetails, "Close Button is not working accomodation Details page");;
					}
					s_assert.assertTrue(accomodationDetailslink, "Accomodation Details link is not working");
				}
				s_assert.assertNotNull(accomodationDetailsHeading, "Details Heading is getting Null value");

				Boolean mapopen=comman.Openlinks(hoteldetail.mapOpenlink);
				if (mapopen) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");

					Boolean closemap=comman.Openlinks(hoteldetail.close_Maplink);
					s_assert.assertTrue(closemap, "Close Map Button is not working");
				}
				s_assert.assertTrue(mapopen, "map link is not working");

				Boolean backbtn=comman.Openlinks(hoteldetail.backpageBtn);
				if (backbtn) {
					Boolean hiltonhotelopen1=comman.Openlinks(deshboard.hiltonHotellink);
					s_assert.assertTrue(hiltonhotelopen1, "hilton hotel is not open after back button");
				}
				s_assert.assertTrue(backbtn,"Back Button is not present");


			}
			s_assert.assertTrue(hiltonhotelopen, "hilton hotel is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 7, description = "")
	public void VerifyroomavailabilityPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyroomavailabilityPage()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");

			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(3);


			Boolean hiltonhotelopen=comman.Openlinks(deshboard.hiltonHotellink);
			s_assert.assertTrue(hiltonhotelopen, "hilton hotel is not open");

			Boolean deluxroom=comman.Openlinks(hoteldetail.deluxRoom_link);
			if (deluxroom) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Rooms Availability");

				Boolean checkin=comman.IselementPresent(roomavailability.checkInTime_click_gettext);
				if (checkin) {
					String checkintimeget=comman.Getactualtext(roomavailability.checkInTime_click_gettext);
					s_assert.assertNotNull(checkintimeget, "CheckIn time is getting Null value");
				}
				s_assert.assertTrue(checkin, "CheckIn time is not present");

				Boolean checkout=comman.IselementPresent(roomavailability.checkOutTime_click_gettext);
				if (checkout) {
					String checkoutTimeget=comman.Getactualtext(roomavailability.checkOutTime_click_gettext);
					s_assert.assertNotNull(checkoutTimeget, "CheckOut Time is getting Null value");
				}
				s_assert.assertTrue(checkout, "Check Out time is not present");

				Boolean adultscount=comman.IselementPresent(roomavailability.adultsCount_gettext);
				if (adultscount) {
					String adultcountget1=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
					s_assert.assertNotNull(adultcountget1, "Adult count is getting null value");

					Boolean incrementadults1=comman.Openlinks(roomavailability.adultsIncrement_btn);
					if (incrementadults1) {
						String adultcount2=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
						s_assert.assertNotNull(adultcount2, "Adult count after first time increment is getting null value");
						comman.IfAlertpresent();
						comman.Openlinks(roomavailability.adultsIncrement_btn);
						comman.IfAlertpresent();
						comman.Openlinks(roomavailability.adultsIncrement_btn);
						comman.IfAlertpresent();

					}
					s_assert.assertTrue(incrementadults1, "Adult Increment button is not working");

					Boolean decrementadults1=comman.Openlinks(roomavailability.adultsDecrement_btn);
					if (decrementadults1) {
						String adultcount4=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
						s_assert.assertNotNull(adultcount4, "Adult cont after first time decrement is getting Null value.");
					}
					s_assert.assertTrue(decrementadults1, "Adult Drecement button is not working");

				}
				s_assert.assertTrue(adultscount, "Adults count is not present");


				Boolean childrencount=comman.IselementPresent(roomavailability.childrenCount_gettext);
				if (childrencount) {
					String childcount=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
					s_assert.assertNotNull(childcount, "Children count is getting Null value");

					Boolean incrementchildren1=comman.Openlinks(roomavailability.childrenIncrement_btn);
					if (incrementchildren1) {
						String childcount2=	comman.GetAttributevalue(roomavailability.childrenCount_gettext);
						s_assert.assertNotNull(childcount2, "Children count first time increment is getting Null value");
						comman.IfAlertpresent();
						comman.Openlinks(roomavailability.childrenIncrement_btn);
						comman.IfAlertpresent();
						comman.Openlinks(roomavailability.childrenIncrement_btn);
						comman.IfAlertpresent();

					}
					s_assert.assertTrue(incrementchildren1, "children Increment button is not working");

					Boolean decrementchildren1=comman.Openlinks(roomavailability.childrenDrecement_btn);
					if (decrementchildren1) {
						String childcount4=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
						s_assert.assertNotNull(childcount4, "Children count first time dremenent is getting Null value");
					}
					s_assert.assertTrue(decrementchildren1, "children Drecement button is not working");

				}
				s_assert.assertTrue(childrencount, "Children count is not present");		

				Boolean addroompresent=comman.IselementPresent(roomavailability.addRoom_link);
				if (addroompresent) {
					Boolean addroom=comman.Openlinks(roomavailability.addRoom_link);
					if (addroom) {
						Boolean delete=comman.Openlinks(roomavailability.deleteaddRoom_link);
						s_assert.assertTrue(delete, "Delete Room link is not working");
					}
					s_assert.assertTrue(addroom, "Add room link is not working");
				}
				s_assert.assertTrue(addroompresent, "Add Room link is not present ");

				Boolean checkavailability=comman.IselementPresent(roomavailability.checkAvaliability_btn);
				s_assert.assertTrue(checkavailability, "CheckOut Button is not present");
			}
			s_assert.assertTrue(deluxroom, "Delux Room select button is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 8, description = "")
	public void VerifyBookingDetailsPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyBookingDetailsPage()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");

			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is Already Login");
			}

			TimeUnit.SECONDS.sleep(3);


			Boolean hiltonhotelopen=comman.Openlinks(deshboard.hiltonHotellink);
			s_assert.assertTrue(hiltonhotelopen, "hilton hotel is not open");
			Boolean deluxroom=comman.Openlinks(hoteldetail.deluxRoom_link);
			s_assert.assertTrue(deluxroom, "Delux Room select button is not open");
			Boolean checkavailability=comman.IselementPresent(roomavailability.checkAvaliability_btn);
			if (checkavailability) {
				Boolean clickchoutbtn=comman.Openlinks(roomavailability.checkAvaliability_btn);
				if (clickchoutbtn) {
					comman.Getactualtext(comman.header_gettext);

					String hotelname=comman.Getactualtext(bookingdetails.hotelName_gettext);
					s_assert.assertNotNull(hotelname, "Hotel Name is getting Null value");

					String ownername=comman.Getactualtext(bookingdetails.ownerName_gettext);
					s_assert.assertNotNull(ownername, "ownername is getting Null value");

					String checkinTime=comman.Getactualtext(bookingdetails.checkInTime_gettext);
					s_assert.assertNotNull(checkinTime, "checkinTime is getting Null value");

					String checkoutTime=comman.Getactualtext(bookingdetails.checkOutTime_gettext);
					s_assert.assertNotNull(checkoutTime, "checkoutTime is getting Null value");

					String roomtype=comman.Getactualtext(bookingdetails.roomType_gettext);
					s_assert.assertNotNull(roomtype, "roomtype is getting Null value");

					String stayNight=comman.Getactualtext(bookingdetails.stayNightCount_gettext);
					s_assert.assertNotNull(stayNight, "stayNight is getting Null value");

					String roomcount=comman.Getactualtext(bookingdetails.roomCount_gettext);
					s_assert.assertNotNull(roomcount, "roomcount is getting Null value");

					String guestcount=comman.Getactualtext(bookingdetails.guestCount_gettext);
					s_assert.assertNotNull(guestcount, "guestcount is getting Null value");

					String applycouponcode=comman.Getactualtext(bookingdetails.applyCoupon_gettext);
					if (applycouponcode.equalsIgnoreCase("Apply coupon")) {
						Boolean coupontext=comman.TextField(bookingdetails.enterCouponcodeText, "B123");
						s_assert.assertTrue(coupontext, "Coupon Code is not entring");

						Boolean couponapply=comman.Openlinks(bookingdetails.CouponcodeApplylink);
						if (couponapply) {
							comman.IfAlertpresent();
						}
						s_assert.assertTrue(couponapply, "Coupon Apply Btn is not click");
					}
					s_assert.assertNotNull(applycouponcode, "applycouponcode is getting Null value");

					Boolean booknowbtn=comman.IselementPresent(bookingdetails.bookNow_btn);
					s_assert.assertTrue(booknowbtn, "Book Now button is not present");

					Logger.info("----------Print all info on Booking Details--------------");
					Boolean bookingstatusallDetails=comman.getListofLink(bookingdetails.listBookingDetails_gettext);
					s_assert.assertTrue(bookingstatusallDetails, "All Booking status is not present");
				}
				s_assert.assertTrue(clickchoutbtn, "CheckOut button is not click");
			}
			s_assert.assertTrue(checkavailability, "CheckOut Button is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 9, description = "")
	public void VerifyBookHotelpage_BookStatuspage()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyBookHotelpage_BookStatuspage()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");
			TimeUnit.SECONDS.sleep(3);
			Boolean UN=comman.IselementPresent(deshboard.username);
			if (UN) {
				Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
				s_assert.assertTrue(email, "Email field is not enter value");

				Boolean pass=comman.TextField(deshboard.password, "12345678");
				s_assert.assertTrue(pass, "Pass field is not enter value");

				Boolean login=comman.Openlinks(deshboard.LoginBtn);
				s_assert.assertTrue(login, "login field is not click ");

				TimeUnit.SECONDS.sleep(3);
				try{
					driver.findElement(deshboard.Acceptandcontinue).click();
				}catch (Exception e) {
					Logger.info("Accept and continue is Not present");
				}

				/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
				s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
			}
			else{
				Logger.info("User is already login");
			}
			TimeUnit.SECONDS.sleep(3);
			Boolean hiltonhotelopen=comman.Openlinks(deshboard.hiltonHotellink);
			if (hiltonhotelopen) {
				driver.context("NATIVE_APP");
				comman.SwipeBottomToTop();
				PageElement.changeContextToWebView(driver);
				driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				Boolean deluxroom=comman.Openlinks(hoteldetail.deluxRoom_link);
				Boolean deluxroom1=comman.IselementPresent(hoteldetail.deluxRoom_link);
				if (deluxroom1) {
					comman.Openlinks(hoteldetail.deluxRoom_link);
				}
				
				if (deluxroom) {
					Boolean clickchoutbtn=comman.Openlinks(roomavailability.checkAvaliability_btn);
		/*			if (globledeviceName.equals("iPhone")) {
						Boolean icloseCalander=PageElement.Accessibilitylinks(roomavailability.i_closeCalander);
						s_assert.assertTrue(icloseCalander, "icloseCalander button is not wokring on ios");
					}*/
					s_assert.assertTrue(clickchoutbtn, "CheckOut button is not click");
					driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
					Boolean booknowbtn=comman.IselementPresent(bookingdetails.bookNow_btn);
					if (booknowbtn) {
						Boolean clickbooknowbtn =comman.Openlinks(bookingdetails.bookNow_btn);
						if (clickbooknowbtn) {
							s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");
							String gustname=comman.Getactualtext(bookhotel.guestName_gettext);
							s_assert.assertNotNull(gustname, "Guest name is getting Null value");

							Boolean username=comman.IselementPresent(bookhotel.guestName_gettext);
							if (username) {
								Boolean title=comman.IselementPresent(bookhotel.selectTitle);
								if (title) {
									
									Boolean clicktitledroplist=comman.Openlinks(bookhotel.selectTitle);
									
									if (clicktitledroplist) {
										driver.context("NATIVE_APP");
										if (!globledeviceName.equals("iPhone")) {
											String gettitlenative=comman.Getactualtext(bookhotel.selectTitleHeader_Native_gettext);
											s_assert.assertNotNull(gettitlenative, "Title heading is getting null value");

											Boolean mrselect=comman.Openlinks(bookhotel.selectMr_Native_radio_btn);
											s_assert.assertTrue(mrselect, "Mr. Radio button not selected");
										}
										
										else {
											PageElement.changeContextToWebView(driver);	
											comman.Openlinks(bookhotel.selectTitle1);
										}
										PageElement.changeContextToWebView(driver);	
									}
									s_assert.assertTrue(clicktitledroplist, "Title droplist is not click");
								}

								Boolean firstnameclear=comman.ClearTextField(bookhotel.firstName_text);
								if (firstnameclear) {
									Boolean paynowFN=comman.Openlinks(bookhotel.payNow_btn);
									if (paynowFN) {
										comman.IfAlertpresent();
										Boolean firstname=comman.TextField(bookhotel.firstName_text, "Anurag");
										s_assert.assertTrue(firstname, "First Name Text filed not enter value");
									}
									s_assert.assertTrue(paynowFN, "Pay now button is not click");
								}
								s_assert.assertTrue(firstnameclear, "First name is not clear");

								Boolean lastnameclear=comman.ClearTextField(bookhotel.lastName_text);
								if (lastnameclear) {
									Boolean paynowLN=comman.Openlinks(bookhotel.payNow_btn);
									if (paynowLN) {
										comman.IfAlertpresent();
										Boolean lastname=comman.TextField(bookhotel.lastName_text, "Singh");
										s_assert.assertTrue(lastname, "last Name text filed value not enter");
									}
									s_assert.assertTrue(paynowLN, "Pay now button is not click");
								}
								s_assert.assertTrue(lastnameclear, "First name is not clear");

								Boolean emailclear=comman.ClearTextField(bookhotel.email_text);
								if (emailclear) {
									Boolean paynowEmail=comman.Openlinks(bookhotel.payNow_btn);
									if (paynowEmail) {
										comman.IfAlertpresent();
										Boolean Email=comman.TextField(bookhotel.email_text, "appypie2016@gmail.com");
										s_assert.assertTrue(Email, "Email text filed not enter value");
									}
									s_assert.assertTrue(paynowEmail, "Pay now button is not click");
								}
								s_assert.assertTrue(emailclear, "First name is not clear");

								Boolean phoneclear=comman.ClearTextField(bookhotel.phone_text);
								if (phoneclear) {
									Boolean paynowphone=comman.Openlinks(bookhotel.payNow_btn);
									if (paynowphone) {
										comman.IfAlertpresent();
										Boolean phone =comman.TextField(bookhotel.phone_text, "9540198626");
										s_assert.assertTrue(phone, "Phone text field not enter value");
									}
									s_assert.assertTrue(paynowphone, "Pay now button is not click");
								}
								s_assert.assertTrue(phoneclear, "First name is not clear");
							}
							s_assert.assertTrue(username, "User is not present");

							String message=comman.Getactualtext(bookhotel.Message_gettext);
							s_assert.assertNotNull(message, "Booking Details Message is Getting Null value");

							Boolean paynowbtn=comman.Openlinks(bookhotel.payNow_btn);
							if (paynowbtn) {

								s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"HOTEL");

								Boolean CCviaPayPal=comman.Openlinks(payathotelconfirm.CreditCardviaPayPal);
								if (CCviaPayPal) {
									String CreditCardviaPayPallheading=comman.Getactualtext(payathotelconfirm.CreditCardviaPayPal_gettext);
									s_assert.assertNotNull(CreditCardviaPayPallheading, "CreditCardviaPayPallheading message is getting Null Value");
								}
								s_assert.assertTrue(CCviaPayPal, "CreditCardviaPayPal payment gatway not open");

								Boolean PPExpress=comman.Openlinks(payathotelconfirm.PayPalExpress);
								if (PPExpress) {
									String PayPalExpressheading=comman.Getactualtext(payathotelconfirm.PayPalExpress_gettext);
									s_assert.assertNotNull(PayPalExpressheading, "PayPalExpress message is getting Null Value");
								}
								s_assert.assertTrue(PPExpress, "PayPalExpress payment gatway not open");

								Boolean PaywithCC=comman.Openlinks(payathotelconfirm.Paywithcreditcard);
								if (PaywithCC) {
									String Paywithcreditcardheading=comman.Getactualtext(payathotelconfirm.Paywithcreditcard_gettext);
									s_assert.assertNotNull(Paywithcreditcardheading, "Paywithcreditcard message is getting Null Value");
								}
								s_assert.assertTrue(PaywithCC, "Paywithcreditcard payment gatway not open");

								Boolean stripe=comman.Openlinks(payathotelconfirm.Stripe);
								if (stripe) {
									String stripeheading=comman.Getactualtext(payathotelconfirm.Stripe_gettext);
									s_assert.assertNotNull(stripeheading, "stripemessage is getting Null Value");
								}
								s_assert.assertTrue(stripe, "stripe payment gatway not open");


								Boolean payathotel=comman.Openlinks(payathotelconfirm.PayAtHotel);
								if (payathotel) {
									String payathotelheading=comman.Getactualtext(payathotelconfirm.payatHotelHeading_gettext);
									s_assert.assertNotNull(payathotelheading, "pay at Hotel message is getting Null Value");
								}
								s_assert.assertTrue(payathotel, "pay at hotel payment gatway not open");

								Boolean confirmbtn=comman.Openlinks(payathotelconfirm.confirm_btn);
								if (confirmbtn) {
									comman.Getactualtext(comman.header_gettext);

									Boolean bookingstatusdata=comman.getListofLink(bookingstatus.listBookingStatus_gettext);
									s_assert.assertTrue(bookingstatusdata, "Booking status details is not getting list");
								}
								s_assert.assertTrue(confirmbtn, "Confirm Button is not open");
							}
							s_assert.assertTrue(paynowbtn, "pay Now button is not open");
						}
						s_assert.assertTrue(clickbooknowbtn, "Book Now button is not click");
					}
					s_assert.assertTrue(booknowbtn, "Book Now button is not present");
				}
				s_assert.assertTrue(deluxroom, "Delux Room select button is not open");
			}
			s_assert.assertTrue(hiltonhotelopen, "hilton hotel is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 10, description = "")
	public void VerifyBungalow() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			if (hotelmodule) {

				TimeUnit.SECONDS.sleep(3);
				Boolean UN=comman.IselementPresent(deshboard.username);
				if (UN) {
					Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
					s_assert.assertTrue(email, "Email field is not enter value");

					Boolean pass=comman.TextField(deshboard.password, "12345678");
					s_assert.assertTrue(pass, "Pass field is not enter value");

					Boolean login=comman.Openlinks(deshboard.LoginBtn);
					s_assert.assertTrue(login, "login field is not click ");
					try{
						driver.findElement(deshboard.Acceptandcontinue).click();
					}catch (Exception e) {
						Logger.info("Accept and continue is Not present");
					}

					/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
					s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
				}
				else{
					Logger.info("User is Already Login");
				}

				TimeUnit.SECONDS.sleep(3);


				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");

				Boolean Bungalowhotelopen=comman.Openlinks(deshboard.bungalowlink);
				if (Bungalowhotelopen) {
					String hotelnameget=comman.Getactualtext(hoteldetail.hotelName_gettext);
					s_assert.assertNotNull(hotelnameget, "Hotel Name is getting null value");

					Boolean listpresent=comman.getListofLink(hoteldetail.listFacility_gettext);
					if (listpresent) {
						Boolean arrow=comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						if (arrow) {
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);

						}
						s_assert.assertTrue(arrow, "Arrow is not present");
					}
					s_assert.assertTrue(listpresent, "Facility List is not present");

					Boolean hoteldescription=comman.IselementPresent(hoteldetail.hotelDescription_gettext);
					if (hoteldescription) {
						comman.Getactualtext(hoteldetail.hotelDescription_gettext);
					}
					s_assert.assertTrue(hoteldescription, "Hotel description is not present");

					Boolean honername=comman.IselementPresent(hoteldetail.honerName_gettext);
					if (honername) {
						comman.IselementPresent(hoteldetail.honerName_gettext);
					}
					s_assert.assertTrue(honername, "Honour name is not present");

					Boolean checkin=comman.IselementPresent(hoteldetail.checkInTime_gettext);
					if (checkin) {
						comman.Getactualtext(hoteldetail.checkInTime_gettext);
					}
					s_assert.assertTrue(checkin, "CheckIn time is not present");

					Boolean checkout=comman.IselementPresent(hoteldetail.checkOutTime_gettext);
					if (checkout) {
						comman.Getactualtext(hoteldetail.checkOutTime_gettext);
					}
					s_assert.assertTrue(checkout, "Check Out Time is not present");

					Boolean roomtypelist=comman.IselementPresent(hoteldetail.listoomType_gettext);
					if (roomtypelist) {
						comman.getListofLink(hoteldetail.listoomType_gettext);
					}
					s_assert.assertTrue(roomtypelist, "Room Type list is not present");

					Boolean deluxroom=comman.Openlinks(hoteldetail.deluxRoom_link);
					if (deluxroom) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Rooms Availability");

						Boolean checkin1=comman.IselementPresent(roomavailability.checkInTime_click_gettext);
						if (checkin1) {
							String checkintimeget=comman.Getactualtext(roomavailability.checkInTime_click_gettext);
							s_assert.assertNotNull(checkintimeget, "CheckIn time is getting Null value");
						}
						s_assert.assertTrue(checkin1, "CheckIn time is not present");

						Boolean checkout1=comman.IselementPresent(roomavailability.checkOutTime_click_gettext);
						if (checkout1) {
							String checkoutTimeget=comman.Getactualtext(roomavailability.checkOutTime_click_gettext);
							s_assert.assertNotNull(checkoutTimeget, "CheckOut Time is getting Null value");
						}
						s_assert.assertTrue(checkout1, "Check Out time is not present");

						Boolean adultscount=comman.IselementPresent(roomavailability.adultsCount_gettext);
						if (adultscount) {
							String adultcountget1=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
							s_assert.assertNotNull(adultcountget1, "Adult count is getting null value");

							Boolean incrementadults1=comman.Openlinks(roomavailability.adultsIncrement_btn);
							if (incrementadults1) {
								String adultcount2=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
								s_assert.assertNotNull(adultcount2, "Adult count after first time increment is getting null value");
							}
							s_assert.assertTrue(incrementadults1, "Adult Increment button is not working");

							Boolean decrementadults1=comman.Openlinks(roomavailability.adultsDecrement_btn);
							if (decrementadults1) {
								String adultcount4=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
								s_assert.assertNotNull(adultcount4, "Adult cont after first time decrement is getting Null value.");
							}
							s_assert.assertTrue(decrementadults1, "Adult Drecement button is not working");

						}
						s_assert.assertTrue(adultscount, "Adults count is not present");


						Boolean childrencount=comman.IselementPresent(roomavailability.childrenCount_gettext);
						if (childrencount) {
							String childcount=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
							s_assert.assertNotNull(childcount, "Children count is getting Null value");

							Boolean incrementchildren1=comman.Openlinks(roomavailability.childrenIncrement_btn);
							if (incrementchildren1) {
								String childcount2=	comman.GetAttributevalue(roomavailability.childrenCount_gettext);
								s_assert.assertNotNull(childcount2, "Children count first time increment is getting Null value");
							}
							s_assert.assertTrue(incrementchildren1, "children Increment button is not working");

							Boolean decrementchildren1=comman.Openlinks(roomavailability.childrenDrecement_btn);
							if (decrementchildren1) {
								String childcount4=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
								s_assert.assertNotNull(childcount4, "Children count first time dremenent is getting Null value");
							}
							s_assert.assertTrue(decrementchildren1, "children Drecement button is not working");
						}
						s_assert.assertTrue(childrencount, "Children count is not present");		

						Boolean addroom=comman.IselementPresent(roomavailability.addRoom_link);
						s_assert.assertTrue(addroom, "Add Room link is not presentn ");

						Boolean checkavailability=comman.IselementPresent(roomavailability.checkAvaliability_btn);
						if (checkavailability) {
							Boolean clickchoutbtn=comman.Openlinks(roomavailability.checkAvaliability_btn);
							if (clickchoutbtn) {
								comman.Getactualtext(comman.header_gettext);

								String hotelname=comman.Getactualtext(bookingdetails.hotelName_gettext);
								s_assert.assertNotNull(hotelname, "Hotel Name is getting Null value");

								String ownername=comman.Getactualtext(bookingdetails.ownerName_gettext);
								s_assert.assertNotNull(ownername, "ownername is getting Null value");

								String checkinTime=comman.Getactualtext(bookingdetails.checkInTime_gettext);
								s_assert.assertNotNull(checkinTime, "checkinTime is getting Null value");

								String checkoutTime=comman.Getactualtext(bookingdetails.checkOutTime_gettext);
								s_assert.assertNotNull(checkoutTime, "checkoutTime is getting Null value");

								String roomtype=comman.Getactualtext(bookingdetails.roomType_gettext);
								s_assert.assertNotNull(roomtype, "roomtype is getting Null value");

								String stayNight=comman.Getactualtext(bookingdetails.stayNightCount_gettext);
								s_assert.assertNotNull(stayNight, "stayNight is getting Null value");

								String roomcount=comman.Getactualtext(bookingdetails.roomCount_gettext);
								s_assert.assertNotNull(roomcount, "roomcount is getting Null value");

								String guestcount=comman.Getactualtext(bookingdetails.guestCount_gettext);
								s_assert.assertNotNull(guestcount, "guestcount is getting Null value");

								String applycouponcode=comman.Getactualtext(bookingdetails.applyCoupon_gettext);
								s_assert.assertNotNull(applycouponcode, "applycouponcode is getting Null value");

								Logger.info("----------Print all info on Booking Details--------------");
								Boolean bookingstatusallDetails=comman.getListofLink(bookingdetails.listBookingDetails_gettext);
								s_assert.assertTrue(bookingstatusallDetails, "All Booking status is not present");


								Boolean booknowbtn=comman.IselementPresent(bookingdetails.bookNow_btn);
								if (booknowbtn) {
									Boolean clickbooknowbtn =comman.Openlinks(bookingdetails.bookNow_btn);
									if (clickbooknowbtn) {
										s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");
										String gustname=comman.Getactualtext(bookhotel.guestName_gettext);
										s_assert.assertNotNull(gustname, "Guest name is getting Null value");

										Boolean title=comman.IselementPresent(bookhotel.selectTitle);
										if (title) {
											Boolean clicktitledroplist=comman.Openlinks(bookhotel.selectTitle);
											if (clicktitledroplist) {
												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													String gettitlenative=comman.Getactualtext(bookhotel.selectTitleHeader_Native_gettext);
													s_assert.assertNotNull(gettitlenative, "Title heading is getting null value");

													Boolean mrselect=comman.Openlinks(bookhotel.selectMr_Native_radio_btn);
													s_assert.assertTrue(mrselect, "Mr. Radio button not selected");
												}
												else {

													PageElement.changeContextToWebView(driver);	
													comman.Openlinks(bookhotel.selectTitle1);
												}
												PageElement.changeContextToWebView(driver);	
											}
											s_assert.assertTrue(clicktitledroplist, "Title droplist is not click");

										}
										s_assert.assertTrue(title, "Sir name Title is not present");

										Boolean firstname=comman.TextField(bookhotel.firstName_text, "Anurag");
										s_assert.assertTrue(firstname, "First Name Text filed not enter value");

										Boolean lastname=comman.TextField(bookhotel.lastName_text, "Singh");
										s_assert.assertTrue(lastname, "last Name text filed value not enter");

										String contactdetails=comman.Getactualtext(bookhotel.contactDetails_gettext);
										s_assert.assertNotNull(contactdetails, "Contact details heading is getting Null value");

										Boolean Email=comman.TextField(bookhotel.email_text, "appypie2016@gmail.com");
										s_assert.assertTrue(Email, "Email text filed not enter value");

										Boolean phone =comman.TextField(bookhotel.phone_text, "9540198626");
										s_assert.assertTrue(phone, "Phone text field not enter value");

										String message=comman.Getactualtext(bookhotel.Message_gettext);
										s_assert.assertNotNull(message, "Booking Details Message is Getting Null value");

										Boolean paynowbtn=comman.IselementPresent(bookhotel.payNow_btn);
										if (paynowbtn) {
											comman.Openlinks(bookhotel.payNow_btn);
											comman.Getactualtext(comman.header_gettext);

											String payathotelheading=comman.Getactualtext(payathotelconfirm.payatHotelHeading_gettext);
											s_assert.assertNotNull(payathotelheading, "pay at Hotel message is getting Null Value");

											Boolean confirmbtn=comman.Openlinks(payathotelconfirm.confirm_btn);
											if (confirmbtn) {
												comman.Getactualtext(comman.header_gettext);

												Boolean bookingstatusdata=comman.getListofLink(bookingstatus.listBookingStatus_gettext);
												s_assert.assertTrue(bookingstatusdata, "Booking status details is not getting list");
											}
											s_assert.assertTrue(confirmbtn, "Confirm Button is not open");
										}
										s_assert.assertTrue(paynowbtn, "pay Now button is not present");
									}
									s_assert.assertTrue(clickbooknowbtn, "Book Now button is not click");
								}
								s_assert.assertTrue(booknowbtn, "Book Now button is not present");
							}
							s_assert.assertTrue(clickchoutbtn, "CheckOut button is not click");
						}
						s_assert.assertTrue(checkavailability, "CheckOut Button is not present");
					}
					s_assert.assertTrue(deluxroom, "Delux Room select button is not open");
				}
				s_assert.assertTrue(Bungalowhotelopen, "Bungalow hotel is not open");
			}
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 11, description = "")
	public void VerifysharmaHouse() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			if (hotelmodule) {

				TimeUnit.SECONDS.sleep(3);
				Boolean UN=comman.IselementPresent(deshboard.username);
				if (UN) {
					Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
					s_assert.assertTrue(email, "Email field is not enter value");

					Boolean pass=comman.TextField(deshboard.password, "12345678");
					s_assert.assertTrue(pass, "Pass field is not enter value");

					Boolean login=comman.Openlinks(deshboard.LoginBtn);
					s_assert.assertTrue(login, "login field is not click ");
					try{
						driver.findElement(deshboard.Acceptandcontinue).click();
					}catch (Exception e) {
						Logger.info("Accept and continue is Not present");
					}

					/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
					s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
				}
				else{
					Logger.info("User is Already Login");
				}

				TimeUnit.SECONDS.sleep(3);

				comman.Getactualtext(comman.header_gettext);

				Boolean sharmaHouselopen=comman.Openlinks(deshboard.sharmaHouselink);
				if (sharmaHouselopen) {
					String hotelnameget=comman.Getactualtext(hoteldetail.hotelName_gettext);
					//s_assert.assertNotNull(hotelnameget, "Hotel Name is getting null value");

					Boolean listpresent=comman.getListofLink(hoteldetail.listFacility_gettext);
					if (listpresent) {
						Boolean arrow=comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						if (arrow) {
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);

						}
						s_assert.assertTrue(arrow, "Arrow is not present");
					}
					s_assert.assertTrue(listpresent, "Facility List is not present");

					Boolean offer=comman.IselementPresent(hoteldetail.offerHeading_gettext);
					if (offer) {
						comman.Getactualtext(hoteldetail.offerHeading_gettext);
					}
					s_assert.assertTrue(offer, "Offer Heading is not present");

					Boolean hoteldescription=comman.IselementPresent(hoteldetail.hotelDescription_gettext);
					if (hoteldescription) {
						comman.Getactualtext(hoteldetail.hotelDescription_gettext);
					}
					s_assert.assertTrue(hoteldescription, "Hotel description is not present");

					Boolean honername=comman.IselementPresent(hoteldetail.honerName_gettext);
					if (honername) {
						comman.IselementPresent(hoteldetail.honerName_gettext);
					}
					s_assert.assertTrue(honername, "Honour name is not present");

					Boolean checkin=comman.IselementPresent(hoteldetail.checkInTime_gettext);
					if (checkin) {
						comman.Getactualtext(hoteldetail.checkInTime_gettext);
					}
					s_assert.assertTrue(checkin, "CheckIn time is not present");

					Boolean checkout=comman.IselementPresent(hoteldetail.checkOutTime_gettext);
					if (checkout) {
						comman.Getactualtext(hoteldetail.checkOutTime_gettext);
					}
					s_assert.assertTrue(checkout, "Check Out Time is not present");

					Boolean roomtypelist=comman.IselementPresent(hoteldetail.listoomType_gettext);
					if (roomtypelist) {
						comman.getListofLink(hoteldetail.listoomType_gettext);
					}
					s_assert.assertTrue(roomtypelist, "Room Type list is not present");

					Boolean deluxroom=comman.Openlinks(hoteldetail.deluxRoom_link);
					if (deluxroom) {
						comman.Getactualtext(comman.header_gettext);

						Boolean checkin1=comman.IselementPresent(roomavailability.checkInTime_click_gettext);
						if (checkin1) {
							String checkintimeget=comman.Getactualtext(roomavailability.checkInTime_click_gettext);
							//s_assert.assertNotNull(checkintimeget, "CheckIn time is getting Null value");
						}
						s_assert.assertTrue(checkin1, "CheckIn time is not present");

						Boolean checkout1=comman.IselementPresent(roomavailability.checkOutTime_click_gettext);
						if (checkout1) {
							String checkoutTimeget=comman.Getactualtext(roomavailability.checkOutTime_click_gettext);
							s_assert.assertNotNull(checkoutTimeget, "CheckOut Time is getting Null value");
						}
						s_assert.assertTrue(checkout1, "Check Out time is not present");

						Boolean adultscount=comman.IselementPresent(roomavailability.adultsCount_gettext);
						if (adultscount) {
							String adultcountget1=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
							s_assert.assertNotNull(adultcountget1, "Adult count is getting null value");

							Boolean incrementadults1=comman.Openlinks(roomavailability.adultsIncrement_btn);
							if (incrementadults1) {
								String adultcount2=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
								s_assert.assertNotNull(adultcount2, "Adult count after first time increment is getting null value");
							}
							s_assert.assertTrue(incrementadults1, "Adult Increment button is not working");

							Boolean decrementadults1=comman.Openlinks(roomavailability.adultsDecrement_btn);
							if (decrementadults1) {
								String adultcount4=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
								s_assert.assertNotNull(adultcount4, "Adult cont after first time decrement is getting Null value.");
							}
							s_assert.assertTrue(decrementadults1, "Adult Drecement button is not working");

						}
						s_assert.assertTrue(adultscount, "Adults count is not present");


						Boolean childrencount=comman.IselementPresent(roomavailability.childrenCount_gettext);
						if (childrencount) {
							String childcount=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
							s_assert.assertNotNull(childcount, "Children count is getting Null value");

							Boolean incrementchildren1=comman.Openlinks(roomavailability.childrenIncrement_btn);
							if (incrementchildren1) {
								String childcount2=	comman.GetAttributevalue(roomavailability.childrenCount_gettext);
								s_assert.assertNotNull(childcount2, "Children count first time increment is getting Null value");
							}
							s_assert.assertTrue(incrementchildren1, "children Increment button is not working");

							Boolean decrementchildren1=comman.Openlinks(roomavailability.childrenDrecement_btn);
							if (decrementchildren1) {
								String childcount4=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
								s_assert.assertNotNull(childcount4, "Children count first time dremenent is getting Null value");
							}
							s_assert.assertTrue(decrementchildren1, "children Drecement button is not working");
						}
						s_assert.assertTrue(childrencount, "Children count is not present");		

						Boolean addroom=comman.IselementPresent(roomavailability.addRoom_link);
						s_assert.assertTrue(addroom, "Add Room link is not presentn ");

						Boolean checkavailability=comman.IselementPresent(roomavailability.checkAvaliability_btn);
						if (checkavailability) {
							Boolean clickchoutbtn=comman.Openlinks(roomavailability.checkAvaliability_btn);
							if (clickchoutbtn) {
								comman.Getactualtext(comman.header_gettext);

								String hotelname=comman.Getactualtext(bookingdetails.hotelName_gettext);
								s_assert.assertNotNull(hotelname, "Hotel Name is getting Null value");

								String ownername=comman.Getactualtext(bookingdetails.ownerName_gettext);
								s_assert.assertNotNull(ownername, "ownername is getting Null value");

								String checkinTime=comman.Getactualtext(bookingdetails.checkInTime_gettext);
								s_assert.assertNotNull(checkinTime, "checkinTime is getting Null value");

								String checkoutTime=comman.Getactualtext(bookingdetails.checkOutTime_gettext);
								s_assert.assertNotNull(checkoutTime, "checkoutTime is getting Null value");

								String roomtype=comman.Getactualtext(bookingdetails.roomType_gettext);
								s_assert.assertNotNull(roomtype, "roomtype is getting Null value");

								String stayNight=comman.Getactualtext(bookingdetails.stayNightCount_gettext);
								s_assert.assertNotNull(stayNight, "stayNight is getting Null value");

								String roomcount=comman.Getactualtext(bookingdetails.roomCount_gettext);
								s_assert.assertNotNull(roomcount, "roomcount is getting Null value");

								String guestcount=comman.Getactualtext(bookingdetails.guestCount_gettext);
								s_assert.assertNotNull(guestcount, "guestcount is getting Null value");

								String applycouponcode=comman.Getactualtext(bookingdetails.applyCoupon_gettext);
								s_assert.assertNotNull(applycouponcode, "applycouponcode is getting Null value");

								Logger.info("----------Print all info on Booking Details--------------");
								Boolean bookingstatusallDetails=comman.getListofLink(bookingdetails.listBookingDetails_gettext);
								s_assert.assertTrue(bookingstatusallDetails, "All Booking status is not present");


								Boolean booknowbtn=comman.IselementPresent(bookingdetails.bookNow_btn);
								if (booknowbtn) {
									Boolean clickbooknowbtn =comman.Openlinks(bookingdetails.bookNow_btn);
									if (clickbooknowbtn) {
										comman.Getactualtext(comman.header_gettext);
										String gustname=comman.Getactualtext(bookhotel.guestName_gettext);
										s_assert.assertNotNull(gustname, "Guest name is getting Null value");

										Boolean title=comman.IselementPresent(bookhotel.selectTitle);
										if (title) {
											Boolean clicktitledroplist=comman.Openlinks(bookhotel.selectTitle);
											if (clicktitledroplist) {
												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													String gettitlenative=comman.Getactualtext(bookhotel.selectTitleHeader_Native_gettext);
													s_assert.assertNotNull(gettitlenative, "Title heading is getting null value");

													Boolean mrselect=comman.Openlinks(bookhotel.selectMr_Native_radio_btn);
													s_assert.assertTrue(mrselect, "Mr. Radio button not selected");
												}
												else {
													PageElement.changeContextToWebView(driver);	
													comman.Openlinks(bookhotel.selectTitle1);
												}
												PageElement.changeContextToWebView(driver);	
											}
											s_assert.assertTrue(clicktitledroplist, "Title droplist is not click");

										}
										s_assert.assertTrue(title, "Sir name Title is not present");

										Boolean firstname=comman.TextField(bookhotel.firstName_text, "Anurag");
										s_assert.assertTrue(firstname, "First Name Text filed not enter value");

										Boolean lastname=comman.TextField(bookhotel.lastName_text, "Singh");
										s_assert.assertTrue(lastname, "last Name text filed value not enter");

										String contactdetails=comman.Getactualtext(bookhotel.contactDetails_gettext);
										s_assert.assertNotNull(contactdetails, "Contact details heading is getting Null value");

										Boolean Email=comman.TextField(bookhotel.email_text, "appypie2016@gmail.com");
										s_assert.assertTrue(Email, "Email text filed not enter value");

										Boolean phone =comman.TextField(bookhotel.phone_text, "9540198626");
										s_assert.assertTrue(phone, "Phone text field not enter value");

										String message=comman.Getactualtext(bookhotel.Message_gettext);
										s_assert.assertNotNull(message, "Booking Details Message is Getting Null value");

										Boolean paynowbtn=comman.IselementPresent(bookhotel.payNow_btn);
										if (paynowbtn) {
											comman.Openlinks(bookhotel.payNow_btn);
											comman.Getactualtext(comman.header_gettext);

											String payathotelheading=comman.Getactualtext(payathotelconfirm.payatHotelHeading_gettext);
											s_assert.assertNotNull(payathotelheading, "pay at Hotel message is getting Null Value");

											Boolean confirmbtn=comman.Openlinks(payathotelconfirm.confirm_btn);
											if (confirmbtn) {
												comman.Getactualtext(comman.header_gettext);

												Boolean bookingstatusdata=comman.getListofLink(bookingstatus.listBookingStatus_gettext);
												s_assert.assertTrue(bookingstatusdata, "Booking status details is not getting list");
											}
											s_assert.assertTrue(confirmbtn, "Confirm Button is not open");
										}
										s_assert.assertTrue(paynowbtn, "pay Now button is not present");
									}
									s_assert.assertTrue(clickbooknowbtn, "Book Now button is not click");
								}
								s_assert.assertTrue(booknowbtn, "Book Now button is not present");
							}
							s_assert.assertTrue(clickchoutbtn, "CheckOut button is not click");
						}
						s_assert.assertTrue(checkavailability, "CheckOut Button is not present");
					}
					s_assert.assertTrue(deluxroom, "Delux Room select button is not open");
				}
				s_assert.assertTrue(sharmaHouselopen, "sharma House is not open");
			}
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 12, description = "")
	public void VerifyVillaRocha() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyVillaRocha()");
		boolean exception = false;
		try {
			Boolean hotelmodule=comman.Openlinks(deshboard.hotelmodulelink);
			if (hotelmodule) {
				TimeUnit.SECONDS.sleep(3);
				Boolean UN=comman.IselementPresent(deshboard.username);
				if (UN) {
					Boolean email=comman.TextField(deshboard.username, "appypie2016@gmail.com");
					s_assert.assertTrue(email, "Email field is not enter value");

					Boolean pass=comman.TextField(deshboard.password, "12345678");
					s_assert.assertTrue(pass, "Pass field is not enter value");

					Boolean login=comman.Openlinks(deshboard.LoginBtn);
					s_assert.assertTrue(login, "login field is not click ");
					try{
						driver.findElement(deshboard.Acceptandcontinue).click();
					}catch (Exception e) {
						Logger.info("Accept and continue is Not present");
					}

					/*Boolean hotelmodule1=comman.Openlinks(deshboard.hotelmodulelink);
					s_assert.assertTrue(hotelmodule1, "Hotel Module is not open after login");*/
				}
				else{
					Logger.info("User is Already Login");
				}
				TimeUnit.SECONDS.sleep(3);


				comman.Getactualtext(comman.header_gettext);

				Boolean villaRochaopen=comman.Openlinks(deshboard.villaRochalink);
				if (villaRochaopen) {
					String hotelnameget=comman.Getactualtext(hoteldetail.hotelName_gettext);
					s_assert.assertNotNull(hotelnameget, "Hotel Name is getting null value");

					Boolean listpresent=comman.getListofLink(hoteldetail.listFacility_gettext);
					if (listpresent) {
						Boolean arrow=comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
						if (arrow) {
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);
							comman.Openlinks(hoteldetail.listFacilityrightarrow_link);
							comman.getListofLink(hoteldetail.listFacility_gettext);

						}
						s_assert.assertTrue(arrow, "Arrow is not present");
					}
					s_assert.assertTrue(listpresent, "Facility List is not present");



					Boolean hoteldescription=comman.IselementPresent(hoteldetail.hotelDescription_gettext);
					if (hoteldescription) {
						comman.Getactualtext(hoteldetail.hotelDescription_gettext);
					}
					s_assert.assertTrue(hoteldescription, "Hotel description is not present");

					Boolean honername=comman.IselementPresent(hoteldetail.honerName_gettext);
					if (honername) {
						comman.IselementPresent(hoteldetail.honerName_gettext);
					}
					s_assert.assertTrue(honername, "Honour name is not present");

					Boolean checkin=comman.IselementPresent(hoteldetail.checkInTime_gettext);
					if (checkin) {
						comman.Getactualtext(hoteldetail.checkInTime_gettext);
					}
					s_assert.assertTrue(checkin, "CheckIn time is not present");

					Boolean checkout=comman.IselementPresent(hoteldetail.checkOutTime_gettext);
					if (checkout) {
						comman.Getactualtext(hoteldetail.checkOutTime_gettext);
					}
					s_assert.assertTrue(checkout, "Check Out Time is not present");

					Boolean roomtypelist=comman.IselementPresent(hoteldetail.listoomType_gettext);
					if (roomtypelist) {
						comman.getListofLink(hoteldetail.listoomType_gettext);
					}
					s_assert.assertTrue(roomtypelist, "Room Type list is not present");

					Boolean deluxroom=comman.Openlinks(hoteldetail.deluxRoom_link);
					if (deluxroom) {
						comman.Getactualtext(comman.header_gettext);

						Boolean checkin1=comman.IselementPresent(roomavailability.checkInTime_click_gettext);
						if (checkin1) {
							String checkintimeget=comman.Getactualtext(roomavailability.checkInTime_click_gettext);
							s_assert.assertNotNull(checkintimeget, "CheckIn time is getting Null value");
						}
						s_assert.assertTrue(checkin1, "CheckIn time is not present");

						Boolean checkout1=comman.IselementPresent(roomavailability.checkOutTime_click_gettext);
						if (checkout1) {
							String checkoutTimeget=comman.Getactualtext(roomavailability.checkOutTime_click_gettext);
							s_assert.assertNotNull(checkoutTimeget, "CheckOut Time is getting Null value");
						}
						s_assert.assertTrue(checkout1, "Check Out time is not present");

						Boolean adultscount=comman.IselementPresent(roomavailability.adultsCount_gettext);
						if (adultscount) {
							String adultcountget1=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
							s_assert.assertNotNull(adultcountget1, "Adult count is getting null value");

							Boolean incrementadults1=comman.Openlinks(roomavailability.adultsIncrement_btn);
							if (incrementadults1) {
								String adultcount2=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
								s_assert.assertNotNull(adultcount2, "Adult count after first time increment is getting null value");
							}
							s_assert.assertTrue(incrementadults1, "Adult Increment button is not working");

							Boolean decrementadults1=comman.Openlinks(roomavailability.adultsDecrement_btn);
							if (decrementadults1) {
								String adultcount4=comman.GetAttributevalue(roomavailability.adultsCount_gettext);
								s_assert.assertNotNull(adultcount4, "Adult cont after first time decrement is getting Null value.");
							}
							s_assert.assertTrue(decrementadults1, "Adult Drecement button is not working");

						}
						s_assert.assertTrue(adultscount, "Adults count is not present");


						Boolean childrencount=comman.IselementPresent(roomavailability.childrenCount_gettext);
						if (childrencount) {
							String childcount=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
							s_assert.assertNotNull(childcount, "Children count is getting Null value");

							Boolean incrementchildren1=comman.Openlinks(roomavailability.childrenIncrement_btn);
							if (incrementchildren1) {
								String childcount2=	comman.GetAttributevalue(roomavailability.childrenCount_gettext);
								s_assert.assertNotNull(childcount2, "Children count first time increment is getting Null value");
							}
							s_assert.assertTrue(incrementchildren1, "children Increment button is not working");

							Boolean decrementchildren1=comman.Openlinks(roomavailability.childrenDrecement_btn);
							if (decrementchildren1) {
								String childcount4=comman.GetAttributevalue(roomavailability.childrenCount_gettext);
								s_assert.assertNotNull(childcount4, "Children count first time dremenent is getting Null value");
							}
							s_assert.assertTrue(decrementchildren1, "children Drecement button is not working");
						}
						s_assert.assertTrue(childrencount, "Children count is not present");		

						Boolean addroom=comman.IselementPresent(roomavailability.addRoom_link);
						s_assert.assertTrue(addroom, "Add Room link is not presentn ");

						Boolean checkavailability=comman.IselementPresent(roomavailability.checkAvaliability_btn);
						if (checkavailability) {
							Boolean clickchoutbtn=comman.Openlinks(roomavailability.checkAvaliability_btn);
							if (clickchoutbtn) {
								comman.Getactualtext(comman.header_gettext);

								String hotelname=comman.Getactualtext(bookingdetails.hotelName_gettext);
								s_assert.assertNotNull(hotelname, "Hotel Name is getting Null value");

								String ownername=comman.Getactualtext(bookingdetails.ownerName_gettext);
								s_assert.assertNotNull(ownername, "ownername is getting Null value");

								String checkinTime=comman.Getactualtext(bookingdetails.checkInTime_gettext);
								s_assert.assertNotNull(checkinTime, "checkinTime is getting Null value");

								String checkoutTime=comman.Getactualtext(bookingdetails.checkOutTime_gettext);
								s_assert.assertNotNull(checkoutTime, "checkoutTime is getting Null value");

								String roomtype=comman.Getactualtext(bookingdetails.roomType_gettext);
								s_assert.assertNotNull(roomtype, "roomtype is getting Null value");

								String stayNight=comman.Getactualtext(bookingdetails.stayNightCount_gettext);
								s_assert.assertNotNull(stayNight, "stayNight is getting Null value");

								String roomcount=comman.Getactualtext(bookingdetails.roomCount_gettext);
								s_assert.assertNotNull(roomcount, "roomcount is getting Null value");

								String guestcount=comman.Getactualtext(bookingdetails.guestCount_gettext);
								s_assert.assertNotNull(guestcount, "guestcount is getting Null value");

								String applycouponcode=comman.Getactualtext(bookingdetails.applyCoupon_gettext);
								s_assert.assertNotNull(applycouponcode, "applycouponcode is getting Null value");

								Logger.info("----------Print all info on Booking Details--------------");
								Boolean bookingstatusallDetails=comman.getListofLink(bookingdetails.listBookingDetails_gettext);
								s_assert.assertTrue(bookingstatusallDetails, "All Booking status is not present");


								Boolean booknowbtn=comman.IselementPresent(bookingdetails.bookNow_btn);
								if (booknowbtn) {
									Boolean clickbooknowbtn =comman.Openlinks(bookingdetails.bookNow_btn);
									if (clickbooknowbtn) {
										s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");
										String gustname=comman.Getactualtext(bookhotel.guestName_gettext);
										s_assert.assertNotNull(gustname, "Guest name is getting Null value");

										Boolean title=comman.IselementPresent(bookhotel.selectTitle);
										if (title) {
											Boolean clicktitledroplist=comman.Openlinks(bookhotel.selectTitle);
											if (clicktitledroplist) {
												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													String gettitlenative=comman.Getactualtext(bookhotel.selectTitleHeader_Native_gettext);
													s_assert.assertNotNull(gettitlenative, "Title heading is getting null value");

													Boolean mrselect=comman.Openlinks(bookhotel.selectMr_Native_radio_btn);
													s_assert.assertTrue(mrselect, "Mr. Radio button not selected");
												}
												else {

													PageElement.changeContextToWebView(driver);	
													comman.Openlinks(bookhotel.selectTitle1);
												}
												PageElement.changeContextToWebView(driver);	
											}
											s_assert.assertTrue(clicktitledroplist, "Title droplist is not click");

										}
										s_assert.assertTrue(title, "Sir name Title is not present");

										Boolean firstname=comman.TextField(bookhotel.firstName_text, "Anurag");
										s_assert.assertTrue(firstname, "First Name Text filed not enter value");

										Boolean lastname=comman.TextField(bookhotel.lastName_text, "Singh");
										s_assert.assertTrue(lastname, "last Name text filed value not enter");

										String contactdetails=comman.Getactualtext(bookhotel.contactDetails_gettext);
										s_assert.assertNotNull(contactdetails, "Contact details heading is getting Null value");

										Boolean Email=comman.TextField(bookhotel.email_text, "appypie2016@gmail.com");
										s_assert.assertTrue(Email, "Email text filed not enter value");

										Boolean phone =comman.TextField(bookhotel.phone_text, "9540198626");
										s_assert.assertTrue(phone, "Phone text field not enter value");

										String message=comman.Getactualtext(bookhotel.Message_gettext);
										s_assert.assertNotNull(message, "Booking Details Message is Getting Null value");

										Boolean paynowbtn=comman.IselementPresent(bookhotel.payNow_btn);
										if (paynowbtn) {
											comman.Openlinks(bookhotel.payNow_btn);
											s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"HOTEL");

											String payathotelheading=comman.Getactualtext(payathotelconfirm.payatHotelHeading_gettext);
											s_assert.assertNotNull(payathotelheading, "pay at Hotel message is getting Null Value");

											Boolean confirmbtn=comman.Openlinks(payathotelconfirm.confirm_btn);
											if (confirmbtn) {
												s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "HOTEL");

												Boolean bookingstatusdata=comman.getListofLink(bookingstatus.listBookingStatus_gettext);
												s_assert.assertTrue(bookingstatusdata, "Booking status details is not getting list");
												driver.context("NATIVE_APP");
												comman.SwipeBottomToTop();
												PageElement.changeContextToWebView(driver);

												Boolean addtocal=comman.Openlinks(bookingstatus.addToCalendarlink);
												if (addtocal) {
													driver.context("NATIVE_APP");
													NavigationPage.verifyrunTimePermissions(driver);
													driver.context("NATIVE_APP");
													comman.IfAlertpresent();
												}
												s_assert.assertTrue(addtocal, "AddToCalender link is not working");
											}
											s_assert.assertTrue(confirmbtn, "Confirm Button is not open");
										}
										s_assert.assertTrue(paynowbtn, "pay Now button is not present");
									}
									s_assert.assertTrue(clickbooknowbtn, "Book Now button is not click");
								}
								s_assert.assertTrue(booknowbtn, "Book Now button is not present");
							}
							s_assert.assertTrue(clickchoutbtn, "CheckOut button is not click");
						}
						s_assert.assertTrue(checkavailability, "CheckOut Button is not present");
					}
					s_assert.assertTrue(deluxroom, "Delux Room select button is not open");
				}
				s_assert.assertTrue(villaRochaopen, "villa Rocha is not open");
			}
			s_assert.assertTrue(hotelmodule, "Hotel Module is not open");


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
}
