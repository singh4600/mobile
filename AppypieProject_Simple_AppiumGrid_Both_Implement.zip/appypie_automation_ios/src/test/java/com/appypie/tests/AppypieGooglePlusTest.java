package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.bitbar.BaseAndroidTest;
import com.appypie.pages.AppypieGooglePlusPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieGooglePlusTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	AppypieGooglePlusPage google;
	SoftAssert asser;

	@BeforeTest
	@Override
	public void pageSetUp() {
		google = new AppypieGooglePlusPage(driver);
	}

	//@Test
	public void verifyGooglePlusPage() {
		Logger.info("********Test Method Starts: verifyGooglePlusPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			google.openGooglePlusPage();
			boolean Open = google.identifyGooglePlusOpen();
			if (Open) {
				String header = PageElement.getPageHeader(driver);
				asser.assertEquals(header, "Google+");
			} else {
				Logger.info("Google+ Page is not open from main menu");
			}
			asser.assertTrue(Open, "Google+ Page is not Open by clicking the main menu icon");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Google+ page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	//@Test
	public void verifyGooglePlusUrl() {
		Logger.info("********Test Method Starts: verifyGooglePlusUrl********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			google.openGooglePlusPage();
			google.openGooglePlusUrl();
			boolean info = google.checkGooglePlusFeeds();
			asser.assertTrue(info, "Google+ url is not opening or feeds are not present in the facebook url");
			if (!info) {
				boolean nodata = PageElement.checkNoDataOptionInUrl(driver);
				if (nodata)
					Logger.info("No data icon is showing in the Google+ url");
				asser.assertTrue(nodata, "No data icon is not visible and feeds are not present in Google+ url");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Google+ URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyInvalidGooglePlusUrl() {
		Logger.info("********Test Method Starts: verifyInvalidGooglePlusUrl********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			google.openGooglePlusPage();
			boolean open = google.clickInvalidUrl();
			asser.assertTrue(open, "Google+ url is not opening and no data icon is also not visible on screen");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the invalid Google+ URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyFeedInNativeForGooglePlus() {
		Logger.info("********Test Method Starts: verifyFeedInNativeForGooglePlus********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			google.openGooglePlusPage();
			google.openGooglePlusUrl();
			boolean open = google.clickViewButton();
			asser.assertTrue(open, " Google+ feeds is not open in native browser");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Google+ feeds in native", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
