package com.appypie.tests;

import java.util.Random;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.AppypieSheetPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieSheetPageTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieMenuPage menu;
	AppypieSheetPage sheet;

	@Override
	@BeforeTest
	public void pageSetUp() {
		menu = new AppypieMenuPage(driver);
		sheet = new AppypieSheetPage(driver);
	}

	@Test
	public void verifySheetPageandBackbtn() {
		Logger.info("Test Methods start: verifySheetPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from Sheet page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the sheet page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyGoogleSheetandBackbtn() {
		Logger.info("Test Methods start: verifyGoogleSheetandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				sheet.openSheet();
				boolean sheetOpen = sheet.isSheetOpen();
				asser.assertTrue(sheetOpen, "Google sheet is not open");
				if (sheetOpen) {
					PageElement.tapBackButton(driver);
					Thread.sleep(1000);
					asser.assertTrue(sheet.isSheetPageOpen(), "Back Button from Sheet page is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening google sheet ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyaddRowsInSheet() {
		Logger.info("Test Methods start: verifyaddRowsInSheet");
		asser = new SoftAssert();
		int rowCountBeforeUpdate = 0;
		int rowCountAfterUpdate = 0;
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				sheet.openSheet();
				boolean sheetOpen = sheet.isSheetOpen();
				asser.assertTrue(sheetOpen, "Google sheet is not open");
				if (sheetOpen) {
					sheet.openAddRows();
					boolean addRowPage = sheet.isUpdaterowFormOpen();
					asser.assertTrue(addRowPage, "add rows functionality is not working");
					if (addRowPage) {
						rowCountBeforeUpdate = sheet.getSheetrowCount();
						sheet.updateFirstCell("brijesh_" + String.valueOf(new Random().nextInt(40) + 10));
						sheet.updateSecondCell(String.valueOf(100000 + new Random().nextInt(999999)));
						sheet.updateThirdCell("Noida sec 82");
						sheet.updateFourthCell("67826373927");
						sheet.saveNewRow();
						Thread.sleep(3000);
						boolean addrow = sheet.isSheetOpen();
						asser.assertTrue(addrow, "new row is not added ion sheet");
						if (addrow) {
							rowCountAfterUpdate = sheet.getSheetrowCount();
							asser.assertTrue(rowCountBeforeUpdate == rowCountAfterUpdate - 1,
									"New row is not added row count is not increased");
						}
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying add rows functionality ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifySearchFunctionality() {
		Logger.info("Test Methods start: verifySearchFunctionality");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				sheet.openSheet();
				boolean sheetOpen = sheet.isSheetOpen();
				asser.assertTrue(sheetOpen, "Google sheet is not open");
				if (sheetOpen) {
					sheet.enterSearchKeyword("brijesh5");
					sheet.clickSearchBtn();
					Thread.sleep(3000);
					asser.assertTrue(sheet.isSearchPageOpen(), "Search result is not open from sheet");
					asser.assertEquals(sheet.getSearchData(), "brijesh5", "search content is not displayed");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying search functionality ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyRowDetailOpen() {
		Logger.info("Test Methods start: verifyRowDetailOpen");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				sheet.openSheet();
				boolean sheetOpen = sheet.isSheetOpen();
				asser.assertTrue(sheetOpen, "Google sheet is not open");
				if (sheetOpen) {
					sheet.clickRows();
					asser.assertTrue(sheet.isRowDetailsOpen(), "row details are not open upon clicking on row");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Row Detail Open functionality ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyUpdateRow() {
		Logger.info("Test Methods start: verifyUpdateRow");
		asser = new SoftAssert();
		String updatedName = "";
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				sheet.openSheet();
				boolean sheetOpen = sheet.isSheetOpen();
				asser.assertTrue(sheetOpen, "Google sheet is not open");
				if (sheetOpen) {
					sheet.clickRows();
					boolean detail = sheet.isRowDetailsOpen();
					asser.assertTrue(detail, "row details are not open upon clicking on row");
					if (detail) {
						sheet.openUpdateRow();
						updatedName = "brijesh_" + String.valueOf(new Random().nextInt(40) + 40);
						Thread.sleep(1000);
						sheet.updateFirstCell(updatedName);
						sheet.saveUpdate();
						Thread.sleep(1000);
						boolean updateData = sheet.isRowDetailsOpen();
						asser.assertTrue(updateData, "after save update row dwtail page is not open");
						if (updateData) {
							PageElement.tapBackButton(driver);
							Thread.sleep(500);
							asser.assertEquals(sheet.getFirstCellValue(), updatedName, "cell value is not updated");
						}
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying update row functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(dependsOnMethods={"verifyaddRowsInSheet"},alwaysRun=true)
	public void verifyDeleteRow() {
		Logger.info("Test Methods start: verifyDeleteRow");
		asser = new SoftAssert();
		int rowCountBeforeDelete = 0;
		int rowCountAfterDelete = 0;
		boolean exception = false;
		try {
			menu.openPage("appsheets");
			boolean pageOpen = sheet.isSheetPageOpen();
			asser.assertTrue(pageOpen, "Sheet page is not open");
			if (pageOpen) {
				sheet.openSheet();
				boolean sheetOpen = sheet.isSheetOpen();
				asser.assertTrue(sheetOpen, "Google sheet is not open");
				if (sheetOpen) {
					rowCountBeforeDelete = sheet.getSheetrowCount();
					sheet.clickSheetLastRow();
					boolean detail = sheet.isRowDetailsOpen();
					asser.assertTrue(detail, "row details are not open upon clicking on row");
					if (detail) {
						sheet.deleteRow();
						String warning = PageElement.getWarningText(driver);
						asser.assertEquals(warning, "Are you sure you want to delete?");
						if (warning != "") {
							PageElement.closeWarningSingleBtn(driver, "Confirm");
							Thread.sleep(3000);
							rowCountAfterDelete = sheet.getSheetrowCount();
							asser.assertTrue(sheet.isSheetOpen(),
									"not redirecting to sheet home after deleting the row");
							asser.assertEquals(rowCountAfterDelete, rowCountBeforeDelete-1,
									"row count is not reduced!! sheet is not deleted");
						}
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying delete row functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
