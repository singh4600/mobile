package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.Audio.AudioPage;
import com.appypie.pages.Audio.CommanClassAudio;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;
public class AndroidAppiumAudioPageTest extends TestSetup {
	//AppypieAudioPage audio; 
	CommanClassAudio comm;
	AudioPage audio;
	private static final Logger Logger= Log.createLogger();

	//--------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		//audio=new AppypieAudioPage(driver);
		comm=new CommanClassAudio(driver);
		audio=new AudioPage(driver);
	}

	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VerifyAudioModuleOpen() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyAudioModuleOpen()");
		boolean exception = false;
		try {
			Boolean audiomoduleOpen=comm.Openlinks(audio.clickAudioModule);
			if (audiomoduleOpen) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Audio");
				Boolean audiolinklist=comm.getListofLink(audio.getAllaudioLink);
				s_assert.assertTrue(audiolinklist, "List is not getting on audio home page");

				Boolean backbtn=comm.Openlinks(comm.BackButton2);
				s_assert.assertTrue(backbtn, "Back Button is not working on home page");
			}
			s_assert.assertTrue(audiomoduleOpen, "Audio module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifySoundCloud() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySoundCloud()");
		boolean exception = false;
		try {
			Boolean audiomoduleOpen=comm.Openlinks(audio.clickAudioModule);
			if (audiomoduleOpen) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Audio");

				Boolean SoundCloud=comm.Openlinks(audio.clickSoundCloud);
				if (SoundCloud) {
					comm.IfAlertpresent();
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						comm.Syncing_BufferingContent(audio.bufferingNative);
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Sound Cloud");
						driver.context("NATIVE_APP");
						Boolean stopPlayBtn=comm.Openlinks(audio.PlayStopBtn);
						s_assert.assertTrue(stopPlayBtn, "Play/Stop button is not working");

						String songlabel=comm.Getactualtext(audio.songlabel_getText);
						s_assert.assertNotNull(songlabel, "Song label is getting Null value");

						String clock=comm.Getactualtext(audio.time_getText);
						s_assert.assertNotNull(clock, "clock timer is getting Null value");

						String heading=comm.Getactualtext(audio.headingSong_getText);
						s_assert.assertNotNull(heading, "Song heading is getting Null value");

						Boolean songlist=comm.getListofLink(audio.songlist_getText);
						s_assert.assertTrue(songlist, "Song list is not getting");

						/*Boolean Previous=comm.Openlinks(audio.PreviousBtn);
						s_assert.assertTrue(Previous, "Previous button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Backward=comm.Openlinks(audio.BackwardBtn);
						s_assert.assertTrue(Backward, "Backward button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Forward=comm.Openlinks(audio.ForwardBtn);
						s_assert.assertTrue(Forward, "Forward button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Next=comm.Openlinks(audio.NextBtn);
						s_assert.assertTrue(Next, "Next button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);*/

						Boolean shuffal=comm.Openlinks(audio.shuffalBtn);
						s_assert.assertTrue(shuffal, "shuffal button is not working");

						Boolean mute=comm.Openlinks(audio.muteBtn);
						s_assert.assertTrue(mute, "mute button is not working");

						Boolean share=comm.Openlinks(audio.shareBtn);{
							Boolean sharelist=comm.getListofLink(audio.getsharebyItem);
							if (sharelist) {
								driver.navigate().back();
							}
							s_assert.assertTrue(sharelist, "share list is not getting");
						}
						s_assert.assertTrue(share, "share button is not working");

						Boolean bsckbtn=comm.Openlinks(comm.BackButtonNative);
						s_assert.assertTrue(bsckbtn, "back button is not working");
					}
					else {

						Boolean stopPlayBtn=comm.Openlinks(audio.i_PlayStopBtn);
						s_assert.assertTrue(stopPlayBtn, "iPlay/Stop button is not working");

						Boolean shuffal=comm.Openlinks(audio.i_shuffalBtn);
						s_assert.assertTrue(shuffal, "ishuffal button is not working");

						Boolean mute=comm.Openlinks(audio.i_muteBtn);
						s_assert.assertTrue(mute, "imute button is not working");

						Boolean share=comm.Openlinks(audio.i_shareBtn);{
							Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
							s_assert.assertTrue(icancle, "iCancle button is not working");
						}
						s_assert.assertTrue(share, "i_share button is not working");

						Boolean bsckbtn=comm.Openlinks(comm.i_BackButtonNative);
						s_assert.assertTrue(bsckbtn, "iback button is not working");
					}
					PageElement.changeContextToWebView(driver);

				}
				s_assert.assertTrue(SoundCloud, "Sound Cloud link is not working");
			}
			s_assert.assertTrue(audiomoduleOpen, "Audio module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifyMediaRss() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMediaRss()");
		boolean exception = false;
		try {
			Boolean audiomoduleOpen=comm.Openlinks(audio.clickAudioModule);
			if (audiomoduleOpen) {
				comm.Getactualtext(comm.header_gettext);

				Boolean MediaRss=comm.Openlinks(audio.clickMediaRss);
				if (MediaRss) {
					comm.IfAlertpresent();
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						TimeUnit.SECONDS.sleep(2);
						comm.Syncing_BufferingContent(audio.bufferingNative);
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Media RSS");

						comm.SwipetopTobottom();

						Boolean stopPlayBtn=comm.Openlinks(audio.PlayStopBtn);
						s_assert.assertTrue(stopPlayBtn, "Play/Stop button is not working");

						String songlabel=comm.Getactualtext(audio.songlabel_getText);
						s_assert.assertNotNull(songlabel, "Song label is getting Null value");

						String clock=comm.Getactualtext(audio.time_getText);
						s_assert.assertNotNull(clock, "clock timer is getting Null value");

						String heading=comm.Getactualtext(audio.headingSong_getText);
						s_assert.assertNotNull(heading, "Song heading is getting Null value");

						String songdescription=comm.Getactualtext(audio.mediaRssSongDescription);
						s_assert.assertNotNull(songdescription, "songdescription is getting Null value");

						/*				Boolean Previous=comm.Openlinks(audio.PreviousBtn);
						s_assert.assertTrue(Previous, "Previous button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Backward=comm.Openlinks(audio.BackwardBtn);
						s_assert.assertTrue(Backward, "Backward button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Forward=comm.Openlinks(audio.ForwardBtn);
						s_assert.assertTrue(Forward, "Forward button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Next=comm.Openlinks(audio.NextBtn);
						s_assert.assertTrue(Next, "Next button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);*/

						Boolean shuffal=comm.Openlinks(audio.shuffalBtn);
						s_assert.assertTrue(shuffal, "shuffal button is not working");

						Boolean mute=comm.Openlinks(audio.muteBtn);
						s_assert.assertTrue(mute, "mute button is not working");

						Boolean share=comm.Openlinks(audio.shareBtn);{
							Boolean sharelist=comm.getListofLink(audio.getsharebyItem);
							if (sharelist) {
								driver.navigate().back();
							}
							s_assert.assertTrue(sharelist, "share list is not getting");
						}
						s_assert.assertTrue(share, "share button is not working");

						Boolean bsckbtn=comm.Openlinks(comm.BackButtonNative);
						s_assert.assertTrue(bsckbtn, "back button is not working");
					}
					else {
						Boolean stopPlayBtn=comm.Openlinks(audio.i_PlayStopBtn);
						s_assert.assertTrue(stopPlayBtn, "i_Play/Stop button is not working");

						Boolean shuffal=comm.Openlinks(audio.i_shuffalBtn);
						s_assert.assertTrue(shuffal, "i_shuffal button is not working");

						Boolean mute=comm.Openlinks(audio.i_muteBtn);
						s_assert.assertTrue(mute, "i_mute button is not working");

						Boolean share=comm.Openlinks(audio.i_shareBtn);{
							Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
							s_assert.assertTrue(icancle, "iCancle button is not working.");
						}
						s_assert.assertTrue(share, "i_share button is not working");

						Boolean bsckbtn=comm.Openlinks(comm.i_BackButtonNative);
						s_assert.assertTrue(bsckbtn, "iback button is not working");
					}
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(MediaRss, "Media Rss link is not working");
			}
			s_assert.assertTrue(audiomoduleOpen, "Audio module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyRadioStream() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyRadioStream()");
		boolean exception = false;
		try {
			Boolean audiomoduleOpen=comm.Openlinks(audio.clickAudioModule);
			if (audiomoduleOpen) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Audio");

				Boolean RadioStream=comm.Openlinks(audio.clickRadioStream);
				if (RadioStream) {
					comm.IfAlertpresent();
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						comm.Syncing_BufferingContent(audio.bufferingNative);
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Radio Stream");

						TimeUnit.SECONDS.sleep(2);
						driver.context("NATIVE_APP");
						Boolean PlayBtn=comm.Openlinks(audio.clickradiostreamPlayBtn);
						s_assert.assertTrue(PlayBtn, "Play button is not working");
						TimeUnit.SECONDS.sleep(2);

						String songlabel=comm.Getactualtext(audio.getradioName);
						s_assert.assertNotNull(songlabel, "radio name is getting Null value");

						String clock=comm.Getactualtext(audio.getradioStatus);
						s_assert.assertNotNull(clock, "Radio Status is getting Null value");


						Boolean mute=comm.Openlinks(audio.muteBtn);
						s_assert.assertTrue(mute, "mute button is not working");

						Boolean share=comm.Openlinks(audio.shareBtn);{
							Boolean sharelist=comm.getListofLink(audio.getsharebyItem);
							if (sharelist) {
								driver.navigate().back();
							}
							s_assert.assertTrue(sharelist, "share list is not getting");
						}
						s_assert.assertTrue(share, "share button is not working");

						Boolean alarm=comm.Openlinks(audio.clickradiostreamAlermbtn);
						if (alarm) {
							s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Alarm");

							Boolean addalerm=comm.Openlinks(audio.addAlarm);
							s_assert.assertTrue(addalerm, "addalerm button is not working");

							Boolean setTime=comm.Openlinks(audio.setTimelink);
							s_assert.assertTrue(setTime, "setTime link is not working");

							Boolean cancelBtnclock=comm.Openlinks(audio.cancelBtnclocklink);
							s_assert.assertTrue(cancelBtnclock, "cancelBtnclock button is not working");

							Boolean checkall=comm.Openlinks(audio.checkalllink);
							s_assert.assertTrue(checkall, "checkall button is not working");

							Boolean checkall1=comm.Openlinks(audio.checkalllink);
							s_assert.assertTrue(checkall1, "Uncheck All button is not working");

							Boolean checkMonday=comm.Openlinks(audio.checkMondaylink);
							s_assert.assertTrue(checkMonday, "check Monday check Box is not working");

							Boolean addbtn=comm.Openlinks(audio.addbtn);
							s_assert.assertTrue(addbtn, "Add button is not working");

							Boolean cancel=comm.Openlinks(audio.cancelbtn);
							s_assert.assertTrue(cancel, "cancel button is not working");

							Boolean bsckbtn=comm.Openlinks(comm.BackButtonNative);
							s_assert.assertTrue(bsckbtn, "back button is not working");
						}
						s_assert.assertTrue(alarm, "alarm link is not working");

						Boolean bsckbtn=comm.Openlinks(comm.BackButtonNative);
						s_assert.assertTrue(bsckbtn, "back button is not working");
					}
					else {
						Boolean PlayBtn=comm.Openlinks(audio.i_clickradiostreamPlayBtn);
						s_assert.assertTrue(PlayBtn, "i_Play button is not working");
						TimeUnit.SECONDS.sleep(2);

						Boolean mute=comm.Openlinks(audio.i_muteBtn);
						s_assert.assertTrue(mute, "imute button is not working");

						Boolean share=comm.Openlinks(audio.i_shareRadioBtn);{
							Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
							s_assert.assertTrue(icancle, "iCancle button is not working.");
						}
						s_assert.assertTrue(share, "ishare button is not working");

						Boolean alarm=comm.Openlinks(audio.i_clickradiostreamAlermbtn);
						if (alarm) {

							Boolean addalerm=comm.Openlinks(audio.i_addAlarm);
							s_assert.assertTrue(addalerm, "iaddalerm button is not working");

					
							Boolean cancel=comm.Openlinks(audio.i_cancelbtn);
							//s_assert.assertTrue(cancel, "icancel button is not working");

							Boolean done=comm.IselementPresent(comm.i_done);
							if (done) {
								Boolean idone=comm.Openlinks(comm.i_done);
								s_assert.assertTrue(idone, "iDone button is not working");
							}
							else {
								System.out.println("iDone button is not present");
							}
						}
						s_assert.assertTrue(alarm, "ialarm link is not working");
						Boolean bsckbtn=comm.Openlinks(comm.i_BackButtonNative);
						s_assert.assertTrue(bsckbtn, "iback button is not working");
					}
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(RadioStream, "Radio Stream link is not working");
			}
			s_assert.assertTrue(audiomoduleOpen, "Audio module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifyCustom() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyCustom()");
		boolean exception = false;
		try {
			Boolean audiomoduleOpen=comm.Openlinks(audio.clickAudioModule);
			if (audiomoduleOpen) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Audio");

				Boolean Custom=comm.Openlinks(audio.clickCustom);
				if (Custom) {
					comm.IfAlertpresent();
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						comm.Syncing_BufferingContent(audio.bufferingNative);
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Custom");
						driver.context("NATIVE_APP");
						Boolean stopPlayBtn=comm.Openlinks(audio.PlayStopBtn);
						s_assert.assertTrue(stopPlayBtn, "Play/Stop button is not working");

						String songlabel=comm.Getactualtext(audio.songlabel_getText);
						s_assert.assertNotNull(songlabel, "Song label is getting Null value");

						String clock=comm.Getactualtext(audio.time_getText);
						s_assert.assertNotNull(clock, "clock timer is getting Null value");

						String heading=comm.Getactualtext(audio.headingSong_getText);
						s_assert.assertNotNull(heading, "Song heading is getting Null value");

						Boolean songlist=comm.getListofLink(audio.songlist_getText);
						s_assert.assertTrue(songlist, "Song list is not getting");

						/*				Boolean Previous=comm.Openlinks(audio.PreviousBtn);
						s_assert.assertTrue(Previous, "Previous button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Backward=comm.Openlinks(audio.BackwardBtn);
						s_assert.assertTrue(Backward, "Backward button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Forward=comm.Openlinks(audio.ForwardBtn);
						s_assert.assertTrue(Forward, "Forward button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);

						Boolean Next=comm.Openlinks(audio.NextBtn);
						s_assert.assertTrue(Next, "Next button is not working");
						comm.Syncing_BufferingContent(audio.bufferingNative);*/

						Boolean shuffal=comm.Openlinks(audio.shuffalBtn);
						s_assert.assertTrue(shuffal, "shuffal button is not working");

						Boolean mute=comm.Openlinks(audio.muteBtn);
						s_assert.assertTrue(mute, "mute button is not working");

						Boolean share=comm.Openlinks(audio.shareBtn);{
							Boolean sharelist=comm.getListofLink(audio.getsharebyItem);
							if (sharelist) {
								driver.navigate().back();
							}
							s_assert.assertTrue(sharelist, "share list is not getting");
						}
						s_assert.assertTrue(share, "share button is not working");

						Boolean bsckbtn=comm.Openlinks(comm.BackButtonNative);
						s_assert.assertTrue(bsckbtn, "back button is not working");
					}
					else {
						
						Boolean stopPlayBtn=comm.Openlinks(audio.i_PlayStopCustomeBtn);
						s_assert.assertTrue(stopPlayBtn, "iPlay/Stop button is not working");

						Boolean shuffal=comm.Openlinks(audio.i_shuffalBtn);
						s_assert.assertTrue(shuffal, "ishuffal button is not working");

						Boolean mute=comm.Openlinks(audio.i_muteCustomeBtn);
						s_assert.assertTrue(mute, "imute button is not working");

						Boolean share=comm.Openlinks(audio.i_shareBtn);{
							Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
							s_assert.assertTrue(icancle, "iCancle button is not working.");
						}
						s_assert.assertTrue(share, "share button is not working");
						Boolean bsckbtn=comm.Openlinks(comm.i_BackButtonNative);
						s_assert.assertTrue(bsckbtn, "iback button is not working");
					}

					PageElement.changeContextToWebView(driver);

				}
				s_assert.assertTrue(Custom, "Custom link is not working");
			}
			s_assert.assertTrue(audiomoduleOpen, "Audio module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

}
