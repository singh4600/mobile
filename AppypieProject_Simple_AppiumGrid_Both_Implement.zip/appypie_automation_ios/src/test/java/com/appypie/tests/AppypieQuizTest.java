package com.appypie.tests;

import java.util.Random;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieQuizPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieQuizTest extends TestSetup {

	AppypieQuizPage quiz;
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;

	@BeforeTest
	@Override
	public void pageSetUp() {
		quiz = new AppypieQuizPage(driver);
	}

	@Test
	public void verifyQuizPage() {
		Logger.info("********Test Method Start: verifyQuizPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			boolean Open = quiz.viewWelcomeScreen();
			asser.assertTrue(Open, "Welcome Screen is not visible on opening quiz page");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Quiz page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuizStartPageBtn() {
		Logger.info("********Test Method Start: verifyQuizStartPageBtn********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			Thread.sleep(2000);
			asser.assertNotNull(quiz.checkQuestionsVisibility(),
					"Questions are not displayed after clicking on start quiz button");
		} catch (Exception e) {
			Logger.error("Error occurs while clicking the start Quiz button", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuiztimerAndQuestionCounter() {
		Logger.info("********Test Method Start: verifyQuiztimerAndQuestionCounter********");
		asser = new SoftAssert();
		String timer = null;
		String counter = null;
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
				quiz.clickStartQuizButton();
				timer = quiz.getQuestionCounterAndTimer("timer");
				counter = quiz.getQuestionCounterAndTimer("counter");
			
			asser.assertNotNull(timer, "Quiz timer is not displayed after clicking on start quiz button");
			asser.assertNotNull(counter, "Question counter is not displayed after clicking on start quiz button");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the question counter and timer", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyNoquestionAttemptedandtimerExpire() {
		Logger.info("********Test Method Start: verifyNoquestionAttemptedandtimerExpire********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean result = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			String text = quiz.checkQuestionsVisibility();
			if (text != null) {
				Thread.sleep(21000);
				if (quiz.checkResultPageOpen().equals("Your Result:")) {
					result = true;
					asser.assertTrue(quiz.getCountfromQuestionStatus("notattempt") == 4,
							"All questions are not showing not attempted in quiz answer status field: icon of not attempted questions is not visible for all");
					asser.assertTrue(quiz.getCountFromQuizContent(String.valueOf(5)) == 4, "All questions are not showing skipped in quiz end content block");
					Thread.sleep(2000);
					quiz.clickQuizSubmitOnResultPage();
				}
				asser.assertTrue(result, " Result page is not open after timer expire");
			} else {
				Logger.info("Questions are not open after clicking the startquizbutton");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the result page after not attempting all the questions", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();

	}

	@Test
	public void verifynextAndPreviousButton() {
		Logger.info("********Test Method Start: verifynextAndPreviousButton********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean previous = false;
		boolean next = false;
		String result = "";
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			Thread.sleep(2000);
			quiz.tapNextButton();
			Thread.sleep(2000);
				result = quiz.getQuestionCounterAndTimer("counter");
				Logger.info(result);
			Logger.info("question counter after clicking next button is: "
					+ result.substring(result.indexOf(": ") + 1, result.indexOf("/")));
			if (Integer.parseInt(result.substring(result.indexOf(": ") + 1, result.indexOf("/")).trim()) == 2) {
				next = true;
			}
			Thread.sleep(1000);
			quiz.tapPrevButton();
			Thread.sleep(1000);
			String prevPageresult = quiz.getQuestionCounterAndTimer("counter");
			Logger.info("question counter after clicking previous button is: "
					+ prevPageresult.substring(result.indexOf(": ") + 1, result.indexOf("/")));
			if (Integer.parseInt(prevPageresult.substring(result.indexOf(": ") + 1, result.indexOf("/")).trim()) == 1) {
				previous = true;
			}
			asser.assertTrue(next, "Increased question counter is not visible upon clicking next button");
			asser.assertTrue(previous, "Decreased question counter is not visible upon clicking previous button");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the previous and next button of quiz", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifySubmitWithoutSelectingOption() {
		Logger.info("********Test Method Start: verifySubmitWithoutSelectingOption********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			Thread.sleep(2000);
			quiz.tapSubmitButton();
			asser.assertEquals(quiz.getWarning(), "Please select at least one option");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the submit button without selecting any option", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyMultiSelectOption() {
		Logger.info("********Test Method Start: verifyMultiSelectOption********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean multiselect = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			String firstvalue = quiz.getClickOptions(String.valueOf(1), String.valueOf(0));
			String secondvalue = quiz.getClickOptions(String.valueOf(2), String.valueOf(0));
			if (firstvalue.equals("checked") && secondvalue.equals("checked"))
			{
				multiselect = true;
			}
			asser.assertTrue(multiselect, "multiple options are not selected");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying multiple option select", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuizResultWithAllSkipped() {
		Logger.info("********Test Method Start: verifyQuizResultWithAllSkipped********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean statusCount = false;
		boolean endCount = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			for (int i = 1; i < 4; i++) {
				quiz.tapNextButton();
			}
			quiz.tapfinishButton();
			if (quiz.getCountfromQuestionStatus("skip") == 4) {
				statusCount = true;
			}
			if (quiz.getCountFromQuizContent(String.valueOf(4)) == 4) {
				endCount = true;
			}
			asser.assertTrue(statusCount,
					"All questions are not showing skipped in quiz answer status field: icon of skip questions is not visible for all");
			asser.assertTrue(endCount, "All questions are not showing skipped in quiz end content block");
			Thread.sleep(2000);
			quiz.clickQuizSubmitOnResultPage();
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the quiz result with all questions skipped", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuizResultWithCorrectAndIncorrectQuestions() {
		Logger.info("********Test Method Start: verifyQuizResultWithCorrectAndIncorrectQuestions********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean correct = false;
		boolean incorrect = false;
		boolean quizcomplete = true;
		int questionCount = 0;
		String counter = "";
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			for (int i = 0; i < 4; i++) {
				
					quiz.getClickOptions(String.valueOf(new Random().nextInt(2) + 1), String.valueOf(questionCount));
				
				quiz.tapSubmitButton();
				questionCount++;
			}
			Thread.sleep(3000);			
			counter = quiz.getQuestionCounterAndTimer("counter");
			if (Integer.parseInt(counter.substring(counter.indexOf(": ") + 1, counter.indexOf("/")).trim()) == 4) {
				Logger.info("Quiz completed Successfully");
				quiz.tapfinishButton();
				Thread.sleep(3000);
			} else {
				Logger.error("Quiz is not completed : terminated at middle");
				quizcomplete = false;
			}
			if (quizcomplete) {
				if (quiz.getCountfromQuestionStatus("correct") == quiz.getCountFromQuizContent(String.valueOf(2))) {
					correct = true;
				}
				if (quiz.getCountfromQuestionStatus("incorrect") == quiz.getCountFromQuizContent(String.valueOf(3))) {
					incorrect = true;
				}
				boolean share = quiz.clickShareButton();
				Thread.sleep(2000);
				boolean thankPage = quiz.clickQuizSubmitOnResultPage();
				asser.assertTrue(thankPage,
						"thanks page is not displayed after clicking submit button from result page");
				asser.assertTrue(share, "share button from result page is not working");
				asser.assertTrue(correct,
						"Correct question count is not same at question status and quiz content portion of resultpage");
				asser.assertTrue(incorrect,
						"InCorrect question count is not same at question status and quiz content portion of resultpage");
			} else {
				asser.assertTrue(quizcomplete, "Quiz is not completed :terminated at middle");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the quiz result with correct and incorrect questions", e);
			exception = true;
			try {
				if (quiz.checkResultPageOpen().equals("Your Result:")) {
					Thread.sleep(2000);
					quiz.clickQuizSubmitOnResultPage();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			 
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
			
		}
		asser.assertAll();
	}

	@Test
	public void verifyImagePresentInQuestion() {
		Logger.info("********Test Method Start: verifyImagePresentInQuestion********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			asser.assertTrue(quiz.imageExist(), "Image not exist in the question");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the image in quiz question", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyvideoPresentInQuestion() {
		Logger.info("********Test Method Start: verifyvideoPresentInQuestion********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			for (int i = 0; i < 2; i++) {
				quiz.tapNextButton();
			}
			quiz.clickAudioVideo("video");
			asser.assertTrue(quiz.isAudioVideoExist("video","Quiz"),
					"Youtube player is not open upon clicking video option in question");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the video option in quiz question", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyAudioInQuestion() {
		Logger.info("********Test Method Start: verifyAudioInQuestion********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("");
			quiz.clickStartQuizButton();
			quiz.tapNextButton();
			Thread.sleep(500);
			quiz.clickAudioVideo("audio");
			asser.assertTrue(quiz.isAudioVideoExist("audio","Quiz"),
					"Audio player is not open upon clicking audio option in question");
			Thread.sleep(500);
			quiz.clickQuizSubmitOnResultPage();
		} catch (Exception e) {
			Logger.error("Error occurs while verifying audio option in question", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuizWithNoQuestionDisplayed() {
		Logger.info("********Test Method Start: verifyQuizWithNoQuestionDisplayed********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("invalid");
			asser.assertTrue(quiz.checkInvalidQuiz(), "No data icon is not displayed in case of invalid quiz ");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying audio option in question", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	// @Test
	public void verifyAnswerToastsOnSubmitButton() {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			quiz.openQuizFolder();
			quiz.openQuizPage("withlogin");
			quiz.clickStartQuizButton();
			// try{
			// quiz.getClickOptions(String.valueOf(new
			// Random().nextInt(4)+1),String.valueOf(0));
			// }catch(StaleElementReferenceException ex){
			// Logger.error("stale element exception occurs while clicking the
			// question options in checking answer toast",ex);
			// quiz.getClickOptions(String.valueOf(new
			// Random().nextInt(4)+1),String.valueOf(0));
			// }
			// quiz.tapSubmitButton();
			// quiz.getAnswerToast();
			quiz.swipeScreen();
		} catch (Exception e) {
			Logger.error("Error occurs while verifying audio option in question", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
