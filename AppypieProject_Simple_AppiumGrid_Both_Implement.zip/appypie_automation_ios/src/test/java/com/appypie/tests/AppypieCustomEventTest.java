package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.appypie.pages.AppypieCustomEvent;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;


public class AppypieCustomEventTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieCustomEvent CustomEvent;
	PageElement PE;

	@BeforeTest
	@Override

	public void pageSetUp() {

		CustomEvent = new AppypieCustomEvent(driver);

	}


	@Test(priority=0, description="OPEN CE_MODULE")
	public void verifyCustomEventOpenandback(){
		Logger.info("Test Methods start: CustomEventopen");
		asser= new SoftAssert();
		boolean event = false;
		try {
			event=CustomEvent.identifyCEPageOpen();
			asser.assertTrue(event, "Custom Event page not working");
			if (event) {
				asser.assertFalse(PageElement.tapCEBackButton(driver),"Back button not working on customEvents Page.");
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying the Custom Event page ", e);
			e.getMessage();
			e.printStackTrace();
			event = true;
			Assert.assertFalse(event, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


	@Test(priority=1, description="pagedata")
	public void verifyHeader_PageList() {
		Logger.info("********Test Methods start: verify Pagelist*********");
		asser = new SoftAssert();
		boolean PageData = false;
		try {
			PageData=CustomEvent.identifyCEPageOpen();
			asser.assertTrue(PageData, "Custom Event page not working");
			TimeUnit.SECONDS.sleep(3);
			//asser.assertTrue(PageData, "Custom Event page not working");

			Boolean CEvalue=CustomEvent.CEheader();
			if (!CEvalue==false) {
				CustomEvent.CEheader();
			}
			else
				System.out.println("Get CEheader is Null");
			asser.assertNotNull(CEvalue, "Header getting Null value");

			CustomEvent.getListofLink(CustomEvent.getPageItem);
			asser.assertTrue(PageData, "List not present Custom Event page");
		}catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while clicking on map Button ", e);
			PageData = true;
			Assert.assertFalse(PageData, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();

	}


	@Test(priority=2, description="Map")
	public void verifymapopen() {
		Logger.info("********Test Methods start: verifymap*********");
		asser = new SoftAssert();
		boolean map = false;
		try {
			map=CustomEvent.identifyCEPageOpen();
			asser.assertTrue(map, "Custom Event page not working");
			boolean maP=CustomEvent.identifymapOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(CustomEvent.getListofLink(CustomEvent.mapAdres) , "List not avaliable on map page");
			asser.assertTrue(maP, "map open link not working");
			if (map) {
				boolean mapBack=CustomEvent.clickmapbackbtn();
				asser.assertTrue(mapBack, "Back button not working on map page");
				TimeUnit.SECONDS.sleep(3);
				boolean maoPpen=CustomEvent.identifymapOpen();
				asser.assertTrue(maoPpen, "map open link not working");
				TimeUnit.SECONDS.sleep(3);
				boolean mapAdres=CustomEvent.clickmapaddress();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(mapAdres,"map address link not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable on address page");
				asser.assertFalse(PageElement.tapBackButtonP(driver) , "back button not working on map address");
			}	else {

				Logger.info("map field not working on CE Page");

			}



		}
		catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while clicking on map Button ", e);
			map = true;
			Assert.assertFalse(map, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


	@Test(priority=3, description="Filter Page")
	public void verifyfilterpage() {
		Logger.info("********Test Methods start: verifyfilter*********");
		asser = new SoftAssert();
		boolean filter = false;
		try {
			filter=CustomEvent.identifyCEPageOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(filter, "Custom Event page not working");
			if (filter) {
				boolean openFilter=CustomEvent.identifyfilterOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(openFilter, "Filter link not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable on address page");
				boolean filterBck= CustomEvent.clickfilterbackbtn();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(filterBck, "Filter back not working");
				boolean openFilter2=CustomEvent.identifyfilterOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(openFilter2, "Filter link not working");
				/*boolean date=CustomEvent.opendatefield();
				asser.assertTrue(date, "filter date filed not working");*/

			}

		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while clicking on filtr Button ", e);
			filter = true;
			Assert.assertFalse(filter, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


	@Test(priority=4, description="serch")
	public void verifyLoationsrch() {
		Logger.info("********Test Methods start: verifyLoationsrch*********");
		asser = new SoftAssert();
		boolean LocationSearch = false;
		try {
			LocationSearch=CustomEvent.identifyCEPageOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(LocationSearch, "Custom Event page not working");
			if (LocationSearch) {
				boolean searchHeader=CustomEvent.isserchpageOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(searchHeader,"serch field not working");
				boolean cancelBtn=CustomEvent.serch_cancel_button();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(cancelBtn,"serch cancel not working");
				boolean searchHeader2=CustomEvent.isserchpageOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(searchHeader2,"serch field not working");
				boolean enterSearch=CustomEvent.Enter_on_search();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(enterSearch, "Enter location serch page not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable on address page");
				boolean result=CustomEvent.click_REsult();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(result, "serch result not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "Events not present on this area.");
				boolean mumbali=CustomEvent.mumbai_serc_reslt();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(mumbali, "Workshop page not available");
				asser.assertFalse(PageElement.tapBackButtonP(driver), "Back button not working from worksop");
			}
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while clicking on location Button ", e);
			LocationSearch = true;
			Assert.assertFalse(LocationSearch, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(priority=5, description="home serch")
	public void verifyhomesearch(){
		Logger.info("********Test Methods start: verify home serchh*********");
		asser = new SoftAssert();
		boolean HSearch = false;
		try {
			HSearch=CustomEvent.identifyCEPageOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(HSearch, "Custom Event page not working");
			if (HSearch) {
				boolean homeSerch=CustomEvent.Serchhome();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(homeSerch , "home serch Page not working");
				boolean enterhomeSerch=CustomEvent.Enterhmsrc();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(enterhomeSerch, "Search text filed is not enter data");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable on address page");
				PageElement.tapDeviceOk(driver);
				boolean cmd=CustomEvent.clickcomedy();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(cmd, "Events comedy not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable on address page");
				asser.assertFalse(PageElement.tapBackButtonP(driver), "Back button not working from worksop");

			}
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while clicking on home serch ", e);
			HSearch = true;
			Assert.assertFalse(HSearch, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(priority=6, description="OPEN CEMODULE")
	public void verifyCustomEventSubcategory() {
		Logger.info("Test Methods start: Verify Subcategory page");
		asser = new SoftAssert();
		boolean subcategory = false;
		try {
			subcategory=CustomEvent.identifyCEPageOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(subcategory, "Custom Event page not working");
			boolean verifymenulinks = CustomEvent.identifyMenuOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(verifymenulinks, "Menu link not working");
			if (verifymenulinks) {
				boolean login = LoginUtil.isLogindisplaying(driver);
				if(login){
					LoginUtil.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
					TimeUnit.SECONDS.sleep(3);
				}else {
					System.out.println("User is already login");
					CustomEvent.verifyMenuEvents();
					TimeUnit.SECONDS.sleep(3);
				}
				boolean opnSubcategory = CustomEvent.identifySubCat();
				TimeUnit.SECONDS.sleep(3);
				if (opnSubcategory) {
					asser.assertTrue(opnSubcategory, "Sub category not working on Custom Events page");
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.subcategory_Page_list) , "List not Present Under custom Event Sub Category");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on customEvents Page.");
					TimeUnit.SECONDS.sleep(3);
					CustomEvent.identifySubCat();
					TimeUnit.SECONDS.sleep(3);
					boolean ar= CustomEvent.veriftAR_Rehman();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(ar, "A R Rehman page not opening on App");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "A R Rehman page content not present");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on A r rehman Page.");
					CustomEvent.veriftAR_Rehman();
					TimeUnit.SECONDS.sleep(3);
					boolean bookmark=CustomEvent.veriftbookmarks();
					asser.assertTrue(bookmark, "BookMark link not working on A R Rehman Page");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.Bookmarks_Alert) , "Alert not Present on Bookmarks page");
					CustomEvent.verifybookmarks_alert();
					boolean rat=CustomEvent.verifyRating();
					asser.assertTrue(rat, "Rating link not working on A R Rehman page");
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.User_Rating) , "User Ratings not available for this page");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Rating Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean mp=CustomEvent.verifymap_d();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(mp, "Map link not working on A R Rehman page");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Map Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean sre=CustomEvent.verifyshare();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(sre, "Share link not working on A R Rehman page");
					asser.assertTrue(CustomEvent.Shareback(),"Back button not working on share Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean TC=CustomEvent.verify_termscondition();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(TC, "Terms & Condition enable link not working ");
					boolean TCc=CustomEvent.verify_termscondition();
					asser.assertTrue(TCc, "Terms & Condition disable link not working");
					TimeUnit.SECONDS.sleep(3);
					boolean bb= CustomEvent.verifyBookbutton();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(bb, "Book Button link not working");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Map Page.");
					TimeUnit.SECONDS.sleep(3);
					CustomEvent.verifyBookbutton();
					TimeUnit.SECONDS.sleep(3);
					boolean adrs=CustomEvent.verify_address();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(adrs, "address link not working");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.Tkt_link) , "Ticket classes not present");
					boolean clsic=CustomEvent.verify_classic();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(clsic, "Terms & Condition disable link not working");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Classic Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean gd =CustomEvent.verify_gold();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(gd, "Ticket(gold) link not working");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Gold Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean pltnm=CustomEvent.verify_plattinum();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(pltnm, "Ticket(plattinum) link not working");
					boolean tkt=CustomEvent.verify_Ticket();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(tkt, "Ticket link not working");
					boolean cntn=CustomEvent.verify_continue();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(cntn, "Continue link not working");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "User Ratings not available for this page");
					TimeUnit.SECONDS.sleep(3);
					boolean prmo=CustomEvent.verify_PromoApplybtn();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(prmo, "Promo apply button not working");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.Bookmarks_Alert) , "Alert not Present when user tap on bank promo code");
					CustomEvent.verifybookmarks_alert();
					TimeUnit.SECONDS.sleep(3);
					boolean vrfyprmo =CustomEvent.verify_promo();
					asser.assertTrue(vrfyprmo, "Promo code enter field not working");
					TimeUnit.SECONDS.sleep(3);
					prmo=CustomEvent.verify_PromoApplybtn();
					asser.assertTrue(prmo, "Promo apply button not working after enter value");
					TimeUnit.SECONDS.sleep(3);
					boolean mkpymt=CustomEvent.verify_MakePYMT();
					asser.assertTrue(mkpymt, "Make payment button not working on ");
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(mkpymt, "Guest login Page naot displaying or not on flow of the main menu");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "User Ratings not available for this page");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Guest Login Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean mkpymt2=CustomEvent.verify_MakePYMT();
					asser.assertTrue(mkpymt2, "Make payment button not working on ");
					TimeUnit.SECONDS.sleep(3);
					boolean cnfmPymt=CustomEvent.verify_ConfirmPayment();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(cnfmPymt, "Confirm button not working on guest login page");
					TimeUnit.SECONDS.sleep(3);
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Guest Login Page.");
					TimeUnit.SECONDS.sleep(3);
					if (cnfmPymt) {
						CustomEvent.verify_ConfirmPayment();
						boolean strp=CustomEvent.verify_Stripe();
						TimeUnit.SECONDS.sleep(3);
						asser.assertTrue(strp, "Stripe payment gateway not working");
						boolean pypal=CustomEvent.verify_Paypal();
						TimeUnit.SECONDS.sleep(3);
						asser.assertTrue(pypal, "Paypal payment gateway not working");
						boolean PatC= CustomEvent.verifyPAYatCon();
						TimeUnit.SECONDS.sleep(3);
						asser.assertTrue(PatC, "Pay at counter gateway not working");
						boolean cofrmBtn=CustomEvent.verify_Payatcounter_confirmBtn();
						TimeUnit.SECONDS.sleep(3);
						asser.assertTrue(cofrmBtn, "confirm button not working on payment gateway page");

					} else {
						System.out.println("Payment gateway not working perfectly");

					}

				}else {
					System.out.println("error occurs while verifying content under subcategory page");
				}		
			}

		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while verifying the Page", e);
			subcategory = true;
			Assert.assertFalse(subcategory, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(priority=7, description="Free Events")
	public void verifyFreeEvents() {
		Logger.info("Test Methods start: Verify Free Events page");
		asser = new SoftAssert();
		boolean FreeEvents = false;
		try {
			FreeEvents=CustomEvent.identifyCEPageOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(FreeEvents, "Custom Event page not working");
			boolean verifymenulinks = CustomEvent.identifyMenuOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(verifymenulinks, "Menu link not working");
			if (verifymenulinks) {
				boolean login = LoginUtil.isLogindisplaying(driver);
				if(login){
					LoginUtil.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				}else {
					System.out.println("User is already login");
					CustomEvent.verifyMenuEvents();
				}
				TimeUnit.SECONDS.sleep(3);
				boolean Free_seminar = CustomEvent.identifyFreeSeminarOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaible on free seminar page");
				asser.assertTrue(Free_seminar, "Free Events page not working");
				if (Free_seminar) {
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Guest Login Page.");
					TimeUnit.SECONDS.sleep(3);
					CustomEvent.identifyFreeSeminarOpen();
					TimeUnit.SECONDS.sleep(3);

					boolean FreeEbook=CustomEvent.verifyBookbutton();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "Dates not available under free seminar");
					asser.assertTrue(FreeEbook , "Book button not working on working");
					boolean addres=CustomEvent.verify_address();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "Tickets type not available");
					asser.assertTrue(addres , "Book button not working on working");
					boolean clsic=CustomEvent.verify_classic();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "Tickets numbers not available");
					asser.assertTrue(clsic , "Address link not clickable");
					boolean cntnue=CustomEvent.verify_continue();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "Tist not avaible on Review booking page");
					asser.assertTrue(cntnue , "continue button not clickable");
					boolean BkBtn=CustomEvent.verifyBookBtnReviewPage();
					asser.assertTrue(BkBtn , "Book button to payment page not clickable");
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable Guest login page");
					boolean cnfrmBtn=CustomEvent.verify_ConfirmPayment();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(cnfrmBtn , "Confirm payment link not clickable");

					boolean Fcnfrm=CustomEvent.verify_F_Confirm();
					asser.assertTrue(Fcnfrm , "Final Confirmation link not clickable");
				}
			}
		}catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while verifying Free Events ", e);
			FreeEvents = true;
			Assert.assertFalse(FreeEvents, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}




	@Test(priority=8, description="Menu Page")
	public void VerifyMenuPage() {
		Logger.info("Test Methods start: Verify Menu page");
		asser = new SoftAssert();
		boolean MenuPage = false;
		try {
			MenuPage=CustomEvent.identifyCEPageOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(MenuPage, "Custom Event page not working");
			boolean verifymenulinks = CustomEvent.identifyMenuOpen();
			TimeUnit.SECONDS.sleep(3);
			asser.assertTrue(verifymenulinks, "Menu link not working");
			if (verifymenulinks) {
				boolean login = LoginUtil.isLogindisplaying(driver);
				if(login){
					LoginUtil.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				}else {
					System.out.println("User is already login");
					boolean MEvents= CustomEvent.verifyMenuEvents();
					asser.assertTrue(MEvents, "Events Menu link not working");
				}
				TimeUnit.SECONDS.sleep(3);
				boolean MenuLinks = CustomEvent.identifyMenuOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(MenuLinks, "Menu link not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable under menu page");
				boolean Mevents= CustomEvent.verifyMenuEvents();
				asser.assertTrue(Mevents, "Events Menu link not working");
				TimeUnit.SECONDS.sleep(3);
				CustomEvent.identifyMenuOpen();
				boolean mybking=CustomEvent.verifyMyBooking();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(mybking , "My Booking link not clickable");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable under menu page");
				if (mybking) {
					boolean attendent=CustomEvent.verifyAttended();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(attendent , "Attendent link not clickable");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable under Attendent page");
					boolean re_book= CustomEvent.verifyReBook();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(re_book , "Rebook link not clickable");
					asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable when re-book through my booking");
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on Re-Book Page.");
					TimeUnit.SECONDS.sleep(3);
					boolean vrfyReview=CustomEvent.verifyPostReview();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(vrfyReview , "Post a Review link not clickable");
					TimeUnit.SECONDS.sleep(3);
					if (vrfyReview) {
						asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable under menu page");
						boolean review=CustomEvent.clickReview5();
						TimeUnit.SECONDS.sleep(3);
						asser.assertTrue(review, "Review5 button not working");
						boolean reviewField=CustomEvent.WriteReview();
						asser.assertTrue(reviewField, "Enter Reviw field not working not working");
						TimeUnit.SECONDS.sleep(3);
						boolean postRvew =CustomEvent.VerifyPostReviewBtn();
						TimeUnit.SECONDS.sleep(3);
						asser.assertTrue(postRvew, "conrirm review button not working");
						boolean alert=CustomEvent.getListofLink(CustomEvent.Bookmarks_Alert);
						asser.assertTrue(alert, "Confirm post review alert not Showing");
						boolean alertOk=CustomEvent.verifybookmarks_alert();
						asser.assertTrue(alertOk, "Ok button not working on after post review");
						asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "Newely added list not avaliable under review page");
						asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on reviews page Page.");
					} else {
						System.out.println("Reiew page not opens in flow of main menu");
					}
					TimeUnit.SECONDS.sleep(3);

					boolean upcmg=CustomEvent.verifyUpcoming();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(upcmg, "Upcoming link not working");
					boolean clendr=CustomEvent.verify_AddToCalender();
					TimeUnit.SECONDS.sleep(3);
					asser.assertTrue(clendr, "Add To Calender link not working");
					boolean alertOk=CustomEvent.verifybookmarks_alert();
					asser.assertTrue(alertOk, "Ok button not working on after Add to calender");
					TimeUnit.SECONDS.sleep(3);
					asser.assertFalse(PageElement.tapBackButtonP(driver),"Back button not working on my bookings page .");
					TimeUnit.SECONDS.sleep(3);
				} else {
					System.out.println("My booking page not opens in flow of the main menu");
				}
				CustomEvent.identifyMenuOpen();
				boolean menuBkmarks=CustomEvent.verifyMenuBookmarks();	
				TimeUnit.SECONDS.sleep(3);	
				asser.assertTrue(menuBkmarks, "Upcoming link not working");
				asser.assertTrue(CustomEvent.getListofLink(CustomEvent.getpageItem) , "List not avaliable under menu page");
				boolean openbookmarks=CustomEvent.verifyBookmarksopen();
				asser.assertTrue(openbookmarks, "Bookmarks page not open");
				TimeUnit.SECONDS.sleep(3);	
				boolean remove=CustomEvent.verifyMenuBookmarksRemove();
				TimeUnit.SECONDS.sleep(3);	
				asser.assertTrue(remove, "Bookmarks remove button not clickable");
				TimeUnit.SECONDS.sleep(3);
				boolean alert=CustomEvent.getListofLink(CustomEvent.Bookmarks_Alert);
				asser.assertTrue(alert, "Bookmarks remove alert not present");
				boolean alertOk=CustomEvent.verifybookmarks_alert();
				asser.assertTrue(alertOk, "Bookmarks Ok button not working");
				TimeUnit.SECONDS.sleep(3);
				boolean backBkmarks=CustomEvent.verifyBookmarksBack();
				asser.assertTrue(backBkmarks, "Bookmarks Back button not working when user removed bookmarks");
				TimeUnit.SECONDS.sleep(3);
				boolean MenuLinks3 = CustomEvent.identifyMenuOpen();
				TimeUnit.SECONDS.sleep(3);
				asser.assertTrue(MenuLinks3, "Menu Page not working for checking cross button");
				boolean croosBtn=CustomEvent.verifyMenuCrossBtn();
				asser.assertTrue(croosBtn , "Cross button not working on menu page");
				TimeUnit.SECONDS.sleep(3);
			}
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			Logger.error("Error occurs while Menu page ", e);
			MenuPage = true;
			Assert.assertFalse(MenuPage, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
