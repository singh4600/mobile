package com.appypie.tests;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMapPage;
import com.appypie.pages.directoryHyperLocalpages.AppHomePage;
import com.appypie.pages.directoryHyperLocalpages.BookMarkPage;
import com.appypie.pages.directoryHyperLocalpages.CheckInPage;
import com.appypie.pages.directoryHyperLocalpages.DirectoryLoginPage;
import com.appypie.pages.directoryHyperLocalpages.DirectoryMainMenuPage;
import com.appypie.pages.directoryHyperLocalpages.FilterIconPage;
import com.appypie.pages.directoryHyperLocalpages.FilterResultPage;
import com.appypie.pages.directoryHyperLocalpages.HomePage;
import com.appypie.pages.directoryHyperLocalpages.HyperLocalPostJobPage;
import com.appypie.pages.directoryHyperLocalpages.HyperLocalRequestQuoteForm;
import com.appypie.pages.directoryHyperLocalpages.ListingDetailPage;
import com.appypie.pages.directoryHyperLocalpages.LocationPage;
import com.appypie.pages.directoryHyperLocalpages.ProfilePage;
import com.appypie.pages.directoryHyperLocalpages.RatingAndReviewPage;
import com.appypie.pages.directoryHyperLocalpages.SubCategoryAndListingPage;
import com.appypie.pages.directoryHyperLocalpages.UpdateListingPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.ios.IOSTouchAction;

public class AppypieHyperLocalTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();

	HomePage home;
	HyperLocalPostJobPage postJob;
	CheckInPage checkIn;
	AppHomePage appMenu;
	DirectoryMainMenuPage mainMenu;
	FilterIconPage filter;
	LocationPage loc;
	ProfilePage profile;
	RatingAndReviewPage rate;
	SubCategoryAndListingPage subCat;
	DirectoryLoginPage login;
	FilterResultPage result;
	ListingDetailPage listDetail;
	BookMarkPage bookmark;
	UpdateListingPage updateList;
	HyperLocalRequestQuoteForm enquiry;

	SoftAssert asser;
	String deleteMsg="Are you sure you want to delete this record?";

	@BeforeTest
	@Override
	public void pageSetUp() {
		home = new HomePage(driver);
		postJob = new HyperLocalPostJobPage(driver);
		checkIn = new CheckInPage(driver);
		appMenu = new AppHomePage(driver);
		mainMenu = new DirectoryMainMenuPage(driver);
		filter = new FilterIconPage(driver);
		loc = new LocationPage(driver);
		profile = new ProfilePage(driver);
		rate = new RatingAndReviewPage(driver);
		subCat = new SubCategoryAndListingPage(driver);
		login = new DirectoryLoginPage(driver);
		result = new FilterResultPage(driver);
		listDetail = new ListingDetailPage(driver);
		bookmark = new BookMarkPage(driver);
		updateList = new UpdateListingPage(driver);
		enquiry = new HyperLocalRequestQuoteForm(driver);
	}

	@Test
	public void verifyPostJobPagefeatures() {
		Logger.info("********Test Methods start: verifyPostJobPagefeatures********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.openPageMenu("hyperlocal");
				boolean menuOpen = mainMenu.isMainMenuOpen("hyperlocal");
				if (menuOpen) {
					boolean login = verifyHyperlocalLogin("hyperlocal");
					if (login) {
						mainMenu.clickPostJob();
						boolean pageOpen= postJob.isPostJobPageOpen();
						if(pageOpen) {
						// *** verification of image Upload****
						asser.assertTrue(postJob.imageUploadinPostJob(), "image upload in post job is not working");

						// *** verification of youtubeurl****
						postJob.clickYouTubeOption();
						asser.assertTrue(postJob.isYouTubeHolderExist(), "youtube option in post job is not working");

						// *** verification of addmoreurl****
						postJob.clickAddMore("url");
						Thread.sleep(1000);
						asser.assertTrue(postJob.getelementCount("url") == 2, "addmore in url doesn't open second field");
						postJob.clickCloseAddMore("url");
						Thread.sleep(1000);
						asser.assertTrue(postJob.getelementCount("url") == 1,
								"close addmore in url doesn't close second field");

						// *** verification of addmoreemail****
						postJob.clickAddMore("email");
						Thread.sleep(1000);
						asser.assertTrue(postJob.getelementCount("email") == 2, "addmore in email doesn't open second field");
						postJob.clickCloseAddMore("email");
						Thread.sleep(1000);
						asser.assertTrue(postJob.getelementCount("email") == 1,
								"close addmore in email doesn't close second email");

						// *** verification of addmorePhone****
						postJob.clickAddMore("phone");
						Thread.sleep(1000);
						asser.assertTrue(postJob.getelementCount("phone") == 2, "addmore in phone doesn't open second field");
						postJob.clickCloseAddMore("phone");
						Thread.sleep(1000);
						asser.assertTrue(postJob.getelementCount("phone") == 1,
								"close addmore in phone doesn't close second email");

						// *** verification of ScheduleHourCheckBox****
							postJob.clickScheduleHourCheckbox();
							asser.assertTrue(postJob.isScheduleHoursDisplayed(),
									"Jobs schedule hours are not displayed upon clicking on checkbox");
							postJob.clickScheduleHourCheckbox();
						} else {
							asser.assertTrue(pageOpen, "Hyperlocal post job page is not open from main menu");
						}
					} else {
						Logger.info("Hyperlocal login is not successfull");
						asser.assertTrue(login, "Hyperlocal login is not successful");
					}
				} else {
					Logger.info("Hyperlocal menu is not open upon clicking on menu button from hyperlocal home page");
					asser.assertTrue(menuOpen, "hyperlocal menu is not open");
				}
			} else {
				Logger.info("Hyperlocal page is not open in app");
				asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
			}

		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the post job in hyperlocal", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyPostJob() {
		Logger.info("********Test Methods start: verifyPostJob********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.openPageMenu("hyperlocal");
				boolean menuOpen = mainMenu.isMainMenuOpen("hyperlocal");
				if (menuOpen) {
					boolean login = verifyHyperlocalLogin("hyperlocal");
					if (login) {
						mainMenu.clickPostJob();
						boolean pageOpen= postJob.isPostJobPageOpen();
						if(pageOpen) {	
							// ****** verification of submission of blankForm******
							postJob.submitJob();
							String blankForm_text=PageElement.getWarningText(driver);
							asser.assertEquals(blankForm_text, "Please select a job category");
							if(blankForm_text!="")
							PageElement.closeWarningSingleBtn(driver,"Ok");
							Thread.sleep(1000);

							// ****** verification of submission of form without mandatory fields******
							postJob.selectCategory("four");
							Thread.sleep(2000);
							postJob.submitJob();
							String text = PageElement.getWarningText(driver);
							asser.assertEquals(text, "Please enter a valid job title");
							if (text != "")
								PageElement.closeWarningSingleBtn(driver,"Ok");
							Thread.sleep(1000);
							
							// ****** verification of submission of jobs******
							postJob.selectCategory("one");
							Thread.sleep(1000);
							postJob.selectSubCategory();
							postJob.enterTtile("AutomationTest");
							postJob.enterBudget("OPEN VAULT");
							//postJob.enterYouTubeUrl();
							postJob.enterUrl("www.google.com");
							postJob.enterEmail("aa@aa.com");
							postJob.enterPhone("3728293392");
							postJob.clickYouTubeOption();
							Thread.sleep(2000);
							postJob.submitJob();
							String text_submit = PageElement.getWarningText(driver);
							asser.assertEquals(text_submit, "Job posted successfully","list is not added or taking too much time:");
							if (text_submit != "")
								PageElement.closeWarningSingleBtn(driver,"Ok");
							Thread.sleep(1000);
						} else {
							asser.assertTrue(pageOpen, "Hyperlocal post job page is not open from main menu");
						}
					} else {
						Logger.info("Hyperlocal login is not successfull");
						asser.assertTrue(login, "Hyperlocal login is not successful");
					}
				} else {
					Logger.info("Hyperlocal menu is not open upon clicking on menu button from hyperlocal home page");
					asser.assertTrue(menuOpen, "hyperlocal menu is not open");
				}
			} else {
				Logger.info("Hyperlocal page is not open in app");
				asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
			}

		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the post job in hyperlocal", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	public boolean verifyHyperlocalLogin(String page) {
		boolean success = false;
		try {
			if (!mainMenu.isDirectoryLogin()) {
				mainMenu.clickDirectoryLogin();
				boolean loginPageOpen = login.isDirectoryLoginOpen();
				if (loginPageOpen) {
					login.loginDirectory("pk@pk.com", "12345678");
					if (login.isLoginSuccess()) {
						success = true;
						Thread.sleep(2000);
						home.openPageMenu(page);
						Thread.sleep(2000);
					}
				} else {
					Logger.info("login page is not open upon clicking on login from menu");
				}
			} else {
				Logger.info("User is already login in the app");
				success = true;
			}

		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the Directory login", ex);
		}
		return success;
	}
	
	@Test(dependsOnMethods = { "verifyPostJobPagefeatures" }, alwaysRun = true)
	public void verifyUpdateJobFeature() {
		Logger.info("********Test Methods start: verifyUpdateJobFeature********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.openPageMenu("hyperlocal");
				boolean menuOpen = mainMenu.isMainMenuOpen("hyperlocal");
				if (menuOpen) {
					boolean login = verifyHyperlocalLogin("hyperlocal");
					if (login) {
						// *** verification of update list open from main menu****
						mainMenu.clickupdateJob();
						List<Boolean> updateJobOpen = updateList.isUpdateListingPageOpen("hyperlocal");
						asser.assertTrue(updateJobOpen.get(0) || updateJobOpen.get(1),
								"update job page is not open from main menu");

						// *** verification of recently added list in update list****
						if (updateJobOpen.get(0)) {
							asser.assertEquals(updateList.getListHeading(), "AutomationTest",
									"recently added job is not found in update job");

							// *** verification of update listing****
							updateList.clickList("hyperlocal");
							boolean postJobOpen = postJob.isPostJobPageOpen();
							if (postJobOpen) {
								updateList.updateJobTitle();
								updateList.submitUpdateListForm("hyperlocal");
								String updateJobtext = PageElement.getWarningText(driver);
								boolean alertOpen=false;
								if (updateJobtext != "") {
									alertOpen=true;
									PageElement.closeWarningSingleBtn(driver,"Ok");
									Thread.sleep(1000);
									if (updateJobtext.toUpperCase().equals("Already exist".toUpperCase())) {
										PageElement.tapBackButton(driver);
										Thread.sleep(500);
									} else {
										asser.assertEquals(updateJobtext.toUpperCase(),"Job posted successfully".toUpperCase());
										asser.assertEquals(updateList.getListHeading(), "UpdateJobAutomation",
												"Job is not updated");
									}
								} else {
									Logger.error("Update job pop doesn't appear");
									asser.assertTrue(alertOpen, "update job pop doesn't appear");
									PageElement.tapBackButton(driver);
									Thread.sleep(500);
								}
								
								// *** verification of delete listing****
								updateList.deleteListing("hyperlocal");
								String text = PageElement.getWarningText(driver);
								asser.assertEquals(text, deleteMsg, "Delete job poppup doesn't appear");
								if (text != "")
									updateList.clickDeleteButtonOnPopup();
								Thread.sleep(500);
								asser.assertTrue(home.isHomePageOpen(),
										"Hyperlocal home page is not open after deleting the list: no job to update");
							} else {
								Logger.info("job update is not working while updating from update job in main menu");
								asser.assertTrue(postJobOpen, "post Job page is not open from update jobs");
							}
						} else {
							Logger.info("No job is present for update: NO data icon is visible ");
						}
					} else {
						Logger.info("Hyperlocal login is not successfull");
						asser.assertTrue(login, "Hyperlocal login is not successful");
					}
				} else {
					Logger.info("Hyperlocal menu is not open upon clicking on menu button from hyperlocal home page");
					asser.assertTrue(menuOpen, "hyperlocal menu is not open");
				}
			} else {
				Logger.info("Hyperlocal page is not open in app");
				asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
			}

		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the update jobs in hyperlocal", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyHomeandMainCategoryInHyperlocalMenu() {
		Logger.info("********Test Methods start: verifyHomeandMainCategoryInHyperlocalMenu********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.openPageMenu("hyperlocal");
				boolean menuOpen = mainMenu.isMainMenuOpen("hyperlocal");
				if (menuOpen) {
					mainMenu.clickMainCategory();
					asser.assertTrue(home.isHomePageOpen(),	"Home page is not open upon clicking on main menu in hyperlocal");
//					Thread.sleep(1000);
//					home.openPageMenu("hyperlocal");
//					mainMenu.clickHome();
//					asser.assertTrue(appMenu.isHyperlocalExist(), " Home is not working in hyperlocal menu");
				} else {
					Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
					asser.assertTrue(menuOpen, "Directory menu is not open");
				}
			} else {
				Logger.info("Hyperlocal page is not open in app");
				asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying home and menu button from hyperlocal menu",ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyDistanceFilterFunctionalitiesInHyperlocal() {
		Logger.info("********Test Methods start: verifyDistanceFilterFunctionalitiesInHyperlocal********");
		asser = new SoftAssert();
		boolean exception = false;
		int x=0;
		int y=0;
		int backX=0;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.clickFilterIcon();
				boolean filterPageOpen = filter.isFilterPageOpen();
				if (filterPageOpen) {
					// *************verify backward movement of Distance Slider***********
					String frange = filter.getRangeValue("hyperlocal");
					driver.context("NATIVE_APP");
					Dimension size = driver.manage().window().getSize();
					Logger.info("width of the page " + size.width);
					if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
						x = (int) (size.width * .5925);
						y = (int) (size.width * .5324);
						backX = (int) (size.width * .6972);
					} else {
						x = (int) (size.width * .54);
						y = (int) (size.width * .435);
						backX = (int) (size.width * .665);
					}
					PageElement.changeContextToWebView(driver);
					filter.moveDistanceSlider("hyperlocal",x, y);
					Thread.sleep(1000);
					
					String fnewRange = filter.getRangeValue("hyperlocal");
					asser.assertTrue(filter.getNumeralRange(fnewRange) < filter.getNumeralRange(frange),
							"Distance is not increased with moving distance slider forward");
                   
					// *************verify forward movement of Distance Slider***********
					String brange = filter.getRangeValue("hyperlocal");
					filter.moveDistanceSlider("hyperlocal",backX, y);
					Thread.sleep(1000);
					String bnewRange = filter.getRangeValue("hyperlocal");
					asser.assertTrue(filter.getNumeralRange(bnewRange) > filter.getNumeralRange(brange),
							"Distance is not Decreased with moving distance slider backward");

					// *************verify KM Button***********
					filter.clickKm();
					asser.assertTrue(filter.getRangeValue("hyperlocal").contains("KM"),
							"KM button is not chnaging range into KM");

					// *************verify Miles Button***********
					filter.clickMiles();
					asser.assertTrue(filter.getRangeValue("hyperlocal").contains("Miles"),
							"Miles button is not chnaging range into Miles");

					// *************verify Distance Search***********
					filter.clickSearch("distance");
					asser.assertTrue(result.isFilterResultPageOpen().get(0) || result.isFilterResultPageOpen().get(1),
							"Filter result page is not open from distance search in directory");
				} else {
					Logger.info("Filter page is not open from Hyperlocal home page");
					asser.assertTrue(filterPageOpen, "Filter page is not open from hyperlocal home page");
				}
			} else {
				Logger.info("Hyperlocal page is not open in app");
				asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying the distance filter page functionalities in Hyperlocal", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	//------Prince(start)
	
	@Test
	
	public void verifyDistanceFilterFunctionalities_Hyperlocal() {
		Logger.info("********Test Methods start: verifyDistanceFilterFunctionalitiesInHyperlocal********");
		asser = new SoftAssert();
		boolean filterPage = false;
		int x=0;
		int y=0;
		int backX=0;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.clickFilterIcon();
				boolean filterPageOpen = filter.isFilterPageOpen();
				asser.assertTrue(filterPageOpen, "Filter Page not working");
				if (filterPageOpen) {
					filter.clickMiles();
					asser.assertTrue(filterPageOpen, "miles button not working");
					boolean dis=filter.clickDistanceAll();
					asser.assertTrue(dis, "Distance all button not working");
					boolean tapOnfilter=filter.clickFilter();
					asser.assertTrue(tapOnfilter, "Filter button not working");
					Thread.sleep(3000);
					asser.assertFalse(PageElement.tapBackButtonP(driver) , "back button not working on filterd page");
					Thread.sleep(2000);
					
					  //-------Verify custom Range--------
					home.clickFilterIcon();
					boolean filterPageOpen1 = filter.isFilterPageOpen();
					asser.assertTrue(filterPageOpen1, "Filter Page not working");
					if (filterPageOpen1) {
						filter.clickKm();
						asser.assertTrue(filterPageOpen1, "miles button not working");
						boolean cus=filter.clickCustom();
						asser.assertTrue(cus, "Custom distance field button not working");
						
						Thread.sleep(3000);
						
						filter.moveDistanceSlider("price",x, y);
						Thread.sleep(1000);
						
					
					
						boolean tapOnfilter1=filter.clickFilter();
						asser.assertTrue(tapOnfilter1, "Filter button not working");
						asser.assertFalse(PageElement.tapBackButtonP(driver) , "back button not working on filterd page");
						Thread.sleep(2000);
						
					} else {
							Logger.info("Filter page not opens up after clicking on back button");
					}

					}
				}
			
		} catch (Exception e) {
			Logger.error("Exception occurs while verifying the distance filter page functionalities in Hyperlocal", e);
			e.getMessage();
			e.printStackTrace();
			filterPage = true;
			Assert.assertFalse(filterPage,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
//------Prince(end)-----
	
	@Test
	public void verifyRatingFilterFunctionalitiesInHyperlocal() {
		Logger.info("********Test Methods start: verifyRatingFilterFunctionalitiesInHyperlocal********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			boolean homePage = home.isHomePageOpen();
			if (homePage) {
				home.clickFilterIcon();
				boolean filterPageOpen = filter.isFilterPageOpen();
				if (filterPageOpen) {
					filter.openRatingTab();
					boolean ratingTabOpen = filter.isRatingTabOpen();
					if (ratingTabOpen) {
						// *************verify search without select rating***********
						filter.clickSearch("rating");
						String text=PageElement.getWarningText(driver);
						 asser.assertEquals(text, "Please rate before posting the review");
						 if(!text.equals(""))
						PageElement.closeWarningSingleBtn(driver,"Ok");
						Thread.sleep(1000);

						// *************verify search with rating***********
						filter.clickRating1();
						filter.clickSearch("rating");
						List<Boolean> filterResultOpen = result.isFilterResultPageOpen();
						asser.assertTrue(filterResultOpen.get(0) || filterResultOpen.get(1),
								"Filter result page is not open from Rating search in Hyperlocal");

						// *************verify Filter Result Page***********
						if (filterResultOpen.get(0)) {
							result.clickOnLocation();
							asser.assertTrue(result.isMapOpen("Filter Results"),
									"Google map is not open from filter result page in Hyperlocal");
						} else {
							Logger.info("No data icon is visible on filter result page");
						}
					} else {
						Logger.info("Rating tab is not open from Hyperlocal filter page");
						asser.assertTrue(ratingTabOpen, "Rating tab is not open from Hyperlocal filter page");
					}
				} else {
					Logger.info("Filter page is not open from Hyperlocal home page");
					asser.assertTrue(filterPageOpen, "Filter page is not open from hyperlocal home page");
				}
			} else {
				Logger.info("Hyperlocal page is not open in app");
				asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying the rating filter page functionalities in Hyperlocal", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	   @Test
		public void verifypriceFilterFunctionalitiesInHyperlocal() {
			Logger.info("********Test Methods start: verifypriceFilterFunctionalitiesInHyperlocal********");
			asser = new SoftAssert();
			boolean exception = false;
			int x=0;
			int y=0;
			int backX=0;
			try {
				appMenu.openHyperlocal();
				boolean homePage = home.isHomePageOpen();
				if (homePage) {
					home.clickFilterIcon();
					boolean filterPageOpen = filter.isFilterPageOpen();
					if (filterPageOpen) {
						filter.openPriceTab();
						// *************verify forward movement of Distance Slider***********
						String frange = filter.getRangeValue("price");
						driver.context("NATIVE_APP");
						Dimension size = driver.manage().window().getSize();
						Logger.info("width of the page " + size.width);
					if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
						x = (int) (size.width * .6972);
						y = (int) (size.width * .5324);
						backX = (int) (size.width * .5462);
					} else {
						x = (int) (size.width * .665);
						y = (int) (size.width * .435);
						backX = (int) (size.width * .54);
					}
						PageElement.changeContextToWebView(driver);
						filter.moveDistanceSlider("price",x, y);
						Thread.sleep(1000);
						
						String fnewRange = filter.getRangeValue("price");
						System.out.println("filter range is "+fnewRange);
						System.out.println("filter old range is "+frange);
						asser.assertTrue(filter.getNumeralRange(fnewRange) > filter.getNumeralRange(frange),
								"Distance is not increased with moving distance slider forward");

						// *************verify backward movement of Distance Slider***********
						String brange = filter.getRangeValue("price");
						filter.moveDistanceSlider("price",backX, y);
						Thread.sleep(1000);
						String bnewRange = filter.getRangeValue("price");
						asser.assertTrue(filter.getNumeralRange(bnewRange) < filter.getNumeralRange(brange),
								"Distance is not Decreased with moving distance slider backward");

						// *************verify price Search***********
						filter.clickSearch("price");
						List<Boolean> filterResultOpen = result.isFilterResultPageOpen();
						asser.assertTrue(filterResultOpen.get(0) || filterResultOpen.get(1),
								"Filter result page is not open from distance search in directory");
						
						// *************verify Filter Result Page***********
						if (filterResultOpen.get(0)) {
							result.clickOnLocation();
							asser.assertTrue(result.isMapOpen("Filter Results"),
									"Google map is not open from filter result page in Hyperlocal");
						} else {
							Logger.info("No data icon is visible on filter result page");
						}
					} else {
						Logger.info("Filter page is not open from Hyperlocal home page");
						asser.assertTrue(filterPageOpen, "Filter page is not open from hyperlocal home page");
					}
				} else {
					Logger.info("Hyperlocal page is not open in app");
					asser.assertTrue(homePage, "hyperlocal page is not open from app menu");
				}
			} catch (Exception ex) {
				Logger.error("Exception occurs while verifying the price filter page functionalities in Hyperlocal", ex);
				exception = true;
				Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
			}
			asser.assertAll();
		}
		
	    @Test
		public void verifyLocationSearchOnHyperlocalHomePage() {
			Logger.info("********Test Methods start: verifyLocationSearchOnHyperlocalHomePage********");
			asser = new SoftAssert();
			boolean exception = false;
			try {
				appMenu.openHyperlocal();
				boolean homePageOpen = home.isHomePageOpen();
				if (homePageOpen) {
					home.openLocation();
					boolean open = loc.islocationOpen();
					if (open) {
						loc.typeSearchData("noida");
						PageElement.tapDeviceOk(driver);
						Thread.sleep(4000);
						boolean data = loc.isSearchDataAvailable();
						if (data) {
							loc.ClickSearchData();
							List<Boolean> resultPageOpen = result.isFilterResultPageOpen();
							asser.assertTrue(resultPageOpen.get(0) || resultPageOpen.get(1),"Serach option is not working from location tab");
						} else {
							asser.assertTrue(data, "Search data is not available in location search");
						}
					} else {
						asser.assertTrue(open, "location tab is not open from directory home page");
					}
				} else {
					Logger.info("Hyperlocal Home page is not open");
					asser.assertTrue(homePageOpen, "Directory page is not open in the app");
				}
			} catch (Exception ex) {
				Logger.error("exception occurs while verifying location search on hyperlocal home page", ex);
				exception = true;
				Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
			}
			asser.assertAll();
		}
	    
	@Test
	public void verifySearchOnHyperlocalHomePage() {
		Logger.info("********Test Methods start: verifySearchOnHyperlocalHomePage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			boolean homePageOpen = home.isHomePageOpen();
			if (homePageOpen) {
				home.clickOnSerach("hyperlocal");
				asser.assertTrue(home.isSearchTextDisplayed(),
						"search text box is not diplayed upon clicking on search button on hyperlocal home page");
				home.typeOnSearch("hyperlocal", "Noida");
				Thread.sleep(1000);
				PageElement.tapDeviceOk(driver);
				List<Boolean> resultPageOpen = result.isFilterResultPageOpen();
				asser.assertTrue(resultPageOpen.get(0) || resultPageOpen.get(1),
						"Serach option is not working from hyperlocal home page");
			} else {
				Logger.info("Hyperlocal Home page is not open");
				asser.assertTrue(homePageOpen, "Directory page is not open in the app");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying search on hyperlocal home page", ex);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

		@Test
		public void verifyCloseBtnOnSearchInHyperlocal() {
			Logger.info("********Test Methods start: verifyCloseBtnOnSearchInHyperlocal********");
			asser = new SoftAssert();
			boolean exception = false;
			try {
				appMenu.openHyperlocal();
				boolean homePageOpen = home.isHomePageOpen();
				if (homePageOpen) {
					home.openLocation();
					boolean open = loc.islocationOpen();
					if (open) {
						loc.closeLocationTab();
						boolean homePageOpenAgain = home.isHomePageOpen();
						if (homePageOpenAgain) {
							home.openPageMenu("hyperlocal");
							boolean openMenu = mainMenu.isMainMenuOpen("hyperlocal");
							if (openMenu) {
								mainMenu.closeMainMenu();
								asser.assertTrue(home.isHomePageOpen(),"close button on main menu is not working");
							} else {
								asser.assertTrue(openMenu, "hyperlocal menu is not open");
							}
						} else {
							asser.assertTrue(homePageOpen, "Close button is not working on location tab");
						}
					} else {
						asser.assertTrue(open, "location tab is not open from hyperlocal home page");
					}
				} else {
					Logger.info("hyperlocal Home page is not open");
					asser.assertTrue(homePageOpen, "hyperlocal page is not open in the app");
				}
			} catch (Exception ex) {
				Logger.error("exception occurs while verifying close buttons on search in hyperlocal", ex);
				exception = true;
				Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
			}
			asser.assertAll();
		}
		
		@Test
		public void verifyHyperlocalMenuSearch() {
			Logger.info("********Test Methods start: verifyHyperlocalMenuSearch********");
			asser = new SoftAssert();
			boolean exception = false;
			try {
				appMenu.openHyperlocal();
				boolean homePageOpen = home.isHomePageOpen();
				if (homePageOpen) {
					home.openPageMenu("hyperlocal");
					boolean menuOpen = mainMenu.isMainMenuOpen("hyperlocal");
					if (menuOpen) {
					mainMenu.typeSearchData("ddd");
					PageElement.tapDeviceOk(driver);
					List<Boolean> resultPageOpen = result.isFilterResultPageOpen();
					asser.assertTrue(resultPageOpen.get(0) || resultPageOpen.get(1),"Serach option is not working from hyperlocalmenu");
					} else {
						Logger.info("hyperlocal menu is not open upon clicking on menu button from directory home page");
						asser.assertTrue(menuOpen, "hyperlocal menu is not open");
					}
				} else {
					Logger.info("hyperlocal Home page is not open");
					asser.assertTrue(homePageOpen, "hyperlocal page is not open in the app");
				}
			} catch (Exception ex) {
				Logger.error("exception occurs while verifying search on main menu in hyperlocal", ex);
				exception = true;
				Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
			}
			asser.assertAll();
		}
		
		@Test
		public void verifyBookmarkInHyperlocal() {
			Logger.info("********Test Methods start: verifyBookmarkInHyperlocal********");
			asser = new SoftAssert();
			boolean exception = false;
			try {
				appMenu.openHyperlocal();
				home.openCategoryfromMainList("hyperlocal");
				boolean catOpen = subCat.isSubCategoryPageOpen();
				if (catOpen) {
					boolean listing = subCat.isListingPresentinCategory("hyperlocal");
					if (listing) {
						subCat.openListing("hyperlocal");
						boolean listPageOpen = listDetail.isListingDetailPageOpen();
						if (listPageOpen) {
							listDetail.bookMarkList();
							Thread.sleep(500);
							PageElement.tapBackButton(driver);
							Thread.sleep(500);
							PageElement.tapBackButton(driver);
							Thread.sleep(1000);
							home.openPageMenu("hyperlocal");
							boolean menuOpen = mainMenu.isMainMenuOpen("hyperlocal");
						if (menuOpen) {
							mainMenu.clickBookmark("hyperloal");
							boolean bookmarkList = bookmark.isBookMarkedListExist("hyperlocal");
							if (bookmarkList) {
								bookmark.openBookMarkList("hyperlocal");
								asser.assertTrue(bookmark.islistingOpenFromBookMarkPage("hyperlocal"),
										"listing detail is not open from bookmark list");
								PageElement.tapBackButton(driver);
								
								// **********delete bookmark icon on list**********
								bookmark.clickBookMarkIcon();
								String bookmark_text = PageElement.getWarningText(driver);
								asser.assertEquals(bookmark_text, "Do you want to remove the bookmark?",
										"delete bookmark icon is not working");
								if (bookmark_text != "") {
									bookmark.clickDeleteBookMark();
								}
								asser.assertTrue(home.isHomePageOpen(),
										"home page is not open after deleting bookmark list");
							} else {
								Logger.info("Bookmark list is not present: Bookmark option is not working");
								asser.assertTrue(bookmarkList, "bookmark list is not present");
							}
						} else {
								Logger.info(
										"Hyperlocal menu is not open upon clicking on menu button from Hyperlocal home page");
								asser.assertTrue(menuOpen, "Hyperlocal menu is not open");
							}
						} else {
							Logger.info("listing page is not open");
							asser.assertTrue(listPageOpen, "listing page is not open");
						}
					} else {
						Logger.info("listing is not present in the category");
						asser.assertTrue(catOpen, "listing is not present in the category");
					}
				} else {
					Logger.info("Hyperlocal category is not open from home page");
					asser.assertTrue(catOpen, "Hyperlocal Category is not open");
				}

			} catch (Exception ex) {
				Logger.error("Exception occurs while verifying bookmark functionalities in Hyperlocal", ex);
				exception = true;
				Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
			}
			asser.assertAll();
		}
		
	@Test
	public void verifyRatingShareCallAndLoc() {
		Logger.info("********Test Methods start: verifyRatingShareCallAndLoc********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean catOpenAgain=false;
		try {
			appMenu.openHyperlocal();
			home.openCategoryfromMainList("hyperlocal");
			boolean catOpen = subCat.isSubCategoryPageOpen();
			if (catOpen) {
				// ******* verification of share on subList********
				subCat.openShare("hyperlocal");
				asser.assertTrue(PageElement.checkSharePopUp(driver), "Share Listing is not working");

				// ***** verification of Location on listing********
				subCat.openLocation("hyperlocal");
				asser.assertTrue(subCat.isGoogleMapOpen("four 44"), "Location icon on listing is not working");

				// ***** verification of call on listing********
				subCat.openCallinHyperLocal();
				if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				List<Object> text = PageElement.getWarningTitle(driver);
				asser.assertEquals((String) text.get(0), "Call");
				if ((boolean) text.get(1))
					PageElement.cancelPopup(driver);
				}else{
				asser.assertTrue(subCat.isCallOpeninIOS(),"Open Call is not working in IOS");
				}
				// ******* verification of rating on subList and back without writing review********
				subCat.openRating("hyperlocal");
				boolean rateOpen = rate.isRatingAndReviewPageOpen("hyperlocal");
				if (rateOpen) {
					PageElement.tapBackButton(driver);
					Thread.sleep(500);
					 catOpenAgain = subCat.isSubCategoryPageOpen();
					asser.assertTrue(catOpenAgain, "back without writing review doesn't redirect to listing");
				}
				// ******* verification of rating on subList********
					if(catOpenAgain){
						subCat.openRating("hyperlocal");
						boolean rateOpenAgain = rate.isRatingAndReviewPageOpen("hyperlocal");
						if (rateOpenAgain) {	
					// *******submit without selecting rating********
					rate.submitReview("hyperlocal");
					String blank_text = PageElement.getWarningText(driver);
					asser.assertEquals(blank_text, "Select at least one rating to post");
					if (blank_text != "")
						PageElement.closeWarningSingleBtn(driver,"Ok");
					Thread.sleep(1000);

					// *******submit rating********
					rate.selectStars();
					rate.writeReview("For testing purpose");
					rate.submitReview("hyperlocal");
					boolean loginPageOpen = login.isDirectoryLoginOpen();
					if (loginPageOpen) {
						login.loginDirectory("pk@pk.com", "12345678");
					} else {
						Logger.info("User is already login into app");
					}
					asser.assertEquals(PageElement.getWarningText(driver), "Your review has been successfully posted.");

				} else {
					asser.assertTrue(rateOpen, "Rating page is not open from subcategoty in hyperlocal");
				}
					}
			} else {
				Logger.info("Hyperlocal category is not open from home page");
				asser.assertTrue(catOpen, "Hyperlocal Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying rating share call and loc in Hyperlocal", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
		
	@Test
	public void verifyEnquiryFormInHyperlocal() {
		Logger.info("********Test Methods start: verifyEnquiryFormInHyperlocal********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			home.openCategoryfromMainList("hyperlocal");
			boolean catOpen = subCat.isSubCategoryPageOpen();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("hyperlocal");
				if (listing) {
					subCat.openListing("hyperlocal");
					boolean listPageOpen = listDetail.isListingDetailPageOpen();
					if (listPageOpen) {
						listDetail.clickSendEnquiry("hyperlocal");
						boolean quoteOpen = enquiry.isRequestQuotePageOpen();
						if (quoteOpen) {
							
							// ********* verification of blank form*************
							enquiry.submitQuery();
							boolean loginPageOpen = login.isDirectoryLoginOpen();
							if (loginPageOpen) {
								login.loginDirectory("pk@pk.com", "12345678");
							} 
								Logger.info("User is already login into directory");
								String warning_timee = PageElement.getWarningText(driver);
								asser.assertEquals(warning_timee, "Please select time");
								if (warning_timee != "") {
									PageElement.closeWarningSingleBtn(driver,"Ok");
									Thread.sleep(500);
								
							}
							// ********* verification of time*************
							enquiry.submitQuery();
							String warning_time = PageElement.getWarningText(driver);
							asser.assertEquals(warning_time, "Please select time");
							if (warning_time != "") {
								PageElement.closeWarningSingleBtn(driver,"Ok");
								Thread.sleep(500);
							}
							
							// ***** verification of datatime on specific date span
							enquiry.clickSpecificDateOption();
							asser.assertTrue(enquiry.isDateTimeVisible(),
									"Date time option is not visible with selecting specific date radio option");

							// ********* verification of location*************
							enquiry.clickTiming();
							Thread.sleep(500);
							enquiry.clickremoteJobCheckBox();
							enquiry.submitQuery();
							String warning_loc = PageElement.getWarningText(driver);
							asser.assertEquals(warning_loc, "Enter your postal/zip code or full address");
							if (warning_loc != "") {
								PageElement.closeWarningSingleBtn(driver,"Ok");
								Thread.sleep(500);
							}

							// ********* verification of description*************
							enquiry.clickTiming();
							enquiry.EnterLocation();
							enquiry.submitQuery();
							String warning_des = PageElement.getWarningText(driver);
							asser.assertEquals(warning_des, "Describe the service you are interested in");
							if (warning_des != "") {
								PageElement.closeWarningSingleBtn(driver,"Ok");
								Thread.sleep(500);
							}

							// ********* verification of query submission*************
							enquiry.clickTiming();
							enquiry.EnterLocation();
							enquiry.EnterDescription();
							enquiry.submitQuery();
							String warning = PageElement.getWarningText(driver);
							asser.assertEquals(warning, "Your request has been submitted successfully");
							if (warning != "") {
								PageElement.closeWarningSingleBtn(driver,"Ok");
								Thread.sleep(500);
							}
						} else {
							asser.assertTrue(quoteOpen, "requestQuote page is not open from listing in hyperlocal");
						}
					} else {
						Logger.info("listing page is not open");
						asser.assertTrue(listPageOpen, "listing page is not open");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Hyperlocal category is not open from home page");
				asser.assertTrue(catOpen, "Hyperlocal Category is not open");
			}
                                                                    
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying enquiry form in Hyperlocal", ex);
			exception = true; 
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}                                                     
		asser.assertAll();
	}
	
	@Test
	public void verifyAudioVideoandImagesInJobs() {
		Logger.info("********Test Methods start: verifyAudioVideoandImagesInJobs********");
		asser = new SoftAssert();
		boolean exception = false;
		int yaxis=0;
		try {
			appMenu.openHyperlocal();
			home.openCategoryfromMainList("hyperlocal");
			boolean catOpen = subCat.isSubCategoryPageOpen();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("hyperlocal");
				if (listing) {
					subCat.openListing("hyperlocal");
					boolean listPageOpen = listDetail.isListingDetailPageOpen();
					if (listPageOpen) {
						driver.context("NATIVE_APP");
						Dimension size = driver.manage().window().getSize();
						int startx = (int) (size.width * 0.80);
						int endx = (int) (size.width * 0.20);
						if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase()))
					    yaxis= (int)(size.height*.28);
					    else
					    yaxis= (int)(size.height*.18);	 
						Logger.info("width of the page " + startx);
						Logger.info("height of the page " + endx);
						driver.swipe(startx, yaxis, endx,yaxis, 7000);
						
						PageElement.changeContextToWebView(driver);
						asser.assertTrue(listDetail.isSwiperWorking(), "Swiper is not working on jobs");
						listDetail.clickYoutube();
						asser.assertTrue(listDetail.isYouTubeOpen("four 44"), "YouTubr player is not open from job");
					} else {
						Logger.info("listing page is not open");
						asser.assertTrue(listPageOpen, "listing page is not open");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Hyperlocal category is not open from home page");
				asser.assertTrue(catOpen, "Hyperlocal Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while veryfying audio video and images in jobs", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		Assert.assertFalse(exception, "Exception occurs while veryfying audio video and images in jobs");
		asser.assertAll();
	}
	
	@Test
	public void verifyOptionsinHyperlocaljobDetails() {
		Logger.info("********Test Methods start: verifyOptionsonHyperlocaljobDetails********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.openHyperlocal();
			home.openCategoryfromMainList("hyperlocal");
			boolean catOpen = subCat.isSubCategoryPageOpen();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("hyperlocal");
				if (listing) {
					subCat.openListing("hyperlocal");
					boolean listPageOpen = listDetail.isListingDetailPageOpen();
					if (listPageOpen) {
						
					// ********verification of visit options*******
					listDetail.openHyperLocalJobOptions("visit");
					asser.assertTrue(PageElement.isContentOpenInNative(driver,""),"visit option is not working from joblisting details");
					
					//*********verification of call****************
					listDetail.openHyperLocalJobOptions("call");
					asser.assertTrue(listDetail.isCallfeatureWorkingOnHyperlocalJobListDetail(), "call feature is not working");
					
					//*********verification of location Pop Up****************
						listDetail.openHyperLocalJobOptions("loc");
						boolean location = new AppypieMapPage(driver).isPopUpDisplayed();
						asser.assertTrue(location, "location popup is not working from job list detail");
						if (location) {
							PageElement.closeWarningSingleBtn(driver, "Cancel");
						}
	
					} else {
						Logger.info("job listing detail page is not open");
						asser.assertTrue(listPageOpen, "listing page is not open");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Hyperlocal category is not open from home page");
				asser.assertTrue(catOpen, "Hyperlocal Category is not open");
			}
                                                                    
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying options on hyperlocal job details", ex);
			exception = true; 
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}                                                     
		asser.assertAll();
	}
	
		
	
}
