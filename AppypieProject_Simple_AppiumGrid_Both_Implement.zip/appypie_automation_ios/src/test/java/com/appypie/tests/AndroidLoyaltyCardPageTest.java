package com.appypie.tests;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.Loyaltycard.CommanClassLoyaltycard;
import com.appypie.pages.Loyaltycard.LoyaltycardPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AndroidLoyaltyCardPageTest extends TestSetup {
	
	int count=0;
	

	LoyaltycardPage loyaltycard;
	CommanClassLoyaltycard comm;


	private static final Logger Logger = Log.createLogger();
	
	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		loyaltycard =new LoyaltycardPage(driver);
		comm=new CommanClassLoyaltycard(driver);
	
	}

	public String Getactualtext(AppiumDriver<MobileElement> driver, By gettext ){
		String Actualtext = null;
		WebElement element = ElementWait.waitForOptionalElement(driver,gettext,20);
		if(element!=null && element.isDisplayed()){
			Actualtext=	element.getText();
			Logger.info("Get Text:  "+Actualtext);
		}
		return Actualtext;
	}


	// ----------------------------------------------------------------------------------------------------

	@Test(priority = 0, description = "")
	public void VerifyDeshBoard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDeshBoard()");
		boolean exception = false;
		try {
			Boolean loyaltycard=comm.Openlinks(this.loyaltycard.loyaltycardmodulelink);
			if (loyaltycard) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Loyalty Card");
				
				List<MobileElement> allcardTitle = driver.findElements(this.loyaltycard.allcardTitle_gettext);      
				List<MobileElement> allcarddiscription = driver.findElements(this.loyaltycard.allcarddiscription_gettext);
				List<MobileElement> allcardtime = driver.findElements(this.loyaltycard.allcardtime_gettext);  

				for(int i=0;i<allcardTitle.size();i++){
					count++;
					Logger.info(count+"). "+allcardTitle.get(i).getText()+"\n"+allcarddiscription.get(i).getText()+":-"+allcardtime.get(i).getText());
				}
			}
			s_assert.assertTrue(loyaltycard, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifySingleCode() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySingleCode()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				
				String Title=comm.Getactualtext(loyaltycard.singlecodeCardTitle_gettext);
				s_assert.assertNotNull(Title, "Title is getting null value");
				
				String Desc=comm.Getactualtext(loyaltycard.singlecodeCardDesc_gettext);
				s_assert.assertNotNull(Desc, "Desc is getting null value");
				
				String date=comm.Getactualtext(loyaltycard.singlecodeCardDate_gettext);
				s_assert.assertNotNull(date, "Date is getting null value");
				
				Boolean TC=comm.Openlinks(loyaltycard.singlecodeCard_TClink);
				if (TC) {
					String TCTitle=comm.Getactualtext(loyaltycard.singlecodeCard_TC_title_gettext);
					s_assert.assertNotNull(TCTitle, "TC title is getting null value");
					
					String TCmessage=comm.Getactualtext(loyaltycard.singlecodeCard_TC_gettext);
					s_assert.assertNotNull(TCmessage, "TC message is getting null value");
					
					Boolean closeTC=comm.Openlinks(loyaltycard.singlecodeCard_TClink_Close);
					s_assert.assertTrue(closeTC, "TC closed Button is not working");
				}
				s_assert.assertTrue(TC, "TC link is not working");
				
				Boolean SC=comm.Openlinks(loyaltycard.singleCodelink);
				if (SC) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Single code");
					
					String msg=comm.Getactualtext(loyaltycard.Message_gettext);
					s_assert.assertNotNull(msg, "Message is getting Null value");
					
					Boolean clickfirst=comm.Openlinks(loyaltycard.firstNo_singleCodelink);
					if (clickfirst) {
						String head=comm.Getactualtext(loyaltycard.heading_gettext);
						s_assert.assertNotNull(head, "Heading is getting Null value");
						
						String desc=comm.Getactualtext(loyaltycard.desc_gettext);
						s_assert.assertNotNull(desc, "Description is getting Null value");
						
						Boolean sc=comm.Openlinks(loyaltycard.securityCodebtn);
						s_assert.assertTrue(sc, "SecurityCode link is not working");
						
						Boolean sctext=comm.TextField(loyaltycard.securityCodeText,"12345");
						s_assert.assertTrue(sctext, "SecurityCode text is not working");
						
						Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
						if (validate) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(validate, "Validate Btn is not working");
						
						Boolean cancel=comm.Openlinks(loyaltycard.cancelBtn);
						if (cancel) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(cancel, "cancel Btn is not working");
						
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working");
					}
					s_assert.assertTrue(clickfirst, "First No is not click");
				}
				s_assert.assertTrue(SC, "Single Code link is not working");
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 2, description = "")
	public void VerifyUniqueCodes() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyUniqueCodes()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				
				String Title=comm.Getactualtext(loyaltycard.uniqueCodesCardTitle_gettext);
				s_assert.assertNotNull(Title, "Title is getting null value");
				
				String Desc=comm.Getactualtext(loyaltycard.uniqueCodesCardDesc_gettext);
				s_assert.assertNotNull(Desc, "Desc is getting null value");
				
				String date=comm.Getactualtext(loyaltycard.uniqueCodesCardDate_gettext);
				s_assert.assertNotNull(date, "Date is getting null value");
				
				Boolean TC=comm.Openlinks(loyaltycard.uniqueCodesCard_TClink);
				if (TC) {
					String TCTitle=comm.Getactualtext(loyaltycard.uniqueCodesCard_TC_title_gettext);
					s_assert.assertNotNull(TCTitle, "TC title is getting null value");
					
					String TCmessage=comm.Getactualtext(loyaltycard.uniqueCodesCard_TC_gettext);
					s_assert.assertNotNull(TCmessage, "TC message is getting null value");
					
					Boolean closeTC=comm.Openlinks(loyaltycard.uniqueCodesCard_TClink_Close);
					s_assert.assertTrue(closeTC, "TC closed Button is not working");
				}
				s_assert.assertTrue(TC, "TC link is not working");
				
				Boolean UC=comm.Openlinks(loyaltycard.uniqueCodeslink);
				if (UC) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Unique Codes");
					
					String msg=comm.Getactualtext(loyaltycard.Message_gettext);
					s_assert.assertNotNull(msg, "Message is getting Null value");
					
					Boolean clickfirst=comm.Openlinks(loyaltycard.first_uniqueCodes);
					if (clickfirst) {
						String head=comm.Getactualtext(loyaltycard.heading_gettext);
						s_assert.assertNotNull(head, "Heading is getting Null value");
						
						String desc=comm.Getactualtext(loyaltycard.desc_gettext);
						s_assert.assertNotNull(desc, "Description is getting Null value");
						
						Boolean sc=comm.Openlinks(loyaltycard.securityCodebtn);
						s_assert.assertTrue(sc, "SecurityCode link is not working");
						
						Boolean sctext=comm.TextField(loyaltycard.securityCodeText,"12345");
						s_assert.assertTrue(sctext, "SecurityCode text is not working");
						
						Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
						if (validate) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(validate, "Validate Btn is not working");
						
						Boolean cancel=comm.Openlinks(loyaltycard.cancelBtn);
						if (cancel) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(cancel, "cancel Btn is not working");
						
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working");
					}
					s_assert.assertTrue(clickfirst, "First No is not click");
				}
				s_assert.assertTrue(UC, "uniqueCodes link is not working");
				
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 3, description = "")
	public void Verifysinglecodewithdailylimit() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  Verifysinglecodewithdailylimit()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				
				String Title=comm.Getactualtext(loyaltycard.singlecodewithdailylimitCardTitle_gettext);
				s_assert.assertNotNull(Title, "Title is getting null value");
				
				String Desc=comm.Getactualtext(loyaltycard.singlecodewithdailylimitCardDesc_gettext);
				s_assert.assertNotNull(Desc, "Desc is getting null value");
				
				String date=comm.Getactualtext(loyaltycard.singlecodewithdailylimitCardDate_gettext);
				s_assert.assertNotNull(date, "Date is getting null value");
				
				Boolean TC=comm.Openlinks(loyaltycard.singlecodewithdailylimitCard_TClink);
				if (TC) {
					String TCTitle=comm.Getactualtext(loyaltycard.singlecodewithdailylimitCard_TC_title_gettext);
					s_assert.assertNotNull(TCTitle, "TC title is getting null value");
					
					String TCmessage=comm.Getactualtext(loyaltycard.singlecodewithdailylimitCard_TC_gettext);
					s_assert.assertNotNull(TCmessage, "TC message is getting null value");
					
					Boolean closeTC=comm.Openlinks(loyaltycard.singlecodewithdailylimitCard_TClink_Close);
					s_assert.assertTrue(closeTC, "TC closed Button is not working");
				}
				s_assert.assertTrue(TC, "TC link is not working");
				
				Boolean SCDL=comm.Openlinks(loyaltycard.singlecodewithdailylimitlink);
				if (SCDL) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Single code with daily limit");
					
					String msg=comm.Getactualtext(loyaltycard.Message_gettext);
					s_assert.assertNotNull(msg, "Message is getting Null value");
					
					Boolean clickfirst=comm.Openlinks(loyaltycard.first_singlecodewithdailylimit);
					if (clickfirst) {
						
						String head=comm.Getactualtext(loyaltycard.headingSCWDL_gettext);
						s_assert.assertNotNull(head, "Heading is getting Null value");
						
						String desc=comm.Getactualtext(loyaltycard.descSCWDL_gettext);
						s_assert.assertNotNull(desc, "Description is getting Null value");
						
						Boolean sc=comm.Openlinks(loyaltycard.securityCodebtn);
						s_assert.assertTrue(sc, "SecurityCode link is not working");
						
						Boolean sctext=comm.TextField(loyaltycard.securityCodeText,"12345");
						s_assert.assertTrue(sctext, "SecurityCode text is not working");
						
						Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
						if (validate) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(validate, "Validate Btn is not working");
						
						Boolean cancel=comm.Openlinks(loyaltycard.cancelBtn);
						if (cancel) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(cancel, "cancel Btn is not working");
						
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working");
					}
					s_assert.assertTrue(clickfirst, "First No is not click");
				}
				s_assert.assertTrue(SCDL, "single code with daily limit link is not working");
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 4, description = "")
	public void VerifymanualcheckinCard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifymanualcheckinCard()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				
				String Title=comm.Getactualtext(loyaltycard.manualcheckinCardTitle_gettext);
				s_assert.assertNotNull(Title, "Title is getting null value");
				
				String Desc=comm.Getactualtext(loyaltycard.manualcheckinCardDesc_gettext);
				s_assert.assertNotNull(Desc, "Desc is getting null value");
				
				String date=comm.Getactualtext(loyaltycard.manualcheckinCardDate_gettext);
				s_assert.assertNotNull(date, "Date is getting null value");
				
				Boolean TC=comm.Openlinks(loyaltycard.manualcheckinCard_TClink);
				if (TC) {
					String TCTitle=comm.Getactualtext(loyaltycard.manualcheckinCard_TC_title_gettext);
					s_assert.assertNotNull(TCTitle, "TC title is getting null value");
					
					String TCmessage=comm.Getactualtext(loyaltycard.manualcheckinCard_TC_gettext);
					s_assert.assertNotNull(TCmessage, "TC message is getting null value");
					
					Boolean closeTC=comm.Openlinks(loyaltycard.manualcheckinCard_TClink_Close);
					s_assert.assertTrue(closeTC, "TC closed Button is not working");
				}
				s_assert.assertTrue(TC, "TC link is not working");
				
				Boolean MCI=comm.Openlinks(loyaltycard.manualCheckInlink);
				if (MCI) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Manual check in");
					
					String msg=comm.Getactualtext(loyaltycard.Message_gettext);
					s_assert.assertNotNull(msg, "Message is getting Null value");
					
					Boolean clickfirst=comm.Openlinks(loyaltycard.first_manualCheckIn);
					if (clickfirst) {
						String head=comm.Getactualtext(loyaltycard.headingMCI_gettext);
						s_assert.assertNotNull(head, "Heading is getting Null value");
						
						String desc=comm.Getactualtext(loyaltycard.descMCI_gettext);
						s_assert.assertNotNull(desc, "Description is getting Null value");
									
						Boolean add=comm.Openlinks(loyaltycard.addBtn);
						if (add) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(add, "add Btn is not working");
						
						Boolean invoice=comm.TextField(loyaltycard.invoiceNotext,"12345");
						s_assert.assertTrue(invoice, "Invoice text is not working");
						
						Boolean add1=comm.Openlinks(loyaltycard.addBtn);
						if (add1) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(add1, "add Btn is not working");
						
								
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working");
					}
					s_assert.assertTrue(clickfirst, "First No is not click");
				}
				s_assert.assertTrue(MCI, "manual Check In link is not working");
				
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 5, description = "")
	public void VerifymanualcheckinwithdailylimitCard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifymanualcheckinwithdailylimitCard()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				
				String Title=comm.Getactualtext(loyaltycard.manualcheckinwithdailylimitCardTitle_gettext);
				s_assert.assertNotNull(Title, "Title is getting null value");
				
				String Desc=comm.Getactualtext(loyaltycard.manualcheckinwithdailylimitCardDesc_gettext);
				s_assert.assertNotNull(Desc, "Desc is getting null value");
				
				String date=comm.Getactualtext(loyaltycard.manualcheckinwithdailylimitCardDate_gettext);
				s_assert.assertNotNull(date, "Date is getting null value");
				
				Boolean TC=comm.Openlinks(loyaltycard.manualcheckinwithdailylimitCard_TClink);
				if (TC) {
					String TCTitle=comm.Getactualtext(loyaltycard.manualcheckinwithdailylimitCard_TC_title_gettext);
					s_assert.assertNotNull(TCTitle, "TC title is getting null value");
					
					String TCmessage=comm.Getactualtext(loyaltycard.manualcheckinwithdailylimitCard_TC_gettext);
					s_assert.assertNotNull(TCmessage, "TC message is getting null value");
					
					Boolean closeTC=comm.Openlinks(loyaltycard.manualcheckinwithdailylimitCard_TClink_Close);
					s_assert.assertTrue(closeTC, "TC closed Button is not working");
				}
				s_assert.assertTrue(TC, "TC link is not working");
				
				Boolean MCWDL=comm.Openlinks(loyaltycard.manualCheckInWithDailylimtlink);
				if (MCWDL) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Manual check in with daily limit");
					
					String msg=comm.Getactualtext(loyaltycard.Message_gettext);
					s_assert.assertNotNull(msg, "Message is getting Null value");
					
					Boolean clickfirst=comm.Openlinks(loyaltycard.first_manualCheckInWithDailylimt);
					if (clickfirst) {
						String head=comm.Getactualtext(loyaltycard.headingMCWDL_gettext);
						s_assert.assertNotNull(head, "Heading is getting Null value");
						
						String desc=comm.Getactualtext(loyaltycard.descMCWDL_gettext);
						s_assert.assertNotNull(desc, "Description is getting Null value");
						
						
						
						Boolean invoice=comm.TextField(loyaltycard.invoiceNotext,"12345");
						s_assert.assertTrue(invoice, "invoice text is not working");
						
						Boolean upload=comm.Openlinks(loyaltycard.uploadbtn);
						if (upload) {
							
							Boolean gallery=comm.Openlinks(loyaltycard.clickgallerylink);
							s_assert.assertTrue(gallery, "Gallery Link is not working");
							
							driver.context("NATIVE_APP");
							
							if (!globledeviceName.equals("iPhone")) {
								Boolean selectphoto=comm.Openlinks(loyaltycard.clickselectphoto);
								s_assert.assertTrue(selectphoto, "Select photo is not select");
							}
							else {
								Boolean cameraroll =PageElement.Accessibilitylinks(PageElement.i_cameraRoll);
								if (cameraroll) {
									Boolean access=PageElement.Accessibilitylinks(PageElement.i_image);
								     s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );
								}
								s_assert.assertTrue(cameraroll, "i_camera roll is not open");
							}
							
						
							PageElement.changeContextToWebView(driver);
							comm.IfAlertpresent();
							
						}
						s_assert.assertTrue(upload, "upload Btn is not working");
						
						Boolean add=comm.Openlinks(loyaltycard.addBtn);
						if (add) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(add, "add Btn is not working");
						
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working");
					}
					s_assert.assertTrue(clickfirst, "First No is not click");
				}
				s_assert.assertTrue(MCWDL, "manual Check In With Daily limt link is not working");
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 6, description = "")
	public void VerifyinvalidCard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyinvalidCard()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				
				String Title=comm.Getactualtext(loyaltycard.invalidCardTitle_gettext);
				s_assert.assertNotNull(Title, "Title is getting null value");
				
				String Desc=comm.Getactualtext(loyaltycard.invalidCardDesc_gettext);
				s_assert.assertNotNull(Desc, "Desc is getting null value");
				
				String date=comm.Getactualtext(loyaltycard.invalidCardDate_gettext);
				s_assert.assertNotNull(date, "Date is getting null value");
				
				Boolean TC=comm.Openlinks(loyaltycard.invalidCard_TClink);
				if (TC) {
					String TCTitle=comm.Getactualtext(loyaltycard.invalidCard_TC_title_gettext);
					s_assert.assertNotNull(TCTitle, "TC title is getting null value");
					
					String TCmessage=comm.Getactualtext(loyaltycard.invalidCard_TC_gettext);
					s_assert.assertNotNull(TCmessage, "TC message is getting null value");
					
					Boolean closeTC=comm.Openlinks(loyaltycard.invalidCard_TClink_Close);
					s_assert.assertTrue(closeTC, "TC closed Button is not working");
				}
				s_assert.assertTrue(TC, "TC link is not working");
				
				Boolean invalid=comm.Openlinks(loyaltycard.invalidlink);
				if (invalid) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Invalid");
					
					String msg=comm.Getactualtext(loyaltycard.Message_gettext);
					s_assert.assertNotNull(msg, "Message is getting Null value");
					
					Boolean clickfirst=comm.Openlinks(loyaltycard.first_invalid);
					if (clickfirst) {
						comm.IfAlertpresent();
						/*
						String head=comm.Getactualtext(loyaltycard.heading_gettext);
						s_assert.assertNotNull(head, "Heading is getting Null value");
						
						String desc=comm.Getactualtext(loyaltycard.desc_gettext);
						s_assert.assertNotNull(desc, "Description is getting Null value");
						
						Boolean sc=comm.Openlinks(loyaltycard.securityCodebtn);
						s_assert.assertTrue(sc, "SecurityCode link is not working");
						
						Boolean sctext=comm.TextField(loyaltycard.securityCodeText,"12345");
						s_assert.assertTrue(sctext, "SecurityCode text is not working");
						
						Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
						if (validate) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(validate, "Validate Btn is not working");
						
						Boolean cancel=comm.Openlinks(loyaltycard.cancelBtn);
						if (cancel) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(cancel, "cancel Btn is not working");
						*/
						
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working");
					}
					s_assert.assertTrue(clickfirst, "First No is not click");
				}
				s_assert.assertTrue(invalid, "invalid link is not working");
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 7, description = "")
	public void VerifyExtranalLinkUniqueCodeOutSide() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyExtranalLinkUniqueCodeOutSide()");
		boolean exception = false;
		try {

			Boolean lc=comm.Openlinks(loyaltycard.loyaltycardmodulelink);
			if (lc) {
				Boolean exlink1=comm.Openlinks(loyaltycard.extranallink_uniquecode);
				if (exlink1) {
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Loyalty Card");
						Boolean back=comm.Openlinks(comm.BackButtonNative);
						s_assert.assertTrue(back, "Back Button is not working main page");
					}
					else {
						Boolean i_back=comm.Openlinks(comm.i_BackButtonNative);
						s_assert.assertTrue(i_back, "i_Back Button is not working ");
					}
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(exlink1, "Extranal link1 is not working");
				
				Boolean exlink2=comm.Openlinks(loyaltycard.extranallink2_uniquecode);
				if (exlink2) {
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Loyalty Card");
						
						Boolean back=comm.Openlinks(comm.BackButtonNative);
						s_assert.assertTrue(back, "Back Button is not working main page");
					}
					else {
						Boolean i_back=comm.Openlinks(comm.i_BackButtonNative2);
						s_assert.assertTrue(i_back, "i_Back Button is not working2 ");
					}
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(exlink2, "Extranal link 2 is not working");
				
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 8, description = "")
	public void VerifyOneCard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyOneCard()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(this.loyaltycard.loyaltycardmodulelink);
			if (lc) {
				comm.Getactualtext(comm.header_gettext);
				
				comm.Getactualtext(loyaltycard.oneCardTitle_gettext);
				comm.Getactualtext(loyaltycard.oneCardDesc_gettext);
				comm.Getactualtext(loyaltycard.oneCardDate_gettext);
				
				Boolean oneCard_TC=comm.Openlinks(loyaltycard.oneCard_TClink);
				if (oneCard_TC) {
					Boolean TCclose=comm.Openlinks(loyaltycard.oneCard_TClink_Close);
					s_assert.assertTrue(TCclose, "TC close is not open"); 
				}
				s_assert.assertTrue(oneCard_TC, "one Card TC  is not open");
				
				Boolean oneCard=comm.Openlinks(loyaltycard.oneCardlink);
				if (oneCard) {
					comm.Getactualtext(loyaltycard.header_gettext);
					comm.Getactualtext(loyaltycard.Message_gettext);
					
					Boolean oneNo=comm.Openlinks(loyaltycard.oneNo_oneCardlink);
					if (oneNo) {
						Boolean securityCode=comm.Openlinks(loyaltycard.securityCodebtn);
						if (securityCode) {
							Boolean securityCodetxt=comm.TextField(loyaltycard.securityCodeText, "1111");
							if (securityCodetxt) {
								Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
								if (validate) {
									comm.IfAlertpresent();
									Boolean redeemit=comm.Openlinks(loyaltycard.redeemitoneNo_oneCardlink);
									if (redeemit) {
										comm.IfAlertpresent();
										Boolean securityCode1=comm.Openlinks(loyaltycard.securityCodebtn);
										if (securityCode1) {
											Boolean securityCodetxt1=comm.TextField(loyaltycard.securityCodeText, "1111");
											if (securityCodetxt1) {
												Boolean validate1=comm.Openlinks(loyaltycard.validateBtn);
												if (validate1) {
													comm.IfAlertpresent();
												}
												s_assert.assertTrue(validate, "validate  is not open"); 
											}
											s_assert.assertTrue(securityCodetxt, "security Code txt is not working");
										}
										s_assert.assertTrue(securityCode, "securityCode button  is not open");
									}
									s_assert.assertTrue(redeemit, "redeem it button is not open"); 
								}
								s_assert.assertTrue(validate, "validate  is not open"); 
							}
							s_assert.assertTrue(securityCodetxt, "security Code txt is not working");
						}
						s_assert.assertTrue(securityCode, "securityCode button  is not open");
					}
					s_assert.assertTrue(oneNo, "one No  is not open");
				} 
				s_assert.assertTrue(oneCard, "one Card  is not open"); 

				
				
				
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	
	@Test(priority = 9, description = "")
	public void VerifyDailyLimit() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDailyLimit()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(this.loyaltycard.loyaltycardmodulelink);
			if (lc) {
				comm.Getactualtext(comm.header_gettext);
				
				comm.Getactualtext(loyaltycard.DailyLimit_TC_title_gettext);
				comm.Getactualtext(loyaltycard.dailyLimitDesc_gettext);
				comm.Getactualtext(loyaltycard.dailyLimitDate_gettext);
				
				Boolean TC=comm.Openlinks(loyaltycard.dailyLimit_TClink);
				if (TC) {
					Boolean TCclose=comm.Openlinks(loyaltycard.dailyLimit_TClink_Close);
					s_assert.assertTrue(TCclose, "TC close is not open"); 
				}
				s_assert.assertTrue(TC, "TC  is not open");
				
				Boolean dailyLimit=comm.Openlinks(loyaltycard.dailyLimitlink);
				if (dailyLimit) {
					comm.Getactualtext(loyaltycard.header_gettext);
					comm.Getactualtext(loyaltycard.Message_gettext);
					
					Boolean oneNo=comm.Openlinks(loyaltycard.firstNo_dailyLimitlink);
					if (oneNo) {
						Boolean securityCode=comm.Openlinks(loyaltycard.securityCodebtn);
						if (securityCode) {
							Boolean securityCodetxt=comm.TextField(loyaltycard.securityCodeText, "1111");
							if (securityCodetxt) {
								Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
								if (validate) {
									comm.IfAlertpresent();
									Boolean oneNo1=comm.Openlinks(loyaltycard.firstNo_dailyLimitlink);
									if (oneNo1) {
										comm.IfAlertpresent();
									}
									s_assert.assertTrue(oneNo1, "one No  is not open");
								}
								s_assert.assertTrue(validate, "validate  is not open"); 
							}
							s_assert.assertTrue(securityCodetxt, "security Code txt is not working");
						}
						s_assert.assertTrue(securityCode, "securityCode button  is not open");
					}
					s_assert.assertTrue(oneNo, "one No  is not open");
				} 
				s_assert.assertTrue(dailyLimit, "daily Limit  is not open"); 
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 10, description = "")
	public void VerifyManualCheckInWithDailyLimit() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyManualCheckInWithDailyLimit()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(this.loyaltycard.loyaltycardmodulelink);
			if (lc) {
				comm.Getactualtext(comm.header_gettext);
				
				comm.Getactualtext(loyaltycard.manualCheckInWithDailyLimitTitle_gettext);
				comm.Getactualtext(loyaltycard.manualCheckInWithDailyLimitDesc_gettext);
				comm.Getactualtext(loyaltycard.manualCheckInWithDailyLimitDate_gettext);
				
				Boolean TC=comm.Openlinks(loyaltycard.manulCheckInWithDailyLimit_TClink);
				if (TC) {
					Boolean TCclose=comm.Openlinks(loyaltycard.manulCheckInWithDailyLimit_TClink_Close);
					s_assert.assertTrue(TCclose, "TC close is not open"); 
				}
				s_assert.assertTrue(TC, "TC  is not open");
				
				Boolean cardLink=comm.Openlinks(loyaltycard.manulCheckInWithDailyLimitlink);
				if (cardLink) {
					comm.Getactualtext(loyaltycard.header_gettext);
					comm.Getactualtext(loyaltycard.Message_gettext);
					
					Boolean oneNo=comm.Openlinks(loyaltycard.first_manulCheckInWithDailyLimit);
					if (oneNo) {
						Boolean securityCode=comm.Openlinks(loyaltycard.securityCodebtn);
						if (securityCode) {
							Boolean securityCodetxt=comm.TextField(loyaltycard.securityCodeText, "1111");
							if (securityCodetxt) {
								Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
								if (validate) {
									comm.IfAlertpresent();
									Boolean redeemit=comm.Openlinks(loyaltycard.redeemitoneNo_oneCardlink);
									if (redeemit) {
										Boolean securityCode1=comm.Openlinks(loyaltycard.securityCodebtn);
										if (securityCode1) {
											Boolean securityCodetxt1=comm.TextField(loyaltycard.securityCodeText, "1111");
											if (securityCodetxt1) {
												Boolean validate1=comm.Openlinks(loyaltycard.validateBtn);
												if (validate1) {
													comm.IfAlertpresent();
													//---
												}
												s_assert.assertTrue(validate1, "validate1  is not open");
											}
											s_assert.assertTrue(securityCodetxt1, "security1 Code txt is not working");
										}
										s_assert.assertTrue(securityCode1, "securityCode1 button  is not open");
									}
									s_assert.assertTrue(redeemit, "redeem It Button  is not open"); 
								}
								s_assert.assertTrue(validate, "validate  is not open"); 
							}
							s_assert.assertTrue(securityCodetxt, "security Code txt is not working");
						}
						s_assert.assertTrue(securityCode, "securityCode button  is not open");
					}
					s_assert.assertTrue(oneNo, "one No  is not open");
				} 
				s_assert.assertTrue(cardLink, "manul Check In With Daily Limit  is not open"); 
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 11, description = "")
	public void VerifyManualCheckIn() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyManualCheckIn()");
		boolean exception = false;
		try {
			Boolean lc=comm.Openlinks(this.loyaltycard.loyaltycardmodulelink);
			if (lc) {
				comm.Getactualtext(comm.header_gettext);
				
				comm.Getactualtext(loyaltycard.manualCheckInTitle_gettext);
				comm.Getactualtext(loyaltycard.manualCheckInDesc_gettext);
				comm.Getactualtext(loyaltycard.manualCheckInDate_gettext);
				
				Boolean TC=comm.Openlinks(loyaltycard.manulCheckIn_TClink);
				if (TC) {
					Boolean TCclose=comm.Openlinks(loyaltycard.manulCheckIn_TClink_Close);
					s_assert.assertTrue(TCclose, "TC close is not open"); 
				}
				s_assert.assertTrue(TC, "TC  is not open");
				
				Boolean cardLink=comm.Openlinks(loyaltycard.manulCheckInlink);
				if (cardLink) {
					comm.Getactualtext(loyaltycard.header_gettext);
					comm.Getactualtext(loyaltycard.Message_gettext);
					
					Boolean oneNo=comm.Openlinks(loyaltycard.first_manulCheckInWithDailyLimit);
					if (oneNo) {
						Boolean securityCode=comm.Openlinks(loyaltycard.securityCodebtn);
						if (securityCode) {
							Boolean securityCodetxt=comm.TextField(loyaltycard.securityCodeText, "1111");
							if (securityCodetxt) {
								Boolean validate=comm.Openlinks(loyaltycard.validateBtn);
								if (validate) {
									comm.IfAlertpresent();
									Boolean redeemit=comm.Openlinks(loyaltycard.redeemitoneNo_oneCardlink);
									if (redeemit) {
										Boolean securityCode1=comm.Openlinks(loyaltycard.securityCodebtn);
										if (securityCode1) {
											Boolean securityCodetxt1=comm.TextField(loyaltycard.securityCodeText, "1111");
											if (securityCodetxt1) {
												Boolean validate1=comm.Openlinks(loyaltycard.validateBtn);
												if (validate1) {
													comm.IfAlertpresent();
													//---
												}
												s_assert.assertTrue(validate1, "validate1  is not open");
											}
											s_assert.assertTrue(securityCodetxt1, "security1 Code txt is not working");
										}
										s_assert.assertTrue(securityCode1, "securityCode1 button  is not open");
									}
									s_assert.assertTrue(redeemit, "redeem It Button  is not open"); 
								}
								s_assert.assertTrue(validate, "validate  is not open"); 
							}
							s_assert.assertTrue(securityCodetxt, "security Code txt is not working");
						}
						s_assert.assertTrue(securityCode, "securityCode button  is not open");
					}
					s_assert.assertTrue(oneNo, "one No  is not open");
				} 
				s_assert.assertTrue(cardLink, "manul Check In With Daily Limit  is not open"); 
			}
			s_assert.assertTrue(lc, "loyaltycard module is not open");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	
	
}
