package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.ECommerce.CommanClassEcommerce;
import com.appypie.pages.ECommerce.EcommPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;
public class AndroidAppiumECommerceTest extends TestSetup {

	EcommPage ecom;
	CommanClassEcommerce comm;

	private static final Logger Logger= Log.createLogger();

	//--------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		ecom=new EcommPage(driver);
		comm=new CommanClassEcommerce(driver);
	}
	
	//---------------------------------------------------------------------------------------------------- 
		
	@Test(priority = 0, description = "")
	public void VerifyOpenECommerceModule() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyOpenECommerceModule()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean backbtn=comm. Openlinks(comm.BackButton2);
				s_assert.assertTrue(backbtn, "Back Button is not working on Ecommerce Home Page");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 1, description = "")
	public void VerifyEtsy() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyEtsy()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				
				Boolean etsy=comm.Openlinks(ecom.openEtsylink);
				if (etsy) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Etsy");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Etsy Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(etsy, "Etsy is not working");
				
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 2, description = "")
	public void VerifyShopify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyShopify()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				
				Boolean Shopify=comm.Openlinks(ecom.openShopifylink);
				if (Shopify) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Shopify");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Shopify Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(Shopify, "Shopify is not working");
				
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 3, description = "")
	public void VerifyWooCommerce() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyWooCommerce()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean WooCommerce=comm.Openlinks(ecom.openWooCommercelink);
				if (WooCommerce) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Woo Commerce");
					
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on WooCommerce Page");
					
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(WooCommerce, "WooCommerce is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 4, description = "")
	public void VerifyMagento() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMagento()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean Magento=comm.Openlinks(ecom.openMagentolink);
				if (Magento) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Magento");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Magento Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(Magento, "Magento is not working");
				
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 5, description = "")
	public void VerifyVolusion() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyVolusion()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean Volusion=comm.Openlinks(ecom.openVolusionlink);
				if (Volusion) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Volusion");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Volusion Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(Volusion, "Volusion is not working");
				
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 6, description = "")
	public void VerifyBigCommerce() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyBigCommerce()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean BigCommerce=comm.Openlinks(ecom.openBigCommercelink);
				if (BigCommerce) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "BigCommerce");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on BigCommerce Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(BigCommerce, "BigCommerce is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 7, description = "")
	public void VerifyOSCommerece() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyOSCommerece()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean OSCommerece=comm.Openlinks(ecom.openOSCommerecelink);
				if (OSCommerece) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "osCommerce");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on  Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(OSCommerece, "OSCommerece is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 8, description = "")
	public void Verifyprestashop() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  Verifyprestashop()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean prestashop=comm.Openlinks(ecom.openprestashoplink);
				if (prestashop) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "PrestaShop");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on prestashop Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(prestashop, "prestashop is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 9, description = "")
	public void Verifysquerespace() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  Verifysquerespace()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean squerespace=comm.Openlinks(ecom.opensquerespacelink);
				if (squerespace) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Square Space");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on squerespace Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(squerespace, "squerespace is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 10, description = "")
	public void VerifyAmeriCommerce() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyAmeriCommerce()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean AmeriCommerce=comm.Openlinks(ecom.openAmeriCommercelink);
				if (AmeriCommerce) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "AmeriCommerce");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on AmeriCommerce Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(AmeriCommerce, "AmeriCommerce is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 11, description = "")
	public void VerifyAmazon() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyAmazon()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean Amazon=comm.Openlinks(ecom.openAmazonlink);
				if (Amazon) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "Amazon");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Amazon Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(Amazon, "Amazon is not working");
				
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 12, description = "")
	public void VerifyEbay() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyEbay()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean Ebay=comm.Openlinks(ecom.openEbaylink);
				if (Ebay) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "E-Bay");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Ebay Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(Ebay, "Amazon is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 13, description = "")
	public void VerifyCustomeAppupie() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyCustomeAppupie()");
		boolean exception = false;
		try {
			Boolean openEcommodule=comm.Openlinks(ecom.openEcommerceModule);
			if (openEcommodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "E-Commerce");
				Boolean Appypiecustome=comm.Openlinks(ecom.openAppypiecustomelink);
				if (Appypiecustome) {
					driver.context("NATIVE_APP");
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext_native), "appypie");
					Boolean backbtnnative=comm.Openlinks(comm.BackButtonNative);
					s_assert.assertTrue(backbtnnative, "back button is not working on Appypie custome Page");
					PageElement.changeContextToWebView(driver);
				}
				s_assert.assertTrue(Appypiecustome, "Appypie custome is not working");
			}
			s_assert.assertTrue(openEcommodule, "Comm module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

}



