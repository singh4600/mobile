package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.AppypieSurveyPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieSurveyTest extends TestSetup {
	
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieMenuPage menu;
	AppypieSurveyPage survey;

	@Override
	@BeforeTest
	public void pageSetUp() {
		menu= new AppypieMenuPage(driver);
		survey= new AppypieSurveyPage(driver);
	}
	
	@Test
	public void verifySurveyPageAndBackBtn() {
		Logger.info("Test Methods start: verifySurveyPageAndBackBtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("survey");
			boolean pageOpen = PageElement.isContentOpenInNative(driver, "");
			asser.assertTrue(pageOpen, "Survey page is not open");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the survey page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
