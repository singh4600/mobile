package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieDBPage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieDBTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieDBPage db;
	AppypieMenuPage menu;

	@BeforeTest
	@Override
	public void pageSetUp() {
		db = new AppypieDBPage(driver);
		menu = new AppypieMenuPage(driver);
	}

	@Test
	 public void verifyDBPageandBackbtn() {
	  Logger.info("Test Methods start: verifyDBPageandBackbtn");
	  asser = new SoftAssert();
	  boolean exception = false;
	  try {
	   menu.openPage("appypiedb");
	   boolean pageOpen = db.isDBPageOpen();
	   asser.assertTrue(pageOpen, "DB page is not open");
	   if (pageOpen) {
	    PageElement.tapBackButton(driver);
	    Thread.sleep(1000);
	    asser.assertTrue(menu.isPageExist("about"), "Back Button from DB page is not working");
	   }
	  } catch (Exception e) {
	   Logger.error("Error occurs while opening the DB page ", e);
	   exception = true;
	   Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
	  }
	  asser.assertAll();
	 }

	@Test
	public void verifyDBPageSearch() {
		Logger.info("Test Methods start: verifyDBPageSearch");
		asser = new SoftAssert();
		boolean exception = false;
		try {
		   menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				String value = db.getSearchBoxClass();
				if (value.equals("on")) {
					db.clickSearch();
					asser.assertEquals(db.getSearchBoxClass(), "",
							"search box is not open after click on search button");
				} else {
					Logger.info("search box is already displayed");
					db.clickSearch();
					asser.assertEquals(db.getSearchBoxClass(), "on",
							"search box is not closed after click on search button");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the search option on DB page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDBValues() {
		Logger.info("Test Methods start: verifyDBValues");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				asser.assertNotNull(db.getDetails("dob"), "DOB of record is not displayed");
				asser.assertNotNull(db.getDetails("email"), "email of record is not displayed");
				asser.assertNotNull(db.getDetails("name"), "Name of record is not displayed");
				asser.assertNotNull(db.getDetails("title"), "title of record is not displayed");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying db values ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDBEntryDetailOpen() {
		Logger.info("Test Methods start: verifyDBEntryDetailOpen");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				db.clickData();
				asser.assertTrue(db.isDataDetailOpen(), "detail page is not open upon clicking on data page entry");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying db entry detail open ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyFacebookOnDBPage() {
		Logger.info("Test Methods start: verifyFacebookOnDBPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				db.clickData();
				boolean detailOpen = db.isDataDetailOpen();
				asser.assertTrue(detailOpen, "detail page is not open upon clicking on data page entry");
				if (detailOpen) {
					db.openSocial("fb");
					asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "fb is not open from db page");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying facebook on db page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyGoogleOnDBPage() {
		Logger.info("Test Methods start: verifyGoogleOnDBPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				db.clickData();
				boolean detailOpen = db.isDataDetailOpen();
				asser.assertTrue(detailOpen, "detail page is not open upon clicking on data page entry");
				if (detailOpen) {
					db.openSocial("google");
					asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "google is not open from db page");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying google on db page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyLinkedInOnDBPage() {
		Logger.info("Test Methods start: verifyLinkedInOnDBPages");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				db.clickData();
				boolean detailOpen = db.isDataDetailOpen();
				asser.assertTrue(detailOpen, "detail page is not open upon clicking on data page entry");
				if (detailOpen) {
					db.openSocial("linkedin");
					asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "LinkedIn is not open from db page");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying LinkedIn on db page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyPinterestOnDBPage() {
		Logger.info("Test Methods start: verifyPinterestOnDBPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				db.clickData();
				boolean detailOpen = db.isDataDetailOpen();
				asser.assertTrue(detailOpen, "detail page is not open upon clicking on data page entry");
				if (detailOpen) {
					db.openSocial("pinterest");
					asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "Pinterest is not open from db page");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Pinterest on db page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyTwitterOnDBPage() {
		Logger.info("Test Methods start: verifyTwitterOnDBPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("appypiedb");
			boolean pageOpen = db.isDBPageOpen();
			asser.assertTrue(pageOpen, "DB page is not open");
			if (pageOpen) {
				db.clickData();
				boolean detailOpen = db.isDataDetailOpen();
				asser.assertTrue(detailOpen, "detail page is not open upon clicking on data page entry");
				if (detailOpen) {
					db.openSocial("twitter");
					asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "Twitter is not open from db page");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Twitter on db page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
