package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.AppypieQuotePage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieQuotePageTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieMenuPage menu;
	AppypieQuotePage quote;

	@Override
	@BeforeTest
	public void pageSetUp() {
		menu = new AppypieMenuPage(driver);
		quote = new AppypieQuotePage(driver);
	}

	@Test
	public void verifyQuotePageandBackbtn() {
		Logger.info("Test Methods start: verifyQuotePageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("quote");
			boolean pageOpen = quote.isQuotePageOpen();
			asser.assertTrue(pageOpen, "Quote page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from Quote page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Quote page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyQuotePresent() {
		Logger.info("Test Methods start: verifyQuotePresent");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("quote");
			boolean pageOpen = quote.isQuotePageOpen();
			asser.assertTrue(pageOpen, "Quote page is not open");
			if (pageOpen) {
				boolean quotePresent = quote.isQuotePresent();
				asser.assertTrue(quotePresent, "No Quote is present on quote page");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying quotes ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyShareOnQuote() {
		Logger.info("Test Methods start: verifyShareOnQuote");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("quote");
			boolean pageOpen = quote.isQuotePageOpen();
			asser.assertTrue(pageOpen, "Quote page is not open");
			if (pageOpen) {
				boolean quotePresent = quote.isQuotePresent();
				if (quotePresent) {
					quote.clickShare();
					asser.assertTrue(PageElement.checkSharePopUp(driver), "Share btn is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying share on quotes ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyFavouriteQuoteFunctionality() {
		Logger.info("Test Methods start: verifyFavouriteQuoteFunctionality");
		asser = new SoftAssert();
		String text="";
		boolean exception = false;
		try {
			menu.openPage("quote");
			boolean pageOpen = quote.isQuotePageOpen();
			asser.assertTrue(pageOpen, "Quote page is not open");
			if (pageOpen) {
				boolean quotePresent = quote.isQuotePresent();
				if (quotePresent) {
					text=quote.getQuoteText();
					quote.markQuoteFavourite();
					Thread.sleep(1000);
					quote.openFavouriteQuotePage();
					boolean fav = quote.isFavouriteQuotePageOpen();
					asser.assertTrue(fav, "Favourite quote page is not open upon clicking on btn on headers");
					if(fav){
					asser.assertTrue(quote.isMarkedQuoteVisibleInFavourites(text), "favourite marked quote is not displayed in favourite quote list");	
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying favourite quote functionality  ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
