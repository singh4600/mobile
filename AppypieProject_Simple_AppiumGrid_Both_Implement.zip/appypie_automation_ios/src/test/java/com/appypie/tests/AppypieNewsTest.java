package com.appypie.tests;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.newspages.CommentPostPage;
import com.appypie.pages.newspages.FeedDetailPage;
import com.appypie.pages.newspages.NewsHomePage;
import com.appypie.pages.newspages.NewsMenuPage;
import com.appypie.pages.newspages.NewsRssFeeds;
import com.appypie.pages.newspages.SearchAndBookmarkPage;
import com.appypie.pages.newspages.SettingPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

public class AppypieNewsTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	NewsHomePage home;
	NewsMenuPage menu;
	SearchAndBookmarkPage search;
	FeedDetailPage feeds;
	AppypieMenuPage app;
	CommentPostPage post;
	SettingPage setting;
	NewsRssFeeds rss;

	@Override
	@BeforeTest
	public void pageSetUp() {
		home = new NewsHomePage(driver);
		menu = new NewsMenuPage(driver);
		search = new SearchAndBookmarkPage(driver);
		feeds = new FeedDetailPage(driver);
		app = new AppypieMenuPage(driver);
		post= new CommentPostPage(driver);
		setting= new SettingPage(driver);
		rss= new NewsRssFeeds(driver);
	}

	@Test
	public void verifyNewsPageandNewsFeeds() {
		Logger.info("********Test Method Start: verifyNewsPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			asser.assertTrue(open, "news page is not open from main menu");
			if (open) {
				asser.assertEquals(home.getFirstNewsListingName(), "up news",
						"First News feeds are not displayed on home page");
				asser.assertNotNull(home.getFirstNewsListingDate(), "Dates are not shown on first listing");
				asser.assertEquals(home.getSecondNewsListingName(), "India news",
						"Second News feeds are not displayed on home page");
				asser.assertNotNull(home.getSecondNewsListingDate(), "Dates are not shown on Second listing");		
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the news  page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyHomeAndMainMenu() {
		Logger.info("********Test Method Start: verifyHomeAndMainMenu********");
		asser = new SoftAssert();     
		boolean exception = false;     
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				// *** verification of main menu*****
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "news menu is not open");
				if (menuOpen) {
					menu.clickMainMenu();
					asser.assertTrue(home.isHomePageOpen(), "main menu option is not working from news menu");
				}
//				// *** verification of home*****
//				home.openMenu();
//				boolean menuOpenagain = menu.isNewsMenuOpen();
//				asser.assertTrue(menuOpenagain, "news menu is not open while verifying home option");
//				if (menuOpenagain) {
//					menu.clickHome();
//					asser.assertTrue(app.isPageExist("news"), "home option is not working from news menu");
//				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying home and main menu in news", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyBookmarkinNews() {
		Logger.info("********Test Method Start: verifyBookmarkinNews********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				String feedName = home.getFirstNewsListingName();
				home.openFeeds("one");
				boolean feedOpen = feeds.isFeedDetailOpen();
				asser.assertTrue(feedOpen, "feeds on home page is not open");
				if (feedOpen) {
					feeds.clickBookMark();
					feeds.clickBackBtn();
					Thread.sleep(1000);
				}
				boolean homeopenagain = home.isHomePageOpen();
				asser.assertTrue(homeopenagain, "back button on feed details is not working");
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "menu is not open while verifying bookmark");
				if (menuOpen) {
					menu.clickBookmark();
					boolean bookmarkopen = search.isBookmarkPageOpen();
					asser.assertTrue(bookmarkopen, "bookmark page is not open from news menu");
					if (bookmarkopen) {
						List<Object> info = search.isFeedsPresent();
						asser.assertTrue((boolean) info.get(1), "feed is not present on bookmarkpage");
						if ((boolean) info.get(1)) {
							asser.assertEquals((String) info.get(0), feedName, "bookmarked feed is not present");
							search.openBookMarkFeed();
							boolean feedOpenagain = feeds.isFeedDetailOpen();
							asser.assertTrue(feedOpen, "bookmark feed is not open");
							if (feedOpenagain) {
								feeds.removeBookMark();
								Thread.sleep(1000);
								feeds.clickBackBtn();
								Thread.sleep(1000);
							}
							home.openMenu();
							menu.clickBookmark();
							Thread.sleep(5000);
							List<Object> feeds = search.isFeedsPresent();
							asser.assertTrue((boolean) feeds.get(2), "bookmark is not removed");	
						} else {
							asser.assertTrue((boolean) info.get(2), "no data icon is not present on bookmarkpage");
						}
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying bookmark in news", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	
	@Test
	public void verifyHollyWoodNewsFeeds() {
		Logger.info("********Test Method Start: verifyHollywoodNewsFeeds********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "news menu is not open");
				if (menuOpen) {
					menu.clickHollywood();
					boolean homeOpenAgain = home.isHollywoodFeedsOpen();
					asser.assertTrue(homeOpenAgain, "hollywood news feeds are not open from news menu");
					if (homeOpenAgain) {
						asser.assertTrue(homeOpenAgain, "home page is not open again when select news from main menu");
						asser.assertEquals(home.getFirstNewsListingName(), "Aajtk",
								"First News feeds are not displayed on home page");
						asser.assertNotNull(home.getFirstNewsListingDate(), "Dates are not shown on first listing");
						asser.assertEquals(home.getSecondNewsListingName(), "News",
								"Second News feeds are not displayed on home page");
						asser.assertNotNull(home.getSecondNewsListingDate(), "Dates are not shown on Second listing");
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying hollywood news feeds", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyBollywoodNewsFeeds() {
		Logger.info("********Test Method Start: verifyBollywoodNewsFeeds********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "news menu is not open");
				if (menuOpen) {
					menu.clickBollywood();
					boolean homeOpenAgain = home.isBollywoodFeedsOpen();
					asser.assertTrue(homeOpenAgain, "Bollywood news feeds are not open from news menu");
					if (homeOpenAgain) {
						asser.assertTrue(homeOpenAgain, "home page is not open again when select news from main menu");
						asser.assertEquals(home.getFirstNewsListingName(), "Mumbai",
								"First News feeds are not displayed on home page");
						asser.assertNotNull(home.getFirstNewsListingDate(), "Dates are not shown on first listing");
						asser.assertEquals(home.getSecondNewsListingName(), "Karan Studio",
								"Second News feeds are not displayed on home page");
						asser.assertNotNull(home.getSecondNewsListingDate(), "Dates are not shown on Second listing");
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying bollywood news feeds", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
                                                      	
	@Test
	public void verifySearchonMenu() {
		Logger.info("********Test Method Start: verifySearchonMenu********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "news menu is not open");
				if (menuOpen) {
				menu.typeSearchKeyWord("Mumbai");
				PageElement.tapDeviceOk(driver);
				boolean searchOpen= search.isSearchPageOpen();
				asser.assertTrue(searchOpen, "search page is not open from main menu");
				if(searchOpen){
					List<Object> info = search.isFeedsPresent();
					asser.assertTrue((boolean) info.get(1), "feed isnot present on search page");
					if ((boolean) info.get(1)) {
						asser.assertEquals((String) info.get(0), "Karan Studio", "search feed is not present");
					} else {
						asser.assertTrue((boolean) info.get(2), "no data icon is not present on search page");
					}
				}	
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying search on menu", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	                    
  	@Test
	public void verifyCloseOptiononNewsMenu() {
		Logger.info("********Test Method Start: verifyCloseOptiononNewsMenu********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "news menu is not open");
				if (menuOpen) {
					menu.closeMenu();
					asser.assertTrue(home.isHomePageOpen(), "close option on news search menu is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying close option on search menu", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyThemeShareandFontBtnonFeeds() {
		Logger.info("********Test Method Start: verifyThemeShareandFontBtnonFeeds********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openFeeds("first");
				boolean feedOpen = feeds.isFeedDetailOpen();
				asser.assertTrue(feedOpen, "news feeds are not open");
				if (feedOpen) {
					
					// ******verification of theme button*******
					String status = feeds.getThemeStatus();
					feeds.clickTheme();     
					Thread.sleep(1000);      
					if (status.equals("theme-btn")) {
						asser.assertEquals(feeds.getThemeStatus(), "theme-btn on", "theme button is not working");
					} else {
						asser.assertEquals(feeds.getThemeStatus(), "theme-btn", "theme button is not working");
					
					}
					
				   // ******verification of share button**************
					feeds.clickShare();
					asser.assertTrue(PageElement.checkSharePopUp(driver), "share button is not working on news feeds");
					
					 // ******verification of font button**************
					feeds.clickFontBtn();
					List<Object> warning= PageElement.getWarningTitle(driver);
					asser.assertTrue((boolean)warning.get(1),"font change pop up doesn't appear");
					asser.assertEquals((String)warning.get(0),"Select Font Size");
					if((boolean)warning.get(1)){
					 PageElement.cancelPopup(driver);
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying theme share and font buttons on feeds", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyPostCommentOnfeeds() {
		Logger.info("********Test Method Start: verifyPostCommentOnfeeds********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openFeeds("first");
				boolean feedOpen = feeds.isFeedDetailOpen();
				asser.assertTrue(feedOpen, "news feeds are not open");
				if (feedOpen) {
					feeds.clickcommentOnHeader();
					boolean postOpen = post.isCommentPostPageOpen();
					asser.assertTrue(postOpen, "post comment page is not open");
					if (postOpen) {
						post.postComment();
						boolean login = LoginUtil.isLoginPageOpen(driver);
						if (login) {
							LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
							Thread.sleep(6000);
							boolean openagain=post.isCommentPostPageOpen();
							asser.assertTrue(openagain, "post comment page is not open again after login");
							if(openagain)
							post.postComment();
						}
						Thread.sleep(3000);
						boolean commentBox = post.isCommentBoxDisplayed();
						asser.assertTrue(commentBox,"comment box is not displayed after login or clicking post button");
						if (commentBox) {
							
							// **** verification of blank post*****
							post.postComment();
							String blank_Text = PageElement.getWarningText(driver);
							asser.assertEquals(blank_Text, "Post a Comment");
							if (blank_Text != "") {
								PageElement.closeWarningSingleBtn(driver,"Ok");
								Thread.sleep(1000);
							}
							
							// **** verification of writing post*****
							post.writeComment("Fine Reviewed");
							post.postComment();
							String currentDate=post.getCurrentDate();
							String text = PageElement.getWarningText(driver);
							asser.assertEquals(text, "Comment has successfully posted");
							if (text != "") {
								PageElement.closeWarningSingleBtn(driver,"Ok");
								Thread.sleep(2000);
								
								// **** verification of submitted post*****
								asser.assertTrue(post.isPreviousCommentsExist(), "previous comments are not visible");
								asser.assertEquals(post.getComment(), "Fine Reviewed");
								asser.assertEquals(post.getUserName(), "TestName");
								//asser.assertEquals(post.getPostDate(),currentDate,"comment is not posted with current date");
							}

						}
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying posting the comment on feeds", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyPostCommentButtonOnFeeds() {
		Logger.info("********Test Method Start: verifyPostCommentButtonOnFeeds********");
		asser = new SoftAssert();
		boolean postOpen = false;
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openFeeds("first");
				boolean feedOpen = feeds.isFeedDetailOpen();
				asser.assertTrue(feedOpen, "news feeds are not open");
				if (feedOpen) {
					feeds.clickPostBtn();
					boolean login = LoginUtil.isLoginPageOpen(driver);
					if (!login) {
						postOpen = post.isCommentPostPageOpen();
					}
					asser.assertTrue(login || postOpen, "Post Comment button on feeds bottom is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying post comment button on bottom of feeds", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDateTextAndSwiperonFeedsDetails() {
		Logger.info("********Test Method Start: verifyDateTextAndSwiperonFeedsDetails********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				String feedName = home.getFirstNewsListingName();
				String secondFeedName = home.getSecondNewsListingName();
				home.openFeeds("one");
				boolean feedOpen = feeds.isFeedDetailOpen();
				asser.assertTrue(feedOpen, "news feeds are not open");
				if (feedOpen) {
					asser.assertEquals(feeds.getFeedText(), feedName);
					asser.assertNotNull(feeds.getFeedDate(), "date on feed detail is not displayed");
//					feeds.swipeFeedPage();
//					Thread.sleep(1000);
//					asser.assertEquals(feeds.getFeedText(), secondFeedName, "swiper among feeds is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying date, text and swiper on feeds details", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyVideoAndPdfinFeeds() {
		Logger.info("********Test Method Start: verifyVideoAndPdfinFeeds********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean pdfOpen=false;
		boolean videoOpen=false;
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				home.openMenu();
				boolean menuOpen = menu.isNewsMenuOpen();
				asser.assertTrue(menuOpen, "news menu is not open");
				if (menuOpen) {
					menu.clickHollywood();
					boolean homeOpenAgain = home.isHollywoodFeedsOpen();
					asser.assertTrue(homeOpenAgain, "hollywood feeds page is not open");
					if (homeOpenAgain) {
						home.openFeeds("one");
						boolean feedOpen = feeds.isFeedDetailOpen();
						if (feedOpen) {	
							if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
								feeds.openPDF();
								pdfOpen = feeds.isPdfOrVideoOpen("pdf");
								//asser.assertTrue(pdfOpen, " pdf from news feeds is not open");
								if (pdfOpen) {
									feeds.clickNativeBack(feeds.native1backbtn);
									Thread.sleep(1000);
								}						}
//								else {
//								pdfOpen = PageElement.isContentOpenInNative(driver, "PDF");
//							}
							

						}
						boolean feedOpenAgain = feeds.isFeedDetailOpen();
						asser.assertTrue(feedOpenAgain, "backbutton on native pdf is not working");
						if (feedOpenAgain) {
							feeds.openVideo();
							if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
						    videoOpen=feeds.isPdfOrVideoOpen("YouTube");
							if(videoOpen){
								feeds.clickNativeBack(feeds.native1backbtn);
								Thread.sleep(1000);	
							}
							} else {
								videoOpen = PageElement.isContentOpenInNative(driver, "Automate");
							}
						 asser.assertTrue(videoOpen,"youtube is not open from native feeds");
						 asser.assertTrue(feeds.isFeedDetailOpen(), "backbutton on youtube is not working");
						}
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying video and pdf in feeds", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifySettings() {
		Logger.info("********Test Method Start: verifySettings********");
		asser = new SoftAssert();     
		boolean exception = false;     
		try {
			app.openPage("news");
			boolean open = home.isHomePageOpen();
			if (open) {
				// *** verification of main menu*****
				home.openSettings();
				boolean login= LoginUtil.isLoginPageOpen(driver);
				if(login){
					LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
					Thread.sleep(2000);
					boolean homeOpenagain=home.isHomePageOpen();
					asser.assertTrue(homeOpenagain, "login failed or home page is not open after login");
					if(homeOpenagain){
						home.openSettings();	
					}
				}
				boolean settingOpen = setting.isSettingPageOpen();
				asser.assertTrue(settingOpen, "setting page is not open from news menu");
				if (settingOpen) {
					setting.updateSetting();
					Thread.sleep(2000);
					String warning= PageElement.getWarningText(driver);
					asser.assertEquals(warning, "Settings updated successfully");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying settings in news", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyRSSFeedsinNews() {
		Logger.info("********Test Method Start: verifyRSSFeedsinNews********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rss.openNewsWithRssFeeds();
			Thread.sleep(3000);
			boolean pageOpen = rss.isFeedsOpen();
			asser.assertTrue(pageOpen, "News with Rss Feeds is not open from main menu");
			if (pageOpen) {
				rss.openRssFeeds();
				boolean feedOpen = rss.isFeedDetailPageOpen();
				asser.assertTrue(feedOpen, "feeds details are not open from feeds list");
				if (feedOpen) {
					rss.openSharePopUp();
					asser.assertTrue(PageElement.checkSharePopUp(driver),"Share button on feeds description is not open");
					Thread.sleep(1000);
					rss.openFontpopUp();
					List<Object> warning = PageElement.getWarningTitle(driver);
					asser.assertEquals((String) warning.get(0), "Select Font Size","Font Button is not working or text differs");
					if ((boolean) warning.get(1)) {
						PageElement.closeWarningSingleBtn(driver, "Cancel");
					}
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying RSS feeds in news", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
