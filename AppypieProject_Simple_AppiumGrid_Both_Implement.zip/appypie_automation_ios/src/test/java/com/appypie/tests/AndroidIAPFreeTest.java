package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieIAPPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AndroidIAPFreeTest extends TestSetup {

	AppypieIAPPage iap;
	private static final Logger Logger = Log.createLogger();
	

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		iap=new AppypieIAPPage(driver);
	}

	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Veriy() throws Exception {
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 1, description = "")
	public void VeriyOpenIAPmodule() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyOpenIAPmodule()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(3);
			Boolean iapopen=iap.Openlinks(iap.iapFreeModule_link);
			if(iapopen){
				s_assert.assertEquals(iap.Getactualtext(iap.header_gettext), "IAP(Free)");
			}
			s_assert.assertTrue(iapopen, "IAP free module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + iap.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	@Test(priority = 2, description = "")
	public void VeriyViewAllTABTechnologyGeeks() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyViewAllTABSongs()");
		boolean exception = false;
		try {
			Boolean iapopen=iap.Openlinks(iap.iapFreeModule_link);
			s_assert.assertTrue(iapopen, "IAP is not open");

			Boolean Viewall=iap.Openlinks(iap.viewAll_btn);
			if (Viewall) {
				String title=iap.Getactualtext(iap.heading_gettext);
				s_assert.assertNotNull(title, "Song Title is getting Null Value");

				String descriptionSong=iap.Getactualtext(iap.description_gettext);
				s_assert.assertNotNull(descriptionSong, "Song description is getting Null Value");

				Boolean View_Freebtn=iap.Openlinks(iap.View_Free_btn);
				if (View_Freebtn) {
					iap.IfAlertpresent1();
					Boolean View_Freebtn1=iap.Openlinks(iap.View_Free_btn);
					if (View_Freebtn1) {
						driver.context("NATIVE_APP");
						driver.navigate().back();
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(View_Freebtn1, "PDF is not open");
				}
				s_assert.assertTrue(View_Freebtn, "View_Free btn is not open");

			}
			s_assert.assertTrue(Viewall, "View All TAB is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + iap.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VeriyMyCollectionTAB() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyMyCollectionTABSongs()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(3);
			Boolean iapopen=iap.Openlinks(iap.iapFreeModule_link);
			s_assert.assertTrue(iapopen, "IAP is not open");

			Boolean myCollection=iap.Openlinks(iap.myCollection_btn);
			if (myCollection) {

				String restore=iap.Getactualtext(iap.RestorePurchases_gettext);
				if (restore.equalsIgnoreCase("Restore Purchases")) {
					Boolean restorebtm=iap.Openlinks(iap.Rrestore_btn);
					if (restorebtm) {
						iap.Login();
						Boolean restorebtm1=iap.Openlinks(iap.Rrestore_btn);
						s_assert.assertTrue(restorebtm1, "Restore Button is not working");
					}
					s_assert.assertTrue(restorebtm, "Restore Button is not working");
				}
				else{		
					String title=iap.Getactualtext(iap.headingGeek_mycollection_gettext);
					s_assert.assertNotNull(title, "Song Title is getting Null Value on myCollection TAB");

					String descriptionSong=iap.Getactualtext(iap.descriptionGeek_mycollection_gettext);
					s_assert.assertNotNull(descriptionSong, "Song description is getting Null Value myCollection TAB");

					Boolean View_Freebtn=iap.Openlinks(iap.View_btn_mycollection);
					if (View_Freebtn) {
						iap.IfAlertpresent1();
						driver.context("NATIVE_APP");
						s_assert.assertEquals(iap.Getactualtext(iap.header_gettext_native), "IAP(Free)");
						iap.BackButtonNative(iap.BackButtonNative);
						PageElement.changeContextToWebView(driver);

					}
					s_assert.assertTrue(View_Freebtn, "View_Free btn is not open myCollection TAB");}
			}
			s_assert.assertTrue(myCollection, "View All TAB is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + iap.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 4, description = "")
	public void VeriyViewAllTABSongs() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyViewAllTABSongs()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(3);
			Boolean iapopen=iap.Openlinks(iap.iapFreeModule_link);
			s_assert.assertTrue(iapopen, "IAP is not open");

			Boolean Viewall=iap.Openlinks(iap.viewAll_btn);
			if (Viewall) {
				String title=iap.Getactualtext(iap.titleSong_gettext);
				s_assert.assertNotNull(title, "Song Title is getting Null Value");

				String descriptionSong=iap.Getactualtext(iap.descriptionSong_gettext);
				s_assert.assertNotNull(descriptionSong, "Song description is getting Null Value");

				Boolean View_Freebtn=iap.Openlinks(iap.View_FreeSong_btn);
				if (View_Freebtn) {
					iap.IfAlertpresent1();
					Boolean View_Freebtn1=iap.Openlinks(iap.View_FreeSong_btn);
					if (View_Freebtn1) {
						Logger.info("Again View button is present");
					}else{
						Logger.info("Again view button is not present"); 
					}

					driver.context("NATIVE_APP");
					s_assert.assertEquals(iap.Getactualtext(iap.header_gettext_native), "IAP(Free)");
					iap.BackButtonNative(iap.BackButtonNative);
					PageElement.changeContextToWebView(driver);

				}
				s_assert.assertTrue(View_Freebtn, "View_Free btn is not open");

			}
			s_assert.assertTrue(Viewall, "View All TAB is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + iap.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VeriyMyCollectionTABSongs() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyMyCollectionTABSongs()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(3);
			Boolean iapopen=iap.Openlinks(iap.iapFreeModule_link);
			s_assert.assertTrue(iapopen, "IAP is not open");

			Boolean myCollection=iap.Openlinks(iap.myCollection_btn);
			if (myCollection) {



				String restore=iap.Getactualtext(iap.RestorePurchases_gettext);
				if (restore.equalsIgnoreCase("Restore Purchases")) {
					Boolean restorebtm=iap.Openlinks(iap.Rrestore_btn);
					if (restorebtm) {
						iap.Login();
						Boolean restorebtm1=iap.Openlinks(iap.Rrestore_btn);
						s_assert.assertTrue(restorebtm1, "Restore Button is not working");
					}
					s_assert.assertTrue(restorebtm, "Restore Button is not working");
				}
				else{

					String title=iap.Getactualtext(iap.headingSong_mycollection_gettext);
					s_assert.assertNotNull(title, "Song Title is getting Null Value on myCollection TAB");

					String descriptionSong=iap.Getactualtext(iap.descriptionSong_mycollection_gettext);
					s_assert.assertNotNull(descriptionSong, "Song description is getting Null Value myCollection TAB");

					Boolean View_Freebtn=iap.Openlinks(iap.View_btn_mycollection);
					if (View_Freebtn) {
						iap.IfAlertpresent1();
						driver.context("NATIVE_APP");
						s_assert.assertEquals(iap.Getactualtext(iap.header_gettext_native), "IAP(Free)");
						iap.BackButtonNative(iap.BackButtonNative);
						PageElement.changeContextToWebView(driver);

					}
					s_assert.assertTrue(View_Freebtn, "View_Free btn is not open myCollection TAB");
				}

			}
			s_assert.assertTrue(myCollection, "View All TAB is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + iap.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



}