package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.bitbar.BaseAndroidTest;
import com.appypie.pages.AppypieBlog;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

public class AppypieBlogPageTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	AppypieBlog blogpage;
	SoftAssert asser;

	@BeforeTest
	@Override
	public void pageSetUp() {
		blogpage = new AppypieBlog(driver);
	}

	@Test
	public void verifyBlogPage() {
		Logger.info("Test Methods start: verifyBlogPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			boolean blogOpen = blogpage.identifyBlogPageOpen();
			if (blogOpen) {
				PageElement.tapBackButton(driver);
				asser.assertEquals(PageElement.getAppName(driver), "Automate");
			}
			asser.assertTrue(blogOpen, "Blog  Page is not Open by clicking the main menu icon");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the blog page", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyBlogPageHeader() {
		Logger.info("Test Methods start: verifyBlogPageHeader");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			String blogHeading = PageElement.getPageHeader(driver);
			asser.assertEquals(blogHeading, "BlogPage");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the Blog Header", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	
	public void openBlogUrl(String blogType) {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls(blogType);
			boolean open = blogpage.getListing();
			asser.assertTrue(open, blogType + " blog from the blog page is ot open");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the " + blogType + " blog ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	public void BlogUrlListHeadingAndContent(String blogType) {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls(blogType);
			String headingText = blogpage.listHeading();
			String content = blogpage.listContent();
			asser.assertNotNull(headingText, " heading of " + blogType + " listing is not present");
			asser.assertNotNull(content, " Contentof " + blogType + " listing is not present");
		} catch (Exception e) {
			Logger.error("Error occurs while fetching the text of " + blogType + " listheading and content ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	public void clickList(String blogType) {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls(blogType);
			String heading = blogpage.listHeading();
			blogpage.openListing();
			String listPageheading = blogpage.getListPageContent();
			Logger.info("heading of list on listing page is " + heading
					+ " and on the list detail page after clicking on list is " + listPageheading);
			asser.assertEquals(heading, listPageheading);
		} catch (Exception e) {
			Logger.error("Error occurs while clicking the " + blogType + " listing ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	public void openListInNative(String blogType) {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls(blogType);
			blogpage.openListing();
			boolean open = blogpage.openListInNative(blogType);
			asser.assertTrue(open, blogType + " listing is not open in native browser");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the " + blogType + " list in native Browser", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	// ****************TestMethods for Wordpress Blog**************

	@Test
	public void verifyWordPressOpen() {
		Logger.info("********Test Methods start: verifyWordPressOpen********");
		openBlogUrl("wordpress");
	}

	@Test
	public void verifyWordPressListHeadingAndContent() {
		Logger.info("********Test Methods start: verifyWordPressListHeadingAndContent********");
		BlogUrlListHeadingAndContent("wordpress");
	}

	@Test
	public void verifyWordPressListOpen() {
		Logger.info("********Test Methods start: verifyWordPressListOpen********");
		clickList("wordpress");
	}

	@Test
	public void verifyWordpressListInNative() {
		Logger.info("********Test Methods start: verifyWordpressListInNative********");
		openListInNative("wordpress");
	}
	
	

	// ****************TestMethods for Blogger Blog**************

	@Test
	public void verifyBloggerOpen() {
		Logger.info("********Test Methods start: verifyBloggerOpen********");
		openBlogUrl("blogger");
	}

	@Test
	public void verifyBloggerListHeadingAndContent() {
		Logger.info("********Test Methods start: verifyBloggerListHeadingAndContent********");
		BlogUrlListHeadingAndContent("blogger");
	}

	@Test
	public void verifyBloggerImage() {
		Logger.info("********Test Methods start: verifyBloggerImage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls("blogger");
			boolean image = blogpage.getImage();
			asser.assertTrue(image, "image of the blog is not present in listing");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the blog image ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyBloggerListOpen() {
		Logger.info("********Test Methods start: verifyBloggerListOpen********");
		clickList("blogger");
	}

	//@Test
	public void verifyBloggerListInNative() {
		Logger.info("********Test Methods start: verifyBloggerListInNative********");
		openListInNative("blogger");
	}

	// ****************TestMethods for FeedBurner Blog**************

	@Test
	public void verifyFeedBurnerOpen() {
		Logger.info("********Test Methods start: verifyFeedBurnerOpen********");
		openBlogUrl("burner");
	}

	@Test
	public void verifyFeedBurnerListHeadingAndContent() {
		Logger.info("********Test Methods start: verifyFeedBurnerListHeadingAndContent********");
		BlogUrlListHeadingAndContent("burner");
	}

	@Test
	public void verifyFeedBurnerListOpen() {
		Logger.info("********Test Methods start: verifyFeedBurnerListOpen********");
		clickList("burner");
	}

//	@Test
	public void verifyFeedBurnerListInNative() {
		Logger.info("********Test Methods start: verifyFeedBurnerListInNative********");
		openListInNative("burner");
	}

	// ****************TestMethods for Tumblr Blog**************
	@Test
	public void verifyTumblrOpen() {
		Logger.info("********Test Methods start: verifyTumblrOpen********");
		openBlogUrl("tumbler");
	}

	@Test
	public void verifyTumblrListHeadingAndContent() {
		Logger.info("********Test Methods start: verifyTumblrListHeadingAndContent********");
		BlogUrlListHeadingAndContent("tumbler");
	}

   @Test
	public void verifyTumblrListOpen() {
		Logger.info("********Test Methods start: verifyTumblrListOpen********");
		clickList("tumbler");
	}

//	@Test
	public void verifyDeepLinkInTumblr() {
		Logger.info("********Test Methods start: verifyDeepLinkInTumblr********");
		openListInNative("tumbler");
	}
	
	// ****************TestMethods for Custom Blog**************

		@Test
		public void verifycustomBlogOpen() {
			Logger.info("********Test Methods start: verifycustomBlogOpen********");
			openBlogUrl("customblog");
		}

		@Test
		public void verifyCustomBlogListHeadingAndContent() {
			Logger.info("********Test Methods start: verifyCustomBlogListHeadingAndContent********");
			BlogUrlListHeadingAndContent("customblog");
		}

		@Test
		public void verifyCustomBlogListOpen() {
			Logger.info("********Test Methods start: verifyCustomBlogListOpen********");
			clickList("customblog");
		}

		@Test
		public void verifyCustomBlogListInNative() {
			Logger.info("********Test Methods start: verifyCustomBlogListInNative********");
			openListInNative("customblog");
		}

	@Test
	public void verifyFontBtn() {
		Logger.info("********Test Methods start: verifyFontBtn********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls("tumbler");
			blogpage.openListing();
			boolean font = blogpage.fontBtn();
			asser.assertTrue(font, "Font Buttton is not Working ");
		} catch (Exception e) {
			Logger.error("Error occurs while clicking on FontButton ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

    @Test
	public void verifyShareBtn() {
		Logger.info("********Test Methods start: verifyShareBtn*********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls("tumbler");
			blogpage.openListing();
			 blogpage.clickShareBtn();
			asser.assertTrue(PageElement.checkSharePopUp(driver), "share Buttton is not Working ");
		} catch (Exception e) {
			Logger.error("Error occurs while clicking on share Button ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
    
	@Test
	public void verifyPostCommentOnCustomBlog() {
		Logger.info("********Test Methods start: verifyPostCommentOnCustomBlog********");
		asser = new SoftAssert();
		int commentsCount=0;
		int updateCommentsCount=0;
		boolean exception = false;
		try {
			blogpage.openBlogPage();
			blogpage.openBlogUrls("customblog");
			blogpage.openListing();
			Thread.sleep(1000);
			PageElement.scrollPageVertically(driver, .50, .90, .05,8000);
			Thread.sleep(1000);
			PageElement.scrollPageVertically(driver, .50, .90, .05,8000);
			blogpage.openCommentPage();
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
			}
			boolean pageOpen = blogpage.isCommentPageOpen();
			asser.assertTrue(pageOpen, "comment page is not open from custom blog list");
			if (pageOpen) {
				commentsCount= blogpage.getCommentsCount();
				// for posting blank comment
				blogpage.postComment();
				String blank_warning = PageElement.getWarningText(driver);
				asser.assertEquals(blank_warning, "please enter comment");
				if (blank_warning != "") {
					PageElement.closeWarningSingleBtn(driver, "Ok");
				}
				// for posting comment with data
				Thread.sleep(2000);
				blogpage.writeComment("Testing purpose Automations");
				blogpage.postComment();
				String warning = PageElement.getWarningText(driver);
				asser.assertEquals(warning, "Comment has successfully posted");
				if (blank_warning != "") {
					PageElement.closeWarningSingleBtn(driver, "Ok");
					updateCommentsCount= blogpage.getCommentsCount();
					asser.assertEquals(updateCommentsCount,commentsCount+1, "comment count is not increased: comment is not posted successfully");
				}	
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying post comment on custom blog ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
