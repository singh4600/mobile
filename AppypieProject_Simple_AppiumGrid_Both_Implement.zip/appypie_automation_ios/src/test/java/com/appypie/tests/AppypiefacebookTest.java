package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypiefacebookPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypiefacebookTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypiefacebookPage fbpage;

	@BeforeTest
	@Override
	public void pageSetUp() {
		fbpage = new AppypiefacebookPage(driver);
	}

	@Test
	public void verifyfacebookPage() {
		Logger.info("********Test Method Starts: verifyfacebookPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			fbpage.openFacebookPage("feeds");
			boolean Open = fbpage.identifyFacebookOpen();
			if (Open) {
				String fbHeader = PageElement.getPageHeader(driver);
				asser.assertEquals(fbHeader, "Facebook");
			} else {
				Logger.info("Facebook Page is not open from main menu");
			}
			asser.assertTrue(Open, "Facebook Page is not Open by clicking the main menu icon");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Facebook page", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyfacebookUrl() {
		Logger.info("********Test Method Starts: verifyfacebookUrl********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			fbpage.openFacebookPage("feeds");
			fbpage.openfacebookUrl();
			boolean info = fbpage.checkFacebookFeeds();
			asser.assertTrue(info, "Facebook url is not opening or feeds are not present in the facebook url");
			if (!info) {
				boolean nodata = PageElement.checkNoDataOptionInUrl(driver);
				if (nodata)
					Logger.info("No data icon is showing in the facebook url");
				asser.assertTrue(nodata, "No data icon is not visible and feeds are not present in facebook url");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Facebook URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyInvalidfacebookUrl() {
		Logger.info("********Test Method Starts: verifyInvalidfacebookUrl********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			fbpage.openFacebookPage("feeds");
			fbpage.clickInvalidUrl();
			String likes=fbpage.getLikes();
			int count= Integer.parseInt(likes.substring(likes.indexOf("\"")+1, likes.indexOf("\"")+2));
			asser.assertTrue(count==1, "Invalid facebook url is not open and doesn't shows zero feeds");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the invalid Facebook URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyLikeScrollAndLoadmore() {
		Logger.info("********Test Method Starts: verifyLikeScrollAndLoadmore********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean feedcount = false;
		try {
			fbpage.openFacebookPage("feeds");
			fbpage.openfacebookUrl();
			String like = fbpage.getLikes();
			int feedsbeforeLoadmore = fbpage.getNumberOfFeeds();
			boolean btn = fbpage.checkScrollOptionandLoadMore();
			Thread.sleep(4000);
			int feedsafterLoadmore = fbpage.getNumberOfFeeds();
			if (feedsafterLoadmore > feedsbeforeLoadmore) {
				feedcount = true;
			}
			asser.assertTrue(feedcount,
					"feed count is same after clicking on load more button: no more feeds are loaded");
			asser.assertTrue(btn, "Load more button is not present in the url");
			asser.assertNotNull(like, "Facebook likes are not present in the facebook url");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the Like and scroll option in  Facebook URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyFeedInNative() {
		Logger.info("********Test Method Starts: verifyFeedInNative********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			fbpage.openFacebookPage("feeds");
			fbpage.openfacebookUrl();
			boolean open = fbpage.clickViewButton();
			asser.assertTrue(open, " Facebook feeds is not open in native browser");
		} catch (Exception e) { 
			Logger.error("Error occurs while opening the Facebook feeds in native", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyFaceBookAsWebsite() {
		Logger.info("********Test Method Starts: verifyFaceBookAsWebsite********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			fbpage.openFacebookPage("website");
			asser.assertTrue(PageElement.isContentOpenInNative(driver,""), " Facebook page as website is not open");
		} catch (Exception e) { 
			Logger.error("Error occurs while verifying facebook as web site", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
