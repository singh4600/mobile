package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieWebsitePage;
import com.appypie.pages.Audio.AudioPage;
import com.appypie.pages.Audio.CommanClassAudio;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.CommanClass;
import com.appypie.util.Log;
import com.appypie.util.PageElement;
public class AppypieWebsiteTest_iOS extends TestSetup {
	
	AppypieWebsitePage websitepage;
	private static final Logger Logger= Log.createLogger();

	//--------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		websitepage=new AppypieWebsitePage(driver);
	}

	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VerifyInSideWebSitePage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyInSideWebSitePage()");
		boolean exception = false;
		try {
			
			Boolean websitepagemodule=CommanClass.Openlinks(websitepage.i_websiteFolder);
			s_assert.assertTrue(CommanClass.IselementPresent(websitepage.i_insideWebsite),"Website page module is not open");
			if (websitepagemodule) {
				Boolean insitewebsite=CommanClass.Openlinks(websitepage.i_insideWebsite);
				driver.context("NATIVE_APP");
				s_assert.assertTrue(CommanClass.IselementPresent(CommanClass.i_header_gettext_native), "InsideWebsite is not Open");
				if (insitewebsite) {
					CommanClass.Getactualtext(CommanClass.i_header_gettext_native);
					Boolean iback=CommanClass.Openlinks(CommanClass.i_BackButtonNative);
					PageElement.changeContextToWebView(driver);
					s_assert.assertTrue(CommanClass.IselementPresent(websitepage.insidewebsitePage), "i_Back Button is not working");
				}
				PageElement.changeContextToWebView(driver);
			}
			

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 1, description = "")
	public void VerifyOutSideWebSitePage() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

			Boolean websitepagemodule=CommanClass.Openlinks(websitepage.i_websiteFolder);
			s_assert.assertTrue(CommanClass.IselementPresent(websitepage.i_OutsideWebsite),"Website page module is not open");
			if (websitepagemodule) {
				Boolean outSidewebsite=CommanClass.Openlinks(websitepage.i_OutsideWebsite);
				s_assert.assertTrue(CommanClass.IselementPresent(websitepage.website1), "OutSidewebsite link is not open");
				if (outSidewebsite) {
					Boolean website1=CommanClass.Openlinks(websitepage.website1);
					driver.context("NATIVE_APP");
					s_assert.assertTrue(CommanClass.IselementPresent(CommanClass.i_header_gettext_native), "Website1 link is not open");
					if (website1) {
						CommanClass.Getactualtext(CommanClass.i_header_gettext_native);
						Boolean iback=CommanClass.Openlinks(CommanClass.i_BackButtonNative);
						PageElement.changeContextToWebView(driver);
						s_assert.assertTrue(CommanClass.IselementPresent(websitepage.website1), "iBack button is not working on website1");
					}
					Boolean website2=CommanClass.Openlinks(websitepage.website2);
					driver.context("NATIVE_APP");
					s_assert.assertTrue(CommanClass.IselementPresent(CommanClass.i_header_gettext_native), "Website2 link is not open");
					if (website2) {
						CommanClass.Getactualtext(CommanClass.i_header_gettext_native);
						Boolean iback=CommanClass.Openlinks(CommanClass.i_BackButtonNative);
						PageElement.changeContextToWebView(driver);
						s_assert.assertTrue(CommanClass.IselementPresent(websitepage.website2), "iBack button is not working on website2");
					}
					Boolean websiteInvalid=CommanClass.Openlinks(websitepage.websiteInvalid);
					driver.context("NATIVE_APP");
					s_assert.assertTrue(CommanClass.IselementPresent(CommanClass.i_header_gettext_native), "WebsiteInvalid link is not open");
					if (websiteInvalid) {
						CommanClass.Getactualtext(CommanClass.i_header_gettext_native);
						Boolean iback=CommanClass.Openlinks(CommanClass.i_BackButtonNative);
						PageElement.changeContextToWebView(driver);
						s_assert.assertTrue(CommanClass.IselementPresent(websitepage.websiteInvalid), "iBack button is not working on WebsiteInvalid");
					}
				}
				
			}
			
			
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 2, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	
}
