package com.appypie.tests;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.AppypieTestimonialPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieTestimonialTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieTestimonialPage testimonial;
	AppypieMenuPage menu;
	String[] content = {"Media Company Located in Noida.", "For Automation Testing purpose"};
	String[] title = {"ONSIS", "Appypie"};

	@Override
	@BeforeTest
	public void pageSetUp() {
		testimonial = new AppypieTestimonialPage(driver);
		menu = new AppypieMenuPage(driver);
	}

	@Test
	public void verifyTestimonialPageandBackbtn() {
		Logger.info("Test Methods start: verifyTestimonialPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("testimonial");
			boolean pageOpen = testimonial.isTestimonialPageOpen();
			asser.assertTrue(pageOpen, "Testimonial page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from testimonial page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Testimonial Page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyTestimonialsData() {
		Logger.info("Test Methods start: verifyTestimonialsData");
		asser = new SoftAssert();
		int i = 1;
		boolean exception = false;
		try {
			menu.openPage("testimonial");
			boolean pageOpen = testimonial.isTestimonialPageOpen();
			asser.assertTrue(pageOpen, "Testimonial page is not open");
			if (pageOpen) {
				List<List<Object>> list = testimonial.getAllTestimonialsDetails();
				System.out.println(list);
				Iterator<List<Object>> itr = list.iterator();
				while (itr.hasNext()) {
					List<Object> values = (List<Object>) itr.next();
					asser.assertTrue((boolean) values.get(0),"Starting quotes are not present in testimonial on position: " + i);
					asser.assertTrue((boolean) values.get(1),"End quotes are not present in testimonial on position: " + i);
					asser.assertNotNull((String) values.get(2),"image url is not present in testimonial on position: " + i);
				    asser.assertNotNull((String) values.get(3),"Content is not available in testimonial on position:" +i);
					asser.assertEquals((String) values.get(4), title[i-1],"Titile mismatch in testimonial on position:" +i);
					i++;
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Testimonials data ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
