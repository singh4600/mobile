package com.appypie.tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.AppypieWebsitePage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.CommanClass;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieWebsiteTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	AppypieWebsitePage websitepage;
	SoftAssert asser;

	@BeforeTest
	@Override
	public void pageSetUp() {
		websitepage = new AppypieWebsitePage(driver);
	}

	@Test
	public void verifyWebsitePageOpen() {
		Logger.info("********Test Method start: verifyWebsitePageOpen********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			websitepage.openwebsiteFolder();
			boolean open = websitepage.identifywebsiteOpen();
			asser.assertTrue(open, "Website Page is not Open by clicking the main menu icon");
			if (open) {
				PageElement.tapBackButton(driver);
				asser.assertTrue(new AppypieMenuPage(driver).isPageExist("about"), "back button is not working from website page");
			} 
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Website page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyinSideAppWebSitesOpen() {
		Logger.info("********Test Method start: verifyinSideAppWebSitesOpen********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			websitepage.openwebsiteFolder();
			websitepage.openwebsitePage("inside");
			asser.assertTrue(PageElement.isContentOpenInNative(driver, ""), "Website url is not open on webview inside app");
	
		} catch (Exception e) {
			Logger.error("Error occurs while opening Website Url inside App", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyOutsideAppWebSitesOpen() {
		Logger.info("********Test Method start: verifyOutsideAppWebSitesOpen********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			websitepage.openwebsiteFolder();
			websitepage.openwebsitePage("outside");
			
	
				boolean urlOpen = websitepage.outsideAppOpenWebsiteUrls("one");
				boolean invalidurlOpen = websitepage.outsideAppOpenWebsiteUrls("two");
				asser.assertTrue(urlOpen, "Website url is not open on Outside app");
				asser.assertTrue(invalidurlOpen, "invalid Website url is not open on Outside app");
			
			
		} catch (Exception e) {
			Logger.error("Error occurs while opening Website Url outside app", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
