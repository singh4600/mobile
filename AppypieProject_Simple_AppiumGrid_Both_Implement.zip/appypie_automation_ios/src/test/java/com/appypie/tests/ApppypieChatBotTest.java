package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieChatBotPage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class ApppypieChatBotTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieMenuPage menu;
	AppypieChatBotPage bot;
	

	@Override
	@BeforeTest
	public void pageSetUp() {
		menu= new AppypieMenuPage(driver);
		bot= new AppypieChatBotPage(driver);
	}
	
	@Test
	public void verifyChatBotPageandBackbtn() {
		Logger.info("Test Methods start: verifyChatBotPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("chatbot");
			boolean pageOpen = bot.isChatBotPageOpen();
			asser.assertTrue(pageOpen, "chatBot page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from chatBot page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the chatbot page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	
	@Test
	public void verifyChatBotMessageAndReply() {
		Logger.info("Test Methods start: verifyChatBotMessageAndReply");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("chatbot");
			boolean pageOpen = bot.isChatBotPageOpen();
			asser.assertTrue(pageOpen, "chatBot page is not open");
			if (pageOpen) {
				Thread.sleep(3000);
				bot.typeMsg("pawan");
				bot.sendMsg();
				Thread.sleep(3000);
				asser.assertEquals(bot.getMsg(), "pawan");
				asser.assertNotNull(bot.getMsgTime(), "msg time is not displayed");
				Thread.sleep(3000);
				asser.assertEquals(bot.getReply(), "automation");
				asser.assertNotNull(bot.getReplyTime(), "Reply time is not displayed");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying chatbot functionalities ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
