package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.NavigationPage;
import com.appypie.pages.formbuilder.AppointmentPage;
import com.appypie.pages.formbuilder.CommanClassforFormBuilder;
import com.appypie.pages.formbuilder.CustomPage;
import com.appypie.pages.formbuilder.DeshboardPage;
import com.appypie.pages.formbuilder.InquirePage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.TouchAction;

public class AndroidFormBuilderPageTest2 extends TestSetup {
	DeshboardPage deshboard;
	AppointmentPage appointment;
	InquirePage 	inquire;
	CustomPage custom;
	CommanClassforFormBuilder comm;

	private static final Logger Logger = Log.createLogger();

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		deshboard = new DeshboardPage(driver);
		appointment = new AppointmentPage(driver);
		inquire = new InquirePage(driver);
		custom = new CustomPage(driver);
		comm=new CommanClassforFormBuilder(driver);
	}

	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void verify() throws Exception {
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	 */

	@Test(priority = 0, description = "")
	public void VeriyFormBuilderModuleOpen() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyFormBuilderModuleOpen()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			if (formbuilder) {
				s_assert.assertEquals(comm.Getactualtext(deshboard.header_gettext), "Form Builder");
			}
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VeriyActivityFieldsList() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyActivityFieldsList()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");

			Boolean fields = deshboard.IselementPresent(deshboard.getListPresentfileds);
			if (fields) {
				deshboard.getListofLink(deshboard.getListPresentfileds);
			}
			s_assert.assertTrue(fields, "Active Fields is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VeriyAppointmentField() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyAppointmentField()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");

			Boolean appoint=deshboard.Openlinks(deshboard.appointment_link);
			if (appoint) {
				s_assert.assertEquals(comm.Getactualtext(appointment.header_gettext), "Appointment");
				s_assert.assertEquals(comm.Getactualtext(appointment.heading_gettext), "Book your Appointment");
				s_assert.assertEquals(comm.Getactualtext(appointment.formDesc_gettext), "All fields are required");

				/*		Boolean checkschedulebtn=appointment.Openlinks(appointment.checkschedule_btn);
				if (checkschedulebtn) {
					Boolean openschedule=appointment.IselementPresent(appointment.checkscheduledays_getlist);
					if (openschedule) {
						s_assert.assertEquals(Getactualtext(appointment.checkscheduleframeHeading_gettext), "Schedule");
						Logger.info("Get the List of the avaliable and close date");
						appointment.getListofLink(appointment.checkscheduledays_getlist);

						Boolean checkscheleduClosedbtn=appointment.IselementPresent(appointment.checkscheduleClosed_btn);
						if (checkscheleduClosedbtn) {
							appointment.Openlinks(appointment.checkscheduleClosed_btn);
						}
						s_assert.assertTrue(checkscheleduClosedbtn, "check schedule closed button is not present");
					}
					s_assert.assertTrue(openschedule, "schedule frame is not present");

				}
				s_assert.assertTrue(checkschedulebtn, "Check schedule frame is not open by click on check schedule button.");*/
			}
			s_assert.assertTrue(appoint,"Appointment link is not open");

			Boolean confirmdate=appointment.Openlinks(appointment.confirm_btn);
			if (confirmdate) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					appointment.IfAlertpresent();

					Boolean appodate=appointment.IselementPresent(appointment.appointmentdate_droplist);
					if (appodate) {
						if (!globledeviceName.equals("iPhone")) {
							//appointment.Openlinks(appointment.appointmentdateclick_droplist);
							WebElement element = driver.findElement(appointment.appointmentdate_droplist);
							Actions action = new Actions(driver);
							action.moveToElement(element).click().perform();
							TimeUnit.SECONDS.sleep(2);
						}
						else {
							Boolean iappointmentdate=comm.Openlinks(appointment.i_appointmentdate_droplist);
							if (iappointmentdate) {
								comm.Openlinks(appointment.i_appointmentdate_droplist);
							}
							s_assert.assertTrue(iappointmentdate, "iappointment date is not working ");
							TimeUnit.SECONDS.sleep(2);
						}

						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean dateselect =appointment.IselementPresent(appointment.appointmentdate_native);
							if (dateselect) {
								comm.Getactualtext(appointment.AppointmentDate_gettext_native);
								boolean setbtn=appointment.IselementPresent(appointment.appointmentdate_Set_btn_native);
								if (setbtn) {
									appointment.Openlinks(appointment.appointmentdate_Set_btn_native);
								}
								s_assert.assertTrue(setbtn, "Set Button is not present");
							}
							s_assert.assertTrue(dateselect, "Select date is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for appointment date");
						}
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(appodate, "appodate drop down is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmdate, "Confirm buton for phone is not present");

			Boolean confirmname=appointment.Openlinks(appointment.confirm_btn);
			if (confirmname) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean name=appointment.IselementPresent(appointment.name_text);
					if (name) {
						appointment.TextField(appointment.name_text, "Anurag Singh");
					}
					s_assert.assertTrue(name, "name text filed is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmname, "Confirm buton is not present");

			Boolean confirmemail=appointment.Openlinks(appointment.confirm_btn);
			if (confirmemail) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean email=appointment.IselementPresent(appointment.email_text);
					if (email) {
						appointment.TextField(appointment.email_text, "prince@appypie.com");
					}
					s_assert.assertTrue(email, "Email text filed is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmemail, "Confirm buton for Email is not present");

			Boolean confirmPhone=appointment.Openlinks(appointment.confirm_btn);
			if (confirmPhone) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean phone=appointment.IselementPresent(appointment.phone_text);
					if (phone) {
						appointment.TextField(appointment.phone_text, "+911234567890");
					}
					s_assert.assertTrue(phone, "phone text filed is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmPhone, "Confirm buton for phone is not present");

			Boolean confirmtime=appointment.Openlinks(appointment.confirm_btn);
			if (confirmtime) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean appotime=appointment.IselementPresent(appointment.appointmenttime_droplist);
					if (appotime) {
						if (!globledeviceName.equals("iPhone")) {
							//appointment.Openlinks(appointment.appointmenttime_droplist);
							WebElement element = driver.findElement(appointment.appointmenttime_droplist);
							Actions action = new Actions(driver);
							action.moveToElement(element).click().perform();
							TimeUnit.SECONDS.sleep(2);
						}
						else {
							Boolean iappointmenttime=comm.Openlinks(appointment.i_appointmenttime_droplist);
							if (iappointmenttime) {
								comm.Openlinks(appointment.i_appointmenttime_droplist);
							}
							s_assert.assertTrue(iappointmenttime, "iappointment time is not working ");
							TimeUnit.SECONDS.sleep(2);
							
						}
						
					
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean timeselect =appointment.IselementPresent(appointment.appointmenttime_native);
							if (timeselect) {
								comm.Getactualtext(appointment.AppointmentTime_gettext_native);
								boolean setbtn=appointment.IselementPresent(appointment.appointmenttime_Set_btn_native);
								if (setbtn) {
									TimeUnit.SECONDS.sleep(2);
									appointment.Openlinks(appointment.appointmenttime_hour_native);
									TimeUnit.SECONDS.sleep(2);
									appointment.Openlinks(appointment.appointmenttime_Set_btn_native);
								}
								s_assert.assertTrue(setbtn, "Set Button is not present");
							}
							s_assert.assertTrue(timeselect, "Select time is not present");
						}
						else {
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for appointment time");
						}
						
						PageElement.changeContextToWebView(driver);

					}
					s_assert.assertTrue(appotime, "appodate drop down is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmtime, "Confirm buton for phone is not present");

			Boolean confirmgender=appointment.Openlinks(appointment.confirm_btn);
			if (confirmgender) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean gender=appointment.IselementPresent(appointment.gender_droplist);
					if (gender) {
						
						
						if (!globledeviceName.equals("iPhone")) {
							//appointment.Openlinks(appointment.gender_droplist);
							WebElement element = driver.findElement(appointment.gender_droplist);
							Actions action = new Actions(driver);
							action.moveToElement(element).click().perform();
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean igender=comm.Openlinks(appointment.gender_droplist);
							if (igender) {
								comm.Openlinks(appointment.gender_droplist);
							}
							s_assert.assertTrue(igender, "iGender link is not working");
						}
						
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean genderselect =appointment.IselementPresent(appointment.gender_gettext_native);
							if (genderselect) {
								comm.Getactualtext(appointment.gender_gettext_native);
								boolean male=appointment.IselementPresent(appointment.gender_male_radiobtn_native);
								if (male) {
									appointment.Openlinks(appointment.gender_male_radiobtn_native);
								}
								s_assert.assertTrue(male, "Male radio is not present");
							}
							s_assert.assertTrue(genderselect, "Gender heading is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
						}
						
						PageElement.changeContextToWebView(driver);

					}
					s_assert.assertTrue(gender, "Gender drop down is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmgender, "Confirm buton for phone is not present");

			Boolean confirmcountry=appointment.Openlinks(appointment.confirm_btn);
			if (confirmcountry) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean country=appointment.IselementPresent(appointment.country_droplist);
					if (country) {
						appointment.Openlinks(appointment.country_droplist);
						TimeUnit.SECONDS.sleep(2);
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean countryframe =appointment.IselementPresent(appointment.Countryframe_native);
							if (countryframe) {

								appointment.countryselect();
							}
							s_assert.assertTrue(countryframe, "country frame is not present");
						}
						else {
							PageElement.changeContextToWebView(driver);
							Boolean icountryselect=comm.Openlinks(appointment.i_CountryApportment);
							if (icountryselect) {
								driver.context("NATIVE_APP");
								Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
								s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
							}
							s_assert.assertTrue(icountryselect, "iCountry is not selected");
						}
			
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(country, "country drop down is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmcountry, "Confirm buton for country is not present");

			Boolean confirmstate=appointment.Openlinks(appointment.confirm_btn);
			if (confirmstate) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean state=appointment.IselementPresent(appointment.state_text);
					if (state) {
						appointment.TextField(appointment.state_text, "Delhi");
					}
					s_assert.assertTrue(state, "state text filed is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmstate, "Confirm buton is not present");


			Boolean confirmAbout=appointment.Openlinks(appointment.confirm_btn);
			if (confirmAbout) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean aboutyou=appointment.IselementPresent(appointment.aboutYou_text);
					if (aboutyou) {
						appointment.TextField(appointment.aboutYou_text, "Hi my name appium driver for using android application automation.");
					}
					s_assert.assertTrue(aboutyou, "About you text filed is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmAbout, "Confirm buton is not present");

			Boolean confirmproblem=appointment.Openlinks(appointment.confirm_btn);
			if (confirmproblem) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean problem=appointment.IselementPresent(appointment.whatyourprobleam_text);
					if (problem) {
						appointment.TextField(appointment.whatyourprobleam_text, "Hi my name appium driver for using android application automation.");
					}
					s_assert.assertTrue(problem, "what your problem text filed is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmproblem, "Confirm buton is not present");

			Boolean confirmbodypart=appointment.Openlinks(appointment.confirm_btn);
			if (confirmbodypart) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean head=appointment.IselementPresent(appointment.head_checkbox);
					if (head) {
						appointment.Openlinks(appointment.head_checkbox);
					}
					s_assert.assertTrue(head, "head check box is not present");

					Boolean arm=appointment.IselementPresent(appointment.arm_checkbox);
					if (arm) {
						appointment.Openlinks(appointment.arm_checkbox);
					}
					s_assert.assertTrue(arm, "arm check box is not present");

					Boolean shoulder=appointment.IselementPresent(appointment.shoulder_checkbox);
					if (shoulder) {
						appointment.Openlinks(appointment.shoulder_checkbox);
					}
					s_assert.assertTrue(shoulder, "shoulder check box is not present");

					Boolean finger=appointment.IselementPresent(appointment.finger_checkbox);
					if (finger) {
						appointment.Openlinks(appointment.finger_checkbox);
					}
					s_assert.assertTrue(finger, "finger check box is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmbodypart, "Confirm buton is not present");


			Boolean confirmmeetme=appointment.Openlinks(appointment.confirm_btn);
			if (confirmmeetme) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean meetme=appointment.IselementPresent(appointment.meettingme_droplist);
					if (meetme) {
					
						
						if (!globledeviceName.equals("iPhone")) {
							//appointment.Openlinks(appointment.meettingme_droplist);
							WebElement element = driver.findElement(appointment.meettingme_droplist);
							Actions action = new Actions(driver);
							action.moveToElement(element).click().perform();
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean imeetting=comm.Openlinks(appointment.meettingme_droplist);
							if (imeetting) {
								comm.Openlinks(appointment.meettingme_droplist);
							}
							s_assert.assertTrue(imeetting, "imeetting link is not working");
						}
						
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean meetmetext =appointment.IselementPresent(appointment.meetme_gettext_native);
							if (meetmetext) {
								comm.Getactualtext(appointment.meetme_gettext_native);
								Boolean atoffice=appointment.IselementPresent(appointment.meettime_atoffice_radiobtn_native);
								if (atoffice) {
									appointment.Openlinks(appointment.meettime_atoffice_radiobtn_native);
								}
								s_assert.assertTrue(atoffice,"At office radio button is not present");
							}
							s_assert.assertTrue(meetmetext, "meet me frame is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
						}
						
						PageElement.changeContextToWebView(driver);

					}
					s_assert.assertTrue(meetme, "meetme drop down is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmmeetme, "Confirm buton for country is not present");

			Boolean confirmpay=appointment.Openlinks(appointment.confirm_btn);
			if (confirmpay) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean bycash=appointment.IselementPresent(appointment.bycash_radiobtn);
					if (bycash) {
						appointment.Openlinks(appointment.bycash_radiobtn);
					}
					s_assert.assertTrue(bycash, "bycash radio button is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmpay, "Confirm buton for pay is not present");


			Boolean confirmdoctorType=appointment.Openlinks(appointment.confirm_btn);
			if (confirmdoctorType) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean doctortype=appointment.IselementPresent(appointment.doctortype_droplist);
					if (doctortype) {
						
						if (!globledeviceName.equals("iPhone")) {
							//appointment.Openlinks(appointment.gender_droplist);
							WebElement element = driver.findElement(appointment.doctortype_droplist);
							Actions action = new Actions(driver);
							action.moveToElement(element).click().perform();
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean idoctor=comm.Openlinks(appointment.i_doctortype_gents_checkbox_native);
							if (idoctor) {
								comm.Openlinks(appointment.i_doctortype_gents_checkbox_native);
							}
							s_assert.assertTrue(idoctor, "idoctor link is not working");
						}
						
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean gents =appointment.IselementPresent(appointment.doctortype_gents_checkbox_native);
							if (gents) {
								appointment.Openlinks(appointment.doctortype_gents_checkbox_native);
							}
							s_assert.assertTrue(gents, "gents check box is not present");

							Boolean ladies =appointment.IselementPresent(appointment.doctortype_ladies_checkbox_native);
							if (ladies) {
								appointment.Openlinks(appointment.doctortype_ladies_checkbox_native);
							}
							s_assert.assertTrue(ladies, "ladies check box is not present");

							Boolean ok =appointment.IselementPresent(appointment.doctortype_ok_btn_native);
							if (ok) {
								appointment.Openlinks(appointment.doctortype_ok_btn_native);
							}
							s_assert.assertTrue(ok, "ok btn for doctoy type is not present");
						}
						else {
							
							Boolean igent=PageElement.Accessibilitylinks(appointment.i_Gents);
							if (igent) {
								Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
								s_assert.assertTrue(idone, "idone button is not working on gents");
							}
							s_assert.assertTrue(igent,"iGents is not selected");
							
							/*
							 PageElement.changeContextToWebView(driver);
							Boolean gents =appointment.IselementPresent(appointment.i_doctortype_gents_checkbox_native);
							if (gents) {
								appointment.Openlinks(appointment.i_doctortype_gents_checkbox_native);
							}
							s_assert.assertTrue(gents, "igents check box is not present");

							Boolean ladies =appointment.IselementPresent(appointment.i_doctortype_ladies_checkbox_native);
							if (ladies) {
								appointment.Openlinks(appointment.i_doctortype_ladies_checkbox_native);
							}
							s_assert.assertTrue(ladies, "iladies check box is not present");*/
						}
						
						PageElement.changeContextToWebView(driver);

					}
					s_assert.assertTrue(doctortype, "doctor type drop down is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmdoctorType, "Confirm buton for doctor Type is not present");

			Boolean confirmUpload=appointment.Openlinks(appointment.confirm_btn);
			if (confirmUpload) {
				Boolean alert=appointment.IselementPresent(appointment.AlertHeader_gettext);
				if (alert) {
					Logger.info("Alert Is present");
					appointment.IfAlertpresent();

					Boolean upload=appointment.IselementPresent(appointment.uploadyourreport_link);
					if (upload) {
					
						
						if (!globledeviceName.equals("iPhone")) {
							//appointment.Openlinks(appointment.uploadyourreport_link);
							WebElement element = driver.findElement(appointment.uploadyourreport_link);
							Actions action = new Actions(driver);
							action.moveToElement(element).click().perform();
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean iuploadyourreport=comm.Openlinks(appointment.uploadyourreport_link);
							if (iuploadyourreport) {
								comm.Openlinks(appointment.uploadyourreport_link);
							}
							s_assert.assertTrue(iuploadyourreport, "iuploadyourreport link is not working");
						}

						Boolean gallery=appointment.IselementPresent(appointment.gallery_link);
						if (gallery) {
							appointment.Openlinks(appointment.gallery_link);
							driver.context("NATIVE_APP");
							if (!globledeviceName.equals("iPhone")) {
								TimeUnit.SECONDS.sleep(2);
								appointment.Openlinks(appointment.selectphoto_native);
							}
							else {
								Boolean icameraroll=PageElement.Accessibilitylinks(PageElement.i_cameraRoll);
								if (icameraroll) {
									Boolean ifirstphoto=PageElement.Accessibilitylinks(PageElement.i_image);
									s_assert.assertTrue(ifirstphoto, "iFirst photo is not selected");
								}
								s_assert.assertTrue(icameraroll, "iCamera roll is not open");
							}
							PageElement.changeContextToWebView(driver);
							
							Boolean cancle=appointment.IselementPresent(appointment.cancle_link);
							if (cancle) {
								appointment.Openlinks(appointment.cancle_link);
							}
							else {
								System.out.println("Cancle Button is not present");
							}
							
						}
						s_assert.assertTrue(gallery, "Gallery link is not present");

						Boolean confirmbtn=appointment.IselementPresent(appointment.confirm_btn);
						if (confirmbtn) {
							appointment.Openlinks(appointment.confirm_btn);

							Boolean thankyou=appointment.IselementPresent(appointment.AlertHeader_gettext);
							if (thankyou) {
								appointment.IfAlertpresent();
							}
							s_assert.assertTrue(thankyou, "thank you Popup is not present");
						}
						s_assert.assertTrue(confirmbtn, "Confirm button is not present");

					}
					s_assert.assertTrue(upload, "upload button is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(confirmUpload, "Confirm buton for upload is not present");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void verifyInquireFieldOpen() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  verifyInquireModule()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");

			Boolean inquirefield=deshboard.IselementPresent(deshboard.inquire_link);
			if (inquirefield) {
				deshboard.Openlinks(deshboard.inquire_link);
				s_assert.assertEquals(comm.Getactualtext(inquire.header_gettext), "Inquire");
			}
			s_assert.assertTrue(inquirefield, "Inquire field is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void verifyInquireForm() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  verifyInquireForm()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");

			Boolean inquirefield=deshboard.Openlinks(deshboard.inquire_link);
			s_assert.assertTrue(inquirefield, "Inquire field is not present");

			Boolean submitfname=inquire.IselementPresent(inquire.submit_btn);
			if (submitfname) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean fname=inquire.IselementPresent(inquire.firstname_text);
					if (fname) {
						inquire.TextField(inquire.firstname_text, "Anurag");
					}
					s_assert.assertTrue(fname, "First name is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitfname, "Submit button for first name is not present");

			Boolean submitlname=inquire.IselementPresent(inquire.submit_btn);
			if (submitlname) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean lname=inquire.IselementPresent(inquire.lastname_text);
					if (lname) {
						inquire.TextField(inquire.lastname_text, "Singh");
					}
					s_assert.assertTrue(lname, "Last name is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitlname, "Submit button for last name is not present");

			Boolean submitEmail=inquire.IselementPresent(inquire.submit_btn);
			if (submitEmail) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean email=inquire.IselementPresent(inquire.email_text);
					if (email) {
						inquire.TextField(inquire.email_text, "prince@appypie.com");
					}
					s_assert.assertTrue(email, "Email id is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitEmail, "Submit button for email id is not present");

			Boolean submitcompany=inquire.IselementPresent(inquire.submit_btn);
			if (submitcompany) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean company=inquire.IselementPresent(inquire.companyname_text);
					if (company) {
						inquire.TextField(inquire.companyname_text, "Appypie");
					}
					s_assert.assertTrue(company, "Company is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitcompany, "Submit button for company is not present");

			Boolean mobile=inquire.IselementPresent(inquire.mobile_text);
			if (mobile) {
				inquire.TextField(inquire.mobile_text, "9540198626");
			}
			s_assert.assertTrue(mobile, "Mobile text field is not present");

			Boolean submitphone=inquire.IselementPresent(inquire.submit_btn);
			if (submitphone) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean phone=inquire.IselementPresent(inquire.phone_text);
					if (phone) {
						inquire.TextField(inquire.phone_text, "9540198626");
					}
					s_assert.assertTrue(phone, "Phone  text field is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitphone, "Submit button for Phone is not present");

			Boolean website=inquire.IselementPresent(inquire.website_text);
			if (website) {
				inquire.TextField(inquire.website_text, "appypie.com");
			}
			s_assert.assertTrue(website, "Website text field is not present");

			Boolean submitcity=inquire.IselementPresent(inquire.submit_btn);
			if (submitcity) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean city=inquire.IselementPresent(inquire.city_text);
					if (city) {
						inquire.TextField(inquire.city_text, "Noida");
					}
					s_assert.assertTrue(city, "City text field is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitcity, "Submit button for city is not present");

			Boolean submitcountry=inquire.IselementPresent(inquire.submit_btn);
			if (submitcountry) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean country=inquire.IselementPresent(inquire.country_droplist);
					if (country) {
						if (!globledeviceName.equals("iPhone")) {
							inquire.Openlinks(inquire.country_droplist);
							inquire.countryselect();
						}
						else {
							PageElement.changeContextToWebView(driver);
							Boolean icountry=inquire.Openlinks(inquire.country_droplist);
							if (icountry) {
								driver.context("NATIVE_APP");
								Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
								s_assert.assertTrue(idone, "iDone button is not working for Country selection");
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(icountry, "icountry is not selected");
						}
						
					}
					s_assert.assertTrue(country, "country drop list is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitcountry, "Submit button for Country  is not present");

			Boolean submitcomment=inquire.IselementPresent(inquire.submit_btn);
			if (submitcomment) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					inquire.IfAlertpresent();
					Boolean comment=inquire.IselementPresent(inquire.comments_text);
					if (comment) {
						inquire.TextField(inquire.comments_text, "Hi my name appium driver for using android application automation.");
					}
					s_assert.assertTrue(comment, "City text field is not present");
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submitcomment, "Submit button for city is not present");

			Boolean submit=inquire.IselementPresent(inquire.submit_btn);
			if (submit) {
				inquire.Openlinks(inquire.submit_btn);
				Boolean alert=inquire.IselementPresent(inquire.AlertHeader_gettext);
				if (alert) {
					s_assert.assertEquals(comm.Getactualtext(inquire.AlertHeader_gettext), "App_Automation_by_Anurag");
					s_assert.assertEquals(comm.Getactualtext(inquire.AlertText_gettext), "Thank you for your interest. We will get back to you soon.");
					inquire.IfAlertpresent();
					TimeUnit.SECONDS.sleep(10);
				}
				s_assert.assertTrue(alert, "Alert is not present");
			}
			s_assert.assertTrue(submit, "Submit button is not present");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VeriyCustomeFieldOpen() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyCustomeFieldOpen()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");
			Boolean customefield=deshboard.IselementPresent(deshboard.custome);
			if (customefield) {
				deshboard.Openlinks(deshboard.custome);
				s_assert.assertEquals(comm.Getactualtext(custom.header_gettext), "Custom");
			}
			s_assert.assertTrue(customefield, "Custome field is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VeriyCustomeForm() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyCustomeForm()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");

			Boolean customefield=deshboard.Openlinks(deshboard.custome);
			s_assert.assertTrue(customefield, "Custome field is not present");

//			String heading=comm.Getactualtext(custom.headingMessage_gettext);
//			s_assert.assertNotNull(heading, "Heading is getting Null value");

			Boolean submitname=custom.IselementPresent(custom.submit_btn);
			if (submitname) {
				custom.Openlinks(custom.submit_btn);
				
					custom.IfAlertpresent();
					Boolean name=custom.IselementPresent(custom.name_text);
					if (name) {
						Boolean info=comm.Openlinks(custom.nameinfo);
						if (info) {
							comm.IfAlertpresent();
						}
						custom.TextField(custom.name_text, "Anurag Singh");
					}
					s_assert.assertTrue(name, "Name text filed is not present.");
				
			}
			s_assert.assertTrue(submitname, "Submit button for name is not present");

			Boolean submitemail=custom.IselementPresent(custom.submit_btn);
			if (submitemail) {
				custom.Openlinks(custom.submit_btn);
				
					custom.IfAlertpresent();
					Boolean email=custom.IselementPresent(custom.email_text);
					if (email) {

						Boolean info=comm.Openlinks(custom.emailinfo);
						if (info) {
							comm.IfAlertpresent();
						}
						custom.TextField(custom.email_text, "prince@appypie.com");
					}
					s_assert.assertTrue(email, "Email text filed is not present.");
				
			}
			s_assert.assertTrue(submitemail, "Submit button for Email is not present");

			Boolean submitgender=custom.IselementPresent(custom.submit_btn);
			if (submitgender) {
				custom.Openlinks(custom.submit_btn);
			
					custom.IfAlertpresent();
					Boolean gender=custom.IselementPresent(custom.gender_droplist);
					if (gender) {
						
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.gender_droplist);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean igender=comm.Openlinks(custom.gender_droplist);
							if (igender) {
								comm.Openlinks(custom.gender_droplist);
							}
							s_assert.assertTrue(igender, "igender link is not working");
						}
						
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean genderselect =custom.IselementPresent(custom.gender_gettext_native);
							if (genderselect) {
								comm.Getactualtext(custom.gender_gettext_native);
								boolean male=custom.IselementPresent(custom.gender_male_radiobtn_native);
								if (male) {
									custom.Openlinks(custom.gender_male_radiobtn_native);
								}
								s_assert.assertTrue(male, "Male radio is not present");
							}
							s_assert.assertTrue(genderselect, "Gender heading is not present");
						}
						else {
							driver.context("NATIVE_APP");
							comm.SwipeBottomToTop();
								Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
								s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
							
						
						}
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(gender, "Gender text filed is not present.");
				
			}
			s_assert.assertTrue(submitgender, "Submit button for gender is not present");

			Boolean submitphone=custom.IselementPresent(custom.submit_btn);
			if (submitphone) {
				custom.Openlinks(custom.submit_btn);
			
					custom.IfAlertpresent();
					Boolean phone=custom.IselementPresent(custom.phone_text);
					if (phone) {
						Boolean info=comm.Openlinks(custom.phoneinfo);
						if (info) {
							comm.IfAlertpresent();
						}
						custom.TextField(custom.phone_text, "9540198626");
					}
					s_assert.assertTrue(phone, "Phone text filed is not present.");
				
			}
			s_assert.assertTrue(submitphone, "Submit button for Phone is not present");

			Boolean submitdate=custom.Openlinks(custom.submit_btn);
			if (submitdate) {
				
					custom.IfAlertpresent();

					Boolean customdate=custom.IselementPresent(custom.date);
					if (customdate) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.date);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean idate=comm.Openlinks(custom.date);
							if (idate) {
								comm.Openlinks(custom.date);
							}
							s_assert.assertTrue(idate, "idate link is not working");
						}
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean dateselect =custom.IselementPresent(custom.Date_gettext_native);
							if (dateselect) {
								comm.Getactualtext(custom.Date_gettext_native);
								boolean setbtn=custom.IselementPresent(custom.date_Set_btn_native);
								if (setbtn) {
									custom.Openlinks(custom.date_Set_btn_native);
								}
								s_assert.assertTrue(setbtn, "Set Button is not present");
							}
							s_assert.assertTrue(dateselect, "Select date is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
						}
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(customdate, "custom date drop down is not present");
				
			}
			s_assert.assertTrue(submitdate, "Submit buton for date is not present");

			//=============================================================================================
			PageElement.changeContextToWebView(driver);
			Boolean submittime=custom.Openlinks(custom.submit_btn);
			if (submittime) {
			
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean customtime=custom.IselementPresent(custom.time);
					if (customtime) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.time);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean itime=comm.Openlinks(custom.time);
							if (itime) {
								comm.Openlinks(custom.time);
							}
							s_assert.assertTrue(itime, "itime link is not working");
						}
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean timeselect =custom.IselementPresent(custom.Time_gettext_native);
							if (timeselect) {
								comm.Getactualtext(custom.Time_gettext_native);
								boolean setbtn=custom.IselementPresent(custom.time_Set_btn_native);
								if (setbtn) {
									TimeUnit.SECONDS.sleep(2);
									custom.Openlinks(custom.time_hour_native);
									TimeUnit.SECONDS.sleep(2);
									custom.Openlinks(custom.time_Set_btn_native);
								}
								s_assert.assertTrue(setbtn, "Set Button is not present");
							}
							s_assert.assertTrue(timeselect, "Select time is not present");
						}
						else {
							TimeUnit.SECONDS.sleep(2);
							driver.context("NATIVE_APP");
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
						}
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(customtime, "Time drop down is not present");
				
			}
			s_assert.assertTrue(submittime, "Confirm buton for Time is not present");


			Boolean submitcountry=custom.Openlinks(custom.submit_btn);
			if (submitcountry) {
			
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean country=custom.IselementPresent(custom.country_droplist);
					if (country) {
						custom.Openlinks(custom.country_droplist);
						TimeUnit.SECONDS.sleep(2);
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean countryframe =custom.IselementPresent(custom.Countryframe_native);
							if (countryframe) {
								custom.countryselect();
							}
							s_assert.assertTrue(countryframe, "country frame is not present");
						}
						else {
							PageElement.changeContextToWebView(driver);
							Boolean icountryselect=comm.Openlinks(appointment.i_CountryCustome);
							if (icountryselect) {
								driver.context("NATIVE_APP");
								Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
								s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
							}
							s_assert.assertTrue(icountryselect, "iCountry is not selected");
							
						}
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(country, "country drop down is not present");
				
			}
			s_assert.assertTrue(submitcountry, "submit buton for country is not present");

			Boolean submitstate=custom.Openlinks(custom.submit_btn);
			if (submitstate) {
				
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean state=custom.IselementPresent(custom.state_text);
					if (state) {
						custom.TextField(custom.state_text, "Delhi");
					}
					s_assert.assertTrue(state, "state text filed is not present");
				
			}
			s_assert.assertTrue(submitstate, "submit buton for state is not present");

			
			Boolean submitfirm=custom.Openlinks(custom.submit_btn);
			if (submitfirm) {
			
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean firm=custom.IselementPresent(custom.firm_text);
					if (firm) {
						custom.TextField(custom.firm_text, "Appypie Noida");
					}
					s_assert.assertTrue(firm, "firm text filed is not present");
				
			}
			s_assert.assertTrue(submitfirm, "submit buton for firm is not present");

			Boolean submitintrest=custom.Openlinks(custom.submit_btn);
			if (submitintrest) {
		
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean intrest=custom.IselementPresent(custom.intrestHobbies_text);
					if (intrest) {
						custom.TextField(custom.intrestHobbies_text, "Appypie");
					}
					s_assert.assertTrue(intrest, "Intrest text filed is not present");
				
			}
			s_assert.assertTrue(submitintrest, "submit buton for Intrest is not present");

			Boolean submitjobType=custom.Openlinks(custom.submit_btn);
			if (submitjobType) {
		
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean tele=custom.IselementPresent(custom.telephonic_checkbox);
					if (tele) {
						custom.Openlinks(custom.telephonic_checkbox);
					}
					s_assert.assertTrue(tele, "telephonic check box is not present");

					Boolean deposition=custom.IselementPresent(custom.deposition_checkbox);
					if (deposition) {
						custom.Openlinks(custom.deposition_checkbox);
					}
					s_assert.assertTrue(deposition, "deposition check box is not present");

					Boolean arbitration=custom.IselementPresent(custom.arbitration_checkbox);
					if (arbitration) {
						custom.Openlinks(custom.arbitration_checkbox);
					}
					s_assert.assertTrue(arbitration, "arbitration check box is not present");

					Boolean hearing=custom.IselementPresent(custom.hearing_checkbox);
					if (hearing) {
						custom.Openlinks(custom.hearing_checkbox);
					}
					s_assert.assertTrue(hearing, "hearing check box is not present");

					Boolean meeting=custom.IselementPresent(custom.meeting_checkbox);
					if (meeting) {
						custom.Openlinks(custom.meeting_checkbox);
					}
					s_assert.assertTrue(meeting, "meeting check box is not present");
				
			}
			s_assert.assertTrue(submitjobType, "submit buton for Job type is not present");	


			Boolean submitpay=custom.Openlinks(custom.submit_btn);
			if (submitpay) {
			
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean website=custom.IselementPresent(custom.website_radiobtn);
					if (website) {
						custom.Openlinks(custom.website_radiobtn);
					}
					s_assert.assertTrue(website, "website radio button is not present");
				
			}
			s_assert.assertTrue(submitpay, "submit buton for aboutUS is not present");	


			Boolean submitjob=custom.IselementPresent(custom.submit_btn);
			if (submitjob) {
				custom.Openlinks(custom.submit_btn);
				
					custom.IfAlertpresent();
					Boolean job=custom.IselementPresent(custom.job_droplist);
					if (job) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.job_droplist);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean ijob_droplist=comm.Openlinks(custom.job_droplist);
							if (ijob_droplist) {
								comm.Openlinks(custom.job_droplist);
							}
							s_assert.assertTrue(ijob_droplist, "job_droplist link is not working");
						}
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean job1 =custom.IselementPresent(custom.job_gettext_native);
							if (job1) {
								comm.Getactualtext(custom.job_gettext_native);
								boolean office=custom.IselementPresent(custom.job_office_radiobtn_native);
								if (office) {
									custom.Openlinks(custom.job_office_radiobtn_native);
								}
								s_assert.assertTrue(office, "office radio is not present");
							}
							s_assert.assertTrue(job1, "job* heading is not present");
						}
						else {
							driver.context("NATIVE_APP");
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Gender selection");
						}
					
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(job, "Job drop list is not present.");
				
			}
			s_assert.assertTrue(submitjob, "Submit button for Job is not present");

			Boolean submitchoose1=custom.IselementPresent(custom.submit_btn);
			if (submitchoose1) {
				custom.Openlinks(custom.submit_btn);
			
					custom.IfAlertpresent();
					Boolean choose1=custom.IselementPresent(custom.chooseOption1_droplist);
					if (choose1) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.chooseOption1_droplist);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean ichooseOption1_droplist=comm.Openlinks(custom.chooseOption1_droplist);
							if (ichooseOption1_droplist) {
								comm.Openlinks(custom.chooseOption1_droplist);
							}
							s_assert.assertTrue(ichooseOption1_droplist, "ichooseOption1_droplist link is not working");
						}
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean chooseanOption =custom.IselementPresent(custom.chooseOption1_gettext_native);
							if (chooseanOption) {
								comm.Getactualtext(custom.chooseOption1_gettext_native);
								boolean office=custom.IselementPresent(custom.chooseOption1_office_radiobtn_native);
								if (office) {
									custom.Openlinks(custom.chooseOption1_office_radiobtn_native);
								}
								s_assert.assertTrue(office, "office radio is not present");
							}
							s_assert.assertTrue(chooseanOption, "chooseanOption* heading is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Choose option 1");
						}
					
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(choose1, "choose1 drop list is not present.");
				
			}
			s_assert.assertTrue(submitchoose1, "Submit button for Choose1 is not present");

			Boolean submitchoose2=custom.IselementPresent(custom.submit_btn);
			if (submitchoose2) {
				custom.Openlinks(custom.submit_btn);
			
					custom.IfAlertpresent();
					Boolean choose2=custom.IselementPresent(custom.chooseOption2_droplist);
					if (choose2) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.chooseOption2_droplist);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean ichooseOption2_droplist=comm.Openlinks(custom.chooseOption2_droplist);
							if (ichooseOption2_droplist) {
								comm.Openlinks(custom.chooseOption2_droplist);
							}
							s_assert.assertTrue(ichooseOption2_droplist, "ichooseOption2_droplist link is not working");
						}
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean chooseanOption =custom.IselementPresent(custom.chooseOption2_gettext_native);
							if (chooseanOption) {
								comm.Getactualtext(custom.chooseOption2_gettext_native);
								boolean forwork=custom.IselementPresent(custom.chooseOption2_forwork_radiobtn_native);
								if (forwork) {
									custom.Openlinks(custom.chooseOption2_forwork_radiobtn_native);
								}
								s_assert.assertTrue(forwork, "for work radio is not present");
							}
							s_assert.assertTrue(chooseanOption, "chooseanOption2* heading is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Choose option 2");
						}
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(choose2, "choose2 drop list is not present.");
				
			}
			s_assert.assertTrue(submitchoose2, "Submit button for Choose2 is not present");

			Boolean submitJobType=custom.IselementPresent(custom.submit_btn);
			if (submitJobType) {
				custom.Openlinks(custom.submit_btn);
			
					custom.IfAlertpresent();
					Boolean jobtype=custom.IselementPresent(custom.jobtype_droplist);
					if (jobtype) {
					
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.jobtype_droplist);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean ijobtype_droplist=comm.Openlinks(custom.jobtype_droplist);
							if (ijobtype_droplist) {
								comm.Openlinks(custom.jobtype_droplist);
							}
							s_assert.assertTrue(ijobtype_droplist, "ijobtype_droplist link is not working");
						}
						
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);

							Boolean AD=custom.IselementPresent(custom.jobtype_AD_checkboc_native);
							if (AD) {
								custom.Openlinks(custom.jobtype_AD_checkboc_native);
							}
							s_assert.assertTrue(AD, "AD check box is not present");

							Boolean AM=custom.IselementPresent(custom.jobtype_AM_checkboc_native);
							if (AM) {
								custom.Openlinks(custom.jobtype_AM_checkboc_native);
							}
							s_assert.assertTrue(AM, "AM check box is not present");

							Boolean AP=custom.IselementPresent(custom.jobtype_AP_checkboc_native);
							if (AP) {
								custom.Openlinks(custom.jobtype_AP_checkboc_native);
							}
							s_assert.assertTrue(AP, "AP check box is not present");

							Boolean AA=custom.IselementPresent(custom.jobtype_AA_checkboc_native);
							if (AA) {
								custom.Openlinks(custom.jobtype_AA_checkboc_native);
							}
							s_assert.assertTrue(AA, "AA check box is not present");

							Boolean ok=custom.IselementPresent(custom.jobtype_OK_btn_native);
							if (ok) {
								custom.Openlinks(custom.jobtype_OK_btn_native);
							}
							s_assert.assertTrue(ok, "OK Button is not present");
						}
						else {
							driver.context("NATIVE_APP");
							PageElement.Accessibilitylinks(custom.i_jobtype_AD_checkboc_native);
							PageElement.Accessibilitylinks(custom.i_jobtype_AM_checkboc_native);
							PageElement.Accessibilitylinks(custom.i_jobtype_AP_checkboc_native);
						
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Choose option 2");
						}
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(jobtype, "job type drop list is not present.");
				
			}
			s_assert.assertTrue(submitJobType, "Submit button for Job Type is not present");

			Boolean submitselectionBasedEmail=custom.IselementPresent(custom.submit_btn);
			if (submitselectionBasedEmail) {
				custom.Openlinks(custom.submit_btn);
			
					custom.IfAlertpresent();
					Boolean basedemail=custom.IselementPresent(custom.selectionBasedEmail_droplist);
					if (basedemail) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.selectionBasedEmail_droplist);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean iselectionBasedEmail_droplistt=comm.Openlinks(custom.selectionBasedEmail_droplist);
							if (iselectionBasedEmail_droplistt) {
								comm.Openlinks(custom.selectionBasedEmail_droplist);
							}
							s_assert.assertTrue(iselectionBasedEmail_droplistt, "iselectionBasedEmail_droplistt link is not working");
						}
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							TimeUnit.SECONDS.sleep(2);
							Boolean selectionemail =custom.IselementPresent(custom.selectionBasedEmail_gettext_native);
							if (selectionemail) {
								comm.Getactualtext(custom.selectionBasedEmail_gettext_native);
								boolean office=custom.IselementPresent(custom.selectionBasedEmail_Office_radiobtn_native);
								if (office) {
									custom.Openlinks(custom.selectionBasedEmail_Office_radiobtn_native);
								}
								s_assert.assertTrue(office, "office radio is not present");
							}
							s_assert.assertTrue(selectionemail, "selectionemail* heading is not present");
						}
						else {
							comm.SwipeBottomToTop();
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone, "iDone button is not working for Email");
						}
			
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(basedemail, "Based email drop list is not present.");
			
			}
			s_assert.assertTrue(submitselectionBasedEmail, "Submit button for selection Based Email is not present");

			Boolean submitResume=custom.Openlinks(custom.submit_btn);
			if (submitResume) {
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean upload=custom.IselementPresent(custom.resume_link);
					if (upload) {
						Boolean info=comm.Openlinks(custom.resumeinfo);
						if (info) {
							comm.IfAlertpresent();
						}

					
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.resume_link);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean iresume_link=comm.Openlinks(custom.resume_link);
							if (iresume_link) {
								comm.Openlinks(custom.resume_link);
							}
							s_assert.assertTrue(iresume_link, "iresume_link link is not working");
						}

						Boolean gallery=custom.IselementPresent(custom.gallery_link);
						if (gallery) {
							custom.Openlinks(custom.gallery_link);
							driver.context("NATIVE_APP");
							if (!globledeviceName.equals("iPhone")) {
								TimeUnit.SECONDS.sleep(2);
								custom.Openlinks(custom.selectphoto_native);
							}
							else {
								Boolean icameraroll=PageElement.Accessibilitylinks(PageElement.i_cameraRoll);
								if (icameraroll) {
									Boolean ifirstphoto=PageElement.Accessibilitylinks(PageElement.i_image);
									s_assert.assertTrue(ifirstphoto, "iFirst photo is not selected");
								}
								s_assert.assertTrue(icameraroll, "iCamera roll is not open");
							}
							
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(gallery, "Gallery link is not present");
					}
					s_assert.assertTrue(upload, "upload button is not present");
			
			}
			s_assert.assertTrue(submitResume, "submit buton for resume is not present");

			Boolean submitSign=custom.Openlinks(custom.submit_btn);
			if (submitSign) {
		
					Logger.info("Alert Is present");
					custom.IfAlertpresent();

					Boolean upload=custom.IselementPresent(custom.signheare_link);
					if (upload) {
						
						if (!globledeviceName.equals("iPhone")) {
							custom.Actionclick(custom.signheare_link);
							TimeUnit.SECONDS.sleep(2);
						}
						else{
							Boolean isignheare_link=comm.Openlinks(custom.signheare_link);
							if (isignheare_link) {
								comm.Openlinks(custom.signheare_link);
							}
							s_assert.assertTrue(isignheare_link, "isignheare_link link is not working");
						}

						Boolean gallery=custom.IselementPresent(custom.gallery_link);
						if (gallery) {
							custom.Openlinks(custom.gallery_link);
							driver.context("NATIVE_APP");
							if (!globledeviceName.equals("iPhone")) {
								TimeUnit.SECONDS.sleep(2);
								custom.Openlinks(custom.selectphoto_native);
							}
							else {
								Boolean icameraroll=PageElement.Accessibilitylinks(PageElement.i_cameraRoll);
								if (icameraroll) {
									Boolean ifirstphoto=PageElement.Accessibilitylinks(PageElement.i_image);
									s_assert.assertTrue(ifirstphoto, "iFirst photo is not selected for Sign");
								}
								s_assert.assertTrue(icameraroll, "iCamera roll is not open");
							}
							
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(gallery, "Gallery link is not present");
					}
					s_assert.assertTrue(upload, "upload button is not present");
				
			}
			s_assert.assertTrue(submitSign, "submit buton for Sign is not present");

			Boolean submit=inquire.IselementPresent(custom.submit_btn);
			if (submit) {
				custom.Openlinks(custom.submit_btn);
				custom.IfAlertpresent();
				driver.context("NATIVE_APP");
				if (!globledeviceName.equals("iPhone")) {
					TimeUnit.SECONDS.sleep(50);
					Boolean headernative=custom.IselementPresent(custom.header_gettext_native);
					if (headernative) {
						comm.Getactualtext(custom.header_gettext_native);
				}
				s_assert.assertTrue(headernative, "Header native not present");
				}				
					PageElement.changeContextToWebView(driver);

					try{
						System.out.println("try block");
						comm.Openlinks(custom.cancelpayment);
					}
					catch (Exception e) {
						System.out.println("catch block");
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							comm.Openlinks(custom.cancelpayment);
						}
						else {
							PageElement.changeContextToWebView(driver);
							comm.Openlinks(custom.cancelpayment);
						}
						
						PageElement.changeContextToWebView(driver);
					}
				PageElement.changeContextToWebView(driver);
			
		}
			s_assert.assertTrue(submit, "Submit button is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 7, description = "")
	public void verifyCamera_Sign() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  verifyDS()");
		boolean exception = false;
		try {
			Boolean formbuilder = deshboard.Openlinks(deshboard.formBuilderModule_link);
			s_assert.assertTrue(formbuilder, "Form Builder module is not open");

			Boolean customefield=deshboard.Openlinks(deshboard.custome);
			s_assert.assertTrue(customefield, "Custome field is not present");


			Boolean resume=comm.Openlinks(custom.resume_link);
			if (resume) {
				Boolean camera=comm.Openlinks(custom.camera_link);
				if (camera) {
					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						NavigationPage.verifyrunTimePermissions(driver);

						Boolean clickphotoo=comm.Openlinks(custom.clickPhoto);
						s_assert.assertTrue(clickphotoo, "Click photo link is not working");
					}
					else {
						NavigationPage.verifyrunTimePermissions(driver);

						Boolean i_clickphotoo=comm.Openlinks(PageElement.i_clickcameraphotoNative);
						if (i_clickphotoo) {
							driver.context("NATIVE_APP");
							Boolean iusephoto=PageElement.Accessibilitylinks(PageElement.i_cameraUsePhoto);
							s_assert.assertTrue(iusephoto, "iUse photo button is not working");
						}
						s_assert.assertTrue(i_clickphotoo, "Click photo link is not working");
					}
					PageElement.changeContextToWebView(driver);

				}
				s_assert.assertTrue(camera,"Camera Link is not working");
			}
			s_assert.assertTrue(resume, "Resume link is not working");

			Boolean signlink=comm.Openlinks(custom.signheare_link);
			if (signlink) {

				Boolean choosesignhere=comm.Openlinks(custom.signHerelink);
				if (choosesignhere) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Sign Here");
					comm.getCoordinates(custom.DS);
					comm.Openlinks(custom.DS);
					comm.Openlinks(custom.DS);
					Boolean clear=comm.Openlinks(custom.clear);
					s_assert.assertTrue(clear, "clear button is not working");
					comm.Openlinks(custom.DS);
					try{
						Boolean save=comm.Openlinks(custom.save);
						s_assert.assertTrue(save, "save button is not working");
					}
					catch (Exception e) {
						comm.Openlinks(comm.BackButton2);
					}
				}
				s_assert.assertTrue(choosesignhere, "Choose sign here link is not working");

			}
			s_assert.assertTrue(signlink, "Sign here link is not working");




		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


}