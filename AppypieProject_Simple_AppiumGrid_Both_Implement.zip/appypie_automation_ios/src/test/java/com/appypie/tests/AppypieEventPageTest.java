package com.appypie.tests;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.EventFulFeedsDetailPage;
import com.appypie.pages.EventPage;
import com.appypie.pages.EventfulFeedsListPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieEventPageTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	EventPage event;
	EventfulFeedsListPage feedpage;
	EventFulFeedsDetailPage feedsdetail;

	@BeforeTest
	@Override
	public void pageSetUp() {
		event = new EventPage(driver);
		feedpage = new EventfulFeedsListPage(driver);
		feedsdetail = new EventFulFeedsDetailPage(driver);
	}

	public void openEventUrls(String urlName) {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			event.openEventPage();
			boolean exist = event.isEventUrlExist(urlName);
			if (exist) {
				event.clickEventurl(urlName);
				if (urlName.equals("eventbrite")) {
					boolean open = feedpage.isEventBriteOpen();
					asser.assertTrue(open, "EventBrite url is not open");
				} else {
					boolean feeds = feedpage.isFeedsExist(urlName);
					if (!feeds) {
						boolean noData = feedpage.checkNoDataIcon();
						asser.assertFalse(noData, "NoData icon is present in " + urlName + " url");
						if (!noData) {
							boolean loader = feedpage.CheckLoader();
							asser.assertFalse(loader, "loader is continuously rotating in " + urlName + " url");
						}
					}
					asser.assertTrue(feeds, "feeds are not present in " + urlName + " url");
				}
			} else {
				Logger.info(urlName + " url not exist on the event page");
			}
			asser.assertTrue(exist, urlName + "url is not exist in the event page");
		} catch (Exception e) {
			Logger.error(" Exception occurs while verifying the eventurls", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	public void getFeedsListHeadingAndDate(String urlName) {
		asser = new SoftAssert();
		boolean exception = false;
		try {
			event.openEventPage();
			event.clickEventurl(urlName);
			String heading = feedpage.getFeedHeading(urlName);
			List<String> dates = feedpage.isDateExistOnFeeds(urlName);
			asser.assertNotNull(heading, "Heading is not present in the feeds of " + urlName + " url");
			asser.assertNotNull(dates.get(0), "Month field of the feed  not exist in " + urlName + " url");
			asser.assertNotNull(dates.get(1), "year field of the feed  not exist in " + urlName + " url");
			asser.assertNotNull(dates.get(2), "day field of the feed  not exist in " + urlName + " url");
			asser.assertNotNull(dates.get(3), "time field of the feed  not exist in " + urlName + " url");
		} catch (Exception e) {
			Logger.error(" Exception occurs while verifying the feedlist heading and dates", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	public void OpenEventUrlsFeed(String urlName, String identifire) {
		asser = new SoftAssert();
		String heading = "";
		boolean exception = false;
		try {
			event.openEventPage();
			event.clickEventurl(urlName);
			if (identifire.equals("upcoming")) {
				feedpage.clickUpcomingEvent();
				heading = feedpage.getEventBriteUpcomingFeedHeading();
			} else if (identifire.equals("past")) {
				feedpage.clickPastEvent();
				heading = feedpage.getEventBritepastFeedHeading();
			} else {
				heading = feedpage.getFeedHeading(urlName);
			}
			if(heading!=null){
			feedpage.openFeed(identifire);
			String header = feedsdetail.getFeedsHeading();
			asser.assertEquals(heading, header,identifire+" feeds are not open");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Logger.error(" Exception occurs while verifying the EventUrl feeds having name: " + urlName, e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	public void openEventAndMapInNative(String urlName, String identifier) {
		asser = new SoftAssert();
		boolean exception = false;
		boolean eventopen = false;
		boolean mapopen = false;
		try {
			event.openEventPage();
			event.clickEventurl(urlName);
			if (identifier.equals("upcoming")) {
				feedpage.clickUpcomingEvent();
			}
			if (identifier.equals("past")) {
				feedpage.clickPastEvent();
			}
			if(feedpage.openFeed(identifier)){
			String header = feedsdetail.getFeedsHeading();
			String eventheading = feedsdetail.openFeedInNative("Event");
			if (eventheading.equals(header)) {
				eventopen = true;
			}
			asser.assertTrue(eventopen, " event is not open in native from " + urlName + " feedlist page");
			if (eventopen) {
				feedsdetail.tapBackButtonInNative();
			}
			String mapheading = feedsdetail.openFeedInNative("Map");
			if (mapheading.equals(header))
				mapopen = true;
			asser.assertTrue(mapopen, "Map is not open in native from " + urlName + " feedlist page");
			if (mapopen) {
				feedsdetail.tapBackButtonInNative();
			}
			}
		} catch (Exception e) {
			Logger.error(" Exception occurs while verifying the Event and map open in native from " + urlName + " url",
					e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	public void UpcomingeventLocationVenue(String identifier) {
		asser = new SoftAssert();
		boolean exception = false;
		String heading = "";
		String venue = "";
		try {
			event.openEventPage();
			event.clickEventurl("eventbrite");
			if (identifier.equals("upcoming"))
				feedpage.clickUpcomingEvent();
			else
				feedpage.clickPastEvent();
			boolean feeds = feedpage.isFeedsExist(identifier);
			if (feeds) {
				if (identifier.equals("upcoming")) {
					heading = feedpage.getEventBriteUpcomingFeedHeading();
					venue = feedpage.getEventBriteUpcomingFeedVenue();
				} else {
					heading = feedpage.getEventBritepastFeedHeading();
					venue = feedpage.getEventBritepastFeedVenue();
				}
				asser.assertNotNull(heading, "title of the" + identifier + " event is not present in eventbrite url");
				asser.assertNotNull(venue, "Venue of the " + identifier + " event is not present in eventbrite url");
			} else {
				Logger.info("feeds are not present in the " + identifier + " events");
				asser.assertTrue(feeds,
						"Feeds are not present or displayed in " + identifier + " event of eventbrite url");
			}
		} catch (Exception e) {
			Logger.error(" Exception occurs while verifying upcoming event location and venue of " + identifier, e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();

	}

	// *****************Test Methods for Event Page****************
	@Test
	public void verifyEventPageHeader() {
		Logger.info("********Test case start: verifyEventPageHeader********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			event.openEventPage();
			String header = PageElement.getPageHeader(driver);
			Logger.info(" value of page header is :" + header + " on verify page header test");
			if (header.equals("Events")) {
				PageElement.tapBackButton(driver);
				asser.assertEquals(PageElement.getAppName(driver), "Automate");
			}
			asser.assertEquals(header, "Events");
		} catch (Exception e) {
			Logger.error(" Exception occurs while verifying the eventful header", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	// *****************Test Methods for EventFul Event****************

	@Test
	public void verifyEventfulpageOpen() {
		Logger.info("********Test case start: verifyEventfulpageOpen********");
		openEventUrls("eventful");
	}

	@Test
	public void verifyFeedsListHeadingAndDate() {
		Logger.info("********Test case start: verifyFeedsListHeadingAndDate********");
		getFeedsListHeadingAndDate("eventful");
	}

	@Test
	public void verifyEventFulFeedOpen() {
		Logger.info("********Test case start: verifyEventFulFeedOpen********");
		OpenEventUrlsFeed("eventful", "eventful");
	}

	//@Test
	public void verifyEventfulEventAndMapOpenInNative() {
		Logger.info("********Test case start: verifyEventfulEventAndMapOpenInNative********");
		openEventAndMapInNative("eventful", "eventful");
	}

	// **********Test Methods for EventBrite Event**************

	/*@Test
	public void verifyEventbrite() {
		Logger.info("********Test case start: verifyEventbrite********");
		openEventUrls("eventbrite");
	}

	@Test
	public void verifyUpcomingEventLocationVenue() {
		Logger.info("********Test case start: verifyUpcomingEventLocationVenue********");
		UpcomingeventLocationVenue("upcoming");
	}

	@Test
	public void verifyEventBriteUpcomingFeedOpen() {
		Logger.info("********Test case start: verifyEventBriteUpcomingFeedOpen********");
		OpenEventUrlsFeed("eventbrite", "upcoming");
	}

	//@Test
	public void verifyUpcomingEventOpenInNative() {
		Logger.info("********Test case start: verifyUpcomingEventOpenInNative********");
		openEventAndMapInNative("eventbrite", "upcoming");
	}

	@Test
	public void verifyPastEventLocationVenue() {
		Logger.info("********Test case start: verifyPastEventLocationVenue********");
		UpcomingeventLocationVenue("past");
	}

	@Test
	public void verifyEventBritePastFeedOpen() {
		Logger.info("********Test case start: verifyEventBritePastFeedOpen********");
		OpenEventUrlsFeed("eventbrite", "past");
	}
*/
	//@Test
	public void verifyPastEventOpenInNative() {
		Logger.info("********Test case start: verifyPastEventOpenInNative********");
		openEventAndMapInNative("eventbrite", "past");
	}

	// ********* Test Methods for bandsintown event************

	@Test
	public void verifyBandsinTownOpen() {
		Logger.info("********Test case start: verifyBandsinTownOpen********");
		openEventUrls("bandsintown");
	}

	@Test
	public void verifyBandsintownFeedOpen() {
		Logger.info("********Test case start: verifyBandsintownFeedOpen********");
		OpenEventUrlsFeed("bandsintown", "bandsintown");
	}

	@Test
	public void verifyBandsInTownListHeadingAndDate() {
		Logger.info("********Test case start: verifyBandsInTownListHeadingAndDate********");
		getFeedsListHeadingAndDate("bandsintown");
	}

	//@Test
	public void verifyBandsInTownEventAndMapOpenInNative() {
		Logger.info("********Test case start: verifyBandsInTownEventAndMapOpenInNative********");
		openEventAndMapInNative("bandsintown", "bandsintown");
	}

	// ***** Test Methods for facebook event******

	@Test
	public void verifyFaceBookOpen() {
		Logger.info("********Test case start: verifyBandsInTownEventAndMapOpenInNative********");
		openEventUrls("facebook");
	}

	// ******* Test Methods for Google+ event*****

	@Test
	public void verifyGooglePlusOpen() {
		Logger.info("********Test case start: verifyGooglePlusOpen********");
		openEventUrls("google");
	}

	@Test
	public void verifyGoogleFeedsDateandTime() {
		Logger.info("********Test case start: verifyGoogleFeedsDateandTime********");
		getFeedsListHeadingAndDate("google");
	}

	// @Test
	public void VerifyGoogleCalendar() {
		Logger.info("********Test case start: VerifyGoogleCalendar********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			event.openEventPage();
			event.clickEventurl("google");
			boolean calOpen = feedpage.openGoogleCalendar();
			asser.assertTrue(calOpen, "Calendar is not open from google feed");
		} catch (Exception e) {
			Logger.error(" Exception occurs while opening the calendar from google feed", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	//@Test
	public void VerifyInfoIconOngoogleFeed() {
		Logger.info("********Test case start: VerifyInfoIconOngoogleFeed********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			event.openEventPage();
			event.clickEventurl("google");
			boolean info = feedpage.openGoogleInfo();
			asser.assertTrue(info, "Info icon is not open from google feed");
		} catch (Exception e) {
			Logger.error(" Exception occurs while opening the Info Icon from google feed", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	// Test Methods for BookMyShow event

	//@Test
	public void verifyBookMyShow() {
		Logger.info("********Test case start: verifyBookMyShow********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			event.openEventPage();
			event.clickEventurl("bookmyshow");
			boolean open = feedpage.openBookMyShow();
			asser.assertTrue(open, " BookMyShow event is not open");
		} catch (Exception e) {
			Logger.error("Exception occurs while opening the BookMyShow Event");
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
