package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieCouponDirectoryPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.CommanClass;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.MobileElement;

public class AppypieCouponDirctoryTest extends TestSetup{
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieCouponDirectoryPage cdPage;
	PageElement page;


	@BeforeTest
	@Override
	public void pageSetUp() {
		cdPage = new AppypieCouponDirectoryPage(driver);
		page = new PageElement();
	}


	@Test
	public void verifyCouponDirectoryOpen_Close(){
		Logger.info("Test Methods start: Coupon Directory Page open");
		asser= new SoftAssert();
		boolean coupon = false;

		try {

			Boolean coupounOpen	= cdPage.clickableLinks(cdPage.pagelink);
			asser.assertTrue(coupounOpen, "CouponDirectory page not clickable or not open in the flow of main menu");		
			Thread.sleep(3000);
			Boolean coupounOpenheder = cdPage.isCouponPageOpen();
			asser.assertNotNull(coupounOpenheder, "Header is getting null value");

			if (coupounOpenheder) {

				String alllist = cdPage.printAvailableText(cdPage.pagelist);
				asser.assertNotNull(alllist, "Page list is getting null value");

			} else {
				Logger.info("Coupon Directory page list not showing on app");
			}
			asser.assertFalse(PageElement.tapCEBackButton(driver),"Back button not working on coupon directory Page.");	

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			coupon = true;
			asser.assertFalse(coupon, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}

	@Test
	public void verifyCouponDirectorySearch(){
		Logger.info("Test Methods start: Coupon Directory Search");
		asser= new SoftAssert();
		boolean couponSearch = false;

		try {

			Boolean coupounOpen	= cdPage.clickableLinks(cdPage.pagelink);
			asser.assertTrue(coupounOpen, "CouponDirectory page not clickable or not open in the flow of main menu");		

			Boolean srchOption= cdPage.clickableLinks(cdPage.serch);
			asser.assertTrue(srchOption, "Serch icon not clickable on home page");
			if (srchOption) {

				Boolean enterText= cdPage.serchField(cdPage.serchText, "20%");
				asser.assertTrue(enterText, "Enter text not working on serch field");
				PageElement.tapDeviceOk(driver);

				String alllist = cdPage.printAvailableText(cdPage.serchPagelist);
				asser.assertNotNull(alllist, "Page list is getting null value");

				Boolean opencoupon= cdPage.clickableLinks(cdPage.clickONlist);
				asser.assertTrue(opencoupon, "coupon not clickable after searched from home page");
				cdPage.printAvailableText(cdPage.couponPageList);

			} else {
				Logger.info("Search fuctionality not working on coupon Directory Page");
			}
			Boolean backFromCouponList= cdPage.clickableLinks(cdPage.couponPageListBack);
			asser.assertTrue(backFromCouponList, "Back button not working on open coupon page");

			asser.assertFalse(PageElement.tapCEBackButton(driver),"Back button not working on coupon directory Page.");

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			couponSearch = true;
			asser.assertFalse(couponSearch, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}



	@Test
	public void verifyCouponDirectoryBookmarks(){
 		Logger.info("Test Methods start: Coupon Directory Page Bookmarks");
		asser= new SoftAssert();
		boolean bkmarks = false;

		try {

			Boolean coupounOpen	= cdPage.clickableLinks(cdPage.pagelink);
			asser.assertTrue(coupounOpen, "CouponDirectory page not clickable or not open in the flow of main menu");

			if (!globledeviceName.equals("iPhone")) {
				Boolean coupounOpenheder = cdPage.isCouponPageOpen();
				asser.assertNotNull(coupounOpenheder, "Header is getting null value");
				if (coupounOpenheder) {

					boolean bokmarklist	= cdPage.clickableLinks(cdPage.bkmarks);
					asser.assertTrue(bokmarklist, "Bookmarks link not working on Coupon Directory home page");

					Boolean backFrombookmarksList= cdPage.clickableLinks(cdPage.couponPageListBack);
					asser.assertTrue(backFrombookmarksList, "Back button not working on open coupon page");

					Boolean openCouponCollection= cdPage.clickableLinks(cdPage.madeCoupon);
					asser.assertTrue(openCouponCollection, "Made coupon page not working");

					Boolean selected,notseleted=false;
					selected=driver.findElements(cdPage.couponBkmarksclick).size()!=0;
					notseleted=driver.findElements(cdPage.couponBkmarksclick1).size()!=0;
					if (selected) {
						System.out.println("Already seleted");
					}
					if (notseleted) {
						Boolean select= cdPage.clickableLinks(cdPage.couponBkmarksclick1);
						asser.assertTrue(select, "select Bookmark not working");
						Boolean couponBookmarksAlert= cdPage.isAlertPopupOpen();
						asser.assertTrue(couponBookmarksAlert, "Alert popup not showing when coupon added to bookmarks list");
														
						if (couponBookmarksAlert) {
							String message=cdPage.printAvailableText(cdPage.alertMsg);
							//asser.assertEquals(message, "Bookmark Added");
							PageElement.verifyAlert_Ok();
						}
				}
				 else {
						Logger.info("Coupon Directory page list not showing on app");
					}
			}
			}
			
			else {
				Boolean openCouponCollection= cdPage.clickableLinks(cdPage.madeCoupon);
				asser.assertTrue(openCouponCollection, "Made coupon page not working");
				
				Boolean selected,notseleted=false;
				selected=driver.findElements(cdPage.couponBkmarksclick).size()!=0;
				notseleted=driver.findElements(cdPage.couponBkmarksclick1).size()!=0;
				if (selected) {
					System.out.println("Already seleted");
				}
				if (notseleted) {
					Boolean select= cdPage.clickableLinks(cdPage.couponBkmarksclick1);
					asser.assertTrue(select, "select Bookmark not working");
					
					Boolean couponBookmarksAlert= cdPage.isAlertPopupOpen();
					asser.assertTrue(couponBookmarksAlert, "Alert popup not showing when coupon added to bookmarks list");
													
					if (couponBookmarksAlert) {
						String message=cdPage.printAvailableText(cdPage.alertMsg);
						//asser.assertEquals(message, "Bookmark Added");
						PageElement.verifyAlert_Ok();
					}
				}
			}

		


		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			bkmarks = true;
			asser.assertFalse(bkmarks, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}


	@Test
	public void verifyCouponINFO_Share(){
		Logger.info("Test Methods start: Coupon Info");
		asser= new SoftAssert();
		boolean singleCoupn = false;

		try {

			Boolean coupounOpen	= cdPage.clickableLinks(cdPage.pagelink);
			asser.assertTrue(coupounOpen, "CouponDirectory page not clickable or not open in the flow of main menu");

			Boolean coupounOpenheder = cdPage.isCouponPageOpen();
			asser.assertNotNull(coupounOpenheder, "Header is getting null value");

			if (coupounOpenheder) {

				Boolean openCouponCollection= cdPage.clickableLinks(cdPage.coponCollection);
				asser.assertTrue(openCouponCollection, "Copon Collection page not working");

				String openCouponCollectionPageList= cdPage.printAvailableText(cdPage.coponCollectionList);
				asser.assertNotNull(openCouponCollectionPageList, "Coupon collection page getting null value");

				Boolean openclouths= cdPage.clickableLinks(cdPage.clouths);
				asser.assertTrue(openclouths, "Clothes Copon page not working");

				String ClothesPageList= cdPage.printAvailableText(cdPage.clouthsCoupons);
				asser.assertNotNull(ClothesPageList, "Cloths collection page getting null value");

				Boolean discountCoupon= cdPage.clickableLinks(cdPage.discount);
				asser.assertTrue(discountCoupon, "20% discount coupon not clickable");

				String discountCouponList= cdPage.printAvailableText(cdPage.couponDetails);
				asser.assertNotNull(discountCouponList, "20% discount coupon page getting null value");

				Boolean info= cdPage.clickableLinks(cdPage.info);
				asser.assertTrue(info, "info icon not clickable on coupon");

				String infoDescription= cdPage.printAvailableText(cdPage.infoD);
				asser.assertNotNull(infoDescription, "info Description getting null value");


				Boolean crossInfo= cdPage.clickableLinks(cdPage.infoCross);
				asser.assertTrue(crossInfo, "Cross button on info icon not clickable");

				Boolean sharebutton= cdPage.clickableLinks(cdPage.share);
				asser.assertTrue(sharebutton, "Share button not working");
				
				if (!globledeviceName.equals("iPhone")) {
					driver.context("NATIVE_APP");
					Thread.sleep(2000);
					
					driver.navigate().back();
				}
				else{
				driver.context("NATIVE_APP");
				PageElement.Accessibilitylinks(PageElement.i_cancel);
				}

				
				PageElement.changeContextToWebView(driver);
			} else {
				Logger.info("Coupon Directory page list not showing on app");
			}


		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			singleCoupn = true;
			asser.assertFalse(singleCoupn, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}


	@Test
	public void verifyShoesCoupon(){
		Logger.info("Test Methods start:Verify Coupon Directory Page Shoes coupon");
		asser= new SoftAssert();
		boolean shoesCoupon = false;

		try {

			Boolean coupounOpen	= cdPage.clickableLinks(cdPage.pagelink);
			asser.assertTrue(coupounOpen, "CouponDirectory page not clickable or not open in the flow of main menu");

			Boolean coupounOpenheder = cdPage.isCouponPageOpen();
			asser.assertNotNull(coupounOpenheder, "Header is getting null value");

			if (coupounOpenheder) {

				Boolean openCouponCollection= cdPage.clickableLinks(cdPage.coponCollection);
				asser.assertTrue(openCouponCollection, "Copon Collection page not working");

				Boolean openShoeCoupon= cdPage.clickableLinks(cdPage.shoesCoupons);
				asser.assertTrue(openShoeCoupon, "Shoes coupon page not working");

				String shoeCouponPageList= cdPage.printAvailableText(cdPage.clouthsCoupons);
				asser.assertNotNull(shoeCouponPageList, "Cloths collection page getting null value");

				Boolean buy_get= cdPage.clickableLinks(cdPage.discount);
				asser.assertTrue(buy_get, "Buy & Get coupon not clickable");

				String discountCouponList= cdPage.printAvailableText(cdPage.couponDetails);
				asser.assertNotNull(discountCouponList, "Buy & Get coupon page getting null value");

				Boolean redeemCoupon= cdPage.clickableLinks(cdPage.reedem);
				asser.assertTrue(redeemCoupon, "Redeem coupon link not clickable");

				Boolean redeemCoupon_header_back= cdPage.clickableLinks(cdPage.couponPageListBack);
				asser.assertTrue(redeemCoupon_header_back, "Back button not working on redeem ");

				Boolean redeemCoupon1= cdPage.clickableLinks(cdPage.reedem);
				asser.assertTrue(redeemCoupon1, "Redeem coupon link not clickable");

				Boolean redeemCoupon_back= cdPage.clickableLinks(cdPage.back);
				asser.assertTrue(redeemCoupon_back, "Coupon Back button not working on redeem page");

				Boolean redeemCoupon2= cdPage.clickableLinks(cdPage.reedem);
				asser.assertTrue(redeemCoupon2, "Redeem coupon link not clickable");

				Boolean validateBlank= cdPage.clickableLinks(cdPage.validate);
				asser.assertTrue(validateBlank, "Validate coupon link not working");

				if (validateBlank) {

					String blankAlert= cdPage.printAvailableText(cdPage.alertMsg);
					asser.assertEquals(blankAlert, "Please enter your pin here");

					PageElement.verifyAlert_Ok();

				} 

				else {
					Logger.info("Alert not showing after validating blank coupon");
				}

				Boolean enterCodeFieldInvalid= cdPage.couponCode(cdPage.enterCode, "uty67");
				asser.assertTrue(enterCodeFieldInvalid, "Enter code text field not working");



				Boolean validateInvalid= cdPage.clickableLinks(cdPage.validate);
				asser.assertTrue(validateInvalid, "Validate coupon link not working");

				if (validateInvalid) {

					String blankAlertInvalidCode= cdPage.printAvailableText(cdPage.alertMsg);
					asser.assertEquals(blankAlertInvalidCode, "You have entered the wrong pin. Please try again");

					PageElement.verifyAlert_Ok();

				} 

				else {
					Logger.info("Alert not showing after validating coupon");
				}

				Boolean enterCodeFieldvalid= cdPage.couponCode(cdPage.enterCode, "1111");
				asser.assertTrue(enterCodeFieldvalid, "Enter code text field not working");

				Boolean validate_valid= cdPage.clickableLinks(cdPage.validate);
				asser.assertTrue(validate_valid, "Validate coupon link not working");

				if (validateInvalid) {

					String blankAlertInvalidCode= cdPage.printAvailableText(cdPage.alertMsg);
					asser.assertEquals(blankAlertInvalidCode, "Thanks for redeemed this coupon!");

					PageElement.verifyAlert_Ok();

				} 

				else {
					Logger.info("Alert not showing after validating coupon");
				}

			} else {
				Logger.info("Coupon Directory page list not showing on app");
			}


		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			shoesCoupon = true;
			asser.assertFalse(shoesCoupon, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}

	@Test
	public void verifyotherCoupons(){
		Logger.info("Test Methods start:Other Coupon");
		asser= new SoftAssert();
		boolean otherCoupns = false;

		try {

			Boolean coupounOpen	= cdPage.clickableLinks(cdPage.pagelink);
			asser.assertTrue(coupounOpen, "CouponDirectory page not clickable or not open in the flow of main menu");

			Boolean coupounOpenheder = cdPage.isCouponPageOpen();
			asser.assertNotNull(coupounOpenheder, "Header is getting null value");

			if (coupounOpenheder) {

				Boolean openCouponCollection= cdPage.clickableLinks(cdPage.coponCollection);
				asser.assertTrue(openCouponCollection, "Copon Collection page not working");

				Boolean openShoeCoupon= cdPage.clickableLinks(cdPage.shoesCoupons);
				asser.assertTrue(openShoeCoupon, "Shoes coupon page not working");
				Thread.sleep(2000);
				Boolean scratchCoupon= cdPage.clickableLinks(cdPage.scrtch);
				asser.assertTrue(scratchCoupon, "Scratch Coupon not clickable");

				if (scratchCoupon)
				{
					String blankAlert= cdPage.printAvailableText(cdPage.blankAlert);
					//asser.assertEquals(blankAlert, "Coupon already redeemed");	// verified Already redeemed coupon and alert

					PageElement.verifyAlert_Ok();
				} 
				else

				{
					Logger.info("Scratch & win coupon not clicakble");
				}
				Thread.sleep(2000);
				Boolean scratch_redeem= cdPage.clickableLinks(cdPage.scrtchus);
				asser.assertTrue(scratch_redeem, "Scratch and redeem coupon not working");
				
				String openCouponCollectionPageList= cdPage.printAvailableText(cdPage.couponDetails);
				asser.assertNotNull(openCouponCollectionPageList, "Coupon collection page getting null value");
				
				Boolean redeemCoupon= cdPage.clickableLinks(cdPage.reedemScratchCoupon);
				asser.assertTrue(redeemCoupon, "Redeem coupon link not clickable");
				
				if (redeemCoupon)
				{
					String redeemAlert= cdPage.printAvailableText(cdPage.blankAlert);
					asser.assertEquals(redeemAlert, "Do you want to redeem coupon now ? You can only redeem it once.");
					
					Boolean cancalButton= cdPage.clickableLinks(cdPage.cancel);
					asser.assertTrue(cancalButton, "Cancel button not working when user click on redeem botton after scratch the coupon");
				}
				else
				{
					Logger.info("Scartch coupon not working");
				}
				Thread.sleep(2000);
				Boolean ExpiredCoupon= cdPage.clickableLinks(cdPage.exp);
				asser.assertTrue(ExpiredCoupon, "Expired coupon not showing Alert");
				if (ExpiredCoupon) {
					String expiredCouponAlert= cdPage.printAvailableText(cdPage.blankAlert);
					asser.assertEquals(expiredCouponAlert, "Coupon has been expired");
				} else {
					Logger.info("Expired Coupon Alert not showing");
				}

			} else {
				Logger.info("Coupon Directory page list not showing on app");
			}

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			otherCoupns = true;
			asser.assertFalse(otherCoupns, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}


}
