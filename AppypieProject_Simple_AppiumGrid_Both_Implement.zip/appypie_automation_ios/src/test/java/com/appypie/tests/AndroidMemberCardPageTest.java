package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMembersCardPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

public class AndroidMemberCardPageTest extends TestSetup {

	AppypieMembersCardPage membersCard;
	PageElement PE;

	private static final Logger Logger = Log.createLogger();

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		membersCard = new AppypieMembersCardPage(driver);
	}

	// ---------------------------------
	@Test(priority = 0, description = "")
	public void VeriyMembersCardOpen() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyMembersCardOpen()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			if (openbyclick) {
				Logger.info("openbyclick is present");
				TimeUnit.SECONDS.sleep(3);
				boolean login = membersCard.isLogindisplaying(driver);
				if(login){
					membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
					TimeUnit.SECONDS.sleep(3);
				}else {
					System.out.println("User is already login");
					TimeUnit.SECONDS.sleep(3);
				}
				membersCard.Getactualtext(membersCard.header_gettext);
				//String getvalue = membersCard.Getactualtext(membersCard.header_gettext);
				//s_assert.assertEquals(getvalue, "Members Card");

			} 
			s_assert.assertTrue(openbyclick, "membersCard module is not opened");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();

	}

	@Test(priority = 1, description = "")
	public void VeriyDeshBoardDetails() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case: VeriyDeshBoardDetails()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			if (openbyclick) {
				TimeUnit.SECONDS.sleep(3);
				boolean login = membersCard.isLogindisplaying(driver);
				if(login){
					membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
					TimeUnit.SECONDS.sleep(3);
				}else {
					System.out.println("User is already login");
					TimeUnit.SECONDS.sleep(3);
				}
				
					membersCard.Getactualtext(membersCard.vouchers_gettext);
					membersCard.Getactualtext(membersCard.memberid_gettext);
					membersCard.Getactualtext(membersCard.issuedate_gettext);
					membersCard.Getactualtext(membersCard.validtilldate_gettext);
					membersCard.Getactualtext(membersCard.pointsBalence_gettext);
							
			}
			s_assert.assertTrue(openbyclick, "membersCard module is not opened");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();

	}

	@Test(priority = 2, description = "")
	public void VeriyAddPoints()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case: VeriyAddPoints()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			s_assert.assertTrue(openbyclick, "membersCard module is not opened");
			TimeUnit.SECONDS.sleep(3);
			boolean login = membersCard.isLogindisplaying(driver);
			if(login){
				membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				TimeUnit.SECONDS.sleep(3);
			}else {
				System.out.println("User is already login");
				TimeUnit.SECONDS.sleep(3);
			}
			TimeUnit.SECONDS.sleep(5);
			Boolean clickaddbtn = membersCard.Openlinks(membersCard.add_btn);
			s_assert.assertTrue(clickaddbtn, "Add  button is not working");
			if (clickaddbtn) {
				membersCard.Getactualtext(membersCard.availablepoints_gettext);
				s_assert.assertEquals(membersCard.Getactualtext(membersCard.handoverdiscription_gettext),
						"Please handover your device to the cashier to add points");
			} else {
				Logger.info("Add button is not working");
			}
			TimeUnit.SECONDS.sleep(3);
			Boolean enterpoint = membersCard.TextField(membersCard.point_text, "100");
			s_assert.assertTrue(enterpoint, "EnterPoint filed is not working");
			if (enterpoint) {
				membersCard.Getactualtext(membersCard.availablepoints_gettext);
			} else {
				Logger.info("Enter not is not present");
			}
			TimeUnit.SECONDS.sleep(3);
			Boolean validate = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate, "security btn is not working.");
			if (validate) {
				TimeUnit.SECONDS.sleep(3);
				Boolean codetext = membersCard.TextField(membersCard.securityCodeEnter, "1111");
				s_assert.assertTrue(codetext, "code text is not present");
				membersCard.Openlinks(membersCard.securitycode_btn);
				membersCard.Getactualtext(membersCard.pointsBalence_gettext);
			} else {
				Logger.info("Validate is not present");
			}
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VeriyRedeemit() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case: VeriyRedeemit()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			s_assert.assertTrue(openbyclick, "membersCard module is opened");
			TimeUnit.SECONDS.sleep(3);
			boolean login = membersCard.isLogindisplaying(driver);
			if(login){
				membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				TimeUnit.SECONDS.sleep(3);
			}else {
				System.out.println("User is already login");
				TimeUnit.SECONDS.sleep(3);
			}
			Boolean clickaddbtn = membersCard.Openlinks(membersCard.add_btn);
			s_assert.assertTrue(clickaddbtn, "Add  button is not working");
			Boolean enterpoint = membersCard.TextField(membersCard.point_text, "100");
			s_assert.assertTrue(enterpoint, "EnterPoint filed is not working");
			Boolean validate = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate, "security btn is not working.");
			Boolean codetext = membersCard.TextField(membersCard.securityCodeEnter, "1111");
			s_assert.assertTrue(codetext, "code text is not present");
			Boolean validate1 = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate1, "security btn is not working.");

			Boolean redeembtn = membersCard.Openlinks(membersCard.redeem_btn);
			s_assert.assertTrue(redeembtn, "redeem button is not working");
			if (redeembtn) {
				membersCard.Getactualtext(membersCard.availablepoints_gettext);
			} else {
				Logger.info("Redeem button is not present.");	
			}


			Boolean enterpoint1 = membersCard.TextField(membersCard.point_text, "100");
			s_assert.assertTrue(enterpoint1, "EnterPoint filed is not working");
			Boolean validate2 = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate2, "security btn is not working.");
			Boolean codetext1 = membersCard.TextField(membersCard.securityCodeEnter, "1111");
			s_assert.assertTrue(codetext1, "code text is not present");
			membersCard.Openlinks(membersCard.securitycode_btn);
			Boolean poins = membersCard.IselementPresent(membersCard.pointsBalence_gettext);
			//s_assert.assertTrue(poins, "point is not present");
			if (poins) {
				membersCard.Getactualtext(membersCard.pointsBalence_gettext);
			} else {
				Logger.info("Points is not present");
			}
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifyShareLink() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case: VerifyShareLink()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			s_assert.assertTrue(openbyclick, "membersCard module is not opened");
			TimeUnit.SECONDS.sleep(3);
			boolean login = membersCard.isLogindisplaying(driver);
			if(login){
				membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				TimeUnit.SECONDS.sleep(3);
			}else {
				System.out.println("User is already login");
				TimeUnit.SECONDS.sleep(3);
			}
			Boolean share = membersCard.Openlinks(membersCard.download_share_btn);
			s_assert.assertTrue(share, "Share link is not present");
			if (share) {
				if (!globledeviceName.equals("iPhone")) {
					membersCard.sharelink();
				}
				else {
					membersCard.IfAlertpresent();
				}


			} else {
				Logger.info("Share link is not present");
			}

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 5, description = "")
	public void VerifyTermCondition()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case: VerifyTermCondition()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			s_assert.assertTrue(openbyclick, "membersCard module is not opened");
			TimeUnit.SECONDS.sleep(3);
			boolean login = membersCard.isLogindisplaying(driver);
			if(login){
				membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				TimeUnit.SECONDS.sleep(3);
			}else {
				System.out.println("User is already login");
				TimeUnit.SECONDS.sleep(3);
			}

			Boolean TCinfo = membersCard.Openlinks(membersCard.TC_link);
			s_assert.assertTrue(TCinfo, "TC link is not open");
			if (TCinfo) {
				s_assert.assertEquals(membersCard.Getactualtext(membersCard.TC_heading_gettext), "Terms Conditions");
			} else {
				Logger.info("TC info is not present");
			}
			Boolean tcmessage = membersCard.IselementPresent(membersCard.TC_message_gettext);
			s_assert.assertTrue(tcmessage, "TC message is not present.");
			if (tcmessage) {
				membersCard.Getactualtext(membersCard.TC_message_gettext);

			} else {
				Logger.info("TC message is not present");
			}

			Boolean hyperlink = membersCard.Openlinks(membersCard.TC_inside_hyperlink);
			s_assert.assertTrue(hyperlink, "Hyper link is not open");
			if (hyperlink) {
				driver.context("NATIVE_APP");

				if (!globledeviceName.equals("iPhone")) {
					s_assert.assertEquals(membersCard.Getactualtext(membersCard.header_gettext_native), "Members Card");
					Boolean bacnbtnnative = membersCard.Openlinks(membersCard.BackButtonNative);
					s_assert.assertTrue(bacnbtnnative, "Back btn page is not open");
					if (bacnbtnnative) {
						PageElement.changeContextToWebView(driver);
						s_assert.assertEquals(membersCard.Getactualtext(membersCard.TC_heading_gettext), "Terms Conditions");
					} else {
						Logger.info("Back button is not present");
					}
				
				}
				else {
					driver.context("NATIVE_APP");
					TimeUnit.SECONDS.sleep(8);
					Boolean bacnbtnnative = membersCard.Openlinks(membersCard.i_BackButtonNative);
					s_assert.assertTrue(bacnbtnnative, "i_Back btn page is not open");
					TimeUnit.SECONDS.sleep(2);
				}

				PageElement.changeContextToWebView(driver);

				Boolean closebtn=membersCard.Openlinks(membersCard.TC_close_btn);
				s_assert.assertTrue(closebtn,"close button is not working");
				if (closebtn) {
					s_assert.assertEquals(membersCard.Getactualtext(membersCard.vouchers_gettext), "Vouchers");
				}
				else{
					Logger.info("close button is not present");
				}

			} else {
				Logger.info("Hyper link is not present");
			}

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VeriypartiallyRedeemit() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriypartiallyRedeemit()");
		boolean exception = false;
		try {
			Boolean openbyclick = membersCard.Openlinks(membersCard.memberscardModulelink);
			s_assert.assertTrue(openbyclick, "membersCard module is not opened");
			TimeUnit.SECONDS.sleep(3);
			boolean login = membersCard.isLogindisplaying(driver);
			if(login){
				membersCard.loginIntoPage(driver, "appypie2016@gmail.com", "12345678");
				TimeUnit.SECONDS.sleep(3);
			}else {
				System.out.println("User is already login");
				TimeUnit.SECONDS.sleep(3);
			}
			Boolean clickaddbtn = membersCard.Openlinks(membersCard.add_btn);
			s_assert.assertTrue(clickaddbtn, "Add  button is not working");
			TimeUnit.SECONDS.sleep(3);
			Boolean enterpoint = membersCard.TextField(membersCard.point_text, "100");
			s_assert.assertTrue(enterpoint, "EnterPoint filed is not working");
			TimeUnit.SECONDS.sleep(3);
			Boolean validate = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate, "security btn is not working.");
			TimeUnit.SECONDS.sleep(3);
			Boolean codetext = membersCard.TextField(membersCard.securityCodeEnter, "1111");
			s_assert.assertTrue(codetext, "code text is not present");
			TimeUnit.SECONDS.sleep(3);
			Boolean validate1 = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate1, "security btn is not working.");

			Boolean redeembtn = membersCard.Openlinks(membersCard.redeem_btn);
			s_assert.assertTrue(redeembtn, "redeem button is not working");
			if (redeembtn) {
				membersCard.Getactualtext(membersCard.availablepoints_gettext);
			} else {
				Logger.info("Redeem button is not present");	
			}

			Boolean enterpoint1 = membersCard.TextField(membersCard.point_text, "85");
			s_assert.assertTrue(enterpoint1, "EnterPoint filed is not working");
			Boolean validate2 = membersCard.Openlinks(membersCard.securitycode_btn);
			s_assert.assertTrue(validate2, "security btn is not working.");
			Boolean codetext1 = membersCard.TextField(membersCard.securityCodeEnter, "1111");
			s_assert.assertTrue(codetext1, "code text is not present");
			membersCard.Openlinks(membersCard.securitycode_btn);
			Boolean poins = membersCard.IselementPresent(membersCard.pointsBalence_gettext);
			//s_assert.assertTrue(poins, "point is not present");
			if (poins) {
				//s_assert.assertEquals(membersCard.Getactualtext(membersCard.pointsBalence_gettext), "15\nPoints\nBalance");
				membersCard.Getactualtext(membersCard.pointsBalence_gettext);
			} else {
				Logger.info("points is not present");
			}
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

}
