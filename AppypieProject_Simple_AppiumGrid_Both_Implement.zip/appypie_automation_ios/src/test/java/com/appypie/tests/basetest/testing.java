package com.appypie.tests.basetest;

import static org.testng.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.interactions.Actions;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class testing 
{

	static Workbook w;
	static WebDriver driver;
	

	public static void main(String args[]) throws InterruptedException
	{
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.mamobilemassage.com/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		System.out.println("Title of the WebSite:  "+driver.getTitle());
		
		assertEquals(driver.getTitle(), "Home | Mass Mobile Massage");
		
		//Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@class='sign_in_btn']/a")).click();


		try {
			ExcelReader();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Sheet s=w.getSheet(0);

		for(int i = 0; i < s.getColumns(); i++) //Read data from excel sheet
		{

			String coloum_1=s.getCell(0,i).getContents();
			String coloum_2 =s.getCell(1,i).getContents();

			System.out.println(i+") "+"coloum_1 : "+coloum_1);
			System.out.println(i+") "+"coloum_2 : "+coloum_2);
			driver.findElement(By.id("UserEmail")).sendKeys(coloum_1);
			//Thread.sleep(2000);
			driver.findElement(By.id("UserPassword")).sendKeys(coloum_2);

			driver.findElement(By.xpath(".//*[@id='UserLoginForm']/div[2]/input")).click();

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		
		
		driver.close();
		driver.quit();

	}

	public static void ExcelReader() throws BiffException, IOException {

		FileInputStream fi=new FileInputStream("./testing.xls");
		w=Workbook.getWorkbook(fi);
		

	}
	
	




}