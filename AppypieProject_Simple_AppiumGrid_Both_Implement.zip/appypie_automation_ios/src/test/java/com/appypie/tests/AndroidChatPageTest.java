package com.appypie.tests;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tools.ant.filters.LineContains.Contains;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieChatPage;
import com.appypie.pages.NavigationPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;

public class AndroidChatPageTest extends TestSetup {

	AppypieChatPage chat;
	private static final Logger Logger = Log.createLogger();

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		chat=new AppypieChatPage(driver);
	}
	
	// ----------------------------------------------------------------------------------------------------
/*	@Test(priority = 0, description = "")
	public void Veriy() throws Exception {
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {
			

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VeriyChatModleOpen() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case: VeriyChatModleOpen()");
		boolean exception = false;
		try {
			
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			if (chatmodule) {
				s_assert.assertEquals(chat.Getactualtext(chat.header_gettext), "Chat");
			}
			s_assert.assertTrue(chatmodule, "chat module is not open");
			
			Boolean header=chat.IselementPresent(chat.header_gettext);
			if (header) {
				chat.getListofLink(chat.getListItem);
			}
			s_assert.assertTrue(header, "header is not present");
		
			Boolean backbtn=chat.Openlinks(chat.BackButton2);
			s_assert.assertTrue(backbtn, "Back button is not working on home page");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VeriyChatRoomGallery() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyChatRoom()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
	
			Boolean chartroom=chat.Openlinks(chat.chatroom_link);
			if (chartroom) {
				s_assert.assertEquals(chat.Getactualtext(chat.header_gettext), "Chat Room");
				
				Boolean upload=chat.Openlinks(chat.uploadpiclink);
				if (upload) {
					Boolean gallery=chat.Openlinks(chat.gallerylink);
					if (gallery) {
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							Boolean selectphoto=chat.Openlinks(chat.selectphoto);
							s_assert.assertTrue(selectphoto, "Select photo is not selected");
						}
						else {
							Boolean cameraroll=chat.Openlinks(chat.i_selectphoto);
							if (cameraroll) {
							
									Boolean access=chat.Accessibilitylinks(chat.i_image);
								     s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );
								
							}
							s_assert.assertTrue(cameraroll,"i_Camera Roll link is not wokring ");
						}
						
						PageElement.changeContextToWebView(driver);
						
					}
					s_assert.assertTrue(gallery, "gallery link is not working");
					
					Boolean clearscreen=chat.ClearTextField(chat.screenName_text);
					if (clearscreen) {
						
						Boolean nextbtn=chat.Openlinks(chat.nextbtn_chatroom);
						if (nextbtn) {
							chat.IfAlertpresent();
						}
						s_assert.assertTrue(nextbtn, "Next button is not working");
						Boolean screenname=chat.TextField(chat.screenName_text, "Appypie testing");
						s_assert.assertTrue(screenname, "Screen Name text filed is not present");
						
						Boolean nextbtn1=chat.Openlinks(chat.nextbtn_chatroom);
						if (nextbtn) {
							chat.IfAlertpresent();
						}
						s_assert.assertTrue(nextbtn1, "Next button second is not working");
					}
					s_assert.assertTrue(clearscreen, "Screen name text filed is not present");
				}
				//s_assert.assertTrue(upload, "upload link is not working");
				
		
				
				s_assert.assertEquals(chat.Getactualtext(chat.header_gettext), "Chat Room");
				
				Boolean enterchat=chat.TextField(chat.enterchatText, "Hi Appypie I am anurag singh");
				s_assert.assertTrue(enterchat, "Entyer chat Text is not working");
				
				Boolean sendkey=chat.Openlinks(chat.sendbtn);
				s_assert.assertTrue(sendkey, "Chat send button is not working");
				
				Boolean backbtn=chat.Openlinks(chat.BackButton);
				s_assert.assertTrue(backbtn,"back button is not working on Chat page");
				
			}
			s_assert.assertTrue(chartroom, "Chat Room is not open.");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 3, description = "")
	public void VeriyWeChat() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyWeChat()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
			Boolean wechat=chat.Openlinks(chat.wechat_link);
			if (wechat) {
				driver.context("NATIVE_APP");
				if (!globledeviceName.equals("iPhone")) {
					String Google=chat.Getactualtext(chat.googleplaystore_gettext);
					s_assert.assertNotNull(Google, "Google text is getting Null value");
					boolean backbtn=chat.Openlinks(chat.backbtngoogleplaystore);
					s_assert.assertTrue(backbtn, "back Button is not working on google page");
				}
				else {
					Boolean access=chat.Accessibilitylinks(chat.i_backtoApp);
					s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );
				}
				PageElement.changeContextToWebView(driver);
			}
			s_assert.assertTrue(wechat, "We Chat is not open.");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 4, description = "")
	public void VeriySkype() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriySkype()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
			Boolean skype=chat.Openlinks(chat.skype_link);
			if (skype) {
				driver.context("NATIVE_APP");
				if (!globledeviceName.equals("iPhone")) {
					String Google=chat.Getactualtext(chat.googleplaystore_gettext);
					s_assert.assertNotNull(Google, "Google text is getting Null value");
					boolean backbtn=chat.Openlinks(chat.backbtngoogleplaystore);
					s_assert.assertTrue(backbtn, "back Button is not working on google page");
				}
				else {
					Boolean access=chat.Accessibilitylinks(chat.i_backtoApp);
					s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );
				}
				
				
				PageElement.changeContextToWebView(driver);
			}
			s_assert.assertTrue(skype, "Skype is not open.");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 5, description = "")
	public void VeriyWhatsapp() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyWhatsapp()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
			Boolean whatsapp=chat.Openlinks(chat.whatsapp_link);
			if (whatsapp) {
				driver.context("NATIVE_APP");
			
				if (!globledeviceName.equals("iPhone")) {
					String Google=chat.Getactualtext(chat.googleplaystore_gettext);
					s_assert.assertNotNull(Google, "Google text is getting Null value");
					boolean backbtn=chat.Openlinks(chat.backbtngoogleplaystore);
					s_assert.assertTrue(backbtn, "back Button is not working on google page");
				}
				else {
					Boolean access=chat.Accessibilitylinks(chat.i_backtoApp);
					s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );
					
					
				}
				
				PageElement.changeContextToWebView(driver);
			}
			s_assert.assertTrue(whatsapp, "Whatsapp is not open.");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VeriySnapChat() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriySnapChat()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
			Boolean snapchat=chat.Openlinks(chat.snapchat_link);
			if (snapchat) {
				driver.context("NATIVE_APP");
	if (!globledeviceName.equals("iPhone")) {
		String Googleacount=chat.Getactualtext(chat.googleplaystore_gettext);
		s_assert.assertNotNull(Googleacount, "Google text is getting Null value");
		driver.navigate().back();
				}
				else {
					Boolean access=chat.Accessibilitylinks(chat.i_backtoApp);
					s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );
				}
				
				PageElement.changeContextToWebView(driver);
			}
			s_assert.assertTrue(snapchat, "Snap Chat is not open.");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 6, description = "")
	public void VeriyLine() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyLine()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
			Boolean line=chat.Openlinks(chat.line_link);
			if (line) {
				driver.context("NATIVE_APP");
	if (!globledeviceName.equals("iPhone")) {
		String Google=chat.Getactualtext(chat.googleplaystore_gettext);
		s_assert.assertNotNull(Google, "Google text is getting Null value");
		boolean backbtn=chat.Openlinks(chat.backbtngoogleplaystore);
		s_assert.assertTrue(backbtn, "back Button is not working on google page");
				}
				else {
					driver.findElementByAccessibilityId(chat.i_backtoApp).click();
				}
				
				PageElement.changeContextToWebView(driver);
			}
			s_assert.assertTrue(line, "Line is not open.");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 7, description = "")
	public void VeriyChatRoomCamera() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyChatRoomCamera()");
		boolean exception = false;
		try {
			Boolean chatmodule=chat.Openlinks(chat.chatModule_link);
			s_assert.assertTrue(chatmodule, "chat module is not open");
	
			Boolean chartroom=chat.Openlinks(chat.chatroom_link);
			if (chartroom) {
				s_assert.assertEquals(chat.Getactualtext(chat.header_gettext), "Chat Room");
				
				Boolean uploadcamera=chat.Openlinks(chat.uploadpiclink);
				if (uploadcamera) {
					Boolean cameralink=chat.Openlinks(chat.camera);
					if (cameralink) {
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							NavigationPage.verifyrunTimePermissions(driver);
							Boolean clickphoto=chat.Openlinks(chat.clickcameraphotoNative);
							if (clickphoto) {
								chat.IfAlertpresent();
							}
							s_assert.assertTrue(clickphoto, "camera photo click is not Working");
						}
						else {
							
							NavigationPage.verifyrunTimePermissions(driver);
							Boolean clickphoto=chat.Openlinks(chat.i_clickcameraphotoNative);
							if (clickphoto) {
								chat.IfAlertpresent();
							}
							s_assert.assertTrue(clickphoto, "camera photo click is not Working");
							
						/*	
							Boolean access=chat.Accessibilitylinks(chat.i_backtoApp);
							s_assert.assertTrue(access, "AccessibilityId: i_backtoApp is not open" );*/
						}
						
						
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(cameralink, "camera link is not working");
					
							
				Boolean clearscreen=chat.ClearTextField(chat.screenName_text);
				if (clearscreen) {
					
					Boolean nextbtn=chat.Openlinks(chat.nextbtn_chatroom);
					if (nextbtn) {
						chat.IfAlertpresent();
					}
					s_assert.assertTrue(nextbtn, "Next button is not working");
					Boolean screenname=chat.TextField(chat.screenName_text, "Appypie testing");
					s_assert.assertTrue(screenname, "Screen Name text filed is not present");
					
					Boolean nextbtn1=chat.Openlinks(chat.nextbtn_chatroom);
					if (nextbtn) {
						chat.IfAlertpresent();
					}
					s_assert.assertTrue(nextbtn1, "Next button second is not working");
				}
				s_assert.assertTrue(clearscreen, "Screen name text filed is not present");
				}
				//s_assert.assertTrue(uploadcamera, "uploadcamera link is not working");
				
				
				s_assert.assertEquals(chat.Getactualtext(chat.header_gettext), "Chat Room");
				
				Boolean enterchat=chat.TextField(chat.enterchatText, "Hi Appypie I am anurag singh");
				s_assert.assertTrue(enterchat, "Entyer chat Text is not working");
				
				Boolean sendkey=chat.Openlinks(chat.sendbtn);
				s_assert.assertTrue(sendkey, "Chat send button is not working");
				
				Boolean backbtn=chat.Openlinks(chat.BackButton);
				s_assert.assertTrue(backbtn,"back button is not working on Chat page");
				
			}
			s_assert.assertTrue(chartroom, "Chat Room is not open.");
			
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + chat.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
}
