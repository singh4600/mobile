package com.appypie.tests.logintests;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.pages.loginpages.AppypieSignUpPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.LoginServiceHandler;
import com.appypie.util.PageElement;

public class AppypieCountryCodeinLoginTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieSignUpPage signup;
	AppypieLoginPage login;

	@Override
	@BeforeTest
	public void pageSetUp() {
		signup = new AppypieSignUpPage(driver);
		login = new AppypieLoginPage(driver);
	}
	
   @Test(groups={"countrycode"})
	public void verifyCountryCodeFeatureinSignUp() {
		Logger.info("********Test Method Starts: verifyCountryCodeFeatureinSignUp********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					boolean cCodeField = signup.isCountryCodeFieldExist();
					asser.assertTrue(cCodeField, "country code field is not displayed on sign up");
					if (cCodeField) {
						signup.openCountryCodeList();
						boolean cCodeList = signup.isCountryListOpen();
						asser.assertTrue(cCodeList, "country code list is not open from sign up page");
						if (cCodeList) {
							signup.backFromcCodeList();
							asser.assertTrue(signup.isSignUpPageOpen(),
									"back button from country code list is not working");
						}
					}
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying country code option in sign up", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
   
   
   @BeforeGroups(groups="countrycode")
	public String  cCodePrecondition() {
		String status = "";
		int value=2;
		System.out.println("Before Group for LDAP called");
		List<String> list = new ArrayList<String>();
		list.add("phone_country_code");
		try {
			String response = LoginServiceHandler.getSettingValues(list);
		    status = response.substring(response.indexOf("status\":\"") + 9, response.lastIndexOf("\"}"));
			if (status.toUpperCase().equals("success".toUpperCase())) {
				value = Integer.parseInt(String.valueOf(response.charAt(response.indexOf("phone_country_code\":\"") +21)));
				if(value!=1){
					TreeMap<String,Integer> map= new TreeMap<String,Integer>();
					map.put("phone_country_code", 1);
				    status = LoginServiceHandler.updateUserSetting(map);	
				    driver.resetApp();
				    driver.context("NATIVE_APP");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	@AfterGroups(groups={"countrycode"})
	public void ldapPostCondition(){
		try{
			TreeMap<String,Integer> map= new TreeMap<String,Integer>();
			map.put("phone_country_code", 0);
		    LoginServiceHandler.updateUserSetting(map);
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
