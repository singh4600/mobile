package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieVideoPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AndroidVideoPageTest extends TestSetup {

	AppypieVideoPage video; 


	private static final Logger Logger = Log.createLogger();

	SoftAssert s_assert = new SoftAssert();



	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		video=new AppypieVideoPage(driver);
	}

	public String Getactualtext(AppiumDriver<MobileElement> driver, By gettext ){
		String Actualtext=" ";
		WebElement element = ElementWait.waitForOptionalElement(driver,gettext,20);
		if(element!=null && element.isDisplayed()){
			Actualtext=	element.getText();
			Logger.info("Get Text:  "+Actualtext);
		}
		return Actualtext;
	}

	// ----------------------------------------------------------------------------------------------------

	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

				Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				Boolean =video.Openlinks();
		s_assert.assertTrue(, "  is not open"); 

		Boolean =video.TextField(, "");
		s_assert.assertTrue(, " is not working");

		String =video.Getactualtext(video.);
				if (youtube.equalsIgnoreCase("")) {

				}
				s_assert.assertNotNull(, "  is getting Null Value ");

		}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 




		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 1, description = "")
	public void VerifyYouTube() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyYouTube()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				/*Boolean =video.Openlinks();
				s_assert.assertTrue(, "  is not open"); */

				String youtube=video.Getactualtext(video.YoutubeHeading_gettext);
				if (youtube.equalsIgnoreCase("youTube")) {

					Boolean Youtubelink=video.Openlinks(video.Youtubevideolink);
					if (Youtubelink) {
						video.getListofLink(video.youtubePlaylist_get);

						Boolean playyoutubeVideo=video.Openlinks(video.playyoutubeVideoNative);
						if (playyoutubeVideo) {
							driver.context("NATIVE_APP");
							video.Getactualtext(video.header_gettext_native);
							Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
							s_assert.assertTrue(BackButtonNativ, "Back Button is not open on Video page");


							PageElement.changeContextToWebView(driver);

							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");

						}
						s_assert.assertTrue(playyoutubeVideo, "play youtube Video  is not open"); 

					}
					s_assert.assertTrue(Youtubelink, "Youtube link is not open"); 

				}
				s_assert.assertNotNull(youtube, "Youtube Heading is getting Null Value ");

			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifyFaceBook() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFaceBook()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);

				String FBHeading=video.Getactualtext(video.FBHeading_gettext);
				if (FBHeading.equalsIgnoreCase("Facebook")) {

					Boolean FBlink=video.Openlinks(video.FBvideolink);
					if (FBlink) {
						video.getListofLink(video.FBPlaylist_get);

						Boolean playFBVideo=video.Openlinks(video.playFBVideoNative);
						if (playFBVideo) {
							driver.context("NATIVE_APP");
							video.Getactualtext(video.header_gettext_native);
							Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
							s_assert.assertTrue(BackButtonNativ, "Back Button is not open on fb page");
							PageElement.changeContextToWebView(driver);

							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");
						}
						s_assert.assertTrue(playFBVideo, "play FB Video is not open"); 
					}
					s_assert.assertTrue(FBlink, "FB link is not open"); 
				}
				s_assert.assertNotNull(FBHeading, "FB Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyUstream() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyUstream()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);

				String Ustream=video.Getactualtext(video.UstreamHeading_gettext);
				if (Ustream.equalsIgnoreCase("Ustream")) {

					Boolean Ustreamlinkk=video.Openlinks(video.Ustreamlink);
					if (Ustreamlinkk) {
						driver.context("NATIVE_APP");
						video.Getactualtext(video.header_gettext_native);
						Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
						s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
						PageElement.changeContextToWebView(driver);

						Boolean BackButton=video.Openlinks(video.BackButton1);
						s_assert.assertTrue(BackButton, "Back Button  is not open");

						/*
						video.getListofLink(video.);

						Boolean =video.Openlinks(video.);
						if () {
							driver.context("NATIVE_APP");
							Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
							s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
							PageElement.changeContextToWebView(driver);

							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");

						}
						s_assert.assertTrue(, "  is not open"); 

						 */}
					s_assert.assertTrue(Ustreamlinkk, "Ustream link is not open"); 
				}
				s_assert.assertNotNull(Ustream, "Ustream Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifyVimeo() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyVimeo()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);


				String VimeoHeading=video.Getactualtext(video.VimeoHeading_gettext);
				if (VimeoHeading.equalsIgnoreCase("Vimeo")) {

					Boolean Vimeolinkk=video.Openlinks(video.Vimeolink);
					if (Vimeolinkk) {
						driver.context("NATIVE_APP");
						video.Getactualtext(video.header_gettext_native);

						/*Boolean like=video.Openlinks(video.likeBtn);
						if (like) {
							driver.context("NATIVE_APP");
							driver.navigate().back();
							//PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(like, "like Button  is not open"); 

						driver.context("NATIVE_APP");
						Boolean watchLater=video.Openlinks(video.watchLaterbtn);
						if (watchLater) {
							driver.context("NATIVE_APP");
							driver.navigate().back();
							//PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(watchLater, "watch Later button  is not open");

						driver.context("NATIVE_APP");
						Boolean share=video.Openlinks(video.sharebtn);
						s_assert.assertTrue(share, "share button  is not open"); 

						driver.context("NATIVE_APP");
						Boolean closeShare=video.Openlinks(video.closeSharebtn);
						s_assert.assertTrue(closeShare, "close Share Button  is not open"); 

						driver.context("NATIVE_APP");
						Boolean play=video.Openlinks(video.playbtn);
						s_assert.assertTrue(play, "play button  is not open"); 

						driver.context("NATIVE_APP");
						Boolean pause=video.Openlinks(video.pausebtn);
						s_assert.assertTrue(pause, "pause button  is not open"); */

						driver.context("NATIVE_APP");
						Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
						s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");

						PageElement.changeContextToWebView(driver);

						Boolean BackButton=video.Openlinks(video.BackButton1);
						s_assert.assertTrue(BackButton, "Back Button  is not open");

						/*
						video.getListofLink(video.);

						Boolean =video.Openlinks(video.);
						if () {
							driver.context("NATIVE_APP");
							Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
							s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
							PageElement.changeContextToWebView(driver);

							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");

						}
						s_assert.assertTrue(, "  is not open"); 

						 */}
					s_assert.assertTrue(Vimeolinkk, "Vimeo link is not open"); 
				}
				s_assert.assertNotNull(VimeoHeading, "Vimeo Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VerifyMediaRss() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMediaRss()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);

				String MediaRssHeading=video.Getactualtext(video.MediaRssHeading_gettext);
				if (MediaRssHeading.equalsIgnoreCase("Media RSS")) {

					video.getListofLink(video.MediaRssPlaylist_get);
							
					Boolean MediaRSSlinkk=video.Openlinks(video.MediaRSSlink);
					
					if (MediaRSSlinkk) {
					
						video.getListofLink(video.MediaRssPlaylist2_get);

						Boolean MediaRssVideoplay=video.Openlinks(video.playMediaRssVideoNative);
						if (MediaRssVideoplay) {
							
							Boolean alertheader=video.IselementPresent(video.AlertHeader_gettext);
							if (alertheader) {
								video.IfAlertpresent();	
							}
							else{
								driver.context("NATIVE_APP");
								Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
								s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
								PageElement.changeContextToWebView(driver);
							}
							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");

						}
						s_assert.assertTrue(MediaRssVideoplay, "Media Rss Video play  is not open"); 

						 }
					s_assert.assertTrue(MediaRSSlinkk, "Media RSS link is not open"); 
				}
				s_assert.assertNotNull(MediaRssHeading, "MediaRss Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 6, description = "")
	public void VerifyDailyMotion() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDailyMotion()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);

				String DailymotionHeading=video.Getactualtext(video.DailymotionHeading_gettext);
				if (DailymotionHeading.equalsIgnoreCase("Dailymotion")) {

					Boolean Dailymotionlinkk=video.Openlinks(video.Dailymotionlink);
					if (Dailymotionlinkk) {

						video.getListofLink(video.DailymotionPlaylist_get);

						Boolean playDailymotion=video.Openlinks(video.playDailymotionVideoNative);
						if (playDailymotion) {
							driver.context("NATIVE_APP");
							Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
							s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
							PageElement.changeContextToWebView(driver);

							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");

						}
						s_assert.assertTrue(playDailymotion, "play Dailymotion video  is not open"); 
					}
					s_assert.assertTrue(Dailymotionlinkk, "Dailymotion link is not open"); 
				}
				s_assert.assertNotNull(DailymotionHeading, "Dailymotion Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 7, description = "")
	public void VerifyCustom() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyCustom()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);

				String CustomHeading=video.Getactualtext(video.CustomHeading_gettext);
				if (CustomHeading.equalsIgnoreCase("Custom")) {

					Boolean customvideolinkk=video.Openlinks(video.customvideolink);
					if (customvideolinkk) {

						driver.context("NATIVE_APP");
						video.Getactualtext(video.header_gettext_native);
						Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
						s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
						PageElement.changeContextToWebView(driver);

						Boolean BackButton=video.Openlinks(video.BackButton1);
						s_assert.assertTrue(BackButton, "Back Button  is not open");
						/*
						video.getListofLink(video.);

						Boolean =video.Openlinks(video.);
						if () {
							driver.context("NATIVE_APP");
							Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
							s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
							PageElement.changeContextToWebView(driver);

							Boolean BackButton=video.Openlinks(video.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open");

						}
						s_assert.assertTrue(, "  is not open"); 

						 */}
					s_assert.assertTrue(customvideolinkk, "custom link is not open"); 
				}
				s_assert.assertNotNull(CustomHeading, "Custom Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 8, description = "")
	public void VerifyLiveStream() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyLiveStream()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);

				String liveStremHeading=video.Getactualtext(video.liveStremHeading_get);
				if (liveStremHeading.equalsIgnoreCase("Live Stream")) {

					Boolean liveStreamvideolinkk=video.Openlinks(video.liveStreamlink);
					if (liveStreamvideolinkk) {

						driver.context("NATIVE_APP");
						video.Getactualtext(video.header_gettext_native);
						Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
						s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");
						PageElement.changeContextToWebView(driver);

						Boolean BackButton=video.Openlinks(video.BackButton1);
						s_assert.assertTrue(BackButton, "Back Button  is not open");
					}
					s_assert.assertTrue(liveStreamvideolinkk, "live Stream video link is not open"); 
				}
				s_assert.assertNotNull(liveStremHeading, "Live Strem Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 9, description = "")
	public void Verify360Video() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  Verify360Video()");
		boolean exception = false;
		try {
			Boolean VideoModule=video.Openlinks(video.VideolinkModule);
			if (VideoModule) {
				video.Getactualtext(video.header_gettext);

				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);
				video.swipingHorizontal(300);

				String video360Heading=video.Getactualtext(video.video360Heading_get);
				if (video360Heading.equalsIgnoreCase("Live Stream")) {

					Boolean video360videolinkk=video.Openlinks(video.video360link);
					if (video360videolinkk) {

						driver.context("NATIVE_APP");
						video.Getactualtext(video.header_gettext_native);
						driver.navigate().back();
						/*Boolean BackButtonNativ=video.Openlinks(video.BackButtonNative);
						s_assert.assertTrue(BackButtonNativ, "Back Button is not open on  page");*/
						PageElement.changeContextToWebView(driver);

						Boolean BackButton=video.Openlinks(video.BackButton1);
						s_assert.assertTrue(BackButton, "Back Button  is not open");
					}
					s_assert.assertTrue(video360videolinkk, "video 360 video link is not open"); 
				}
				s_assert.assertNotNull(video360Heading, "video 360 Heading is getting Null Value ");
			}
			s_assert.assertTrue(VideoModule, "Video Module is not open"); 

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + video.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

}
