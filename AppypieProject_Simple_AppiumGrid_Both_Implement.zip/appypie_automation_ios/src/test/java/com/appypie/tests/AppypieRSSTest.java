package com.appypie.tests;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieBlog;
import com.appypie.pages.AppypieRSSPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieRSSTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	AppypieRSSPage rsspage;
	AppypieBlog blogpage;
	SoftAssert asser;

	@BeforeTest
	@Override
	public void pageSetUp() {
		rsspage = new AppypieRSSPage(driver);
		blogpage = new AppypieBlog(driver);
	}

	@Test
	public void verifyRSSPage() {
		Logger.info("********Test Method Start: verifyRSSPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			boolean rssOpen = rsspage.identifyRSSOpen();
			if (rssOpen) {
				String rssHeader = PageElement.getPageHeader(driver);
				PageElement.tapBackButton(driver);
				asser.assertEquals(PageElement.getAppName(driver), "Automate");
				asser.assertEquals(rssHeader, "RSS");
			} else {
				Logger.info("RSS Page is not open from main menu");
			}
			asser.assertTrue(rssOpen, "RSS  Page is not Open by clicking the main menu icon");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the RSS page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyRssUrls() {
		Logger.info("********Test Method Start: verifyRssUrls********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			boolean info = rsspage.getUrlListing();
			asser.assertTrue(info, "RSS url is not opening");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the RSS URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyInvalidUrl() {
		Logger.info("********Test Method Start: verifyInvalidUrl********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();	
			boolean open = rsspage.clickInvalidUrl();
			asser.assertTrue(open, "RSS url is not opening and no data icon is also not visible on screen");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the invalid RSS URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDatesAndSorting() {
		Logger.info("********Test Method Start: verifyDatesAndSorting********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			boolean sort = rsspage.getDates();
			asser.assertTrue(sort, "Listing corresponding to RSS url  is not Sorted according to Recent update Dates");
		} catch (Exception e) {
			Logger.error("Error occurs while Verifying the Dates in the listings", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyRssUrlsList() {
		Logger.info("********Test Method Start: verifyRssUrlsList********");
		asser = new SoftAssert();
		boolean exception = false;
		boolean date = false;
		boolean heading = false;
		boolean listContent = false;
		boolean image = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			List<Object> content = rsspage.getUrlListingContent();
			image = (boolean) content.get(0);
			if (content.get(1) != "" || content.get(1) != null || content.get(1) != "ND")
				date = true;
			if (content.get(2) != "" || content.get(2) != null || content.get(2) != "ND")
				heading = true;
			if (content.get(3) != "" || content.get(3) != null || content.get(3) != "ND")
				listContent = true;
			asser.assertTrue(image, " image is not displayed for RSS Url feed ");
			asser.assertTrue(date, "Date is not displayed for RSS Url feed ");
			asser.assertTrue(heading, "Header is not displayed for RSS Url feed ");
			asser.assertTrue(listContent, "listContent is not displayed for RSS Url feed");
		} catch (Exception e) {
			Logger.error("Error occurs while fetching the data from the list", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyListClick() {
		Logger.info("********Test Method Start: verifyListClick********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			String heading = blogpage.listHeading();
			blogpage.openListing();
			String listPageheading = blogpage.getListPageContent();
			Logger.info("heading of list on listing page is " + heading
					+ " and on the list detail page after clicking on list is " + listPageheading);
			asser.assertEquals(heading, listPageheading);
		} catch (Exception e) {
			Logger.error("Error occurs while clicking the RssUrl listing ", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	//@Test
	public void openListInNative() {
		Logger.info("********Test Method Start: openListInNative********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			blogpage.openListing();
			boolean open = blogpage.openListInNative("RSS");
			asser.assertTrue(open, "RSS listing is not open in native browser");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Rss Url list in native Browser", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyFontBtn() {
		Logger.info("********Test Method Start: verifyFontBtn********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			blogpage.openListing();
			boolean font = blogpage.fontBtn();
			asser.assertTrue(font, "Font Buttton is not Working ");
		} catch (Exception e) {
			Logger.error("Error occurs while clicking on FontButton ", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyShareBtn() {
		Logger.info("********Test Method Start: verifyShareBtn********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			rsspage.openRSSPage();
			rsspage.openRssUrls();
			blogpage.openListing();
			blogpage.clickShareBtn();
			asser.assertTrue(PageElement.checkSharePopUp(driver), "share Buttton is not Working ");
		} catch (Exception e) {
			Logger.error("Error occurs while clicking on share Button ", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
