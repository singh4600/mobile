package com.appypie.tests.basetest;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.NavigationPage;
import com.appypie.report.ExtentManager;
import com.appypie.util.ChromeDriverHandler;
import com.appypie.util.CommanClass;
import com.appypie.util.ElementWait;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.PageElement;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public abstract class TestSetup {
	public static AppiumDriver<MobileElement> driver;
	private static final Logger Logger = Log.createLogger();
	private NavigationPage navigationPage;
	public static String deviceName;
	SoftAssert asser;
	public static String globledeviceName;
	String webViewName;


	// for Generation of extent report
	private static ExtentReports extent;
	private static ThreadLocal parentTest = new ThreadLocal();
	private static ThreadLocal classTest = new ThreadLocal();
	private static ThreadLocal test = new ThreadLocal();
	
	
	// App1 capabilities
	 public static String DriverPck="com.app.driverautomate";
	 public static String DriverActivityName="com.app.driverautomate.SplahsActivity";
	 public static String IosbundleId="";

	// App2 capabilities
	 public static String PassengerPackageName="com.snappy.appypie";
	 public static String PassengerActivityName="com.snappy.appypie.HomeActivity";


	public abstract void pageSetUp();

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("Appypie test suite start");
		extent = ExtentManager.createInstance("ExtentReport/extent.html");
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("ExtentReport/extent.html");
		extent.attachReporter(htmlReporter);
	}

	@BeforeTest
	@Parameters({ "port", "device", "version", "name","apk" })
	public void setUp(String port, String device, String version, String name,String apk, ITestContext context)
			throws InterruptedException, IOException {
		Logger.info("Start Appium setUp for device: " + name);
		ExtentTest parent = extent.createTest(context.getName());
		parentTest.set(parent);
		// final String URL_STRING = "http://172.16.11.129:"+port+"/wd/hub";
		final String URL_STRING = "http://0.0.0.0:" + port + "/wd/hub";
		deviceName = name;
		globledeviceName=name;
		URL url = new URL(URL_STRING);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		if (!name.equals("iPhone")) {
			capabilities.setCapability("deviceName", device);
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "Android");
			capabilities.setCapability(CapabilityType.VERSION, version);
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("autowebview", true);
			capabilities.setCapability("noReset", false);
			//capabilities.setCapability("fullReset", false);
			capabilities.setCapability(MobileCapabilityType.TAKES_SCREENSHOT, "true");
			capabilities.setCapability("app", apk);
			capabilities.setCapability("newCommandTimeout", 1000);
			capabilities.setCapability("autoGrantPermissions", "true");
			//capabilities.setCapability("chromedriverExecutable", "/Users/pawan/Downloads/chromedriver");
			capabilities.setCapability("recreateChromeDriverSessions", true);
			driver = new AndroidDriver<MobileElement>(url, capabilities);
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

		} else {
			capabilities.setCapability("deviceName", device);
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "iOS");
			capabilities.setCapability(CapabilityType.VERSION, version);
			capabilities.setCapability("platformName", "Mac");
			capabilities.setCapability("startIWDP", true);
			//capabilities.setCapability("udid", "1fafa72d92cae9cc566448e62a3fcc6ccc4abd93");
			capabilities.setCapability("udid", "a969b2ad0c47541ba61bdf1fc28b9ddd58b2c985");
			capabilities.setCapability("autowebview", true);
			capabilities.setCapability("xcodeOrgId", "K2TFWDRZJF");
			capabilities.setCapability("xcodeSigningId", "iPhone Developer");
			capabilities.setCapability("automationName", "XCUITest");
			capabilities.setCapability("noReset", true);
			capabilities.setCapability("bundleId", "com.anuragtest.anuragtest");
			capabilities.setCapability("agentPath","/Applications/Appium.app/Contents/Resources/app/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent/WebDriverAgent.xcodeproj");
			capabilities.setCapability("bootstrapPath", "/Applications/Appium.app/Contents/Resources/app/node_modules/appium/node_modules/appium-xcuitest-driver/WebDriverAgent");
			capabilities.setCapability("app", apk); 
			capabilities.setCapability("newCommandTimeout", 700);
			capabilities.setCapability("recreateChromeDriverSessions", true);
			capabilities.setCapability("autoGrantPermissions", "true");
			capabilities.setCapability("setWebContentsDebuggingEnabled", true);
			capabilities.setCapability("webkitResponseTimeout", "70000");
			capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 50000);
			capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
			capabilities.setCapability("startIWDP", true);
			capabilities.setCapability("locationServicesAuthorized", true);
			capabilities.setCapability("locationServicesEnabled", true);
			capabilities.setCapability("autoAcceptAlerts", true);
			//capabilities.setCapability("shouldWaitForQuiescence", true);
			//capabilities.setCapability("shouldUseTestManagerForVisibilityDetection", false);
			
			driver = new IOSDriver<MobileElement>(url, capabilities);
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		}
		Logger.info("Appium setUp finished and driver is created");

	}

	@AfterTest
	public void tearDownAppium() {
		driver.quit();
	}

	@BeforeClass
	public void navigateTo() {
/*		ExtentTest testclass = ((ExtentTest) parentTest.get()).createNode(getClass().getName());
		classTest.set(testclass);*/
		System.out.println(deviceName);
		if (!globledeviceName.equals("iPhone")) {
			
	/*	navigationPage = new NavigationPage(driver);
		navigationPage.navigateToPage();
		driver.context("NATIVE_APP");*/
			Logger.info("Splash loaded successfully");
			NavigationPage.verifyrunTimePermissions(driver);
			Set<String> webViewName = driver.getContextHandles();
			System.out.println("Context Name is "+ webViewName);	
			Logger.info(" webview starts loading");
			Logger.info(" webview successfully loaded");
			PageElement.changeContextToWebView(driver);
			PageElement.termCond();
			driver.context("NATIVE_APP");
			}
		else{
			Logger.info("Splash loaded successfully");
			NavigationPage.verifyrunTimePermissions(driver);
			Set<String> webViewName = driver.getContextHandles();
			System.out.println("Context Name is "+ webViewName);	
			Logger.info(" webview starts loading");
			Logger.info(" webview successfully loaded");
			PageElement.changeContextToWebView(driver);
			PageElement.termCond();
			driver.context("NATIVE_APP");
		}

	}

	@AfterClass
	public void restartApp() {
		// ChromeDriverHandler.chromeDriverHandlerThread().stop();
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		driver.resetApp();
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
		driver.context("NATIVE_APP");
	}

	@BeforeMethod
	public void startTest(Method method) {
		System.out.println("------------------------------------------------------");
		asser = new SoftAssert();

		if (!globledeviceName.equals("iPhone")) {

	/*		try {
				PageElement.checkForUnexpectedAlert(driver);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			//---------
			/*
		try {
			ExtentTest child = ((ExtentTest) classTest.get()).createNode(method.getName());
			test.set(child);
			asser.assertTrue(new AppypieMenuPage(driver).isPageExist("about"), "main menu is not open");
		} catch (UnhandledAlertException ex) {
			try {
				Logger.debug("unhandle alert exception occurs");
				// takeScreenshot("UnhandleAlertAfter_"+runningTest);
				// ImageUtil.takeScreenshot(driver, "UnhandleAlertAfter_" +
				// runningTest + "_" + TestSetup.deviceName); 
				PageElement.checkForUnexpectedAlert(driver);
				Thread.sleep(1000);
				// takeScreenshot("AfterAlertDismiss_"+runningTest);
				// ImageUtil.takeScreenshot(driver, "AfterAlertDismiss_" +
				// runningTest + "_" + TestSetup.deviceName);
				asser.assertTrue(new AppypieMenuPage(driver).isPageExist("about"),
						"main menu is not open after handling alert");
			} catch (Exception e) {
				Logger.error("Exception occurs getting the header of main menu after unexpected alert occurs :", e);
			}
		} 

			 */
			PageElement.changeContextToWebView(driver);
			

		}
		else{
			try{
				PageElement.changeContextToWebView(driver);
			}
			catch (Exception e) {
				System.out.println("Error in Before Method :: "+e);
			}
		}
	}

	@AfterMethod
	public void returnTopage(ITestResult result) throws InterruptedException {

		if (!globledeviceName.equals("iPhone")) {
		/*	if (result.getStatus() == ITestResult.FAILURE)
				((ExtentTest) test.get()).fail(result.getThrowable());
			else if (result.getStatus() == ITestResult.SKIP)
				((ExtentTest) test.get()).skip(result.getThrowable());
			else {
				((ExtentTest) test.get()).pass("Test passed");
			extent.flush();
			}*/
			// ImageUtil.takeScreenshot(driver, "afterMethod_" + runningTest);
			// takeScreenshot("afterMethod_"+runningTest);
			if (driver.getContext().equals("NATIVE_APP")) {
				// driver.context("WEBVIEW_com.snappy.appypie");
				PageElement.changeContextToWebView(driver);
				Thread.sleep(1000);
			}
			String url= driver.getCurrentUrl();
			//System.out.println(url);
			driver.navigate().to(driver.getCurrentUrl());
		}

		else{
			if (driver.getContext().equals("NATIVE_APP")) {
				// driver.context("WEBVIEW_com.snappy.appypie");
				PageElement.changeContextToWebView(driver);
				Thread.sleep(1000);
			}
			String url= driver.getCurrentUrl();
			//System.out.println(url);
			driver.navigate().to(driver.getCurrentUrl());
		}
		System.out.println("------------------------------------");
	}

}
