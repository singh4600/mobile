package com.appypie.tests;



import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.OrderFoodPages.CartPage;
import com.appypie.pages.OrderFoodPages.CheckOutPage;
import com.appypie.pages.OrderFoodPages.CommanClassforOrderFood;
import com.appypie.pages.OrderFoodPages.HomePage;
import com.appypie.pages.OrderFoodPages.MenuPage;
import com.appypie.pages.OrderFoodPages.PaymentOptionsPage;
import com.appypie.pages.OrderFoodPages.Pickup;
import com.appypie.pages.OrderFoodPages.ProductDetailPage;
import com.appypie.pages.OrderFoodPages.SubcategoryPage;
import com.appypie.pages.OrderFoodPages.ThankYouPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AndroidOrderFoodTest extends TestSetup {
	HomePage homeorderfood;
	MenuPage menu;
	SubcategoryPage subcategory;
	ProductDetailPage productdetail;
	CartPage cart;
	CheckOutPage checkout;
	CommanClassforOrderFood comman;
	PaymentOptionsPage paymentoption;
	ThankYouPage thankyou;
	Pickup pick;



	private static final Logger Logger = Log.createLogger();

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		homeorderfood = new HomePage(driver);
		menu=new MenuPage(driver);
		subcategory=new SubcategoryPage(driver);
		productdetail=new ProductDetailPage(driver);
		cart=new CartPage(driver);
		checkout=new CheckOutPage(driver);
		comman=new CommanClassforOrderFood(driver);
		paymentoption=new PaymentOptionsPage(driver);
		thankyou=new ThankYouPage(driver);
		pick=new Pickup(driver);
	}

	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VerifyMenulists() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenulists()");
		boolean exception = false;
		try {
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"Order Food");

				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean menulist=comman.getListofLink(this.menu.menuList_gettext);
					if (menulist) {
						String un=comman.Getactualtext(this.menu.userName_gettext);
						s_assert.assertNotNull(un, "User Name is getting Null, value");

						String location=comman.Getactualtext(this.menu.address_gettext);
						s_assert.assertNotNull(location, "location is getting Null, value");
					}
					s_assert.assertTrue(menulist,"Menu list is not getting");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login/Close Menu");		
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 1, description = "")
	public void VerifyMenu_MyShop() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_MyShop()");
		boolean exception = false;
		try {

			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");


				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean myshop=comman.Openlinks(this.menu.myshoplink);
					if (myshop) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Order Food","My Shop link is not open");
						if (comman.Getactualtext(comman.header_gettext).equals("Order Food")) {
							System.out.println("Food Order Home page");
							Boolean backbtn=comman.Openlinks(comman.BackButton1);
							s_assert.assertTrue(backbtn, "Back Button is not working after click on My Shop menu link page");
						}
					}
					s_assert.assertTrue(myshop,"My Shop menu link is not working");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifyMenu_Cart() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_Cart()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean cart=comman.Openlinks(this.menu.cartlink);
					if (cart) {

						if (comman.Getactualtext(comman.AlertText_gettext).equals("There are no items in the cart")) {
							System.out.println("Cart is Empty");
							comman.IfAlertpresent();
						}
						else{
							s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"Cart");
							if (comman.Getactualtext(comman.header_gettext).equals("Cart")) {
								Boolean backbtn=comman.Openlinks(comman.BackButton1);
								s_assert.assertTrue(backbtn, "Back Button is not working on cart page");
							}
						}
					}
					s_assert.assertTrue(cart,"cart menu link is not working");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyMenu_OfferZone() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_OfferZone()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");
				
				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					
					Boolean offerzone=comman.Openlinks(this.menu.offerzonelink);
					if (offerzone) {
						
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Offer Zone","Offer Zone link is not open");
						
						if (comman.Getactualtext(comman.header_gettext).equals("Offer Zone")) {
							Boolean backbtn=comman.Openlinks(comman.BackButton1);
							s_assert.assertTrue(backbtn, "Back Button is not working on  Offer Zone page page");
						}
					}
					s_assert.assertTrue(offerzone, "Offer Zone Menu link is not wokring");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 4, description = "")
	public void VerifyMenu_MyOrder() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_MyOrder()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");
				
				
				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					
					Boolean myOrder=comman.Openlinks(this.menu.myOrderlink);
					if (myOrder) {
					s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"My Orders","My orders menu link is not working");
					if (comman.Getactualtext(comman.header_gettext).equals("My Orders")) {
						Boolean order=comman.Openlinks(this.menu.myorderFirst);
						if (order) {
							Boolean deliveryAddress=comman.Openlinks(this.menu.deliveryAddress_myorder);
							if (deliveryAddress) {
								comman.Getactualtext(this.menu.billingAddress_gettext_myorder);
							}
							else{
								System.out.println("delivery Address TAB is not present");
							}
							//s_assert.assertTrue(deliveryAddress, "delivery Address TAB  is not open"); 
							
							Boolean billingAddress=comman.Openlinks(this.menu.billingAddress_myOrder);
							if (billingAddress) {
								comman.Getactualtext(this.menu.billingAddress_gettext_myorder);
							}
							s_assert.assertTrue(billingAddress, "billing Address TAB is not open"); 
							
							Boolean oderDetais=comman.Openlinks(this.menu.oderDetais_myorder);
							if (oderDetais) {
								
								Boolean orderDetailsList=comman.getListofLink(this.menu.orderDetailsList_getxt);
								if (orderDetailsList) {
									Boolean viewItem=comman.Openlinks(this.menu.viewItemBtn);
									if (viewItem) {
										
										comman.getListofLink(this.menu.viewItemlistgetText_myorder);
										Boolean postReview=comman.Openlinks(this.menu.postReview_myorder);
										if (postReview) {
											Boolean BackButton=comman.Openlinks(comman.BackButton1);
											s_assert.assertTrue(BackButton, "Back Button is not open after open post review btn"); 
										}
										s_assert.assertTrue(postReview, "post Review is not open"); 

										Boolean reorder=comman.Openlinks(this.menu.reorder_myOrder);
										if (reorder) {
											comman.IfAlertpresent();
											Boolean BackButton=comman.Openlinks(comman.BackButton1);
											s_assert.assertTrue(BackButton, "Back Button is not open after open post review btn"); 
											
											Boolean BackButton1=comman.Openlinks(comman.BackButton1);
											s_assert.assertTrue(BackButton1, "Back Button1 is not open after open post review btn"); 
										}
										s_assert.assertTrue(reorder, "reorder is not open"); 
									}
									s_assert.assertTrue(viewItem, "view Item is not open"); 
								}
								s_assert.assertTrue(orderDetailsList, "order Details List is not getting"); 
							}
							s_assert.assertTrue(oderDetais, "oder Detais TAB is not open"); 
						}
						s_assert.assertTrue(order, "order link is not open"); 
						
						Boolean backbtn=comman.Openlinks(comman.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working on myOrder page");
					}
					}
					s_assert.assertTrue(myOrder, "myOrder link is not working");
					
				}
		
			s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 5, description = "")
	public void VerifyMenu_MyAccount() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_MyAccount()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean myAccount=comman.Openlinks(this.menu.myAccountlink);
					if (myAccount) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "My Account","My Account link is not Open");
					
						if (comman.Getactualtext(comman.header_gettext).equals("My Account")) {
							Boolean backbtn=comman.Openlinks(comman.BackButton1);
							s_assert.assertTrue(backbtn, "Back Button is not working on myAccount page");
						}
					}
					s_assert.assertTrue(myAccount, "myAccount link is not working");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 6, description = "")
	public void VerifyMenu_Wish() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_Wish()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean wishlist=comman.Openlinks(this.menu.wishlistlink);
					if (wishlist) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "WishList","Wish menu link is not open");
						
						if (comman.Getactualtext(comman.header_gettext).equals("WishList")) {
							Boolean backbtn=comman.Openlinks(comman.BackButton1);
							s_assert.assertTrue(backbtn, "Back Button is not working on wishlist page");
						}
					}
					s_assert.assertTrue(wishlist, "wishlist link is not working");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 7, description = "")
	public void VerifyMenu_TermConditions() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_TermConditions()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean TC=comman.Openlinks(this.menu.TClink);
					if (TC) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Terms and Conditions");
						Boolean backbtn=comman.Openlinks(comman.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working on TC page");
					}
					s_assert.assertTrue(TC, "TC link is not working");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 8, description = "")
	public void VerifyMenu_PrivacyPolicy() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu_Privacy Policy()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean menulink=comman.Openlinks(homeorderfood.Menulink);
				if (menulink) {
					Boolean PP=comman.Openlinks(this.menu.PPlink);
					if (PP) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Privacy Policy");
						Boolean backbtn=comman.Openlinks(comman.BackButton1);
						s_assert.assertTrue(backbtn, "Back Button is not working on PP page");
					}
					s_assert.assertTrue(PP, "PP link is not working");
				}
				s_assert.assertTrue(menulink, "Menu link is not working After Login");
			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 9, description = "")
	public void VerifyNonVegTAB()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyNonVegTAB()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"Order Food");

				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");
				
				driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

				Boolean nonveg=comman.Openlinks(homeorderfood.nonVegTablink);
				Boolean nonveg1=comman.IselementPresent(homeorderfood.nonVegTablink);
				if (nonveg1) {
					Boolean nonveg2=comman.Openlinks(homeorderfood.nonVegTablink);
				}
				
				if (nonveg) {
					driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
					Boolean non=comman.Openlinks(homeorderfood.nonveglink);
					if (non) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Products");

						String productname=comman.Getactualtext(productdetail.ProductName_gettext);
						s_assert.assertNotNull(productname, "Product Name is getting Null value");

						String productPrice=comman.Getactualtext(productdetail.Productprice_gettext);
						s_assert.assertNotNull(productPrice, "Product Price is getting Null value");

						String heading=comman.Getactualtext(productdetail.heading_gettext);
						s_assert.assertNotNull(heading, "heading is getting Null value");

						String discription=comman.Getactualtext(productdetail.discription_gettext);
						s_assert.assertNotNull(discription, "discription is getting Null value");

						String quantity=comman.GetAttributevalue(productdetail.quantity_gettext);
						s_assert.assertNotNull(quantity, "quantity is getting Null value");

						Boolean addticart=comman.Openlinks(productdetail.addincartlink);
						s_assert.assertTrue(addticart, "Add to cart link is not working");

					}
					s_assert.assertTrue(non, "Nonveg link is not working");
				}
				s_assert.assertTrue(nonveg, "NonVeg link is not working");

			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 10, description = "")
	public void VerifycheckoutDelivery()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifycheckoutDelivery()");
		boolean exception = false;
		try {
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"Order Food");

				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean sweet=comman.Openlinks(homeorderfood.sweetTablink);
				if (sweet) {

					String ca=comman.Getactualtext(homeorderfood.maincategory_gettext);
					s_assert.assertNotNull(ca, "Main Category name is getting Null Value");

					String subcat=comman.Getactualtext(homeorderfood.subcategory_gettext);
					s_assert.assertNotNull(subcat, "Sub Category name is getting Null Value");

					Boolean subcatlink=comman.Openlinks(homeorderfood.subcategorylink);
					if (subcatlink) {
						s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "dry sweet");

						Boolean list=comman.getListofLink(subcategory.shortBylist_gettext);
						s_assert.assertTrue(list, "List is not getting");

						String name=comman.Getactualtext(subcategory.subcategoryitems_gettext);
						s_assert.assertNotNull(name, "Product name is getting null value");

						String price=comman.Getactualtext(subcategory.subcategoryitemsprice_gettext);
						s_assert.assertNotNull(price, "Product price is getting null value");

						Boolean subprolink=comman.Openlinks(subcategory.Subcategoryproductlink);
						if (subprolink) {
							s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Products");

							Boolean like=comman.Openlinks(subcategory.likeBtn);
							if (like) {
								comman.IfAlertpresent();
							}
							s_assert.assertTrue(like, "like btn  is not open"); 

							Boolean star=comman.Openlinks(subcategory.starBtn);
							if (star) {
								comman.IfAlertpresent();
							}
							s_assert.assertTrue(star, "star Btn  is not open"); 

							Boolean share=comman.Openlinks(subcategory.shareBtn);
							if (share) {
								if (!globledeviceName.equals("iPhone")) {
									comman.sharelink(comman.getsharebyItem_getlink);
								}
								else {
									driver.context("NATIVE_APP");
									Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
									s_assert.assertTrue(icancle, "icancle button is not working on share button");
									PageElement.changeContextToWebView(driver);
								}
								
							
							}
							s_assert.assertTrue(share, "share btn is not open"); 

							String productname=comman.Getactualtext(productdetail.ProductName_gettext);
							s_assert.assertNotNull(productname, "Product Name is getting Null value");

							String productPrice=comman.Getactualtext(productdetail.Productprice_gettext);
							s_assert.assertNotNull(productPrice, "Product Price is getting Null value");

							String heading=comman.Getactualtext(productdetail.heading_gettext);
							s_assert.assertNotNull(heading, "heading is getting Null value");

							String discription=comman.Getactualtext(productdetail.discription_gettext);
							s_assert.assertNotNull(discription, "discription is getting Null value");

							String quantity=comman.GetAttributevalue(productdetail.quantity_gettext);
							s_assert.assertNotNull(quantity, "quantity is getting Null value");

							Boolean selectcolouropen=comman.Openlinks(productdetail.selectcolorlink);
							if (selectcolouropen) {
								comman.Getactualtext(comman.header_gettext);

								Boolean choose1click=comman.Openlinks(productdetail.Choose1link);
								s_assert.assertTrue(choose1click, "choose colour check box not check");

								Boolean choose2click=comman.Openlinks(productdetail.Choose2link);
								s_assert.assertTrue(choose2click, "choose colour check box not check");

								Boolean donebtnclick=comman.Openlinks(productdetail.Donelink);
								s_assert.assertTrue(donebtnclick, "Done button not click");

								Boolean addintocartclick=comman.Openlinks(productdetail.addincartlink);
								if (addintocartclick) {
									s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Cart");
									try{
										comman.Openlinks(cart.removeProductlink);
									}
									catch (Exception e) {
										System.out.println("Second remove product is not present");
									}

									String pdname=comman.Getactualtext(cart.productName_gettext);
									s_assert.assertNotNull(pdname, "Product Name is getting Null value");

									String pdprice=comman.Getactualtext(cart.productcolour_gettext);
									s_assert.assertNotNull(pdprice, "Product Prioce is getting Null value");

									String Quentity=comman.GetAttributevalue(cart.ProductQuentity_gettext);
									s_assert.assertNotNull(Quentity, "Quentity is getting Null value");

									Boolean increment=comman.Openlinks(cart.Incrementproductbtn);
									if (increment) {
										comman.GetAttributevalue(cart.ProductQuentity_gettext);
									}
									s_assert.assertTrue(increment, "Increment button is not working");

									Boolean decrement=comman.Openlinks(cart.Decrementproductbtn);
									if (decrement) {
										comman.GetAttributevalue(cart.ProductQuentity_gettext);
									}
									s_assert.assertTrue(decrement, "decrement button is not working");

									Boolean increment1=comman.Openlinks(cart.Incrementproductbtn);
									if (increment1) {
										comman.GetAttributevalue(cart.ProductQuentity_gettext);
									}
									s_assert.assertTrue(increment1, "Increment button is not working");

									Boolean coupontext=comman.TextField(cart.CouponTextfieldbtn, "12345");
									s_assert.assertTrue(coupontext, "Coupon text filed is not present");

									Boolean couponapplybtn=comman.Openlinks(cart.CouponApplyBtn);
									if (couponapplybtn) {
										comman.IfAlertpresent();
									}
									s_assert.assertTrue(coupontext, "Coupon Apply btn is not working");

									String PaymentDetailsHeading=comman.Getactualtext(cart.PaymentDetailsHeading_gettext);
									s_assert.assertNotNull(PaymentDetailsHeading, "PaymentDetailsHeading is getting Null value");

									String TotalPayableAmount=comman.Getactualtext(cart.TotalPayableAmount_gettext);
									s_assert.assertNotNull(TotalPayableAmount, "TotalPayableAmount is getting Null value");

									String Subtotal=comman.Getactualtext(cart.Subtotal_gettext);
									s_assert.assertNotNull(Subtotal, "Subtotal is getting Null value");

									String Discount=comman.Getactualtext(cart.Discount_gettext);
									s_assert.assertNotNull(Discount, "Discount is getting Null value");

									String Delivery=comman.Getactualtext(cart.Delivery_gettext);
									s_assert.assertNotNull(Delivery, "Delivery is getting Null value");

									String Tax=comman.Getactualtext(cart.Tax_gettext);
									s_assert.assertNotNull(Tax, "Tax is getting Null value");

									Boolean tipInc=comman.Openlinks(cart.tipinc);
									s_assert.assertTrue(tipInc, "tip Inc is not open"); 

									String Tip=comman.Getactualtext(cart.Tip_gettext);
									s_assert.assertNotNull(Tip, "Tip is getting Null value");

									String miscTax=comman.Getactualtext(cart.miscTax_gettext);
									s_assert.assertNotNull(miscTax, "miscTax is getting Null value");

									String grandTotal=comman.Getactualtext(cart.grandTotal_gettext);
									s_assert.assertNotNull(grandTotal, "grand Total is getting Null value");

									Boolean continueOrdering=comman.IselementPresent(cart.continueOrderinglink);
									s_assert.assertTrue(continueOrdering, "continueOrdering link is not present");

									Boolean checkoutbtnclick=comman.Openlinks(cart.CheckoutBtn);
									if (checkoutbtnclick) {
										s_assert.assertEquals(comman.Getactualtext(comman.header_gettext), "Checkout");

										Boolean name1=comman.TextField(checkout.name_textfield, "anurag singh");
										s_assert.assertTrue(name1, "Name Text filed is not present");

										Boolean email=comman.TextField(checkout.Email_textfield, "anurag@appypie.com");
										s_assert.assertTrue(email, "Email Text filed is not present");

										Boolean phone=comman.TextField(checkout.Telephone_textfield, "9540198626");
										s_assert.assertTrue(phone, "Phone Text filed is not present");

										Boolean address=comman.TextField(checkout.Address_textfield, "Noida NSEZ");
										s_assert.assertTrue(address, "Address Text filed is not present");

										Boolean city=comman.TextField(checkout.City_textfield, "Noida");
										s_assert.assertTrue(city, "City Text filed is not present");

										Boolean state=comman.TextField(checkout.State_textfield, "Uttar Pradesh");
										s_assert.assertTrue(state, "State Text filed is not present");

										Boolean zip=comman.TextField(checkout.Zip_textfield, "201301");
										s_assert.assertTrue(zip, "ZIP Text filed is not present");

										Boolean country= comman.Openlinks(checkout.Country_textfield);
										if (country) {
											comman.countryselect();

										}
										s_assert.assertTrue(country, "country dropdown is not click");


										Boolean Deliveryaddcheckbox=comman.Openlinks(checkout.Deliveryaddresscheckbox);
										if (Deliveryaddcheckbox) {																			
											Boolean user=comman.TextField(checkout.user_delivery, "QA");
											s_assert.assertTrue(user, "User is not working");

											Boolean phonedelivery=comman.TextField(checkout.phone_delivery, "1234567890");
											s_assert.assertTrue(phonedelivery, "phone delivery is not working");

											Boolean addressdelivery=comman.TextField(checkout.address_delivery, "Noida NSEZ");
											s_assert.assertTrue(addressdelivery, "address delivery is not working");

											Boolean citydelivery =comman.TextField(checkout.city_delivery, "Noida");
											s_assert.assertTrue(citydelivery, "city delivery is not working");

											Boolean statedelivery=comman.TextField(checkout.state_delivery, "Uttar Pradesh");
											s_assert.assertTrue(statedelivery, "state delivery is not working");

											Boolean zipdelivery=comman.TextField(checkout.zip_delivery, "201301");
											s_assert.assertTrue(zipdelivery, "zip delivery is not working");

											Boolean countrydelivery=comman.Openlinks(checkout.country_delivery);
											if (countrydelivery) {
												comman.countryselect();
											}
											s_assert.assertTrue(countrydelivery, "country delivery  is not open"); 
										}
										s_assert.assertTrue(Deliveryaddcheckbox, "Delivery address checkbox is not open");


										Boolean asap=comman.CheckingChkbox(checkout.deliverASAPcheckbox);
										if (asap) {		
											TimeUnit.SECONDS.sleep(2);
											Boolean uncheck=comman.Openlinks(checkout.deliverASAPcheckbox);
											if (uncheck) {
												Boolean time=comman.Openlinks(checkout.time);
												if (time) {
													TimeUnit.SECONDS.sleep(2);
													driver.context("NATIVE_APP");
													TimeUnit.SECONDS.sleep(2);
													
													if (!globledeviceName.equals("iPhone")) {
														Boolean pm=comman.Openlinks(checkout.pmNative);
														if (pm) {
															Boolean timena=comman.Openlinks(checkout.timenative);
															if (timena) {
																Boolean setbtn=comman.Openlinks(checkout.time_Set_btn_native);
																s_assert.assertTrue(setbtn, "Set Button is not working");
															}
															s_assert.assertTrue(timena, "Time 10 PM is not working");
														}
														s_assert.assertTrue(pm, "PM is not working");
													}
													else {
														
														Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
														s_assert.assertTrue(idone, "iDone button is not working");
													}
												
													PageElement.changeContextToWebView(driver);
												}
												s_assert.assertTrue(time, "Time is not open");
											}
											s_assert.assertTrue(uncheck, "uncheck  is not open");
										}
										else{
											Boolean uncheck=comman.Openlinks(checkout.deliverASAPcheckbox);
											if (uncheck) {
												TimeUnit.SECONDS.sleep(2);

												Boolean time=comman.Actionclick(checkout.time);
												if (time) {
													TimeUnit.SECONDS.sleep(2);
													driver.context("NATIVE_APP");
													TimeUnit.SECONDS.sleep(2);
													if (!globledeviceName.equals("iPhone")) {
														Boolean pm=comman.Openlinks(checkout.pmNative);
														if (pm) {
															Boolean timena=comman.Openlinks(checkout.timenative);
															if (timena) {
																Boolean setbtn=comman.Openlinks(checkout.time_Set_btn_native);
																s_assert.assertTrue(setbtn, "Set Button is not working");
															}
															s_assert.assertTrue(timena, "Time 10 PM is not working");
														}
														s_assert.assertTrue(pm, "PM is not working");
													}
													else {
														
														Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
														s_assert.assertTrue(idone, "iDone button is not working");
													}
												}
												s_assert.assertTrue(time, "Time is not open");
											}
											s_assert.assertTrue(uncheck, "uncheck  is not open");
										}
										//s_assert.assertTrue(asap, "asap  is not open"); 		



										comman.Getactualtext(checkout.PaymentDetailsHeading_gettext);
										comman.Getactualtext(checkout.Subtotal_gettext);
										comman.Getactualtext(checkout.Discount_gettext);
										comman.Getactualtext(checkout.Delivery_gettext);
										comman.Getactualtext(checkout.Tax_gettext);
										comman.Getactualtext(checkout.Tip_gettext);
										comman.Getactualtext(checkout.GrandTotal_gettext);


										Boolean confirmbtnclick=comman.Openlinks(checkout.confirmbtn);
										TimeUnit.SECONDS.sleep(5);
										if (confirmbtnclick) {

											comman.IfAlertpresent();
											Boolean Stripe=comman.Openlinks(paymentoption.Stripelink);
											if (Stripe) {
												String StripeMessage=comman.Getactualtext(paymentoption.creditCardThroughStripeMessage_gettext);
												s_assert.assertNotNull(StripeMessage, "StripeMessage is getting Null value");
											}
											s_assert.assertTrue(Stripe, "Stripe is not Working");

											Boolean paywithCC=comman.Openlinks(paymentoption.paywithCClink);
											if (paywithCC) {
												String paywithCCmessage=comman.Getactualtext(paymentoption.paywithCCmessage_gettext);
												s_assert.assertNotNull(paywithCCmessage, "paywithCCmessage is getting Null value");
											}
											s_assert.assertTrue(paywithCC, "paywithCC is not Working");

											Boolean cod=comman.Openlinks(paymentoption.CODlink);
											if (cod) {
												String codMessage=comman.Getactualtext(paymentoption.codMessage_gettext);
												s_assert.assertNotNull(codMessage, "codMessage is getting Null value");
											}
											s_assert.assertTrue(cod, "COD is not Working");

											Boolean confirm=comman.Openlinks(paymentoption.confirmBtn);
											if (confirm) {
												String thank=comman.Getactualtext(thankyou.heading_gettext);
												s_assert.assertNotNull(thank, "heading is getting Null value");

												String message=comman.Getactualtext(thankyou.message_gettext);
												s_assert.assertNotNull(message, "Message is getting Null value");

												String orderTime=comman.Getactualtext(thankyou.orderTime_gettext);
												s_assert.assertNotNull(orderTime, "orderTime is getting Null value");

												Boolean continueOrderingthanks=comman.Openlinks(thankyou.continueOrderingBtn);
												s_assert.assertTrue(continueOrderingthanks, "continueOrdering btn is not working");
											}
											s_assert.assertTrue(confirm, "Confirm button is not working");
										}
										s_assert.assertTrue(checkoutbtnclick, "Confirm Button is not click");
									}
									s_assert.assertTrue(checkoutbtnclick, "CheckOut button is not click");
								}
								s_assert.assertTrue(addintocartclick, "Add to cart link is not click on product details page.");
							}
							s_assert.assertTrue(selectcolouropen, "select colour link is not open");
						}
						s_assert.assertTrue(subprolink, "Sub product lini is not working");
					}
					s_assert.assertTrue(subcatlink, "SubCatg link is not working");




				}
				s_assert.assertTrue(sweet, "sweet link is not working");

			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	@Test(priority = 11, description = "")
	public void Verifycheckoutdeliver_ASAP_StoreTime() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  Verifycheckoutdeliver_ASAP_StoreTime()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"Order Food");

				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");
				TimeUnit.SECONDS.sleep(4);
				driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				
				Boolean search=comman.Openlinks(homeorderfood.Searchbuttonlink);
				if (search) {
					Boolean searchtext=comman.TextField(homeorderfood.SearchTextlink,"tikka");
					if (searchtext) {
						PageElement.tapDeviceOk(driver);
						Boolean back=comman.Openlinks(comman.BackButton1);
						s_assert.assertTrue(back, "Back Button is not working after search product");
					}
					s_assert.assertTrue(searchtext, "Search product is not searching");

				}
				s_assert.assertTrue(search, "Search link is not working");

				Boolean subcatlink=comman.Openlinks(homeorderfood.subcategorylink);
				if (subcatlink) {

					Boolean list=comman.getListofLink(subcategory.shortBylist_gettext);
					s_assert.assertTrue(list, "Short By list is not getting");

					Boolean shortlinkk=comman.Openlinks(subcategory.shortBylink);
					if (shortlinkk) {
					
						
						if (!globledeviceName.equals("iPhone")) {
							driver.context("NATIVE_APP");
							Boolean lh=comman.Openlinks(subcategory.LowtoHighradobtn);
							s_assert.assertTrue(lh,"LH radio button is not working");
							PageElement.changeContextToWebView(driver);
						}
						else {
							Boolean lh=comman.Openlinks(subcategory.i_LowtoHighradobtn);
							s_assert.assertTrue(lh,"LH radio button is not working");
						}
					
					}
					s_assert.assertTrue(shortlinkk, "Short link is not working");

					Boolean shortlinkk1=comman.Openlinks(subcategory.shortBylink);
					if (shortlinkk1) {
						
						if (!globledeviceName.equals("iPhone")) {
						driver.context("NATIVE_APP");
						Boolean HL=comman.Openlinks(subcategory.HightoLowradiobtnlink);
						s_assert.assertTrue(HL,"HL radio button is not working");
						PageElement.changeContextToWebView(driver);
						}
						else {
							Boolean HL=comman.Openlinks(subcategory.i_HightoLowradiobtnlink);
							s_assert.assertTrue(HL,"HL radio button is not working");
						}
						
					}
					s_assert.assertTrue(shortlinkk1, "Short link is not working");

					Boolean subprolink=comman.Openlinks(subcategory.Subcategoryproductlink);
					if (subprolink) {

						Boolean selectcolouropen=comman.Openlinks(productdetail.selectcolorlink);
						if (selectcolouropen) {
							Boolean choose1click=comman.Openlinks(productdetail.Choose1link);
							s_assert.assertTrue(choose1click, "choose colour check box not check");

							Boolean choose2click=comman.Openlinks(productdetail.Choose2link);
							s_assert.assertTrue(choose2click, "choose colour check box not check");

							Boolean donebtnclick=comman.Openlinks(productdetail.Donelink);
							s_assert.assertTrue(donebtnclick, "Done button not click");

							Boolean addintocartclick=comman.Openlinks(productdetail.addincartlink);
							if (addintocartclick) {

								Boolean checkoutbtnclick=comman.Openlinks(cart.CheckoutBtn);
								if (checkoutbtnclick) {

									Boolean delivery=comman.Openlinks(checkout.Deliveryaddresscheckbox);
									s_assert.assertTrue(delivery, "delivery Address check box is not working");

									Boolean asap=comman.Openlinks(checkout.deliverASAPcheckbox);
									if (asap) {
										Boolean viewtime=comman.Openlinks(checkout.viewstoretimelink);
										if (viewtime) {
											/*	

											String openingtime=comman.GetAttributevalue(checkout.Genopentime_gettext);
											s_assert.assertNotNull(openingtime, "opening time is getting Null value");

											String workingtime=comman.GetAttributevalue(checkout.Genclosetime_gettext);
											s_assert.assertNotNull(workingtime, "working time is getting Null value");

											String headingCustomeservingtime=comman.GetAttributevalue(checkout.storetimingheadertitle_gettext);
											s_assert.assertNotNull(headingCustomeservingtime, "heading Custome serving time is getting Null value");

											String openingHour=comman.GetAttributevalue(checkout.Customeopentime_gettext);
											s_assert.assertNotNull(openingHour, "opening Hour is getting Null value");

											String workingHour=comman.GetAttributevalue(checkout.Customerclosetime_gettext);
											s_assert.assertNotNull(workingHour, "working Hour is getting Null value");*/

											Boolean close =comman.Openlinks(checkout.closeViewStroeTime);
											s_assert.assertTrue(close, "Close View store time button is not working");

										}
										s_assert.assertTrue(viewtime,"View Store Time link is not working");
									}
									s_assert.assertTrue(asap,"ASAp check box is not working");

								}
								s_assert.assertTrue(checkoutbtnclick, "CheckOut button is not click");
							}
							s_assert.assertTrue(addintocartclick, "Add to cart link is not click on product details page.");
						}
						s_assert.assertTrue(selectcolouropen, "select colour link is not open");
					}
					s_assert.assertTrue(subprolink, "Sub product lini is not working");
				}
				s_assert.assertTrue(subcatlink, "SubCatg link is not working");


			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 12, description = "")
	public void VerifycheckoutPickUp() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifycheckoutPickUp()");
		boolean exception = false;
		try {
			Boolean orderfoodopen=comman.Openlinks(homeorderfood.FoodOrderlink);
			if (orderfoodopen) {
				s_assert.assertEquals(comman.Getactualtext(comman.header_gettext),"Order Food");

				Boolean menu=comman.Openlinks(homeorderfood.Menulink);
				if (menu) {
					Boolean logintext=comman.IselementPresent(this.menu.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						this.menu.login(); 
					}
					else {
						System.out.println("User is already Login");
						comman.Openlinks(this.menu.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean sweet=comman.Openlinks(homeorderfood.sweetTablink);
				if (sweet) {

					Boolean subcatlink=comman.Openlinks(homeorderfood.subcategorylink);
					if (subcatlink) {

						Boolean subprolink=comman.Openlinks(subcategory.Subcategoryproductlink);
						if (subprolink) {


							/*		driver.context("NATIVE_APP");
							TimeUnit.SECONDS.sleep(2);
							comman.ScrollPerticularSection(productdetail.imgnative);
							TimeUnit.SECONDS.sleep(2);
							comman.ScrollPerticularSection(productdetail.imgnative);
							TimeUnit.SECONDS.sleep(2);



							PageElement.changeContextToWebView(driver);
							Boolean playvideobtn=comman.Openlinks(productdetail.playvideo);
							s_assert.assertTrue(playvideobtn, "Play btn not working");

							driver.context("NATIVE_APP");
							driver.navigate().back();

							PageElement.changeContextToWebView(driver);*/


							Boolean addintocartclickwithoutselectingOption=comman.Openlinks(productdetail.addincartlink);
							if (addintocartclickwithoutselectingOption) {
								comman.IfAlertpresent();
							}
							s_assert.assertTrue(addintocartclickwithoutselectingOption, "add to cart click with out selecting Option is not working");

							Boolean selectcolouropen=comman.Openlinks(productdetail.selectcolorlink);
							if (selectcolouropen) {

								Boolean choose1click=comman.Openlinks(productdetail.Choose1link);
								s_assert.assertTrue(choose1click, "choose colour check box not check");

								Boolean choose2click=comman.Openlinks(productdetail.Choose2link);
								s_assert.assertTrue(choose2click, "choose colour check box not check");

								Boolean donebtnclick=comman.Openlinks(productdetail.Donelink);
								s_assert.assertTrue(donebtnclick, "Done button not click");

								Boolean addintocartclick=comman.Openlinks(productdetail.addincartlink);
								if (addintocartclick) {

									Boolean checkoutbtnclick=comman.Openlinks(cart.CheckoutBtn);
									if (checkoutbtnclick) {

										Boolean picup=comman.Openlinks(checkout.PickupTAB);
										if (picup) {

											Boolean inst=comman.TextField(checkout.instructionText, "Appypie");
											s_assert.assertTrue(inst, "instruction Text is not present");

											Boolean viewstore=comman.Openlinks(checkout.ViewStoretimepickupTAB);
											if (viewstore) {
												Boolean close=comman.Openlinks(checkout.closeViewStroeTime);
												s_assert.assertTrue(close,"Close stor time link is not working");
											}
											s_assert.assertTrue(viewstore, "View store time link is not working");

											Boolean biillingcheck=comman.Openlinks(checkout.billcheckbox);
											if (biillingcheck) {
												//---------------

												Boolean name1=comman.TextField(pick.name_textfield, "anurag singh");
												s_assert.assertTrue(name1, "Name Text filed is not present");

												Boolean email=comman.TextField(pick.Email_textfield, "anurag@appypie.com");
												s_assert.assertTrue(email, "Email Text filed is not present");

												Boolean phone=comman.TextField(pick.Telephone_textfield, "9540198626");
												s_assert.assertTrue(phone, "Phone Text filed is not present");

												Boolean address=comman.TextField(pick.Address_textfield, "Noida NSEZ");
												s_assert.assertTrue(address, "Address Text filed is not present");

												Boolean city=comman.TextField(pick.City_textfield, "Noida");
												s_assert.assertTrue(city, "City Text filed is not present");

												Boolean state=comman.TextField(pick.State_textfield, "Uttar Pradesh");
												s_assert.assertTrue(state, "State Text filed is not present");

												Boolean zip=comman.TextField(pick.Zip_textfield, "201301");
												s_assert.assertTrue(zip, "ZIP Text filed is not present");

												Boolean country= comman.Openlinks(pick.Country_textfield);
												if (country) {
													driver.context("NATIVE_APP");
													comman.countryselect();
													PageElement.changeContextToWebView(driver);
												}
												s_assert.assertTrue(country, "country dropdown is not click");
												//-------------------------------------------------------------
											}
											s_assert.assertTrue(biillingcheck,"bill checkbox is not working");

											Boolean confirm=comman.Openlinks(checkout.ConfirmBtnPickUpTAB);
											s_assert.assertTrue(confirm, "Confirm Btn PickUp TAB is not working");
											TimeUnit.SECONDS.sleep(10);
											Boolean paywithCC=comman.Openlinks(paymentoption.paywithCClink);
											if (paywithCC) {
												String paywithCCmessage=comman.Getactualtext(paymentoption.paywithCCmessage_gettext);
												s_assert.assertNotNull(paywithCCmessage, "paywithCCmessage is getting Null value");

												Boolean calll=comman.Openlinks(paymentoption.call);
												if (calll) {
													TimeUnit.SECONDS.sleep(4);
													driver.context("NATIVE_APP");
													if (!globledeviceName.equals("iPhone")) {
														
														Boolean calllok=comman.Openlinks(paymentoption.callok);
														s_assert.assertTrue(calllok, "Call Ok button is not working");
													}
													else {
														Boolean icallcancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
														s_assert.assertTrue(icallcancle, "iCancle Button is not working");
													}
													PageElement.changeContextToWebView(driver);
												}
												s_assert.assertTrue(calll, "Call button is not working");

											}
											s_assert.assertTrue(paywithCC, "paywithCC is not Working");

										}
										s_assert.assertTrue(picup, "PickUp tab link is not working");
									}
									s_assert.assertTrue(checkoutbtnclick, "CheckOut button is not click");
								}
								s_assert.assertTrue(addintocartclick, "Add to cart link is not click on product details page.");
							}
							s_assert.assertTrue(selectcolouropen, "select colour link is not open");
						}
						s_assert.assertTrue(subprolink, "Sub product link is not working");
					}
					s_assert.assertTrue(subcatlink, "SubCatg link is not working");

				}
				s_assert.assertTrue(sweet, "sweet link is not working");

			}
			s_assert.assertTrue(orderfoodopen, "Order Food module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}












}
