package com.appypie.tests.logintests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieLoginPageTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieLoginPage login;
	
	
	@Override
	@BeforeTest
	public void pageSetUp() {
		login= new AppypieLoginPage(driver);
		
	}
	
	@Test
	public void verifyLoginPageFunctionality() {
		Logger.info("********Test Method Starts: verifyLoginPageFunctionality********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				
					// login with blank mail and pwd
				    login.login("", "");
					String warning_blank=PageElement.getWarningText(driver);
					asser.assertEquals(warning_blank, "Mandatory fields can't be left blank");
					if(warning_blank!=""){
					   PageElement.closeWarningSingleBtn(driver, "OK");
					   Thread.sleep(500);
					}
					
					// login with blank mail
					login.login("", "1234");
					String warning_blankmail=PageElement.getWarningText(driver);
					asser.assertEquals(warning_blankmail, "Mandatory fields can't be left blank");
					if(warning_blank!=""){
					   PageElement.closeWarningSingleBtn(driver, "OK");
					   Thread.sleep(500);
					}
					
					// login with blank pwd
					login.login("aa@aa.com", "");
					String warning_blankpwd=PageElement.getWarningText(driver);
					asser.assertEquals(warning_blankpwd, "Mandatory fields can't be left blank");
					if(warning_blank!=""){
					   PageElement.closeWarningSingleBtn(driver, "OK");
					   Thread.sleep(500);
					}
					
					// login with wrong account
					login.login("aa@aa.com", "1234567");
					String warning_wrongmail=PageElement.getWarningText(driver);
					asser.assertEquals(warning_wrongmail, "This account doesn't exist");
					if(warning_blank!=""){
					   PageElement.closeWarningSingleBtn(driver, "OK");
					   Thread.sleep(500);
					}
					
					// login with valid credentials
					login.login("a0@0.com", "12345678");
					Thread.sleep(2000);
					boolean homePageOpen=new AppypieMenuPage(driver).isPageExist("about");
					asser.assertTrue(homePageOpen, "login is not successful");
					if(homePageOpen){
						login.logout();
					}
				
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying login page functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


}
