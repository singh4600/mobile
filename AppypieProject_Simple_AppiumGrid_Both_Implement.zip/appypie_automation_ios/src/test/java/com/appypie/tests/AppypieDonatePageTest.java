package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieDonatePage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieDonatePageTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieDonatePage donate;
	AppypieMenuPage menu;
	
	@BeforeTest
	@Override
	public void pageSetUp() {
		donate = new AppypieDonatePage(driver);
		menu = new AppypieMenuPage(driver);
	}
	
	@Test
	public void verifyDonatePageandBackbtn() {
		Logger.info("Test Methods start: verifyDonatePageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("donation");
			boolean pageOpen = donate.isDonatePageOpen();
			asser.assertTrue(pageOpen, "Donate page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from Donate page is not working");
			}

		} catch (Exception e) {
			Logger.error("Error occurs while opening the Donate page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyDonationUrl() {
		Logger.info("Test Methods start: verifyDonationUrl");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("donation");
			boolean pageOpen = donate.isDonatePageOpen();
			asser.assertTrue(pageOpen, "Donate page is not open");
			if (pageOpen) {
				donate.openDonateUrl();
				asser.assertTrue(PageElement.isContentOpenInNative(driver,""), "Donation url is not open");
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying donation url ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
