package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieEducationPage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieEducationTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	AppypieEducationPage edu;
	AppypieMenuPage menu;
	SoftAssert asser;

	@Override
	@BeforeTest
	public void pageSetUp() {
		edu = new AppypieEducationPage(driver);
		menu = new AppypieMenuPage(driver);
	}

	@Test
	public void verifyEducationPageAndBackBtn() {
		Logger.info("Test Methods start: verifyEducationPageAndBackBtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("education");
			boolean pageOpen = edu.isEducationPageOpen();
			asser.assertTrue(pageOpen, "Education page is not open from main menu");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "backButton on Education page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the education page from main menu", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDictionaryAndSearch() {
		Logger.info("Test Methods start: verifyDictionaryAndSearch");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("education");
			boolean pageOpen = edu.isEducationPageOpen();
			asser.assertTrue(pageOpen, "Education page is not open from main menu");
			if (pageOpen) {
				edu.openEducation("dict");
				boolean dictOpen = edu.isDictionaryOpen();
				asser.assertTrue(dictOpen, "Dictionary is not open from education page");
				if (dictOpen) {
					// *** verify search option without entering keyword******
					edu.pressSearchBtn("dict");
					String dictAlert = edu.getEduAlertText();
					asser.assertEquals(dictAlert.toUpperCase().trim(), "Please enter search Text".toUpperCase());

					// *** verify Dictionary search**********
					edu.typeSearchKeyWord("dict", "nagging");
					edu.pressSearchBtn("dict");
					Thread.sleep(2000);
					asser.assertTrue(edu.isResultDisplayed("dict"), "Search result is not displayed");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying dictionary page", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyKhanAcadAndSearch() {
		Logger.info("Test Methods start: verifyKhanAcadAndSearch");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("education");
			boolean pageOpen = edu.isEducationPageOpen();
			asser.assertTrue(pageOpen, "Education page is not open from main menu");
			if (pageOpen) {
				edu.openEducation("khan");
				boolean khanOpen = edu.isKhanAcadOpen();
				asser.assertTrue(khanOpen, "KhanAcademy is not open from education page");
				if (khanOpen) {

					// *** verify search option without entering keyword******
					edu.pressSearchBtn("khan");
					String alert = edu.getEduAlertText();
					asser.assertEquals(alert.toUpperCase().trim(), "Please select Category".toUpperCase());

					// *** verify khan keyword search**********
					edu.typeSearchKeyWord("khan", "Absolute value");
					edu.pressSearchBtn("khan");
					boolean result = edu.isResultDisplayed("khan");
					asser.assertTrue(result, "khan result is not displayed from search keyword");
					if (result) {
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}

					// *** verify khan cat search**********
					edu.selectCategoryInkhanAcad("Absolute value");
					Thread.sleep(500);
					edu.pressSearchBtn("khan");
					boolean catResult = edu.isResultDisplayed("khan");
					asser.assertTrue(catResult, "khan result is not displayed from category search");
					if (result) {
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying khan Academy page", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
