package com.appypie.tests.basetest;

import static org.testng.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.interactions.Actions;

import com.appypie.util.CommanClass;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class CorrencyTest 
{

	static Workbook w;
	static WebDriver driver;
	

	public static void main(String args[]) throws InterruptedException
	{
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://angularml.pbodev.info/cool-currency-converter/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		System.out.println("Title of the WebSite:  "+driver.getTitle());
		

		CommanClass.getListofLink(By.xpath("//*[@class='selector-container from current']/div[1]/ul[1]/li"));
		
		
		
		
		driver.close();
		driver.quit();

	}

	public static void ExcelReader() throws BiffException, IOException {

		FileInputStream fi=new FileInputStream("./testing.xls");
		w=Workbook.getWorkbook(fi);
		

	}
	
	




}