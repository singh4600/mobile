package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieFitnessPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AndroidAppiumFitnessPageTest extends TestSetup {



	private static final Logger Logger = Log.createLogger();

	AppypieFitnessPage fitness;

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		fitness=new AppypieFitnessPage(driver);
	}


	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/
	@Test(priority = 0, description = "")
	public void VerifyMenu() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);
				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	
				
				Boolean menuagain=fitness.Openlinks(fitness.menulink);
				if (menuagain) {
					Boolean menulist=fitness.getListofLink(fitness.menulist_gettext);
					if (menulist) {
						Boolean home=fitness.Openlinks(fitness.homelinkMenu);
						if (home) {
							Boolean openFitnessmodule1=fitness.Openlinks(fitness.fitnessModulelink);
							s_assert.assertTrue(openFitnessmodule1, "Store Module is not open after click home link on menu page");
						}
						s_assert.assertTrue(home, "Home link on menu is not open"); 
					}
					s_assert.assertTrue(menulist, "Menu list is not Getting");

					Boolean menu1=fitness.Openlinks(fitness.menulink);
					if (menu1) {
						Boolean target=fitness.Openlinks(fitness.targetlinkMenu);
						if (target) {
							Boolean noThanks=fitness.Openlinks(fitness.noThanksBtn);
							s_assert.assertTrue(noThanks, "No Thanks is not open"); 
						}
						s_assert.assertTrue(target, "target link on menu is not open");
					}
					s_assert.assertTrue(menu1, "Menu1 link is not working");

					Boolean menu2=fitness.Openlinks(fitness.menulink);
					if (menu2) {
						Boolean target=fitness.Openlinks(fitness.targetlinkMenu);
						if (target) {
							Boolean TC=fitness.Openlinks(fitness.termsAndConditions);
							if (TC) {
								fitness.Getactualtext(fitness.header_gettext);
								fitness.Getactualtext(fitness.TC_gettext);
								Boolean ok=fitness.Openlinks(fitness.okBtn);
								s_assert.assertTrue(ok, "OK button is not open"); 
							}
							s_assert.assertTrue(TC, "Terms And Conditions is not open"); 
						}
						s_assert.assertTrue(target, "target link on menu is not open");
					}
					s_assert.assertTrue(menu2, "Menu2 link is not working");	

					Boolean menu3=fitness.Openlinks(fitness.menulink);
					if (menu3) {
						Boolean target=fitness.Openlinks(fitness.targetlinkMenu);
						if (target) {
							fitness.Getactualtext(fitness.header_gettext);
							fitness.Getactualtext(fitness.headingTargetMenu_gettext);


							Boolean age=fitness.TextField(fitness.agetargetlinkMenu, "27");
							s_assert.assertTrue(age, "Age is not working");

							Boolean weight=fitness.TextField(fitness.weighttargetlinkMenu, "80");
							s_assert.assertTrue(weight, "weight is not working");

							Boolean gender=fitness.Openlinks(fitness.gendertargetlinkMenu);
							if (gender) {
								driver.context("NATIVE_APP");
								Boolean male=fitness.Openlinks(fitness.maleNativetargetlinkMenu);
								s_assert.assertTrue(male, "Male is not open"); 
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(gender, "gender  is not open"); 

							Boolean goal=fitness.Openlinks(fitness.goaltargetlinkMenu);
							if (goal) {
								driver.context("NATIVE_APP");
								Boolean transform=fitness.Openlinks(fitness.goalNativetargetlinkMenu);
								s_assert.assertTrue(transform, "transform is not open"); 
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(goal, "Goal is not open");

							Boolean save=fitness.Openlinks(fitness.saveBtn);
							if (save) {
								fitness.IfAlertpresent();
							}
							s_assert.assertTrue(save, "Save Button is not open"); 
						}
						s_assert.assertTrue(target, "target link on menu is not open");
					}
					s_assert.assertTrue(menu3, "Menu3 link is not working");	
				}
				s_assert.assertTrue(menuagain, "Menu link is not working after open login");	
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifyWorkouts() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyWorkouts()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				fitness.getListofLink(fitness.deshboardFitnessList_gettext);

				Boolean workouts=fitness.Openlinks(fitness.workoutslink);
				if (workouts) {
					fitness.getMultiListofLink(fitness.headworkouts_gettext, fitness.descworkouts_gettext, fitness.daysworkouts_gettext, fitness.levelworkouts_gettext);
					
					Boolean slimfit=fitness.Openlinks(fitness.slimfitlink);
					if (slimfit ) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.Getactualtext(fitness.heading_gettext);
						fitness.getListofLink(fitness.list_gettext);
						fitness.Getactualtext(fitness.steps_gettext);
						
						Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
						s_assert.assertTrue(BackButton, "BackButton is not open"); 

					}
					s_assert.assertTrue(slimfit, "Slim fit is not open"); 
					
					Boolean biceps=fitness.Openlinks(fitness.bicepslink);
					if (biceps ) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.Getactualtext(fitness.heading_gettext);
						fitness.getListofLink(fitness.list_gettext);
						fitness.Getactualtext(fitness.steps_gettext);
						

						Boolean BackButton1=fitness.Openlinks(fitness.BackButton1);
						s_assert.assertTrue(BackButton1, "BackButton1 is not open"); 

					}
					s_assert.assertTrue(biceps, "biceps is not open"); 

					
				}
				s_assert.assertTrue(workouts, "workouts is not open"); 
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 2, description = "")
	public void VerifyExercise_ExerciseTAB() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyExercise()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean exercise=fitness.Openlinks(fitness.exerciselink);
				if (exercise) {
					fitness.Getactualtext(fitness.header_gettext);

					Boolean exercisestab=fitness.Openlinks(fitness.exercisesTAB);
					if (exercisestab) {
						fitness.getListofLink(fitness.fitnessDetailsList_gettext);
						
						Boolean legpress=fitness.Openlinks(fitness.legpresslink);
						if (legpress) {
							fitness.Getactualtext(fitness.header_gettext);
							Boolean next=fitness.Openlinks(fitness.nextbtn);
							if (next) {
								driver.context("NATIVE_APP");
								Boolean videoPlay=fitness.Openlinks(fitness.videoPlaylink);
								if (videoPlay) {
								PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(videoPlay, "video Play is not open"); 
							}
							s_assert.assertTrue(next, "next slid  is not open"); 
							
							Boolean previous=fitness.Openlinks(fitness.previousBtn);
							s_assert.assertTrue(previous, "previous button is not open"); 
							
							fitness.Getactualtext(fitness.header_gettext);
							fitness.Getactualtext(fitness.heading_gettext);
							fitness.getListofLink(fitness.list_gettext);
							fitness.Getactualtext(fitness.steps_gettext);
							
							Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
							s_assert.assertTrue(BackButton, "BackButton is not open"); 
						}
						s_assert.assertTrue(legpress, "leg press is not open"); 

					}
					s_assert.assertTrue(exercisestab, "exercises tab is not open"); 
				}
				s_assert.assertTrue(exercise, "Exercise is not open"); 
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyExercise_EquipmentsTAB() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyExercise_EquipmentsTAB()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean exercise=fitness.Openlinks(fitness.exerciselink);
				if (exercise) {
					fitness.Getactualtext(fitness.header_gettext);

					Boolean equipmentstab=fitness.Openlinks(fitness.EquipmentsTAB);
					if (equipmentstab) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.getListofLink(fitness.EquipmentsDetailsList_gettext);
						
						Boolean bench=fitness.Openlinks(fitness.benchlink);
						if (bench) {
							fitness.Getactualtext(fitness.header_gettext);
							
							Boolean wideGrip=fitness.Openlinks(fitness.wideGriplink);
							if (wideGrip) {
								fitness.Getactualtext(fitness.header_gettext);
								fitness.Getactualtext(fitness.heading_gettext);
								fitness.getListofLink(fitness.list_gettext);
								fitness.Getactualtext(fitness.steps_gettext);
								
								Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
								s_assert.assertTrue(BackButton, "BackButton is not open"); 
							}
							s_assert.assertTrue(wideGrip, "wideGrip link is not open"); 
							
							Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
							s_assert.assertTrue(BackButton, "BackButton2 is not open");
						}
						s_assert.assertTrue(bench, "bench is not open"); 
						
						
						Boolean equipmentstab1=fitness.Openlinks(fitness.EquipmentsTAB);
						if (equipmentstab1) {
						
						Boolean machine=fitness.Openlinks(fitness.machinelink);
						if (machine) {
													
							Boolean legPress=fitness.Openlinks(fitness.legPresslinklink);
							if (legPress) {
								fitness.Getactualtext(fitness.header_gettext);
								fitness.Getactualtext(fitness.heading_gettext);
								fitness.Getactualtext(fitness.steps_gettext);
								
								Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
								s_assert.assertTrue(BackButton, "BackButton is not open"); 
							}
							s_assert.assertTrue(legPress, "legPress link is not open"); 
						}
						s_assert.assertTrue(machine, "machine is not open"); 
						}
						s_assert.assertTrue(equipmentstab1, "equipments tab1 is not open"); 
					}
					s_assert.assertTrue(equipmentstab, "equipments tab is not open"); 
				}
				s_assert.assertTrue(exercise, "Exercise is not open"); 
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 4, description = "")
	public void VerifyExercise_BodyPartsTAB() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyExercise_BodyPartsTAB()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean exercise=fitness.Openlinks(fitness.exerciselink);
				if (exercise) {
					fitness.Getactualtext(fitness.header_gettext);

					Boolean bodyPartstab=fitness.Openlinks(fitness.BodyPartsTAB);
					if (bodyPartstab) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.getListofLink(fitness.BodyPartsDetailsList_gettext);
						
						Boolean glutes=fitness.Openlinks(fitness.gluteslink);
						if (glutes) {
							fitness.Getactualtext(fitness.header_gettext);
							
							Boolean wideGrip=fitness.Openlinks(fitness.wideGriplink);
							if (wideGrip) {
								fitness.Getactualtext(fitness.header_gettext);
								fitness.Getactualtext(fitness.heading_gettext);
								fitness.getListofLink(fitness.list_gettext);
								fitness.Getactualtext(fitness.steps_gettext);
								
								Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
								s_assert.assertTrue(BackButton, "BackButton is not open"); 
							}
							s_assert.assertTrue(wideGrip, "wideGrip link is not open"); 
							
							Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
							s_assert.assertTrue(BackButton, "BackButton1 is not open");
						}
						s_assert.assertTrue(glutes, "glutes is not open");
						
						
						Boolean bodyPartstab1=fitness.Openlinks(fitness.BodyPartsTAB);
						if (bodyPartstab1) {
							
							Boolean thumb=fitness.Openlinks(fitness.thumblinklink);
							if (thumb) {
								fitness.Getactualtext(fitness.header_gettext);
								
								Boolean legpressbodypar=fitness.Openlinks(fitness.legpressbodyparglink);
								if (legpressbodypar) {
									fitness.Getactualtext(fitness.header_gettext);
									fitness.Getactualtext(fitness.heading_gettext);
									fitness.Getactualtext(fitness.steps_gettext);
									
									Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
									s_assert.assertTrue(BackButton, "BackButton is not open"); 
								}
								s_assert.assertTrue(legpressbodypar, "leg press body part link is not open"); 
								
								Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
								s_assert.assertTrue(BackButton, "BackButton1 is not open");
							}
							s_assert.assertTrue(thumb, "thumb is not open");
						
						}
						s_assert.assertTrue(bodyPartstab1, "bodyParts tab1 is not open"); 
						
					}
					s_assert.assertTrue(bodyPartstab, "bodyParts tab is not open"); 
				}
				s_assert.assertTrue(exercise, "Exercise is not open"); 
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 5, description = "")
	public void VerifyDietPlan_BuildMuscleTAB() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDietPlan_BuildMuscleTAB()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean dietPlan=fitness.Openlinks(fitness.dietPlanlink);
				if (dietPlan) {
					fitness.Getactualtext(fitness.header_gettext);
					
					Boolean buildeMuscle=fitness.Openlinks(fitness.buildeMuscleTAB);
					if (buildeMuscle) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.getListofLink(fitness.buildeMuscleDetailsList);
						Boolean perfectDiet=fitness.Openlinks(fitness.perfectDietlink);
						if (perfectDiet) {
							fitness.Getactualtext(fitness.header_gettext);
							fitness.Getactualtext(fitness.headingPerfectDiet_gettext);
							fitness.Getactualtext(fitness.descriptionPerfectDiet_gettext);
							fitness.SwipetopTobottom();
							
							Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
							s_assert.assertTrue(BackButton, "BackButton is not open");
							
							Boolean startWorkout=fitness.Openlinks(fitness.startWorkoutBtn);
							if (startWorkout) {
								Boolean stopWorkout=fitness.Openlinks(fitness.stopWorkoutBtn);
								s_assert.assertTrue(stopWorkout, "stop Workout is not open"); 
							}
							s_assert.assertTrue(startWorkout, "startWorkout is not open"); 
						}
						s_assert.assertTrue(perfectDiet, "perfect Diet is not open"); 
						
					}
					s_assert.assertTrue(buildeMuscle, "builde Muscle TAB is not open"); 
				}
				s_assert.assertTrue(dietPlan, "diet Plan is not open");
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 6, description = "")
	public void VerifyDietPlan_LostFatTAB() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDietPlan_LostFatTAB()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean dietPlan=fitness.Openlinks(fitness.dietPlanlink);
				if (dietPlan) {
					fitness.Getactualtext(fitness.header_gettext);
					
					Boolean lostFat=fitness.Openlinks(fitness.lostFatTAB);
					if (lostFat) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.getListofLink(fitness.lostFatDetailsList);
						Boolean theGetlean=fitness.Openlinks(fitness.theGetleanlink);
						if (theGetlean) {
							fitness.Getactualtext(fitness.header_gettext);
							fitness.Getactualtext(fitness.headingDietPlan_gettext);
							fitness.Getactualtext(fitness.descriptionDietPlan_gettext);
							fitness.Getactualtext(fitness.listDietPlan_gettext);
							
							Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
							s_assert.assertTrue(BackButton, "BackButton is not open"); 
						}
						s_assert.assertTrue(theGetlean, "the Get-lean is not open"); 
					}
					s_assert.assertTrue(lostFat, "lost Fat TAB is not open"); 
				}
				s_assert.assertTrue(dietPlan, "diet Plan is not open");
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 7, description = "")
	public void VerifyDietPlan_TransformTAB() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDietPlan_TransformTAB()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean dietPlan=fitness.Openlinks(fitness.dietPlanlink);
				if (dietPlan) {
					fitness.Getactualtext(fitness.header_gettext);
					
					Boolean transform=fitness.Openlinks(fitness.transformTAB);
					if (transform) {
						fitness.Getactualtext(fitness.header_gettext);
						fitness.getListofLink(fitness.transformDetailsList);
						Boolean theBeginnerMealPlan=fitness.Openlinks(fitness.theBeginnerMealPlanlink);
						if (theBeginnerMealPlan) {
							fitness.Getactualtext(fitness.header_gettext);
							fitness.Getactualtext(fitness.headingtransform_gettext);
							fitness.Getactualtext(fitness.descriptiontransform_gettext);
							fitness.Getactualtext(fitness.listtransform_gettext);
							
							Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
							s_assert.assertTrue(BackButton, "BackButton is not open"); 
						}
						s_assert.assertTrue(theBeginnerMealPlan, "the Beginner Meal Plan is not open"); 
					}
					s_assert.assertTrue(transform, "transform TAB is not open"); 
				}
				s_assert.assertTrue(dietPlan, "diet Plan is not open");
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	

	@Test(priority = 8, description = "")
	public void VerifyBMRCalculator() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyBMRCalculator()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean bmrCalculator=fitness.Openlinks(fitness.bmrCalculatorlink);
				if (bmrCalculator) {
					fitness.Getactualtext(fitness.header_gettext);
					
					Boolean age=fitness.TextField(fitness.ageText, "27");
					s_assert.assertTrue(age, "age is not working");
					
					Boolean height=fitness.TextField(fitness.heightText, "157");
					s_assert.assertTrue(height, "height is not working");
					
					Boolean weight=fitness.TextField(fitness.weightText, "80");
					s_assert.assertTrue(weight, "weight is not working");
					driver.context("NATIVE_APP");
					Boolean gender=fitness.Openlinks(fitness.genderlink);
					if (gender) {
					
						Boolean male=fitness.Openlinks(fitness.maleradiobtn);
						s_assert.assertTrue(male, "male is not open"); 
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(gender, "gender is not open"); 
					
					driver.context("NATIVE_APP");
					Boolean activetylevel=fitness.Openlinks(fitness.activetylevellink);
					if (activetylevel) {
						
						
						Boolean little=fitness.Openlinks(fitness.littleradioBtn);
						s_assert.assertTrue(little, "little is not open"); 
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(activetylevel, "activety level is not open"); 
					
					fitness.Getactualtext(fitness.headingBMR_gettext);
				
					Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
					s_assert.assertTrue(BackButton, "BackButton is not open"); 
				}
				s_assert.assertTrue(bmrCalculator, "diet is not open");
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority = 9, description = "")
	public void VerifyWorkOutRecord() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyWorkOutRecord()");
		boolean exception = false;
		try {
			Boolean openFitnessmodule=fitness.Openlinks(fitness.fitnessModulelink);
			if (openFitnessmodule) {
				fitness.Getactualtext(fitness.header_gettext);

				Boolean menu=fitness.Openlinks(fitness.menulink);
				if (menu) {
					Boolean logintext=fitness.IselementPresent(fitness.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						fitness.login(); 
					}
					else {
						System.out.println("User is already Login");
						fitness.Openlinks(fitness.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	

				Boolean workoutRecord=fitness.Openlinks(fitness.workoutRecordlink);
				if (workoutRecord) {
					fitness.Getactualtext(fitness.header_gettext);
					fitness.getListofLink(fitness.workoutRecordDetailsList);
					
					Boolean BackButton=fitness.Openlinks(fitness.BackButton1);
					s_assert.assertTrue(BackButton, "BackButton is not open");
				}
				s_assert.assertTrue(workoutRecord, "workoutRecord is not open");
			}
			s_assert.assertTrue(openFitnessmodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + fitness.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
}
