package com.appypie.tests.logintests;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.pages.loginpages.AppypieSignUpPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.LoginServiceHandler;
import com.appypie.util.PageElement;

public class AppypieAutoApprovalOffTest extends TestSetup{
	
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieSignUpPage signup;
	AppypieLoginPage login;

	@Override
	@BeforeTest
	public void pageSetUp() {
		signup = new AppypieSignUpPage(driver);
		login = new AppypieLoginPage(driver);
	}

	@Test(groups={"autoapprovaloff"})
	public void verifyAutoApprovalOff() {
		Logger.info("********Test Method Starts: verifyAutoApprovalOff********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			PageElement.changeContextToWebView(driver);
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					signup.enterName();
					signup.entervalidEmail();
					signup.enterPhone();
					signup.enterPassword();
					signup.enterConfirmPassword();
					signup.selectGender();
					signup.enterState();
					signup.selectCountry();
					signup.selectCheckBox();
					signup.enterText();
					signup.selectList();
					signup.clickRadio();
					signup.submitSignUp();
					Thread.sleep(1000);
					String msg= PageElement.getWarningText(driver);
					asser.assertEquals(msg, "Successfully Registered");
					if(msg!=""){
						PageElement.closeWarningSingleBtn(driver, "OK");
						Thread.sleep(500);
					}
					asser.assertTrue(login.isLoginPageOpen(), "login page is not open after resgistering user in autoapproval off mode");
					if(msg.equalsIgnoreCase("Successfully Registered")){
						signup.setUserValue();
					}
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying sign up with autoapproval off functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@BeforeGroups(groups={"autoapprovaloff"})
	public String  autoapprovalPrecondition() {
		String status = "";
		int value=2;
		System.out.println("Before Group for LDAP called");
		List<String> list = new ArrayList<String>();
		list.add("auto_aproval");
		try {
			String response = LoginServiceHandler.getSettingValues(list);
		   
			if (status.toUpperCase().equals("success".toUpperCase())) {
				value = Integer.parseInt(String.valueOf(response.charAt(response.indexOf("auto_aproval\":\"") + 15)));
				if(value!=0){
					TreeMap<String,Integer> map= new TreeMap<String,Integer>();
					map.put("auto_aproval", 0);
				    status = LoginServiceHandler.updateUserSetting(map);	
				    driver.resetApp();
				    driver.context("NATIVE_APP");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	@AfterGroups(groups={"autoapprovaloff"})
	public void ldapPostCondition(){
		try{
			TreeMap<String,Integer> map= new TreeMap<String,Integer>();
			map.put("auto_aproval", 1);
		    LoginServiceHandler.updateUserSetting(map);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}
