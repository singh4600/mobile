package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieTodoListPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppyPieTodoListPageTest extends TestSetup{

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieTodoListPage todo;
	PageElement page;




	@BeforeTest
	@Override
	public void pageSetUp() {

		todo = new AppypieTodoListPage(driver);
		page = new PageElement();
	}

	@Test
	public void verifyTodoListPage_Open_Close(){
		Logger.info("Test Methods start: Todo List Page open");
		asser= new SoftAssert();
		boolean todoList = false;

		try {

			Boolean openPage= todo.clickableLinks(todo.pagelink);
			asser.assertTrue(openPage, "Todo List page not clickable or not open in the flow of main menu");

			Boolean todoheader = todo.isTodoListOpen();
			asser.assertNotNull(todoheader, "Header is getting null value");

			if (todoheader) {
				String Todo_pagelist = todo.printAvailableText(todo.pageList);
				asser.assertNotNull(Todo_pagelist, "Todo list page getting null value");

			} else {
				Logger.info("Todo list page not open in app");
			}

			asser.assertFalse(PageElement.tapCEBackButton(driver),"Back button not working on Todo list Page."); 

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			todoList = true;
			asser.assertFalse(todoList, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}

	@Test
	public void verifyTodoListContents(){
		Logger.info("Test Methods start: Todo List Page Contents");
		asser= new SoftAssert();
		boolean content = false;

		try {

			Boolean openPage= todo.clickableLinks(todo.pagelink);
			asser.assertTrue(openPage, "Todo List page not clickable or not open in the flow of main menu");

			Boolean shimla= todo.clickableLinks(todo.shimlaTrip);
			asser.assertTrue(shimla, "Shimla trip not clickable on app");

			Boolean back_shimla= todo.clickableLinks(todo.backButton);
			asser.assertTrue(back_shimla, "Back button not working on shimla trip page");

			Boolean shimlaAgain= todo.clickableLinks(todo.shimlaTrip);
			asser.assertTrue(shimlaAgain, "Shimla trip not clickable on app");

			if (shimla) {
				String header= todo.printAvailableText(todo.header);
				asser.assertEquals(header, "SHIMLA TRIP");

				String trip_Header= todo.printAvailableText(todo.tripHeading);
				asser.assertEquals(trip_Header, "Trip Highlights");

				String trip_details= todo.printAvailableText(todo.tripContent);
				asser.assertNotNull(trip_details, "Trip Highlights");

				Boolean day1= todo.clickableLinks(todo.selectCheckBox);
				asser.assertTrue(day1, "Checkbox not working on shimla trip for Day 1");
				Thread.sleep(2000);

				Boolean coment= todo.verifyCommentBox();

				Logger.info(coment);
				Boolean comentboxOpenonapp= todo.isCommentsBoxOpen();
				if (comentboxOpenonapp) {
					String comentboxheader= todo.printAvailableText(todo.popup_Heading);
					asser.assertEquals(comentboxheader, "Add Note");


					if (comentboxheader!=null) {

						Boolean okButton= todo.clickableLinks(todo.ok);
						asser.assertTrue(okButton, "OK button not clickable on comment box");

						String blankAlert= todo.printAvailableText(todo.alertText);
						asser.assertEquals(blankAlert, "Please enter note text!");

						Boolean okAlert= PageElement.verifyAlert_Ok();
						asser.assertTrue(okAlert, "OK button not clickable on comment box");

						Boolean crossButton = todo.clickableLinks(todo.infoCancel);
						asser.assertTrue(crossButton, "OK button not clickable on comment box");

					}

					else
					{
						Logger.info("Alert popup not showing on app");
					}


					Boolean comentA= todo.clickableLinks(todo.editBox);
					asser.assertTrue(comentA, "Comments box not clickale on Shimla trip page2");

					Boolean comentboxOpenA= todo.isCommentsBoxOpen();
					asser.assertTrue(comentboxOpenA, "Comments box not clickale on Shimla trip page3");
					if (comentboxOpenA) {

						Boolean textOnCommentBox = todo.verifyCommentText();
						asser.assertTrue(textOnCommentBox, "Text area not clieckable");

						Boolean okAlert= todo.clickableLinks(todo.ok);
						asser.assertTrue(okAlert, "OK button not clickable on comment box");

					} 
					else
					{
						System.out.println("Comment box not showing on app");
					}

				}

				else 
				{
					Logger.info("User already added comments");
				}
				Thread.sleep(2000);
				
				Boolean selectedCommentsBox=todo.usersComments();
				if (selectedCommentsBox) {
					
					Boolean commentBox=todo.clickableLinks(todo.commentBox);
					asser.assertTrue(commentBox, "Comment Box not clickable on app");
					
				String availableText=todo.verifyCommentWrittenText();
				asser.assertEquals(availableText, "Done");
				
				Boolean okButton= todo.clickableLinks(todo.ok);
				asser.assertTrue(okButton, "OK button not clickable on comment box");
				
				Boolean resetButton= todo.clickableLinks(todo.reset);
				asser.assertTrue(resetButton, "OK button not clickable on comment box");
					
				} else {
					
					Logger.info("User had not added comments for this task");

				}
				
			
			
			} else {
				Logger.info("Shimla Trip page not open in app");
			}

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			content = true;
			asser.assertFalse(content, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}

	
	@Test
	public void verifyFitness(){
		Logger.info("Test Methods start: Todo List Page open");
		asser= new SoftAssert();
		boolean fitness = false;

		try {

			Boolean openPage= todo.clickableLinks(todo.pagelink);
			asser.assertTrue(openPage, "Todo List page not clickable or not open in the flow of main menu");

			Boolean todoheader = todo.isTodoListOpen();
			asser.assertNotNull(todoheader, "Header is getting null value");

			if (todoheader) {
				
				Boolean fitnes= todo.clickableLinks(todo.fitness);
				asser.assertTrue(fitnes, "Fitness link not clickable on app");
				
				String header= todo.printAvailableText(todo.header);
				asser.assertEquals(header, "Fitness");

				String trip_Header= todo.printAvailableText(todo.tripHeading);
				asser.assertEquals(trip_Header, "Get Ready to Fit");

				String trip_details= todo.printAvailableText(todo.tripContent);
				asser.assertNotNull(trip_details, "Trip Highlights");
				
			} else {
				Logger.info("Todo list page not open in app");
			}

		
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			fitness = true;
			asser.assertFalse(fitness, "\n" + PageElement.printExceptionTrace(e));
		}

		asser.assertAll();
	}
	
	
	
}
