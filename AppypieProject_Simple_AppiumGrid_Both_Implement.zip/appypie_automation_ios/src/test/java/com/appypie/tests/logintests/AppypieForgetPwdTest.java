package com.appypie.tests.logintests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.loginpages.AppypieForgetPwdPage;
import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.pages.loginpages.AppypieSignUpPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieForgetPwdTest extends TestSetup {
	
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieSignUpPage signup;
	AppypieLoginPage login;
	AppypieForgetPwdPage forgetpwd;
	String resetWarning="System generated password has been sent to pawan@onsinteractive.com";

	@Override
	@BeforeTest
	public void pageSetUp() {
		signup = new AppypieSignUpPage(driver);
		login = new AppypieLoginPage(driver);
		forgetpwd= new AppypieForgetPwdPage(driver);
	}
	
	@Test
	public void verifyForgetPwdFunctionality() {
		Logger.info("********Test Method Starts: verifyForgetPwdFunctionality********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openforgetPwdPage();
				boolean pageOpen = forgetpwd.isForgetPwdPageOpen();
				asser.assertTrue(pageOpen, "Forget Password page is not open");
				if (pageOpen) {
					
					// Reset pwd with blank email id 
					forgetpwd.submitResetPwd();
					String warning_blank=PageElement.getWarningText(driver);
					asser.assertEquals(warning_blank, "Mandatory fields can't be left blank");
					if(warning_blank!=""){
					   PageElement.closeWarningSingleBtn(driver, "OK");
					}
					
					// Reset Pwd with Wrong email id
					forgetpwd.resetPwd("aa@aa.com");
					forgetpwd.submitResetPwd();
					String warning = PageElement.getWarningText(driver);
					asser.assertEquals(warning, "This account doesn't exist");
					if (warning != "") {
						PageElement.closeWarningSingleBtn(driver, "OK");
					}
					
					// reset pwd with valid account name
					forgetpwd.resetPwd("pawan@onsinteractive.com");
					forgetpwd.submitResetPwd();
					asser.assertEquals(PageElement.getWarningText(driver), resetWarning);
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying forget pwd functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
