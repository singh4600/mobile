package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMapPage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieMapTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieMapPage map;
	AppypieMenuPage menu;

	@Override
	@BeforeTest
	public void pageSetUp() {
		map = new AppypieMapPage(driver);
		menu = new AppypieMenuPage(driver);
	}

	@Test
	public void verifyMapPageandBackbtn() {
		Logger.info("Test Methods start: verifyMapPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("map");
			boolean pageOpen = map.isMapPageOpen();
			asser.assertTrue(pageOpen, "Map page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from Map page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Map Page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyGetDirectionOption() {
		Logger.info("Test Methods start: verifyGetDirectionOption");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("map");
			boolean pageOpen = map.isMapPageOpen();
			asser.assertTrue(pageOpen, "Map page is not open");
			if (pageOpen) {
				map.clickLocation();
				boolean popUp = map.isPopUpDisplayed();
				asser.assertTrue(popUp, "map options pop up is not displayed");
				if (popUp) {
					map.clickOptions("Get Directions");
					asser.assertTrue(map.isMapOptionsOpenInNative("direction"), "Get Direction option is not working");
					boolean mapOpenagain = map.isMapPageOpen();
					asser.assertTrue(mapOpenagain, "back from directions is not working");
					if (!mapOpenagain) {
						PageElement.backFromNaitvePage(driver);
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying getdirection option ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyShowMapOption() {
		Logger.info("Test Methods start: verifyShowMapOption");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("map");
			boolean pageOpen = map.isMapPageOpen();
			asser.assertTrue(pageOpen, "Map page is not open");
			if (pageOpen) {
				map.clickLocation();
				boolean popUp = map.isPopUpDisplayed();
				asser.assertTrue(popUp, "map options pop up is not displayed");
				if (popUp) {
					Thread.sleep(2000);
					map.clickOptions("Show Map");
					asser.assertTrue(map.isMapOptionsOpenInNative("location"), "Show map option is not working");
					boolean mapOpenagain = map.isMapPageOpen();
					asser.assertTrue(mapOpenagain, "back from map is not working");
					if (!mapOpenagain) {
						PageElement.backFromNaitvePage(driver);
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying show map option ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyShareLocation() {
		Logger.info("Test Methods start: verifyShareLocation");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("map");
			boolean pageOpen = map.isMapPageOpen();
			asser.assertTrue(pageOpen, "Map page is not open");
			if (pageOpen) {
				map.clickLocation();
				boolean popUp = map.isPopUpDisplayed();
				asser.assertTrue(popUp, "map options pop up is not displayed");
				if (popUp) {
					map.clickOptions("Share Location");
					asser.assertTrue(PageElement.checkSharePopUp(driver), "Share Location option is not working");
					boolean mapOpenagain = map.isMapPageOpen();
					asser.assertTrue(mapOpenagain, "back from share Option is not working");
					if (!mapOpenagain) {
						PageElement.backFromNaitvePage(driver);
					}	
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying share location and cancel ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
