package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieEreaderPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieEreaderTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieEreaderPage ereader;

	@Override
	@BeforeTest
	public void pageSetUp() {
		ereader = new AppypieEreaderPage(driver);
	}

	@Test
	public void verifyEreaderPageandBackbtn() {
		Logger.info("Test Methods start: verifyEreaderPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			ereader.openEreaderFolder();
			boolean folderOpen = ereader.isEreaderFolderOpen();
			asser.assertTrue(folderOpen, "Ereader Folder from main menu is not open");
			if (folderOpen) {
				ereader.openEreaderPage("inside");
				boolean pageOpen = ereader.isEreaderPageOpen();
				asser.assertTrue(pageOpen, "ereader page is not open");
				if (pageOpen) {
					PageElement.tapBackButton(driver);
					Thread.sleep(1000);
					asser.assertTrue(ereader.isEreaderFolderOpen(), "Back Button from ereader page is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the ereader page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyUploadedPdfFile() {
		Logger.info("Test Methods start: verifyUploadedPdfFile");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			ereader.openEreaderFolder();
			boolean folderOpen = ereader.isEreaderFolderOpen();
			asser.assertTrue(folderOpen, "Ereader Folder from main menu is not open");
			if (folderOpen) {
				ereader.openEreaderPage("inside");
				boolean pageOpen = ereader.isEreaderPageOpen();
				asser.assertTrue(pageOpen, "ereader page is not open");
				if (pageOpen) {
					ereader.openFile("E-Book name");
					asser.assertTrue(ereader.isFileOpenInNative("pdf"), "file named pdf1 is not open in native");
					Thread.sleep(1000);
					boolean pageOpenAgain = ereader.isEreaderPageOpen();
					asser.assertTrue(pageOpenAgain, "back from pdf1 native hasn't worked");
					if (pageOpenAgain) {
						ereader.openFile("Pdf");
						asser.assertTrue(ereader.isFileOpenInNative("pdf"), "file named Pdf is not open in native");
						Thread.sleep(1000);
						if (!ereader.isEreaderPageOpen()) {
							PageElement.backFromNaitvePage(driver);
						}
					} else {
						PageElement.backFromNaitvePage(driver);
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the pdf file in native", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyEpubFile() {
		Logger.info("Test Methods start: verifyEpubFile");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			ereader.openEreaderFolder();
			boolean folderOpen = ereader.isEreaderFolderOpen();
			asser.assertTrue(folderOpen, "Ereader Folder from main menu is not open");
			if (folderOpen) {
				ereader.openEreaderPage("outside");
				boolean pageOpen = ereader.isEreaderPageOpen();
				asser.assertTrue(pageOpen, "ereader page is not open");
				if (pageOpen) {
					ereader.openFile("epuburl");
					asser.assertTrue(ereader.isFileOpenInNative("epub"), "epub file is not open in native");
					Thread.sleep(1000);
					if (!ereader.isEreaderPageOpen()) {
						PageElement.backFromNaitvePage(driver);
					}
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the epub file in native ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
