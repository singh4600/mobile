package com.appypie.tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMapPage;
import com.appypie.pages.directoryHyperLocalpages.AddListingPage;
import com.appypie.pages.directoryHyperLocalpages.AppHomePage;
import com.appypie.pages.directoryHyperLocalpages.BookMarkPage;
import com.appypie.pages.directoryHyperLocalpages.CheckInPage;
import com.appypie.pages.directoryHyperLocalpages.DirectoryCouponPage;
import com.appypie.pages.directoryHyperLocalpages.DirectoryLoginPage;
import com.appypie.pages.directoryHyperLocalpages.DirectoryMainMenuPage;
import com.appypie.pages.directoryHyperLocalpages.EnquiryFormPage;
import com.appypie.pages.directoryHyperLocalpages.FilterIconPage;
import com.appypie.pages.directoryHyperLocalpages.FilterResultPage;
import com.appypie.pages.directoryHyperLocalpages.HomePage;
import com.appypie.pages.directoryHyperLocalpages.ListingDetailPage;
import com.appypie.pages.directoryHyperLocalpages.LocationPage;
import com.appypie.pages.directoryHyperLocalpages.LoyaltyCardPage;
import com.appypie.pages.directoryHyperLocalpages.ProfilePage;
import com.appypie.pages.directoryHyperLocalpages.RatingAndReviewPage;
import com.appypie.pages.directoryHyperLocalpages.SubCategoryAndListingPage;
import com.appypie.pages.directoryHyperLocalpages.UpdateListingPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.CommanClass;
import com.appypie.util.ElementWait;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

public class AppypieDirectoryTest extends TestSetup {

	private static final Logger Logger = Log.createLogger();

	HomePage home;
	AddListingPage addlist;
	CheckInPage checkIn;
	AppHomePage appMenu;
	DirectoryMainMenuPage mainMenu;
	FilterIconPage filter;
	LocationPage loc;
	ProfilePage profile;
	RatingAndReviewPage rate;
	SubCategoryAndListingPage subCat;
	DirectoryLoginPage login;
	FilterResultPage result;
	ListingDetailPage listDetail;
	BookMarkPage bookmark;
	UpdateListingPage updateList;
	EnquiryFormPage enquiry;
	DirectoryCouponPage coupon;
	LoyaltyCardPage loyality;

	SoftAssert asser;
	String postlistmsg = "LISTING HAS BEEN SUBMITTED SUCCESSFULLY";
	String duplicate_list= "Error in submitting the listing, heading already exists.";

	@BeforeTest
	@Override
	public void pageSetUp() {
		home = new HomePage(driver);
		addlist = new AddListingPage(driver);
		checkIn = new CheckInPage(driver);
		appMenu = new AppHomePage(driver);
		mainMenu = new DirectoryMainMenuPage(driver);
		filter = new FilterIconPage(driver);
		loc = new LocationPage(driver);
		profile = new ProfilePage(driver);
		rate = new RatingAndReviewPage(driver);
		subCat = new SubCategoryAndListingPage(driver);
		login = new DirectoryLoginPage(driver);
		result = new FilterResultPage(driver);
		listDetail = new ListingDetailPage(driver);
		bookmark = new BookMarkPage(driver);
		updateList = new UpdateListingPage(driver);
		enquiry = new EnquiryFormPage(driver);
		coupon= new DirectoryCouponPage(driver);
		loyality= new LoyaltyCardPage(driver);
	}

	
	@Test
	public void verifyaddListingPageFields() {
		Logger.info("********Test Methods start: verifyaddListingPageFields********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			boolean Click_hyperlocal =appMenu.openDirectoryPage();;
			Thread.sleep(2000);
			asser.assertTrue(Click_hyperlocal,"Directory Page not clikable");
			home.openPageMenu("dir");
			boolean menuOpen = mainMenu.isMainMenuOpen("directory");
			if (menuOpen) {
				boolean login = verifyDirectoryLogin("dir");
				if (login) {
					mainMenu.clickAddListing();
					Boolean listingPageOpen = addlist.isAddListingPageOpen();
					if (listingPageOpen) {
						// ****** verification of image upload in addlist******
						asser.assertTrue(addlist.imageUploadinAddListing(),
								"image upload in addlisting form is not working");

						// ****** verification of Youtube Video upload in addlist******
						asser.assertTrue(addlist.isYoutubeVideoUploadWorking(),
								"upload youtube video in addlisting form is not working");

						// ****** verification of MediaRSS audio upload in addlist******
						addlist.clickAudioinListing();
						addlist.clickMediaRssinListing();
						asser.assertTrue(addlist.isMediaRssUrlHolderFieldExist(),"MediaRssUrl upload field is not exist in addlisting form");

						// ****** verification of RadioPLS audio upload in addlist******
						addlist.clickRadioPlsinListing();
						asser.assertTrue(addlist.isRadioPlsUrlHolderFieldExist(),"RadioPls upload field is not exist in addlisting form");

						// ****** verification of custom audio upload in addlist******
						addlist.clickcustomAudioinListing();
						asser.assertTrue(addlist.isCustomUrlHolderFieldsExist(),"Custom audio upload fields are not exist in addlisting form");

						// ****** verification of pdf upload in addlist******
						addlist.clickUploadPdfinListing();
						asser.assertTrue(addlist.isPDFHolderFieldsExist(),"PDF upload fields are not exist in addlisting form");
						addlist.clickAddMoreInPdf();
						asser.assertTrue(addlist.isSecondpdfHolderFieldExist(),"Add more button in uploadpdf is not working");
						addlist.clickCloseAddMoreInPdf();
						asser.assertFalse(addlist.isSecondpdfHolderFieldExist(),"close more in upload PDF is not working");

						// ****** verification of URL in addlist******
						addlist.clickAddMoreInUrl();
						asser.assertTrue((boolean)addlist.isSecondUrlFieldExist().get(0), "add more in URL is not working");
						asser.assertEquals((String)addlist.isSecondUrlFieldExist().get(1).toString().toUpperCase(), "url".toUpperCase(),"placeholder value of second field is not correct");
						Thread.sleep(2000);
						
						addlist.scrollDown();
						Thread.sleep(2000);
						addlist.clickCloseAddMoreInUrl();
						asser.assertTrue(addlist.getElementCount("url")==1, "close more in URL is not working");

						// ****** verification of Email in addlist******
						addlist.clickAddMoreInEmail();
						asser.assertTrue((boolean)addlist.isSecondEmailFieldExist().get(0), "add more in email is not working");
						asser.assertEquals((String)addlist.isSecondEmailFieldExist().get(1).toString().toUpperCase(), "email".toUpperCase(),"placeholder value of second field is not correct");
						addlist.clickCloseAddMoreInEmail();
						asser.assertTrue(addlist.getElementCount("email")==1, "close more in Email is not working");

						// ****** verification of Phonenumber in addlist******
						addlist.clickAddMoreInPhoneNo();
						asser.assertTrue((boolean)addlist.isSecondPhoneNoFieldExist().get(0), "add more in phone is not working");
						asser.assertEquals((String)addlist.isSecondPhoneNoFieldExist().get(1).toString().toUpperCase(), "phone".toUpperCase(),"placeholder value of second field is not correct");
						addlist.clickCloseAddMoreInPhoneno();
						asser.assertTrue(addlist.getElementCount("phone")==1, "close more in phoneno is not working");

					} else {
						Logger.info("addListing page is not open upon clicking from directory main menu");
						asser.assertTrue(listingPageOpen, "addListing page is not open");
					}
				} else {
					Logger.info("Directory login is not successfull");
					asser.assertTrue(login, "Directory login is not successful");
				}
			} else {
				Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
				asser.assertTrue(menuOpen, "Directory menu is not open");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the add listing page in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}


	@Test
	public void verifyaddListingFunctionality() {
		Logger.info("********Test Methods start: verifyaddListingFunctionality********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openPageMenu("dir");
			boolean menuOpen = mainMenu.isMainMenuOpen("directory");
			if (menuOpen) {
				
				boolean login = verifyDirectoryLogin("dir");
				if (login) {
					
					mainMenu.clickAddListing();
					Boolean listingPageOpen = addlist.isAddListingPageOpen();
					if (listingPageOpen) {
						
						// ****** verification of submission of blankForm******
						addlist.submitaddListForm();
						String blankForm_text = PageElement.getWarningText(driver);
						asser.assertEquals(blankForm_text, "Please select a category");
						if (blankForm_text != "")
							PageElement.closeWarningSingleBtn(driver,"Ok");
						Thread.sleep(1000);

						// ****** verification of submission of form without mandatory fields******
						addlist.selectCategory();
						Thread.sleep(2000);
						addlist.submitaddListForm();
						String text = PageElement.getWarningText(driver);
						asser.assertEquals(text, "Please enter the heading",
								"list is not added or taking too much time:");
						if (text != "")
							PageElement.closeWarningSingleBtn(driver,"Ok");
						Thread.sleep(1000);

						// ****** verification of submission of addlisting form******
						addlist.fillFormforAddCategory();
						addlist.submitaddListForm();
						String msg=PageElement.getWarningTitle(driver).get(0).toString();
						if(msg.toUpperCase().contains(duplicate_list.toUpperCase())){
							asser.assertEquals(msg.toUpperCase(), duplicate_list.toUpperCase());
							PageElement.closeWarningSingleBtn(driver,"Ok");
						}else{
							asser.assertEquals(PageElement.getWarningText(driver).toUpperCase(),postlistmsg.toUpperCase());
						PageElement.closeWarningSingleBtn(driver,"Ok");
						}
					} else {
						Logger.info("addListing page is not open upon clicking from directory main menu");
						asser.assertTrue(listingPageOpen, "addListing page is not open");
					}
				} else {
					Logger.info("Directory login is not successfull");
					asser.assertTrue(login, "Directory login is not successful");
				}
			} else {
				Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
				asser.assertTrue(menuOpen, "Directory menu is not open");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the add listing page in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	public boolean verifyDirectoryLogin(String page) {
		boolean success = false;
		try {
			if (!mainMenu.isDirectoryLogin()) {
				mainMenu.clickDirectoryLogin();
				boolean loginPageOpen = login.isDirectoryLoginOpen();
				if (loginPageOpen) {
					
					login.loginDirectory("pk@pk.com", "12345678");
					if (login.isLoginSuccess()) {
						success = true;
						Thread.sleep(2000);
						home.openPageMenu(page);
						Thread.sleep(2000);
					}
				} else {
					Logger.info("login page is not open upon clicking on login from menu");
				}
			} else {
				Logger.info("User is already login in the app");
				success = true;
			}

		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the Directory login", ex);
		}
		return success;
	}

	@Test
	public void verifyDistanceFilterFunctionalities() {
		Logger.info("********Test Methods start: verifyDistanceFilterFunctionalities********");
		asser = new SoftAssert();
		boolean exception = false;
		int x=0;
		int y=0;
		int backX=0;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.clickFilterIcon();
			boolean filterPageOpen = filter.isFilterPageOpenDirectory();
			if (filterPageOpen) {
				// *************verify forward movement of Distance Slider***********
				String frange = filter.getRangeValue("dir");
				driver.context("NATIVE_APP");
				Dimension size = driver.manage().window().getSize();
				Logger.info("width of the page " + size.width);
				if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
					x = (int) (size.width * .7407);
					y = (int) (size.width * .6481);
					backX = (int) (size.width * .5555);
				} else {
					x = (int) (size.width * .52);
					y = (int) (size.width * .54);
					backX = (int) (size.width * .40);
				}
				PageElement.changeContextToWebView(driver);
				filter.moveDistanceSlider("dir", x, y);
				Thread.sleep(3000);
				String fnewRange = filter.getRangeValue("dir");
				asser.assertTrue(filter.getNumeralRange(fnewRange) >= filter.getNumeralRange(frange),
						"Distance is not increased with moving distance slider forward");

				// *************verify Backward movement of Distance Slider***********
				String brange = filter.getRangeValue("dir");
				filter.moveDistanceSlider("dir", backX, y);
				Thread.sleep(2000);
				String bnewRange = filter.getRangeValue("dir");
				asser.assertTrue(filter.getNumeralRange(bnewRange) <= filter.getNumeralRange(brange),
						"Distance is not Decreased with moving distance slider backward");

				// *************verify KM Button***********
				filter.clickKm();
				asser.assertTrue(filter.getRangeValue("dir").contains("KM"), "KM button is not chnaging range into KM");

				// *************verify Miles Button***********
				filter.clickMiles();
				asser.assertTrue(filter.getRangeValue("dir").contains("Miles"),
						"Miles button is not chnaging range into Miles");

				// *************verify Distance Search***********
				filter.clickSearch("distance");
				asser.assertTrue(result.isFilterResultPageOpen().get(0) || result.isFilterResultPageOpen().get(1),
						"Filter result page is not open from distance search in directory");
			} else {
				Logger.info("Filter page is not open from directory home page");
				asser.assertTrue(filterPageOpen, "Filter page is not open from directory home page");
			}

		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying the distance filter functionalities in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	
	
	
	
	
	
	@Test
	public void verifyRatingFilterFunctionalities() {
		Logger.info("********Test Methods start: verifyRatigFilterFunctionalities********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			boolean Click_directory =appMenu.openDirectoryPage();
			Thread.sleep(2000);
			asser.assertTrue(Click_directory,"Directory Page not clikable");
			home.clickFilterIcon();
			boolean filterPageOpen = filter.isFilterPageOpenDirectory();
			if (filterPageOpen) {
				filter.openRatingTab();
				boolean ratingTabOpen = filter.isRatingTabOpen();
				if (ratingTabOpen) {
					// *************verify search without select
					// rating***********
					filter.clickSearch("rating");
					asser.assertEquals(PageElement.getWarningText(driver), "Please rate before posting the review");
					PageElement.closeWarningSingleBtn(driver,"Ok");
					Thread.sleep(1000);

					// *************verify search with rating***********
					filter.clickRating(filter.starCheckbox);
					filter.clickRating(filter.starCheckbox1);
					filter.clickRating(filter.starCheckbox2);
					
					filter.clickSearch("rating");
					List<Boolean> filterResultOpen = result.isFilterResultPageOpen();
					Logger.info(filterResultOpen.get(0) + ": : " + filterResultOpen.get(1));
					asser.assertTrue(filterResultOpen.get(0) || filterResultOpen.get(1),
							"Filter result page is not open from Rating search in directory");

					
					// *************verify Filter Result Page***********
					if (filterResultOpen.get(0)) {
						Thread.sleep(1000);
						result.clickOnLocation();
						asser.assertTrue(result.isMapOpen("Filter Results"),
								"Google map is not open from filter result page in directory");
					} else {
						Logger.info("No data icon is visible on filter result page");
					}
				} else {
					Logger.info("Rating tab is not open from directory filter page");
					asser.assertTrue(ratingTabOpen, "Rating tab is not open from directory filter page");
				}
			} else {
				Logger.info("Filter page is not open from directory home page");
				asser.assertTrue(filterPageOpen, "Filter page is not open from directory home page");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying the rating filter functionalities in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	@Test
	public void verifyBookmark() {
		Logger.info("********Test Methods start: verifyBookmark********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openCategoryfromMainList("dir");
			boolean catOpen = subCat.isSubCategoryPageOpenDirectory();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("dir");
				if (listing) {
					subCat.openListing("dir");
					boolean listPageOpen = listDetail.isListingDetailPageOpen();
					if (listPageOpen) {
						listDetail.bookMarkList();
						Thread.sleep(500);
						PageElement.verifyAlert_Ok();
						Thread.sleep(500);
						PageElement.tapBackButtonP(driver);
						Thread.sleep(500);
						PageElement.tapBackButtonP(driver);
						Thread.sleep(500);
						home.openPageMenu("dir");
						boolean menuOpen = mainMenu.isMainMenuOpen("directory");
						if (menuOpen) {
							mainMenu.clickBookmark("dir");
							boolean bookmarkList = bookmark.isBookMarkedListExist("dir");
							if (bookmarkList) {
								bookmark.openBookMarkList("dir");
								asser.assertTrue(bookmark.islistingOpenFromBookMarkPage("dir"),
										"listing detail is not open from bookmark list");
								PageElement.tapBackButtonP(driver);
								Thread.sleep(1000);

								// **********delete bookmark icon on list**********
								bookmark.clickBookMarkIcon();
								String bookmark_text = PageElement.getWarningText(driver);
								asser.assertEquals(bookmark_text, "Do you want to remove the bookmark?",
										"delete bookmark icon is not working");
								if (bookmark_text != "") {
									bookmark.clickDeleteBookMark();
								}
								asser.assertTrue(home.isHomePageOpenDirectory(),
										"home page is not open after deleting bookmark list");
							} else {
								Logger.info("Bookmark list is not present: Bookmark option is not working");
								asser.assertTrue(bookmarkList,
										"Bookmark list is not present: Bookmark option is not working");
							}
						} else {
							Logger.info(
									"Directory menu is not open upon clicking on menu button from directory home page");
							asser.assertTrue(menuOpen, "Directory menu is not open");
						}
					} else {
						Logger.info("listing page is not open");
						asser.assertTrue(listPageOpen, "listing page is not open");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Directory category is not open from home page");
				asser.assertTrue(catOpen, "Directory Category is not open");
			}

		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying bookmark functionalities in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyHomeandMainMenuinDirectoryMenu() {
		Logger.info("********Test Methods start: verifyHomeandMainMenuinDirectoryMenu********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openPageMenu("dir");
			boolean menuOpen = mainMenu.isMainMenuOpen("directory");
			if (menuOpen) {
				mainMenu.clickMainMenu();
				asser.assertTrue(home.isHomePageOpenDirectory(),
						"Home page is not open upon clicking on main menu from directory menu");
//				Thread.sleep(1000);
//				home.openPageMenu("dir");
//				mainMenu.clickHome();
//				asser.assertTrue(appMenu.isDirectoryExist(), "Directory Home is not working in Directory menu");
			} else {
				Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
				asser.assertTrue(menuOpen, "Directory menu is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying home and menu button from directory main menu in directory",ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyProfileUpdateFeature() {
		Logger.info("********Test Methods start: verifyProfileUpdateFeature********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openPageMenu("dir");
			boolean menuOpen = mainMenu.isMainMenuOpen("directory");
			if (menuOpen) {
				boolean login = verifyDirectoryLogin("dir");
				if (login) {
					mainMenu.clickUpdateProfile();
					boolean profilePageOpen = profile.isProfilePageOpen();
					if (profilePageOpen) {
						// ******* verify profile update from update profile  button
						profile.updateImage();
						List<Object> text = PageElement.getWarningTitle(driver);
						asser.assertEquals((String) text.get(0), "Click here to upload image(s)");
						if ((boolean) text.get(1)) {
							profile.cancelUploadPopup();
						}
						profile.editProfileName("TestName");
						profile.saveProfile();
						String profile_warning = PageElement.getWarningText(driver);
						asser.assertEquals(profile_warning, "Profile updated successfully");
						if (profile_warning != "") {
							PageElement.closeWarningSingleBtn(driver,"Ok");
						}
						Thread.sleep(1000);
						asser.assertEquals(profile.getProfileName(), "TestName", "Profile name is not updated");
						profile.backOnProfilePage();
						Thread.sleep(1000);

						// ****** verify profile update from image upload*******
						home.openPageMenu("dir");
						mainMenu.clickUpdateImage();
						asser.assertTrue(profile.isProfilePageOpen(),
								"profile image is not clickable from directory main menu");
					} else {
						Logger.info("profile page is not open from main menu");
						asser.assertTrue(profilePageOpen, "profile page is not open from main menu");
					}
				} else {
					Logger.info("Directory login is not successfull");
					asser.assertTrue(login, "Directory login is not successful");
				}
			} else {
				Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
				asser.assertTrue(menuOpen, "Directory menu is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying the update profile feature from main menu", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test(dependsOnMethods = { "verifyaddListingFunctionality" }, alwaysRun = true)
	public void verifyUpdateListingPage() {
		Logger.info("********Test Methods start: verifyUpdateListingPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openPageMenu("dir");
			boolean menuOpen = mainMenu.isMainMenuOpen("directory");
			if (menuOpen) {
				boolean login = verifyDirectoryLogin("dir");
				if (login) {
					// *** verification of update list open from main menu****
					mainMenu.clickUpdateListing();
					List<Boolean> updateListOpen = updateList.isUpdateListingPageOpen("dir");
					asser.assertTrue(updateListOpen.get(0) || updateListOpen.get(1),
							"update list page is not open from main menu");

					// *** verification of recently added list in update list****
					if (updateListOpen.get(0)) {
						asser.assertEquals(updateList.getListHeading(), "AutomationTest",
								"recently added listing is not found in update listing");

						// *** verification of update listing****
						updateList.clickList("dir");
						boolean addListOpen = addlist.isAddListingPageOpen();
						if (addListOpen) {
							updateList.updateListHeading();
							addlist.clickAudioinListing();
							updateList.submitUpdateListForm("dir");
							asser.assertEquals(PageElement.getWarningText(driver).toUpperCase(),
									postlistmsg.toUpperCase());
							PageElement.closeWarningSingleBtn(driver,"Ok");
							Thread.sleep(1000);
							List<Boolean> updateListOpenagain = updateList.isUpdateListingPageOpen("dir");
							if (updateListOpenagain.get(0)) {
								PageElement.tapBackButton(driver);
								Thread.sleep(1000);
								home.openPageMenu("dir");
								Thread.sleep(2000);
								mainMenu.clickUpdateListing();
								asser.assertEquals(updateList.getListSummary(), "UpdateSummary", "List is not updated");

								// *** verification of delete listing****
								updateList.deleteListing("dir");
								asser.assertEquals(PageElement.getWarningText(driver), "Are you sure you want to delete this record?",
										"Delete list poppup doesn't appear");
								Thread.sleep(2000);
								updateList.clickDeleteButtonOnPopup();
								Thread.sleep(1000);
								asser.assertTrue(home.isHomePageOpenDirectory(),
										"Directory home page is not open after deleting the list");
							} else {
								Logger.info("update list page is not open again after updating the list");
								asser.assertTrue(updateListOpenagain.get(0),
										"update list page is not open again after update the list");
							}
						} else {
							Logger.info("listing update is not working while updating from update list in main menu");
							asser.assertTrue(addListOpen, "addlist page is not open from update list");
						}
					} else {
						Logger.info("No listing is present for update: NO data icon is visible ");
					}    
				} else {
					Logger.info("Directory login is not successfull");
					asser.assertTrue(login, "Directory login is not successful");
				}
			} else {
				Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
				asser.assertTrue(menuOpen, "Directory menu is not open");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying the update listing page in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyCouponOnListing() {
		Logger.info("********Test Methods start: verifyCouponOnListing********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openCategoryfromMainList("dir");
			boolean catOpen = subCat.isSubCategoryPageOpenDirectory();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("dir");
				if (listing) {
					// ***** verification of coupon********
					subCat.openCoupon();
					boolean couponOpen= coupon.isCouponPageOpen();
					asser.assertTrue(couponOpen, "coupon is not open from directory listings");
					if(couponOpen){
						driver.context("NATIVE_APP");
						CommanClass.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
					coupon.openSharefromCoupon();
					
					if (!globledeviceName.equals("iPhone")) {
						asser.assertTrue(PageElement.checkSharePopUp(driver), "share btn on coupon is not working");
					}
					else {
						driver.context("NATIVE_APP");
						PageElement.Accessibilitylinks(PageElement.i_cancel);
						PageElement.changeContextToWebView(driver);
					}
					
					Thread.sleep(500);
					PageElement.tapBackButton(driver);
					Thread.sleep(500);
					}
					asser.assertTrue(subCat.isListingPresentinCategory("dir"), "BackButton from coupon is not working");		
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Directory category is not open from home page");
				asser.assertTrue(catOpen, "Directory Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying coupon in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyLoyaltyCardOnListing() {
		Logger.info("********Test Methods start: verifyLoyaltyCardOnListing********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openCategoryfromMainList("dir");
			boolean catOpen = subCat.isSubCategoryPageOpenDirectory();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("dir");
				if (listing) {
					// ***** verification of coupon********
					subCat.openLoyaltyCard();
					boolean pageOpen = loyality.isLoyaltyCardOpen();
					asser.assertTrue(pageOpen, "loyality card is not open from directory listings");
					if (pageOpen) {
						loyality.openLoyaltyCard();
						boolean cardOpen = loyality.isCardDetailOpen();
						asser.assertTrue(cardOpen, "card detail is not opens");
						Thread.sleep(500);
						PageElement.tapBackButtonP(driver);
						Thread.sleep(500);
					}
					asser.assertTrue(loyality.isLoyaltyCardOpen(), "BackButton from card detail is not working");
					Thread.sleep(1000);
					PageElement.tapBackButtonP(driver);
					Thread.sleep(500);
					asser.assertTrue(subCat.isListingPresentinCategory("dir"),
							"BackButton from loyality page is not working");
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Directory category is not open from home page");
				asser.assertTrue(catOpen, "Directory Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying loyalty card in directory", ex);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyLocationShareRatingandCheckIn() {
		Logger.info("********Test Methods start: verifyCouponLocationShareRatingandCheckIn********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openCategoryfromMainList("dir");
			boolean catOpen = subCat.isSubCategoryPageOpenDirectory();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("dir");
				if (listing) {
					
					// ***** verification of Share Link on listing********
					subCat.openShare("dir");
					asser.assertTrue(PageElement.checkSharePopUp(driver), "Share Listing is not working");

					// ***** verification of Location on listing********
					subCat.openLocation("dir");
					asser.assertTrue(subCat.isGoogleMapOpen("alpha 123"), "Location icon on listing is not working");

					// ***** verification of CheckIn on listing********
					subCat.openCheckIn();
					asser.assertTrue(checkIn.isCheckInPageOpen(),"CheckIN page is not open or google map is not present on page");
					PageElement.tapBackButton(driver);
					Thread.sleep(500);

					// ***** verification of Rating and review on listing********
					subCat.openRating("dir");
					boolean ratingOpen = rate.isRatingAndReviewPageOpen("dir");
					if (ratingOpen) {
						rate.submitReview("dir");
						if ((boolean) PageElement.getWarningTitle(driver).get(1)) {
							asser.assertEquals(PageElement.getWarningText(driver),"Please rate before posting the review");
							PageElement.closeWarningSingleBtn(driver,"Ok");
							Thread.sleep(500);
						} else {
							asser.assertTrue((boolean) PageElement.getWarningTitle(driver).get(1),
									"Warning doesn't apper upon submiting the review without selecting stars");
						}
						rate.selectStars();
						rate.writeReview("review textBox is working fine Content is adding");
						rate.submitReview("dir");
						boolean loginPageOpen = login.isDirectoryLoginOpen();
						if (loginPageOpen) {
							login.loginDirectory("pk@pk.com", "12345678");
						} else {
							Logger.info("User is already login into directory");
						}
						String review_Submit=PageElement.getWarningText(driver);
						asser.assertEquals(review_Submit,"Rating and Comment is submitted successfully");
						if (!review_Submit.equals("")) {
							PageElement.closeWarningSingleBtn(driver,"Ok");
						} 
					} else {
						asser.assertTrue(ratingOpen, "Rating and review page is not open from listing");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Directory category is not open from home page");
				asser.assertTrue(catOpen, "Directory Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying coupon location,Share and CheckIn in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyEnquiryFormSubmission() {
		Logger.info("********Test Methods start: verifyEnquiryFormSubmission********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openCategoryfromMainList("dir");
			boolean catOpen = subCat.isSubCategoryPageOpenDirectory();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("dir");
				if (listing) {
					subCat.openListing("dir");
					boolean listPageOpen = listDetail.isListingDetailPageOpen();
					if (listPageOpen) {
						listDetail.clickSendEnquiry("dir");
						boolean formOpen = enquiry.isEnquiryFormOpen();
						if (formOpen) {
							// ********verification of add images on inquiry
							// form**********
							enquiry.clickAddMore();
							List<Object> text = PageElement.getWarningTitle(driver);
							asser.assertEquals((String) text.get(0), "Click here to upload image(s)");
							if ((boolean) text.get(1)) {
								profile.cancelUploadPopup();
								Thread.sleep(1000);
							}
							// *******verification blank form submit*********
							enquiry.enterBlankName();
							enquiry.submitForm();
							boolean loginPageOpen = login.isDirectoryLoginOpen();
							if (loginPageOpen) {
								login.loginDirectory("pk@pk.com", "12345678");
								boolean pageOpenagain = enquiry.isEnquiryFormOpen();
								if (pageOpenagain) {
									Thread.sleep(2000);
								} else {
									asser.assertTrue(pageOpenagain,
											"login is not successful: rate and reviw page is not open again ");
								}
							} else {
								Logger.info("User is already login into directory");
								String warning_name = PageElement.getWarningText(driver);
								asser.assertEquals(warning_name, "Enter your name");
								if (warning_name != "") {
									PageElement.closeWarningSingleBtn(driver, "Ok");
									Thread.sleep(500);
								}
							}

							// *******verification of phone No field*********
							enquiry.enterName();
							enquiry.enterBlankAddr();
							enquiry.submitForm();
							String warning_phone = PageElement.getWarningText(driver);
							//asser.assertEquals(warning_phone, "Enter your phone number");
							if (warning_phone != "") {
								PageElement.closeWarningSingleBtn(driver, "Ok");
								Thread.sleep(500);
							}

							// *******verification of address field*********
							enquiry.enterName();
							enquiry.enterPhone();
							enquiry.submitForm();
							String warning_address = PageElement.getWarningText(driver);
							//asser.assertEquals(warning_address, "Enter your full address");
							if (warning_address != "") {
								PageElement.closeWarningSingleBtn(driver, "Ok");
								Thread.sleep(500);
							}

							// ********verification of description
							// field**********
							enquiry.enterName();
							enquiry.enterPhone();
							enquiry.enterAddr();
							enquiry.enterBudget();
							enquiry.submitForm();
							String warning_requirement = PageElement.getWarningText(driver);
							//asser.assertEquals(warning_requirement, "What is your requirement?");
							if (warning_requirement != "") {
								PageElement.closeWarningSingleBtn(driver, "Ok");
								Thread.sleep(500);
							}

							// ********verification of full form
							// submit**********
							enquiry.enterName();
							enquiry.enterPhone();
							enquiry.enterAddr();
							enquiry.enterBudget();
							enquiry.enterDescription();
							enquiry.submitForm();
							String finalSubmit = PageElement.getWarningText(driver);
							//asser.assertEquals(finalSubmit, "Your request has been submitted successfully");
							if (finalSubmit != "") {
								PageElement.closeWarningSingleBtn(driver, "Ok");
							}
						} else {
							asser.assertTrue(formOpen, "Enquiry form is not open from listing detail page");
						}
					} else {
						Logger.info("listing page is not open");
						asser.assertTrue(listPageOpen, "listing page is not open");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Directory category is not open from home page");
				asser.assertTrue(catOpen, "Directory Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while veriying submission of enquiry", ex);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyHomePageSearch() {
		Logger.info("********Test Methods start: verifyHomePageSearch********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			boolean homePageOpen = home.isHomePageOpenDirectory();
			if (homePageOpen) {
				// ***** verify search with dropdown options******
				home.typeOnSearch("dir", "ddd");
				boolean searchContent = home.isSearchOptionsVisible();
				Thread.sleep(1000);
				if (searchContent) {
					home.clickOnSearchOptions();
					asser.assertTrue(result.isMapOpen("ddd1"),
							"map is not open upon clicking on serach options of directory");
				} else {
					asser.assertTrue(searchContent, "serach options is not visible in dropsownlist");
				}

				// ***** verify search Button******
				home.typeOnSearch("dir", "ddd");
				Thread.sleep(2000);
				home.clickOnSerach("dir");
				List<Boolean> open = result.isFilterResultPageOpen();
				asser.assertTrue(open.get(0) || open.get(1), "Serach option is not working from directory home search");
			} else {
				Logger.info("Directory Home page is not open");
				asser.assertTrue(homePageOpen, "Directory page is not open in the app");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying home page search in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyLocationSearchOnHomePage() {
		Logger.info("********Test Methods start: verifyLocationSerachOnHomePage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			boolean homePageOpen = home.isHomePageOpenDirectory();
			if (homePageOpen) {
				home.openLocation();
				boolean open = loc.islocationOpen();
				if (open) {
					loc.typeSearchData1();
					CommanClass.TextField(loc.searchOnLocation, "Noida");
			/*		driver.context("NATIVE_APP");
					loc.typeSearchData("noida");
					PageElement.changeContextToWebView(driver);*/
					PageElement.tapDeviceOk(driver);
					Thread.sleep(4000);
					boolean data = loc.isSearchDataAvailable();
					if (data) {
						loc.ClickSearchData();
						List<Boolean> resultPageOpen = result.isFilterResultPageOpen();
						asser.assertTrue(resultPageOpen.get(0) || resultPageOpen.get(1),
								"Serach option is not working from location tab");
					} else {
						asser.assertTrue(data, "Search data is not available in location search");
					}
				} else {
					asser.assertTrue(open, "location tab is not open from directory home page");
				}
			} else {
				Logger.info("Directory Home page is not open");
				asser.assertTrue(homePageOpen, "Directory page is not open in the app");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying location on home page search in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyCloseBtnOnSearch() {
		Logger.info("********Test Methods start: verifyCloseBtnOnSearch********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			boolean homePageOpen = home.isHomePageOpenDirectory();
			if (homePageOpen) {
				home.openLocation();
				boolean open = loc.islocationOpen();
				if (open) {
					loc.closeLocationTab();
					boolean homePageOpenAgain = home.isHomePageOpenDirectory();
					if (homePageOpenAgain) {
						home.openPageMenu("dir");
						boolean openMenu = mainMenu.isMainMenuOpen("directory");
						if (openMenu) {
							mainMenu.closeMainMenu();
							asser.assertTrue(home.isHomePageOpenDirectory(), "close button on main menu is not working");
						} else {
							asser.assertTrue(openMenu, "Directory menu is not open");
						}
					} else {
						asser.assertTrue(homePageOpen, "Close button is not working on location tab");
					}
				} else {
					asser.assertTrue(open, "location tab is not open from directory home page");
				}
			} else {
				Logger.info("Directory Home page is not open");
				asser.assertTrue(homePageOpen, "Directory page is not open in the app");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying close buttons on search in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDirectoryMenuSearch() {
		Logger.info("********Test Methods start: verifyDirectoryMenuSearch********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			boolean homePageOpen = home.isHomePageOpenDirectory();
			if (homePageOpen) {
				home.openPageMenu("dir");
				boolean menuOpen = mainMenu.isMainMenuOpen("directory");
				if (menuOpen) {
					mainMenu.typeSearchDataDirectory("ddd");
					PageElement.tapDeviceOk(driver);
					List<Boolean> resultPageOpen = result.isFilterResultPageOpen();
					asser.assertTrue(resultPageOpen.get(0) || resultPageOpen.get(1),
							"Serach option is not working from Directorymenu");
				} else {
					Logger.info("Directory menu is not open upon clicking on menu button from directory home page");
					asser.assertTrue(menuOpen, "Directory menu is not open");
				}
			} else {
				Logger.info("Directory Home page is not open");
				asser.assertTrue(homePageOpen, "Directory page is not open in the app");
			}
		} catch (Exception ex) {
			Logger.error("exception occurs while verifying search on main menu in directory", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyOptionsOnListDetails() {
		Logger.info("********Test Methods start: verifyOptionsOnListDetails********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			appMenu.opendirectoryFolder();
			appMenu.openDirectoryPage();
			home.openCategoryfromMainList("dir");
			boolean catOpen = subCat.isSubCategoryPageOpenDirectory();
			if (catOpen) {
				boolean listing = subCat.isListingPresentinCategory("dir");
				if (listing) {
					subCat.openListing("dir");
					boolean listPageOpen = listDetail.isListingDetailPageOpen();
					if (listPageOpen) {
						listDetail.openListOptions("review");
						boolean reviewOpen = rate.isRatingAndReviewPageOpen("dir");
						asser.assertTrue(reviewOpen, "review page is not open from list details");
						if (reviewOpen) {
							PageElement.tapBackButton(driver);
							Thread.sleep(1000);
						}

						// verification of link text**
						listDetail.openListOptions("text");
						
						if (!globledeviceName.equals("iPhone")) {
							asser.assertTrue(PageElement.isContentOpenInNative(driver, ""),
									"link text is not open from list details");
						}
						else {
							driver.context("NATIVE_APP");
							Boolean ibackbtn=CommanClass.Openlinks(PageElement.i_backbutton);
							asser.assertTrue(ibackbtn, "i_Back Button is not working on alpha123 page");
							PageElement.changeContextToWebView(driver);
						}
						
						

						// verification of call
						listDetail.openListOptions("call");
						List<Object> title = PageElement.getWarningTitle(driver);
						asser.assertEquals((String) title.get(0), "Call", "Call pop up doesn't appear");
						if ((boolean) title.get(1)) {
							PageElement.closeWarningSingleBtn(driver, "Cancel");
							Thread.sleep(500);
						}
					} else {
						Logger.info("listing page is not open");
						asser.assertTrue(listPageOpen, "listing page is not open");
					}
				} else {
					Logger.info("listing is not present in the category");
					asser.assertTrue(catOpen, "listing is not present in the category");
				}
			} else {
				Logger.info("Directory category is not open from home page");
				asser.assertTrue(catOpen, "Directory Category is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while veriying listDetail Options", ex);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

}
