package com.appypie.tests.basetest;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import static org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class aac {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  int EmailSeed;
  int finalSeed;

  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    driver.manage().window().maximize();
    baseUrl = "https://snappy.appypie.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testAac() throws Exception {
	  SoftAssert asser= new SoftAssert();
	  random();
	  
    driver.get(baseUrl + "/login");
    driver.findElement(By.name("login_username")).clear();
    driver.findElement(By.name("login_username")).sendKeys("rakesh@onsinteractive.com");
    driver.findElement(By.name("login_password")).clear();
    driver.findElement(By.name("login_password")).sendKeys("12345678");
    driver.findElement(By.id("submitme")).click();
    driver.findElement(By.cssSelector("span.icon-color-book.adminIcon")).click();
    driver.findElement(By.xpath("(//input[@id='appName'])[2]")).click();
    driver.findElement(By.xpath("(//input[@id='appName'])[2]")).clear();
    driver.findElement(By.xpath("(//input[@id='appName'])[2]")).sendKeys("Check basic app 06 April"+EmailSeed);
    driver.findElement(By.xpath("//div[@id='1section']/div/div[2]/ul/li[4]/a/span")).click();
    driver.findElement(By.xpath("(//a[contains(text(),'Next')])[2]")).click();
    driver.findElement(By.linkText("Skip")).click();
    driver.findElement(By.xpath("(//a[contains(text(),'Next')])[3]")).click();
    driver.findElement(By.linkText("Save & Continue")).click();
    driver.findElement(By.id("basictopappzz")).click();
    driver.findElement(By.id("purchaseEasy")).click();
    driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
    driver.findElement(By.xpath("(//*[@class='welcomeUser dropdown-toggle ng-scope']")).click();
    driver.findElement(By.linkText("My Apps")).click();
    driver.findElement(By.cssSelector("i.ng-scope.icon-edit-2")).click();
    asser.assertEquals(driver.findElement(By.cssSelector("td.hyper-call.ng-binding")).getText(), "Subscription for Appy Pie Basic Plan");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[6]/div/div/div[2]/table/tbody/tr/td[2]")).getText(), "200 MB");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[7]/div/div/div[2]/table/tbody/tr/td[6]")).getText(), "5000");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[4]")).getText(), "Monthly");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[8]")).getText(), "06 May 2018");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[4]/div/div/div[2]/table/tbody/tr/td[5]")).getText(), "ch_1CDmJGIM5SeMqOoHfXRrjEWR");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[6]")).getText(), "Stripe");
    driver.findElement(By.xpath("(//*[@class='welcomeUser dropdown-toggle ng-scope']")).click();
    driver.findElement(By.linkText("My Apps")).click();
    driver.findElement(By.cssSelector("i.ng-scope.icon-list-2")).click();
    driver.findElement(By.linkText("Upgrade with Add-ons")).click();
    driver.findElement(By.cssSelector("span.title")).click();
    asser.assertEquals(driver.findElement(By.cssSelector("ul > li > span")).getText(), "Unlimited Push Notifications");
    asser.assertEquals(driver.findElement(By.cssSelector("#upgradeaddOnsEssentialsProm > a.plan-det > ul > li > span")).getText(), "Everything included in Essentials PLUS");
    driver.findElement(By.cssSelector("ul > li > span")).click();
    driver.findElement(By.linkText("Continue with these options")).click();
    driver.findElement(By.cssSelector("i.icon-paypal-1.font-icon-pay")).click();
    driver.findElement(By.xpath("(//button[@type='button'])[4]")).click();
    driver.findElement(By.id("Submit")).click();
    driver.findElement(By.name("unified_login.x")).click();
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("12345678");
    driver.findElement(By.id("btnLogin")).click();
    driver.findElement(By.name("submit.x")).click();
    driver.findElement(By.id("load-continue")).click();
    driver.findElement(By.cssSelector("span.iconz-mobile.adminIcon")).click();
    driver.findElement(By.cssSelector("i.ng-scope.icon-edit-2")).click();
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[7]/div/div/div[2]/table/tbody/tr/td[6]")).getText(), "5000");
    asser.assertEquals(driver.findElement(By.cssSelector("td.hyper-call.ng-binding")).getText(), "Renewal subscription for Appy Pie Basic Monthly Subscription with essential");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[7]/div/div/div[2]/table/tbody/tr/td[6]")).getText(), "unlimited");
    driver.findElement(By.cssSelector("i.ng-scope.icon-list-2")).click();
    driver.findElement(By.id("upgradeyearlyPlan")).click();
    driver.findElement(By.xpath("(//a[contains(text(),'Upgrade to Yearly')])[3]")).click();
    driver.findElement(By.cssSelector("span.value.ng-binding")).click();
    driver.findElement(By.cssSelector("#upgradeaddOnsEssentialsProm > a.plan-det > ul > li > span")).click();
    driver.findElement(By.linkText("Continue with these options")).click();
    driver.findElement(By.xpath("(//button[@type='button'])[4]")).click();
    driver.findElement(By.id("load-continue")).click();
    driver.findElement(By.cssSelector("span.iconz-mobile.adminIcon")).click();
    driver.findElement(By.cssSelector("i.ng-scope.icon-edit-2")).click();
    asser.assertEquals(driver.findElement(By.cssSelector("td.hyper-call.ng-binding")).getText(), "Subscription for Appy Pie Gold Yearly Plan with essential and promotion");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[8]")).getText(), "06 Apr 2019");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[2]")).getText(), "Gold");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[4]")).getText(), "Yearly");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[5]/div/div/div[2]/table/tbody/tr/td[6]")).getText(), "Stripe");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[7]/div/div/div[2]/table/tbody/tr/td[2]")).getText(), "Gold");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[7]/div/div/div[2]/table/tbody/tr/td[6]")).getText(), "unlimited");
    asser.assertEquals(driver.findElement(By.xpath("//div[@id='containerUpd1']/div[2]/div/div/div/div[6]/div/div/div[2]/table/tbody/tr/td[2]")).getText(), "400 MB");
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
  
  public void random() {
	  long timeSeed = System.nanoTime();
	  double randSeed = Math.random() * 1000;
	  long midSeed = (long) (timeSeed * randSeed);
	  String s = midSeed + "";
	  
	  String subStr = s.substring(0, 9);
	  finalSeed = Integer.parseInt(subStr);
	  
	  String emailsubStr = s.substring(0, 4);
	   EmailSeed = Integer.parseInt(emailsubStr);
  }
  
  
  
  
}
