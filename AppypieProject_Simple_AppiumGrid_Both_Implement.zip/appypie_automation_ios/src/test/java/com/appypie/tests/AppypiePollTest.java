package com.appypie.tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypiePollPage;
import com.appypie.pages.AppypieQuizPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;
import com.aventstack.extentreports.ExtentTest;

public class AppypiePollTest extends TestSetup {

	AppypiePollPage poll;
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
   

	@Override
	@BeforeTest
	public void pageSetUp() {
		poll = new AppypiePollPage(driver);
	}

	@Test
	public void verifyPollPage() {
		Logger.info("********Test Method Start: verifyPollPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			poll.openPollPage();
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
			} else {
				Logger.info("user is already login into the app");
			}
			asser.assertTrue(poll.isPollPageOpen(), "poll page is not open from main menu");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the poll page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyNextAndPrevBtn() {
		Logger.info("********Test Method Start: verifyNextAndPrevBtn********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			poll.openPollPage();
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
			} else {
				Logger.info("user is already login into the app");
			}
			boolean openPage = poll.isPollPageOpen();
			if (openPage) {
				poll.clickNextBtn();
				boolean nextopen = poll.isPrevBtnDisplayed();
				asser.assertTrue(nextopen, "next button on poll page is not working");
				if (nextopen) {
					poll.clickprevBtn();
					asser.assertFalse(poll.isPrevBtnDisplayed(), "previous button is not working on poll page");
				}
			} else {
				Logger.info("login is not successfull or poll page is not open");
				asser.assertTrue(openPage, "poll page is not open");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying next and prev button", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyResultButton() {
		Logger.info("********Test Method Start: verifyResultButton********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			poll.openPollPage();
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
			} else {
				Logger.info("user is already login into the app");
			}
			boolean openPage = poll.isPollPageOpen();
			if (openPage) {
				poll.clickResultbtn();
				boolean resultPage = poll.isResultPageOpen();
				asser.assertTrue(resultPage, "result page is not open on poll");
				if (resultPage) {
					poll.clickShare();
					asser.assertTrue(PageElement.checkSharePopUp(driver), "share button is not working");
					poll.clickCloseResult();
					asser.assertTrue(poll.isPollPageOpen(), "close button is not working on result page");
				}
			} else {
				Logger.info("login is not successfull or poll page is not open");
				asser.assertTrue(openPage, "poll page is not open");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Result Button", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	//@Test
	public void verifyAudioInPoll() {
		Logger.info("********Test Method Start: verifyAudioInPoll********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			poll.openPollPage();
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
			} else {
				Logger.info("user is already login into the app");
			}
			boolean openPage = poll.isPollPageOpen();
			if (openPage) {
				for (int i = 0; i < 3; i++) {
					poll.clickNextBtn();
					Thread.sleep(500);
				}
				poll.clickAudio();
				asser.assertTrue(new AppypieQuizPage(driver).isAudioVideoExist("audio","Poll automate"),
						"audio is not working in poll");
			} else {
				Logger.info("login is not successfull or poll page is not open");
				asser.assertTrue(openPage, "poll page is not open");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying audio in poll", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyYoutubeInPoll() {
		Logger.info("********Test Method Start: verifyYoutubeInPoll********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			poll.openPollPage();
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
			} else {
				Logger.info("user is already login into the app");
			}
			boolean openPage = poll.isPollPageOpen();
			if (openPage) {
				for (int i = 0; i < 5; i++) {
					poll.clickNextBtn();
					Thread.sleep(500);
				}
				poll.clickYouTube();
				asser.assertTrue(new AppypieQuizPage(driver).isAudioVideoExist("video","Poll automate"),
						"youtube is not working in poll");
			} else {
				Logger.info("login is not successfull or poll page is not open");
				asser.assertTrue(openPage, "poll page is not open");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying youtube in poll", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	
}
