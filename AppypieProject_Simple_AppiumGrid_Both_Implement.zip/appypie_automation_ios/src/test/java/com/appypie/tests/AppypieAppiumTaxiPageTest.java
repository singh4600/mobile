package com.appypie.tests;


import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.Taxi.BookingPage;
import com.appypie.pages.Taxi.MenuPage;
import com.appypie.pages.Taxi.TaxiDriver;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.CommanClass;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.ios.IOSDriver;


public class AppypieAppiumTaxiPageTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	BookingPage book;
	PageElement pe;
	LoginUtil lu;
	MenuPage menu;
	TaxiDriver driverTaxi;


	@BeforeTest
	@Override
	public void pageSetUp() {
		book= new BookingPage(driver);
		lu= new LoginUtil();
		menu= new MenuPage(driver);
		driverTaxi= new TaxiDriver();


	}


	public void second() {
		driver.context("NATIVE_APP");
		//launch settings App
		AndroidDriver<MobileElement> driver1= (AndroidDriver<MobileElement>)driver;
		driver1.startActivity(DriverPck, DriverActivityName);
		
		/*if (!globledeviceName.equals("iPhone")) {
			
		}
		else {
			IOSDriver<MobileElement> driver2=(IOSDriver<MobileElement>)driver;
			driver2.isAppInstalled(IosbundleId);
			
		}*/
	}

	@Test(priority = 0, description = "open Taxi module")
	public void VerifyTaxiModuleOpenandback(){
		Logger.info("Test Case:  VerifyTaxiModuleOpen&Back()");
		asser= new SoftAssert();
		boolean opentaxi = false;

		try {

			if (globledeviceName.equals("iPhone")) {
				Boolean taximoduleOpen=book.Openlinks(book.pagelink);
				asser.assertTrue(taximoduleOpen, "Taxi page not opens or not working on flow of the main menu");
			}
			else {
				Boolean taximoduleOpen=book.Openlinks(book.pagelink);
				asser.assertTrue(taximoduleOpen, "Taxi page not opens or not working on flow of the main menu");
				asser.assertTrue(PageElement.backFromNaitvePageTaxi(), "back button not working on taxi page`");
			}

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			opentaxi=true;
			asser.assertFalse(opentaxi, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();

	}


	@Test(priority = 1, description = "Login")
	public void verifylogin(){
		Logger.info("Test Case:  VerifyTaxiModuleLogin()");
		asser= new SoftAssert();
		boolean loginapp = false;

		try {
			Boolean taximoduleOpen=book.Openlinks(book.pagelink);
			asser.assertTrue(taximoduleOpen, "Taxi page not opens or not working on flow of the main menu");
			driver.context("NATIVE_APP");
			if (globledeviceName.equals("iPhone")) {

				Boolean login=CommanClass.IselementPresent(book.i_signIn);
				if (login) {
					Boolean loginlink=CommanClass.Openlinks(book.i_signIn);
					if (loginlink) {
						Boolean emilid=CommanClass.TextField(book.i_email, "prince@appypie.com");
						asser.assertTrue(emilid, "Email ID is not working");

						Boolean pass=CommanClass.TextField(book.i_pwd, "12345678");
						asser.assertTrue(pass, "Email ID is not working");

						Boolean signinBtn=CommanClass.Openlinks(book.i_signInBtn);
						asser.assertTrue(signinBtn, "Sign_in button is not working");
					}
					asser.assertTrue(loginlink, "Sign_in button is not working");

				}
				else {
					System.out.println("User Alerady Sign");
				}
			}
			else {
				boolean login = book.isLogindisplaying();
				if (login) {
					Boolean loginPassenger = book.Openlinks(book.login);
					asser.assertTrue(loginPassenger, "Login button not working on Taxi page");
					LoginUtil.loginIntoPageNative(driver, "prince@appypie.com", "12345678");
				} 
				else
				{
					System.out.println("User is already login on app");
				}
			}
			PageElement.changeContextToWebView(driver);
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			loginapp=true;
			asser.assertFalse(loginapp, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


	@Test(priority = 2, description = "Booking")
	public void verifyBookingTaxi(){
		Logger.info("Test Case:  VerifyTaxiBooking()");
		asser= new SoftAssert();
		boolean booking = false;

		try {

			Boolean taximoduleOpen=book.Openlinks(book.pagelink);
			asser.assertTrue(taximoduleOpen, "Taxi page not opens or not working on flow of the main menu");
			driver.context("NATIVE_APP");

			if (globledeviceName.equals("iPhone")) {

				Boolean login=CommanClass.IselementPresent(book.i_signIn);
				if (login) {
					Boolean loginlink=CommanClass.Openlinks(book.i_signIn);
					if (loginlink) {
						Boolean emilid=CommanClass.TextField(book.i_email, "prince@appypie.com");
						asser.assertTrue(emilid, "Email ID is not working");

						Boolean pass=CommanClass.TextField(book.i_pwd, "12345678");
						asser.assertTrue(pass, "Email ID is not working");

						Boolean signinBtn=CommanClass.Openlinks(book.i_signInBtn);
						asser.assertTrue(signinBtn, "Sign_in button is not working");
					}
					asser.assertTrue(loginlink, "Sign_in button is not working");

				}
				else {
					System.out.println("User Alerady Sign");
				}
				driver.context("NATIVE_APP");

				Boolean clickwhereto=false;
				try {
					clickwhereto=CommanClass.Openlinks(book.i_whereToo);
				}catch (Exception e) {
					clickwhereto=CommanClass.Openlinks(book.i_whereToo);
				}
				if (clickwhereto) {
									
					Boolean enterlocation=CommanClass.TextField(book.i_dropOff, "Noida");
					if (enterlocation) {
						Boolean selectlocation=CommanClass.Openlinks(book.i_selectLocation);
						if (selectlocation) {
							Boolean min=CommanClass.IselementPresent(book.i_minet);
							if (min) {
								Boolean paymentmethod=CommanClass.Openlinks(book.i_selectpaymentMethod);
								if (paymentmethod) {
									Boolean cashpayment=CommanClass.Openlinks(book.i_cash_pymnt);
									if (cashpayment) {
										Boolean requestDriver=CommanClass.Openlinks(book.i_rqestDriver);
										if (requestDriver) {
											// driver: Accept driver request
											String bookingid=CommanClass.Getactualtext(book.i_getBookingID);
											asser.assertNotNull(bookingid, "BookingID is getting Null Value");
											//driver : I have Arrived
											Boolean taxiDetails=CommanClass.getListofLink(book.i_gettaxiDetails);
											asser.assertNotNull(taxiDetails, "Taxi details getting Null value is getting Null Value");
											//Driver: Begin Journey
											//finish

											String bookinbgid=CommanClass.Getactualtext(book.i_getbookingID);
											asser.assertNotNull(bookinbgid, "bookinbgid is getting Null Value");

											String tollfare=CommanClass.Getactualtext(book.i_gettollFare);
											asser.assertNotNull(tollfare, "tollfare is getting Null Value");

											String tax=CommanClass.Getactualtext(book.i_getTax);
											asser.assertNotNull(tax, "TAX is getting Null Value");

											String totalFare=CommanClass.Getactualtext(book.i_gettotalFare);
											asser.assertNotNull(totalFare, "Total Fare is getting Null Value");

											String totalDiscount=CommanClass.Getactualtext(book.i_gettotalDiscount);
											asser.assertNotNull(totalDiscount, "Total Discount is getting Null Value");


											Boolean pickup_drop_duration=CommanClass.getListofLink(book.i_getPickup_Drop_Duration);
											asser.assertNotNull(pickup_drop_duration, "taxi Pickup,Drop and Duration details getting Null value is getting Null Value");

											Boolean submitReviewbtn=CommanClass.Openlinks(book.i_submitReview);
											if (submitReviewbtn) {
												Boolean feedback=CommanClass.TextField(book.i_EnterReview, "Very Good Very Nice");
												if (feedback) {
													Boolean donereview=CommanClass.Openlinks(book.i_DoneReview);
													asser.assertTrue(donereview, "Done Review");
												}
												asser.assertTrue(feedback, "feedback text field is not working");
											}
											asser.assertTrue(submitReviewbtn, "submit Review btn is not working ");
										}
										asser.assertTrue(requestDriver, "Request Driver Button is not present");
									}
									asser.assertTrue(cashpayment, "cash payment link is not working");
								}
								asser.assertTrue(paymentmethod, "payment method link is not working");
							}
							else {
								System.out.println("Driver not present");
							}
						}
						asser.assertTrue(selectlocation, "select location is not working");
					}
					asser.assertTrue(enterlocation, "Enter location is not working");
				}
				asser.assertTrue(clickwhereto, "click where to text filed");

			}
			else {

				boolean login = book.isLogindisplaying();
				if (login) {

					Boolean loginPassenger = book.Openlinks(book.login);
					asser.assertTrue(loginPassenger, "Login button not working on Taxi page");
					LoginUtil.loginIntoPageNative(driver, "prince@appypie.com", "12345678");

				} 
				else

				{
					System.out.println("User is already login on app");
				}

				Thread.sleep(2000);
				Boolean clickonWhereToo = book.whereToo();
				asser.assertTrue(clickonWhereToo, "WhereToo link not clikable on Taxi page");

				Boolean corssOnPicup=book.addressCross();
				asser.assertTrue(corssOnPicup, "Address cross button not working on Taxi page");

				Boolean clickOnPicup=book.Openlinks(book.dropOff);
				asser.assertTrue(clickOnPicup, "Pickup location is not on Taxi page");

				Boolean lcation = book.enterLocation();
				asser.assertTrue(lcation, "WhereToo link not clikable on Taxi page");


				book.selectOptionWithText("Noida City Centre");
				Thread.sleep(2000);
				Boolean verifyPromo=book.Openlinks(book.promo); 
				if (verifyPromo) {
					Boolean cacl= book.Openlinks(book.cancel_promo);
					asser.assertTrue(cacl, "cancel buttin on promo code not clikable on Taxi page");

					book.Openlinks(book.promo); 

					Boolean enter= book.promoCodeText("FREE");
					asser.assertTrue(enter, "promo code field not editable on Taxi page");

					Boolean aply= book.Openlinks(book.apply_promo);
					asser.assertTrue(aply, "promo code apply button not clickable on Taxi page");
					Thread.sleep(3000);

				} else {
					Logger.info("Promo code field on taxi page does not exit");
				}
				asser.assertTrue(verifyPromo, "promo link not clikable on Taxi page");

				/*			Boolean paymentMethod = book.Openlinks(book.pymnt);
			asser.assertTrue(paymentMethod, "Select Payment Method not clikable on Taxi page");

			Boolean canclPayment = book.Openlinks(book.cross_pymnt);
			asser.assertTrue(canclPayment, "Cancel Payment Method not clikable on Taxi page");

			book.Openlinks(book.pymnt);
			Boolean cardPayment = book.Openlinks(book.card_pymnt);
			asser.assertTrue(cardPayment, "Card type Payment Method not working on Taxi page");

			Thread.sleep(2000);

			Boolean carddetails = book.addressmessage();
			if (carddetails) {
				Boolean alert_message = book.Openlinks(book.card_not_found_alert);
				asser.assertTrue(alert_message, "Card type Payment Method not working on Taxi page");
			}
		 else {
			Logger.info("User already added some card in app");

		}
			Thread.sleep(2000);
			Boolean back_CardPage = book.Openlinks(book.backCardPage);
			asser.assertTrue(back_CardPage, "Back button not working on card page");*/

				Thread.sleep(2000);

				Boolean paymentMethodC = book.Openlinks(book.pymnt);
				asser.assertTrue(paymentMethodC, "Select Payment Method not clikable on Taxi page");

				Boolean cashPayment = book.Openlinks(book.cash_pymnt);
				asser.assertTrue(cashPayment, "Cash type Payment Method not working on Taxi page");



				/// Open Driver App			
				second();
				driver.context("NATIVE_APP");

				/*Boolean reg=CommanClass.IselementPresent(driverTaxi.register);
			if (reg) {
				Boolean signin=CommanClass.Openlinks(driverTaxi.signIn);
				asser.assertTrue(signin, "SignIn button is not working");

				Boolean email=CommanClass.TextField(driverTaxi.emailTaxi, "manoj@onsinteractive.com");
				asser.assertTrue(email, "Email filed is not working");

				Boolean pass=CommanClass.TextField(driverTaxi.pwdTaxi, "12345678");
				asser.assertTrue(pass, "Password filed is not working");

				Boolean carid=CommanClass.TextField(driverTaxi.cariD, "1");
				asser.assertTrue(carid, "Car_id filed is not working");

				Boolean loginbtn=CommanClass.Openlinks(driverTaxi.loginBtnTaxi);
				asser.assertTrue(loginbtn, "login button is not working");

			}
			else {
				System.out.println("User Already Register");
			}
			asser.assertTrue(reg, "Register Now Link is not Present");*/


				//pass
				//passenger();

				PageElement.SwitchApp(driverTaxi.passengerapp);

				Boolean reqDriver = book.Openlinks(book.rqestDriver);

				asser.assertTrue(reqDriver, "Request driver link not clikable on Taxi page");

				Thread.sleep(2000);


				PageElement.SwitchApp(driverTaxi.driverapp);

				CommanClass.OpenlinksByID(driverTaxi.accept);

				//Open passenger app
				PageElement.SwitchApp(driverTaxi.passengerapp);
				driver.context("NATIVE_APP");
				String driverOnTheWay=book.GetPassengerText(book.onTheWay);
				asser.assertEquals(driverOnTheWay, "DRIVER ON THE WAY");

				//open driver app			
				PageElement.SwitchApp(driverTaxi.driverapp);
				driver.context("NATIVE_APP");
				Boolean arrived=CommanClass.OpenlinksByID(driverTaxi.ihaveArrived);
				asser.assertTrue(arrived, "I have arrived button not clickable on drive app");

				//Open passenger app	
				PageElement.SwitchApp(driverTaxi.passengerapp);
				driver.context("NATIVE_APP");
				/*		String driverArrived=book.GetPassengerText(book.onTheWay);
			asser.assertEquals(driverArrived, "DRIVER ARRIVED");*/

				//open driver app			
				PageElement.SwitchApp(driverTaxi.driverapp);
				driver.context("NATIVE_APP");
				Boolean journeyStart=CommanClass.OpenlinksByID(driverTaxi.beginJourney);
				asser.assertTrue(journeyStart, "Being journey button not clickable on drive app");


				//Open passenger app
				PageElement.SwitchApp(driverTaxi.passengerapp);
				driver.context("NATIVE_APP");
				/*	String jurnyStarted=book.GetPassengerText(book.onTheWay);
			asser.assertEquals(jurnyStarted, "JOURNEY STARTED");*/

				//open driver app			
				PageElement.SwitchApp(driverTaxi.driverapp);
				driver.context("NATIVE_APP");
				Boolean passDroped=CommanClass.OpenlinksByID(driverTaxi.passengerDropped);
				asser.assertTrue(passDroped, "Passenger droped on his location");

				Boolean finishDriver=CommanClass.OpenlinksByID(driverTaxi.finish);
				asser.assertTrue(finishDriver, "Finish button not working on driver app");	

				//Open Passenger app	
				PageElement.SwitchApp(driverTaxi.passengerapp);
				driver.context("NATIVE_APP");
				String rcpt=book.GetPassengerText(book.recpt);
				asser.assertEquals(rcpt, "Reciept");

				String bkingID=book.GetPassengerText(book.bookingID);
				asser.assertEquals(bkingID, "Booking ID");

				String TollFare=book.GetPassengerText(book.tollFare);
				asser.assertEquals(TollFare, "Toll Fare");

				String totalfare=book.GetPassengerText(book.tollPrice);
				asser.assertEquals(totalfare, "Total Fare");

				String pickUpLocation=book.GetPassengerText(book.pickupLocation);
				asser.assertEquals(pickUpLocation, "Unnamed Road, Noida, Uttar Pradesh, India");

				String dropOfLction=book.GetPassengerText(book.dropoffLocation);
				asser.assertEquals(dropOfLction, "Unnamed Road, Noida Special Economy Zone, Block A, Sector 81, Noida, Uttar Pradesh 201305, India");

				String duration=book.GetPassengerText(book.duration);
				asser.assertEquals(duration, "DURATION");

				String dstance=book.GetPassengerText(book.dstnce);
				asser.assertEquals(dstance, "DISTANCE");

				String avgSpeed=book.GetPassengerText(book.avgSpeed);
				asser.assertEquals(avgSpeed, "AVG SPEED");

				/*	Boolean rate_revw = book.Openlinks(book.rate);
			asser.assertTrue(rate_revw, "Rate & Review link not clickable");*/


				Boolean submit = book.Openlinks(book.submitRevw);
				asser.assertTrue(submit, "Submit review button not working");


				//PageElement.changeContextToWebView(driver);
			}
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			booking=true;
			asser.assertFalse(booking, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}




	@Test(priority = 3, description = "Booking")

	public void verifyTaxiCancel(){
		Logger.info("Test Case:  VerifyTaxiBooking()");
		asser= new SoftAssert();
		boolean booking = false;

		try {
			if (globledeviceName.equals("iPhone")) {

			}
			else {
				Boolean taximoduleOpen=book.Openlinks(book.pagelink);
				asser.assertTrue(taximoduleOpen, "Taxi page not opens or not working on flow of the main menu");
				driver.context("NATIVE_APP");
				boolean login = book.isLogindisplaying();
				if (login) {

					Boolean loginPassenger = book.Openlinks(book.login);
					asser.assertTrue(loginPassenger, "Login button not working on Taxi page");
					LoginUtil.loginIntoPageNative(driver, "prince@appypie.com", "12345678");

				} 
				else

				{
					System.out.println("User is already login on app");
				}

				Thread.sleep(2000);
				Boolean clickonWhereToo = book.whereToo();
				asser.assertTrue(clickonWhereToo, "WhereToo link not clikable on Taxi page");

				Boolean corssOnPicup=book.addressCross();
				asser.assertTrue(corssOnPicup, "Address cross button not working on Taxi page");

				Boolean clickOnPicup=book.Openlinks(book.dropOff);
				asser.assertTrue(clickOnPicup, "Pickup location is not on Taxi page");

				Boolean lcation = book.enterLocation();
				asser.assertTrue(lcation, "WhereToo link not clikable on Taxi page");


				book.selectOptionWithText("Noida City Centre");
				Thread.sleep(2000);


				Boolean paymentMethodC = book.Openlinks(book.pymnt);
				asser.assertTrue(paymentMethodC, "Select Payment Method not clikable on Taxi page");

				Boolean cashPayment = book.Openlinks(book.cash_pymnt);
				asser.assertTrue(cashPayment, "Cash type Payment Method not working on Taxi page");

				Thread.sleep(3000);
				Boolean reqDriver = book.Openlinks(book.rqestDriver);
				asser.assertTrue(reqDriver, "Request driver link not clikable on Taxi page");

				//---------------------API---


				Boolean taxiOption = book.Openlinks(book.option);
				asser.assertTrue(taxiOption, "option for share, Call and cancel linknot cliakable");

				Boolean shareTaxiBooking = book.isSharePresent();
				if (shareTaxiBooking) {
					Logger.info("Share button present");
				}
				asser.assertTrue(shareTaxiBooking, "Share option not available after taxi booked by user");

				Boolean contactTaxiDriver = book.isCallPresent();
				if (contactTaxiDriver) {
					Logger.info("Call button present");
				}
				asser.assertTrue(contactTaxiDriver, "Call option not available after taxi booked by user");

				Boolean tripCancel = book.Openlinks(book.cancel);
				asser.assertTrue(tripCancel, "Select Payment Method not clikable on Taxi page");

				Boolean cancelTaxiMessage = book.cancelMessage("No need any taxi to go");
				asser.assertTrue(cancelTaxiMessage, "User not able type cancellation message");

				Boolean submitCancel = book.Openlinks(book.sbmit);
				asser.assertTrue(submitCancel, "Submit button not working after entered  cancellation message");

				String Cancellation = book.GetPassengerText(book.cancelTextMessge);
				asser.assertEquals(Cancellation, "Booking cancelled.Cancellation Charges");

				Boolean submitOk = book.Openlinks(book.cancelOk);
				asser.assertTrue(submitOk, "Submit button not working after entered  cancellation message");


				PageElement.changeContextToWebView(driver);
			}
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			booking=true;
			asser.assertFalse(booking, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}


	@Test(priority = 4, description = "Booking")

	public void verifyMenuPage(){
		Logger.info("Test Case:  VerifyMenuPageDetails()");
		asser= new SoftAssert();
		boolean menupagelist = false;

		try {
			if (globledeviceName.equals("iPhone")) {

			}
			else {
				Boolean taximoduleOpen=book.Openlinks(book.pagelink);
				asser.assertTrue(taximoduleOpen, "Taxi page not opens or not working on flow of the main menu");
				driver.context("NATIVE_APP");
				boolean login = book.isLogindisplaying();
				if (login) {

					Boolean loginPassenger = book.Openlinks(book.login);
					asser.assertTrue(loginPassenger, "Login button not working on Taxi page");
					LoginUtil.loginIntoPageNative(driver, "prince@appypie.com", "12345678");

				} 
				else

				{
					System.out.println("User is already login on app");
				}

				Boolean munuLink=book.Openlinks(menu.home);
				asser.assertTrue(munuLink, "Menu link not clickable on taxi page");

				Boolean munuHome=book.Openlinks(menu.home_menu);
				asser.assertTrue(munuHome, "Menu link not clickable on taxi page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			menupagelist=true;
			asser.assertFalse(menupagelist, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}



}
