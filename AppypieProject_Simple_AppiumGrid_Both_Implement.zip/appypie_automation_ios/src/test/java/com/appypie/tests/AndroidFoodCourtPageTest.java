package com.appypie.tests;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.FoodCourt.CartPage;
import com.appypie.pages.FoodCourt.CategoryPage;
import com.appypie.pages.FoodCourt.CheckOutPage;
import com.appypie.pages.FoodCourt.CommanClassFoodCourt;
import com.appypie.pages.FoodCourt.Cuisines_Filter_Sort;
import com.appypie.pages.FoodCourt.DeshboardPage;
import com.appypie.pages.FoodCourt.Favorite;
import com.appypie.pages.FoodCourt.MenuPage;
import com.appypie.pages.FoodCourt.MyAccount;
import com.appypie.pages.FoodCourt.MyOrders;
import com.appypie.pages.FoodCourt.Offered;
import com.appypie.pages.FoodCourt.OrderPreview;
import com.appypie.pages.FoodCourt.ProductDetailsPage;
import com.appypie.pages.FoodCourt.RestaurantDetailsPage;
import com.appypie.pages.FoodCourt.SubCategoryesPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AndroidFoodCourtPageTest extends TestSetup {
	DeshboardPage deshboard;
	CategoryPage category; 
	RestaurantDetailsPage restaurantdetails;
	SubCategoryesPage subcategoryes;
	ProductDetailsPage productdetails;
	CartPage cart;
	CheckOutPage checkout;
	CommanClassFoodCourt comm;
	Cuisines_Filter_Sort cuisi;
	OrderPreview OrderPre;
	MenuPage menu;
	MyAccount myAcc;
	Favorite fav;
	Offered offer;
	MyOrders myorder;



	private static final Logger Logger = Log.createLogger();

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		deshboard=new DeshboardPage(driver);
		category=new CategoryPage(driver);
		restaurantdetails=new RestaurantDetailsPage(driver);
		subcategoryes=new SubCategoryesPage(driver);
		productdetails=new ProductDetailsPage(driver);
		cart=new CartPage(driver);
		checkout=new CheckOutPage(driver);
		comm=new CommanClassFoodCourt(driver);
		cuisi=new Cuisines_Filter_Sort(driver);
		OrderPre=new OrderPreview(driver);
		menu=new MenuPage(driver);
		myAcc=new MyAccount(driver);
		fav=new Favorite(driver);
		offer=new Offered(driver);
		myorder=new MyOrders(driver);


	}



	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
		public void Verify() throws Exception {
			SoftAssert s_assert = new SoftAssert();
			Logger.info("Test Case:  ()");
			boolean exception = false;
			try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

			} catch (Exception e) {
				Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
				exception = true;
				s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
			}
			s_assert.assertAll();
		}
	 */

	@Test(priority = 0, description = "")
	public void VerifyFoodCourtDeshBoard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFoodCourtModuleOpen()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				comm.Getactualtext(comm.header_gettext);

				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}


				Boolean FClist=deshboard.getListofLink(deshboard.restaurantList_gettext);
				s_assert.assertTrue(FClist, "Food Court list is not present");

				Boolean cuisine=deshboard.Openlinks(deshboard.cuisine_link);
				if (cuisine) {
					TimeUnit.SECONDS.sleep(3);
					comm.Getactualtext(comm.header_gettext);
					Boolean cuisinelist=comm.getListofLink(this.cuisi.cuisineslist_get);
					s_assert.assertTrue(cuisinelist, "Cuisines list is not getting");

					Boolean search=comm.TextField(cuisi.searchTextlink, "Ainu");
					if (search) {
						Boolean select=comm.Openlinks(cuisi.selectCuisinesAfterSearchlink);
						s_assert.assertTrue(select, "select check box link is not working");

						Boolean done=comm.Openlinks(cuisi.doneBtnCuisines);
						s_assert.assertTrue(done, "Done Button is not working for Cuisines");
					}
					s_assert.assertTrue(search, "Search is not present");

					Boolean cuisine1=deshboard.Openlinks(deshboard.cuisine_link);
					if (cuisine1) {
						TimeUnit.SECONDS.sleep(3);
						Boolean reset=comm.Openlinks(cuisi.resetBtnCuisines);
						s_assert.assertTrue(reset, "reset button is not working for reset button");
					}
					s_assert.assertTrue(cuisine1, "Again open cuisines link is not open");

					Boolean cuisine2=deshboard.Openlinks(deshboard.cuisine_link);
					if (cuisine2) {
						Boolean backbtn=comm.Openlinks(comm.BackButton3);
						s_assert.assertTrue(backbtn, "reset button is not working");
					}
					s_assert.assertTrue(cuisine2, "Again open cuisines link is not open for Back button");
				}
				s_assert.assertTrue(cuisine, "cuisine link is not open");

				Boolean filter=deshboard.Openlinks(deshboard.filter_link);
				if (filter) {
					TimeUnit.SECONDS.sleep(3);
					comm.Getactualtext(comm.header_gettext);
					String EStimeheader=comm.Getactualtext(cuisi.estimatedTimeHedading_get);
					comm.Openlinks(cuisi.time15link);
					comm.Openlinks(cuisi.time30link);
					comm.Openlinks(cuisi.time45link);
					comm.Openlinks(cuisi.time60link);
					s_assert.assertNotNull(EStimeheader, "Estimated Time Hedading_is getting Nul Value");

					Boolean ESlist=deshboard.getListofLink(cuisi.estimatedTimeList_get);
					s_assert.assertTrue(ESlist, "Estimated Time List is not getting");

					String MinimumOrderAmountHeading=comm.Getactualtext(cuisi.MinimumOrderAmountHeading_get);
					if (MinimumOrderAmountHeading.equalsIgnoreCase("Minimum Order Amount")) {
						comm.Openlinks(cuisi.amount10link);
						comm.Openlinks(cuisi.amount30link);
						comm.Openlinks(cuisi.amount50link);

					}
					s_assert.assertNotNull(MinimumOrderAmountHeading, "Minimum Order Amount Headingis getting Nul Value");

					Boolean MinimumOrderAmountList=deshboard.getListofLink(cuisi.MinimumOrderAmountList_get);
					s_assert.assertTrue(MinimumOrderAmountList, "Minimum Order Amount List is not getting");

					Boolean donefilter=comm.Openlinks(cuisi.doneBtnfilter);
					s_assert.assertTrue(donefilter, "Done button isnot working on Filter page");


					Boolean filetr1=deshboard.Openlinks(deshboard.filter_link);
					if (filetr1) {
						TimeUnit.SECONDS.sleep(3);
						Boolean reset=comm.Openlinks(cuisi.resetBtnCuisines);
						s_assert.assertTrue(reset, "reset button is not working for reset button");
					}
					s_assert.assertTrue(filetr1, "Again open cuisines link is not open for filetr page");

					Boolean filetr2=deshboard.Openlinks(deshboard.filter_link);
					if (filetr2) {
						Boolean backbtn=comm.Openlinks(comm.BackButton3);
						s_assert.assertTrue(backbtn, "reset button is not working");
					}
					s_assert.assertTrue(filetr2, "Again open cuisines link is not open for Back button for filetr page");
				}
				s_assert.assertTrue(filter, "filter link is not open");

				Boolean sortlink=comm.Openlinks(deshboard.sort_link);
				if (sortlink) {
					TimeUnit.SECONDS.sleep(3);
					comm.Getactualtext(comm.header_gettext);
					Boolean sortlist=comm.getListofLink(cuisi.sortlist_get);
					s_assert.assertTrue(sortlist, "Sort list is not present on sort page");

					Boolean backsort=comm.Openlinks(comm.BackButton3);
					s_assert.assertTrue(backsort, "Back Button is not working");

					Boolean sortlink1=comm.Openlinks(deshboard.sort_link);
					if (sortlink1) {
						TimeUnit.SECONDS.sleep(3);
						Boolean LH=comm.Openlinks(cuisi.priceLH);
						s_assert.assertTrue(LH, "Price Low To High link is not working");
					}
					s_assert.assertTrue(sortlink1, "Sort link is not working for Price LH");

					Boolean sortlink2=comm.Openlinks(deshboard.sort_link);
					if (sortlink2) {
						TimeUnit.SECONDS.sleep(3);
						Boolean HL=comm.Openlinks(cuisi.priceHL);
						s_assert.assertTrue(HL, "Price High to Low link is not working");
					}
					s_assert.assertTrue(sortlink2, "Sort link is not working for Price HL");

					Boolean sortlink3=comm.Openlinks(deshboard.sort_link);
					if (sortlink3) {
						TimeUnit.SECONDS.sleep(3);
						Boolean AZ=comm.Openlinks(cuisi.AZ);
						s_assert.assertTrue(AZ, "A to Z link is not working");
					}
					s_assert.assertTrue(sortlink3, "Sort link is not working for A to Z");

					Boolean sortlink4=comm.Openlinks(deshboard.sort_link);
					if (sortlink4) {
						TimeUnit.SECONDS.sleep(3);
						Boolean ZA=comm.Openlinks(cuisi.ZA);
						s_assert.assertTrue(ZA, "Z to A link is not working");
					}
					s_assert.assertTrue(sortlink4, "Sort link is not working for Z to A");

					Boolean sortlink5=comm.Openlinks(deshboard.sort_link);
					if (sortlink5) {
						TimeUnit.SECONDS.sleep(3);
						Boolean rating=comm.Openlinks(cuisi.rating);
						s_assert.assertTrue(rating, "Rating link is not working");
					}
					s_assert.assertTrue(sortlink5, "Sort link is not working for Rating");


					Boolean sortlink6=comm.Openlinks(deshboard.sort_link);
					if (sortlink6) {
						TimeUnit.SECONDS.sleep(3);
						Boolean open=comm.Openlinks(cuisi.open);
						s_assert.assertTrue(open, "Open link is not working");
					}
					s_assert.assertTrue(sortlink6, "Sort link is not working for Open");

					Boolean sortlink7=comm.Openlinks(deshboard.sort_link);
					if (sortlink7) {
						TimeUnit.SECONDS.sleep(3);
						Boolean close=comm.Openlinks(cuisi.closed);
						s_assert.assertTrue(close, "closed link is not working");
					}
					s_assert.assertTrue(sortlink7, "Sort link is not working for Closed");

					Boolean sortlink8=comm.Openlinks(deshboard.sort_link);
					if (sortlink7) {
						TimeUnit.SECONDS.sleep(3);
						Boolean resetbtn=comm.Openlinks(cuisi.resetBtnCuisines);
						s_assert.assertTrue(resetbtn, "Reset button is not working for Sort page");
					}
					s_assert.assertTrue(sortlink8, "Sort link is not working for Reset");



				}
				s_assert.assertTrue(sortlink, "Sort link is not working");

				Boolean search=comm.Openlinks(deshboard.search_link);
				if (search) {
					TimeUnit.SECONDS.sleep(3);
					Boolean entersearch=comm.TextField(deshboard.search_text, "Rajiv Chowk, New Delhi, Delhi, India");
					s_assert.assertTrue(entersearch, "Search text link is not working"); 
				}
				s_assert.assertTrue(search, "Search Link is not working");
			}
			s_assert.assertTrue(foodcourt, "Food cout link is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifyMenuList() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
					//s_assert.assertTrue(login, "Login link is not working");

					Boolean menuafterlogin=comm.Openlinks(deshboard.menu_link1);
					TimeUnit.SECONDS.sleep(3);
					s_assert.assertTrue(menuafterlogin, "After Login menu link is not working");

					String US=comm.Getactualtext(menu.usename_gettext);
					s_assert.assertNotNull(US, "User name is getting Null value");

					String address=comm.Getactualtext(menu.address_gettext);
					s_assert.assertNotNull(address, "address is getting Null value");

					Boolean menulist=comm.getListofLink(menu.menuList_gettext);
					s_assert.assertTrue(menulist, "Menu list is not getting");

					PageElement.searchMenu(driver,menu.searchMenuItem, "food panda");
					PageElement.tapDeviceOk(driver);

				}
				s_assert.assertTrue(menulink, "Menu link is not open");
			}
			s_assert.assertTrue(foodcourt, "Food cout link is not present");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 2, description = "")
	public void VerifyRestaurantDetails() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyRestaurantDetails()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean FP=deshboard.Openlinks(deshboard.foodPandaRestaurant_link);
				if (FP) {
					comm.Getactualtext(comm.header_gettext);
					Boolean fav=comm.Openlinks(restaurantdetails.Favlink);
					if (fav) {
						comm.IfAlertpresent();
					}
					s_assert.assertTrue(fav, "favourite link is not working");

					Boolean share=comm.Openlinks(restaurantdetails.sharelink);
					if (share) {
						driver.context("NATIVE_APP");
						
						if (!globledeviceName.equals("iPhone")) {
							Boolean sharelist=comm.getListofLink(restaurantdetails.sharelistNative_gettext);
							if (sharelist) {
								driver.navigate().back();
							}
							s_assert.assertTrue(sharelist, "Share list is not geting");
						}
						else {
							Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
							s_assert.assertTrue(icancle, "Icancle button is not working on share popup");
						}
						
						PageElement.changeContextToWebView(driver);
					}

					driver.context("NATIVE_APP");
					if (!globledeviceName.equals("iPhone")) {
						Boolean img=comm.IselementPresent(restaurantdetails.imgnative);
						if (img) {

							comm.ScrollPerticularSection(restaurantdetails.imgnative);
							comm.ScrollPerticularSection(restaurantdetails.imgnative);

							PageElement.changeContextToWebView(driver);
							Boolean playvideobtn=comm.Openlinks(restaurantdetails.playvideo);
							s_assert.assertTrue(playvideobtn, "Play btn not working");
							TimeUnit.SECONDS.sleep(10);
							driver.context("NATIVE_APP");
							driver.navigate().back();
							driver.navigate().back();
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(img, "Img is not present");
					}
					else {
						PageElement.changeContextToWebView(driver);
						Boolean img=comm.IselementPresent(restaurantdetails.i_imgnative);
						if (img) {
							driver.context("NATIVE_APP");
							comm.ScrollPerticularSection(restaurantdetails.i_imgnative);
							comm.ScrollPerticularSection(restaurantdetails.i_imgnative);

							PageElement.changeContextToWebView(driver);
							Boolean playvideobtn=comm.Openlinks(restaurantdetails.playvideo);
							s_assert.assertTrue(playvideobtn, "Play btn not working");
							TimeUnit.SECONDS.sleep(10);
							driver.context("NATIVE_APP");
							
							
							Boolean iback=comm.Openlinks(restaurantdetails.i_BackBtnVideoPage);
							s_assert.assertTrue(iback, "iBack button is not working after video play");
							
							
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(img, "Img is not present");
					}
			
					PageElement.changeContextToWebView(driver);

					Boolean FPadderss=restaurantdetails.IselementPresent(restaurantdetails.restaurantAddress_gettext);
					if (FPadderss) {
						comm.Getactualtext(restaurantdetails.restaurantAddress_gettext);
					}
					s_assert.assertTrue(FPadderss, "FP address is not present");

					Boolean storetiming=restaurantdetails.IselementPresent(restaurantdetails.storeTimings_gettext);
					if (storetiming) {
						comm.Getactualtext(restaurantdetails.storeTimings_gettext);

						Boolean storetiminglink=restaurantdetails.Openlinks(restaurantdetails.storeTimings_gettext);
						if (storetiminglink) {
							comm.Getactualtext(comm.header_gettext);

							Boolean backbtn=comm.Openlinks(comm.BackBtn);
							if (backbtn) {		
							}
							s_assert.assertTrue(backbtn, "back btn from store Timing page is not working");

						}
						s_assert.assertTrue(storetiminglink, "Store Timing link is not working");
					}
					s_assert.assertTrue(storetiming, "Store Timing is not present");

					Boolean call=comm.Openlinks(restaurantdetails.calllink);
					if (call) {
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							Boolean oknative=comm.Openlinks(restaurantdetails.OkNativeBtn);
							s_assert.assertTrue(oknative, "Ok button is not working");
						}
						else {
							Boolean oknative=PageElement.Accessibilitylinks(PageElement.i_cancel);
							s_assert.assertTrue(oknative, "iCancle call button is not working");
						}
						
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(call, "Call link is not working0?:  ");

					String deliverytime=comm.Getactualtext(restaurantdetails.deliveryTime_gettext);
					s_assert.assertNotNull(deliverytime, "Delivery time is getting null value");

					String minorder=comm.Getactualtext(restaurantdetails.minOrderAmount_gettext);
					s_assert.assertNotNull(minorder, "min order is getting null value");

					String paymentType=comm.Getactualtext(restaurantdetails.paymentOptions_gettext);
					s_assert.assertNotNull(paymentType, "payment Type is getting null value");

					String message=comm.Getactualtext(restaurantdetails.message_gettext);
					s_assert.assertNotNull(message, "Message is getting Null value");

					Boolean viewmenu=restaurantdetails.Openlinks(restaurantdetails.viewMenu_link);
					if (viewmenu) {
						TimeUnit.SECONDS.sleep(3);
						comm.Getactualtext(comm.header_gettext);
						String categoryname=comm.Getactualtext(category.categoriesName_gettext);
						s_assert.assertNotNull(categoryname, "categories Name is getting Null value");

						String productname=comm.Getactualtext(category.productName_on_categoriePage_gettext);
						s_assert.assertNotNull(productname, "product Name is getting Null value");

						String productprice=comm.Getactualtext(category.productprice_on_categoriePage_gettext);
						s_assert.assertNotNull(productprice, "product price is getting Null value");

						Boolean categoryopen=category.Openlinks(category.categories_link);
						if (categoryopen) {
							comm.Getactualtext(comm.header_gettext);
							String subcatname=comm.Getactualtext(category.subcategoryName_gettext);
							s_assert.assertNotNull(subcatname, "SubCategory name is getting Null value");

							String suncatprice=comm.Getactualtext(category.subcategoryPrice_gettext);
							s_assert.assertNotNull(suncatprice, "SubCategory Price is getting Null value");

							Boolean subcatlink=comm.Openlinks(category.subcategorylink);
							if (subcatlink) {
								comm.Getactualtext(comm.header_gettext);
								Boolean subtypedropdown=comm.Openlinks(category.subtypelink1);
								if (subtypedropdown) {

									//******************Prince(Start)								

									Boolean subtypelist=comm.getListofLink(category.subtypenamelist_gettext1);
									s_assert.assertTrue(subtypelist, "Sub type list is not getting");

									Boolean with=comm.Openlinks(category.withmashroomlinkHybride);
									s_assert.assertTrue(with, "with mashroom radio btn is not working");

									Boolean done=comm.Openlinks(category.DoneButton);
									s_assert.assertTrue(done, "Done btn is not working");

									//******************Prince(End)											


									/*driver.context("NATIVE_APP");
									Boolean subtypelist=comm.getListofLink(category.subtypenamelist_gettext1);
									s_assert.assertTrue(subtypelist, "Sub type list is not getting");

									Boolean with=comm.Openlinks(category.withmashroomlinkHybride);
									s_assert.assertTrue(with, "with mashroom radio btn is not working");

									PageElement.changeContextToWebView(driver);*/
								}
								s_assert.assertTrue(subtypedropdown, "SunType Drop list is not working");

								Boolean addtocatrt=comm.Openlinks(category.addtocartbtnsubtype);
								s_assert.assertTrue(addtocatrt, "AddToCart link is not working on SubType products page");
							}
							s_assert.assertTrue(subcatlink,"Subcat link is not working");
						}
						s_assert.assertTrue(categoryopen, "category is not open");

						Boolean backbtn=comm.Openlinks(comm.BackButton4);
						s_assert.assertTrue(backbtn, "Back Btn is not working on products page");
					}
					s_assert.assertTrue(viewmenu, "View Menu link isNot Open.");
				}
				s_assert.assertTrue(FP, "Food Panda Restaurant link is not open");
			}
			s_assert.assertTrue(foodcourt, "Food cout link is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 3, description = "")
	public void VerifyCheckOutPage() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyCheckOutPage()");
		boolean exception = false;
		try {
			Boolean foodcourt=comm.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}
				TimeUnit.SECONDS.sleep(3);
				Boolean FP=comm.Openlinks(deshboard.foodPandaRestaurant_link);
				if (FP) {
					TimeUnit.SECONDS.sleep(3);
					Boolean viewmenu=comm.Openlinks(restaurantdetails.viewMenu_link);
					if (viewmenu) {
						TimeUnit.SECONDS.sleep(3);
						Boolean addToCart=comm.Openlinks(category.addtoCartOnCatgPage);
						if (addToCart) {
							TimeUnit.SECONDS.sleep(3);
							Boolean cartLink=comm.Openlinks(category.cartlink);
							if (cartLink) {
								TimeUnit.SECONDS.sleep(3);
								comm.Getactualtext(comm.header_gettext);								
								Boolean removmitem=comm.Openlinks(cart.removeItem);
								s_assert.assertTrue(removmitem, "Remove Item is not working");
								
								if (!globledeviceName.equals("iPhone")) {
									driver.context("NATIVE_APP");
									comm.SwipeBottomToTop();
									TimeUnit.SECONDS.sleep(3);
									Boolean continueOrdering=comm.Openlinks(cart.continueOrdering_btn);
									s_assert.assertTrue(continueOrdering, "continueOrdering link is not working");
									PageElement.changeContextToWebView(driver);
								}
								else {
									TimeUnit.SECONDS.sleep(3);
									Boolean continueOrdering=comm.Openlinks(cart.i_continueOrdering_btn);
									s_assert.assertTrue(continueOrdering, "i_continueOrdering link is not working");
								}
							}
							s_assert.assertTrue(cartLink, "Cart link is not open");
						}
						s_assert.assertTrue(addToCart, "addToCart link is not working on category page");

						TimeUnit.SECONDS.sleep(7);

						Boolean addToCart1=comm.Openlinks(category.addtoCartOnCatgPage);
						if (addToCart1) {
							TimeUnit.SECONDS.sleep(3);
							Boolean cartLink1=comm.Openlinks(category.cartlink);
							if (cartLink1) {
								TimeUnit.SECONDS.sleep(3);

								String PN=comm.Getactualtext(cart.productName_gettext);
								s_assert.assertNotNull(PN, "Product name is getting Null value");

								String PP=comm.Getactualtext(cart.productPrice_gettext);
								s_assert.assertNotNull(PP, "Product Price is getting Null value");

								String PQ=comm.GetAttributevalue(cart.quanity_gettext);
								s_assert.assertNotNull(PQ, "Product quanity is getting Null value");

								Boolean increment=cart.IselementPresent(cart.increaseproduct_link);
								if (increment) {
									cart.Openlinks(cart.increaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
									cart.Openlinks(cart.increaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
									cart.Openlinks(cart.increaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
								}
								s_assert.assertTrue(increment, "Increment button is not present on cart page");

								Boolean decrement=cart.IselementPresent(cart.decreaseproduct_link);
								if (decrement) {
									cart.Openlinks(cart.decreaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
									cart.Openlinks(cart.decreaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
									cart.Openlinks(cart.decreaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
									cart.Openlinks(cart.decreaseproduct_link);
									comm.GetAttributevalue(cart.quanity_gettext);
								}
								s_assert.assertTrue(decrement, "decrement button is not present on cart page");

								Boolean coupon=cart.IselementPresent(cart.couponcodecart_text);
								if (coupon) {
									cart.TextField(cart.couponcodecart_text, "123456");

									Boolean couponapplybtn=cart.IselementPresent(cart.couponcodeapplybutton_btn);
									if (couponapplybtn) {
										cart.Openlinks(cart.couponcodeapplybutton_btn);
										TimeUnit.SECONDS.sleep(3);
										cart.IfAlertpresent();
									}
									s_assert.assertTrue(couponapplybtn, "Coupon code apply button is not present on cart page");
								}
								s_assert.assertTrue(coupon, "Coupon code Text filed is not present on cart page");

								Boolean paymentdetail=cart.IselementPresent(cart.paymentDetaisHeading_gettext);
								if (paymentdetail) {
									comm.Getactualtext(comm.header_gettext);
									Boolean subtotal=cart.IselementPresent(cart.subtotal_gettext);
									if (subtotal) {
										comm.Getactualtext(cart.subtotal_gettext);
									}
									s_assert.assertTrue(subtotal, "SubTotal is not present on cart page");

									Boolean tip=cart.IselementPresent(cart.tip_gettext);
									if (tip) {

										comm.SeekBar(cart.tipclick, "Tip");

										comm.Getactualtext(cart.tip_gettext);
									}
									s_assert.assertTrue(tip, "Tip is not present on cart page");

									Boolean gradtotal=cart.IselementPresent(cart.grandTotal_gettext);
									if (gradtotal) {
										comm.Getactualtext(cart.grandTotal_gettext);
									}
									s_assert.assertTrue(gradtotal, "Grand Total is not present on cart page");

									Boolean totalpay=cart.IselementPresent(cart.totalpayableamount_gettext);
									if (totalpay) {
										comm.Getactualtext(cart.totalpayableamount_gettext);
									}
									s_assert.assertTrue(totalpay, "Total payable amount is not present on cart page");
								}
								s_assert.assertTrue(paymentdetail, "payment details heading is not present on cart page");

								Boolean checoutbtn=cart.Openlinks(cart.checkout_btn);
								if (checoutbtn) {
									comm.Getactualtext(comm.header_gettext);									
									Boolean deliverytab=checkout.IselementPresent(checkout.DeliveryTAB);
									if (deliverytab) {
										checkout.Openlinks(checkout.DeliveryTAB);

										Boolean fn=checkout.IselementPresent(checkout.name_textfield);
										if (fn) {
											checkout.TextField(checkout.name_textfield, "Anurag Singh");
										}
										s_assert.assertTrue(fn, "first Name text filed is not present on checkout page.");


										Boolean phone=checkout.IselementPresent(checkout.Telephone_textfield);
										if (fn) {
											checkout.TextField(checkout.Telephone_textfield, "9540198626");
										}
										s_assert.assertTrue(phone, "phone text filed is not present on checkout page.");

										Boolean email=checkout.IselementPresent(checkout.Email_textfield);
										if (email) {
											checkout.TextField(checkout.Email_textfield, "prince@appypie.com");
										}
										s_assert.assertTrue(email, "Email text filed is not present on checkout page.");

										Boolean address=checkout.IselementPresent(checkout.Address_textfield);
										if (address) {
											checkout.TextField(checkout.Address_textfield, "Noida NSEZ");
										}
										s_assert.assertTrue(address, "Address text filed is not present on checkout page.");

										Boolean city=checkout.IselementPresent(checkout.City_textfield);
										if (city) {
											checkout.TextField(checkout.City_textfield, "NOIDA");
										}
										s_assert.assertTrue(city, "city text filed is not present on checkout page.");

										Boolean state=checkout.IselementPresent(checkout.State_textfield);
										if (state) {
											checkout.TextField(checkout.State_textfield, "UTTAR PRADESH");
										}
										s_assert.assertTrue(state, "state text filed is not present on checkout page.");

										Boolean zip=checkout.IselementPresent(checkout.Zip_textfield);
										if (zip) {
											checkout.TextField(checkout.Zip_textfield, "201301");
										}
										s_assert.assertTrue(zip, "zip text filed is not present on checkout page.");

										Boolean country=checkout.IselementPresent(checkout.Country_textfield);
										if (country) {
											if (!globledeviceName.equals("iPhone")) {
												checkout.Actionclick(checkout.Country_textfield);
												TimeUnit.SECONDS.sleep(1);
												driver.context("NATIVE_APP");
												checkout.countryselect();
												PageElement.changeContextToWebView(driver);
											}
											else {
												Boolean icountry=comm.Openlinks(checkout.i_countryBillingAddress);
												if (icountry) {
													driver.context("NATIVE_APP");
													Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
													s_assert.assertTrue(idone, "iDone button is not working");
													PageElement.changeContextToWebView(driver);
												}
												s_assert.assertTrue(icountry, "i_country is not selected");
											}
										
										}
										s_assert.assertTrue(country, "country text filed is not present on checkout page.");
										Logger.info("-----------------------");
										//--------						

										driver.context("NATIVE_APP");
										comm.SwipeBottomToTop();
										PageElement.changeContextToWebView(driver);

										driver.context("NATIVE_APP");
										
										DateFormat dateFormat = new SimpleDateFormat("dd");
										Date date = new Date();
										System.out.println(dateFormat.format(date));

										String value=dateFormat.format(date);
										
										PageElement.changeContextToWebView(driver);

										if (!globledeviceName.equals("iPhone")) {
											Boolean valueenter=comm.TextField(checkout.selectDeliveryDate, value);
											s_assert.assertTrue(valueenter, "preferred Date is not enter");
										}
										else {
											
											/*Boolean preferredDate=comm.Openlinks(checkout.selectDeliveryDate);
											if (preferredDate) {
												driver.context("NATIVE_APP");
												try {
												driver.findElementByAccessibilityId(value).click();
												}catch (Exception e) {
													System.out.println("Error in select iDate");
												}
												Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
												s_assert.assertTrue(idone, "iDone button is not working on date");
												
												
												PageElement.changeContextToWebView(driver);
											}
											s_assert.assertTrue(preferredDate, "preferred Date is not Open");*/
											
										}
										
										/*	WebElement element0 = driver.findElement(checkout.selectDeliveryDate);
										Actions action0= new Actions(driver);
										action0.moveToElement(element0).click().perform();

										driver.context("NATIVE_APP");
										DateFormat dateFormat = new SimpleDateFormat("dd");
										Date date = new Date();
										System.out.println(dateFormat.format(date));

										String value=dateFormat.format(date);
										PageElement.changeContextToWebView(driver);

										driver.context("NATIVE_APP");
										WebElement element1 = driver.findElementByXPath("//android.view.View[@content-desc="+value+"]");
										Actions action1 = new Actions(driver);
										action1.moveToElement(element1).click().perform();
										PageElement.changeContextToWebView(driver);

										WebElement element2 = driver.findElement(checkout.doneSelectDeliveryDate);
										Actions action2 = new Actions(driver);
										action2.moveToElement(element2).click().perform();*/

										/*Boolean preferredDate=comm.Openlinks(checkout.selectDeliveryDate);
										if (preferredDate) {

											driver.context("NATIVE_APP");
											DateFormat dateFormat = new SimpleDateFormat("dd");
											Date date = new Date();
											System.out.println(dateFormat.format(date));

											String value=dateFormat.format(date);
											PageElement.changeContextToWebView(driver);

											driver.findElement(By.xpath("//android.view.View[@content-desc="+value+"]")).click();
											comm.Openlinks(checkout.doneSelectDeliveryDate);
										}
										s_assert.assertTrue(preferredDate, "preferred Date link is not working");*/




										Boolean appotime=checkout.IselementPresent(checkout.time_droplist);
										if (appotime) {
											driver.context("NATIVE_APP");
											if (!globledeviceName.equals("iPhone")) {
												TimeUnit.SECONDS.sleep(2);
												//appointment.Openlinks(appointment.appointmenttime_droplist);
												WebElement element = driver.findElement(checkout.time_droplist);
												Actions action = new Actions(driver);
												action.moveToElement(element).click().perform();
												TimeUnit.SECONDS.sleep(2);
												checkout.Actionclick(checkout.time_droplist);
												TimeUnit.SECONDS.sleep(2);

												Boolean pm=comm.Openlinks(checkout.pmNative);
												if (pm) {
													Boolean time=comm.Openlinks(checkout.time);
													if (time) {
														Boolean setbtn=comm.Openlinks(checkout.time_Set_btn_native);
														s_assert.assertTrue(setbtn, "Set Button is not working");
													}
													s_assert.assertTrue(time, "Time 10 PM is not working");
												}
												s_assert.assertTrue(pm, "PM is not working");
											}
											else {
												//Boolean itime=PageElement.Accessibilitylinks(PageElement.i_done);
												//s_assert.assertTrue(itime, "iDone button is not working on Time seting");
											}
											
											PageElement.changeContextToWebView(driver);
										}
										s_assert.assertTrue(appotime, "appodate drop down is not present");

										if (!globledeviceName.equals("iPhone")) {
											Boolean deliverCheckBox=comm.checkbox(checkout.Deliveryaddresscheckbox);
											if (deliverCheckBox) {
												System.out.println("Already Selected");
											}
											else{
												Boolean checkBoxDelivery=comm.Openlinks(checkout.Deliveryaddresscheckbox);
												if (checkBoxDelivery) {		

													Boolean usernameDelivery=comm.TextField(myAcc.usernameDeliveryAddress, "anurag singh");
													s_assert.assertTrue(usernameDelivery, "usernameDelivery is not working");

													Boolean phoneNoDelivery=comm.TextField(myAcc.phoneNoDeliveryAddress, "1234567890");
													s_assert.assertTrue(phoneNoDelivery, "phoneNoDelivery is not working");

													Boolean addressDelivery=comm.TextField(myAcc.addressDeliveryAddress, "Noida NSEZ");
													s_assert.assertTrue(addressDelivery, "addressDelivery is not working");

													Boolean cityDelivery=comm.TextField(myAcc.cityDeliveryAddress, "Noida");
													s_assert.assertTrue(cityDelivery, "cityDelivery is not working");

													Boolean stateDelivery=comm.TextField(myAcc.stateDeliveryAddress, "Uttar Pradesh");
													s_assert.assertTrue(stateDelivery, "stateDelivery is not working");

													Boolean zipDelivery=comm.TextField(myAcc.zipDeliveryAddress, "201301");
													s_assert.assertTrue(zipDelivery, "zipDelivery is not working");

													Boolean countryDelivery=comm.Openlinks(myAcc.countryDeliveryAddress);
													if (countryDelivery) {
														if (!globledeviceName.equals("iPhone")) {
															driver.context("NATIVE_APP");
															checkout.countryselect();
															PageElement.changeContextToWebView(driver);
														}
														else {
															Boolean icountry=comm.Openlinks(myAcc.i_countryDeliveryAddress);
															s_assert.assertTrue(icountry, "i_country is not selected for DeliveryAddress");
														}
													}
													s_assert.assertTrue(countryDelivery, "countryDelivery is not working");

													Boolean instruction=comm.TextField(myAcc.instructionEnter, "Appypie Noida");
													s_assert.assertTrue(instruction, "instruction is not working");
												}
												s_assert.assertTrue(checkBoxDelivery, "checkBoxDelivery is not working");
											}
										}
										else {

											Boolean checkBoxDelivery=comm.Openlinks(checkout.Deliveryaddresscheckbox);
											if (checkBoxDelivery) {		

												Boolean usernameDelivery=comm.TextField(myAcc.usernameDeliveryAddress, "anurag singh");
												s_assert.assertTrue(usernameDelivery, "usernameDelivery is not working");

												Boolean phoneNoDelivery=comm.TextField(myAcc.phoneNoDeliveryAddress, "1234567890");
												s_assert.assertTrue(phoneNoDelivery, "phoneNoDelivery is not working");

												Boolean addressDelivery=comm.TextField(myAcc.addressDeliveryAddress, "Noida NSEZ");
												s_assert.assertTrue(addressDelivery, "addressDelivery is not working");

												Boolean cityDelivery=comm.TextField(myAcc.cityDeliveryAddress, "Noida");
												s_assert.assertTrue(cityDelivery, "cityDelivery is not working");

												Boolean stateDelivery=comm.TextField(myAcc.stateDeliveryAddress, "Uttar Pradesh");
												s_assert.assertTrue(stateDelivery, "stateDelivery is not working");

												Boolean zipDelivery=comm.TextField(myAcc.zipDeliveryAddress, "201301");
												s_assert.assertTrue(zipDelivery, "zipDelivery is not working");

												Boolean countryDelivery=comm.Openlinks(myAcc.countryDeliveryAddress);
												if (countryDelivery) {
													if (!globledeviceName.equals("iPhone")) {
														driver.context("NATIVE_APP");
														checkout.countryselect();
														PageElement.changeContextToWebView(driver);
													}
													else {
														Boolean icountry=comm.Openlinks(myAcc.i_countryDeliveryAddress);
														s_assert.assertTrue(icountry, "i_country is not selected for DeliveryAddress");
													}
												}
												s_assert.assertTrue(countryDelivery, "countryDelivery is not working");

												Boolean instruction=comm.TextField(myAcc.instructionEnter, "Appypie Noida");
												s_assert.assertTrue(instruction, "instruction is not working");
											}
											s_assert.assertTrue(checkBoxDelivery, "checkBoxDelivery is not working");
										
										}
									

										//---------prince

										Boolean Ddate=comm.Openlinks(checkout.delebiry_date);	
										if (Ddate) {
										Boolean slectDate=comm.Openlinks(checkout.set_date);
												if (slectDate) {
													System.out.println("You are ordering in weekdays");
												} 
												else

												{
													Boolean slectDate2=comm.Openlinks(checkout.set_date_Weekend);	
													s_assert.assertTrue(slectDate2, "set date is not working");
													System.out.println("You are ordering in weekend");
												}
										s_assert.assertTrue(Ddate, "deleveriry date link is not working");

										Boolean slectDone=comm.Openlinks(checkout.date);	
										s_assert.assertTrue(slectDone, "Date done button is not working");

										}
										s_assert.assertTrue(Ddate, "Deleviry date not clikable");
										
										//---------prince(end)

										Boolean confirmbtn=checkout.Openlinks(checkout.confirmbtn);
										if (confirmbtn) {
											checkout.IfAlertpresent();
											comm.Getactualtext(comm.header_gettext);											
											String order=comm.Getactualtext(OrderPre.orderPreview_getText);
											//s_assert.assertNotNull(order, "Order Preview Page data is getting Null Value");
										}
										s_assert.assertTrue(confirmbtn, "Confirm Button is not present ");

										Boolean checkoutbtn=comm.Openlinks(OrderPre.checkoutbtn);
										if (checkoutbtn) {
											comm.Getactualtext(comm.header_gettext);

											Boolean Stripee=comm.Openlinks(OrderPre.Stripe);
											s_assert.assertTrue(Stripee, "Stripe is not open");

											Boolean phonee=comm.Openlinks(OrderPre.phone);
											s_assert.assertTrue(phonee, "phone is not open");

											Boolean PayPalExpresss=comm.Openlinks(OrderPre.PayPalExpress);
											s_assert.assertTrue(PayPalExpresss, "PayPalExpress is not open");

											Boolean CreditCardd=comm.Openlinks(OrderPre.CreditCard);
											s_assert.assertTrue(CreditCardd, "CreditCard is not open");

											Boolean wallett=comm.Openlinks(OrderPre.wallet);
											s_assert.assertTrue(wallett, "wallet is not open");

											Boolean confirmbtn1=comm.Openlinks(OrderPre.confirm_btn);
											if (confirmbtn) {

												comm.Getactualtext(comm.header_gettext);

												Boolean continueOrderingthanksPage=comm.Openlinks(OrderPre.continueOrderingBtn);
												s_assert.assertTrue(continueOrderingthanksPage, "continue Ordering button is not working on Thanks Page");
											}
											s_assert.assertTrue(confirmbtn1, "Confirm Button is not open");
										}
										s_assert.assertTrue(checkoutbtn, "CheckOut button is not working");
									}
									s_assert.assertTrue(deliverytab, "Delivery TAB is not present on checkout page");
								}
								s_assert.assertTrue(checoutbtn, "Check out button is not present");
							}
							s_assert.assertTrue(cartLink1, "Cart1 link is not open");
						}
						s_assert.assertTrue(addToCart1, "addToCart1 link is not working on category page");
					}
					s_assert.assertTrue(viewmenu, "View Menu link isNot Open.");
				}
				s_assert.assertTrue(FP, "foodPanda lis is not open");
			}
			s_assert.assertTrue(foodcourt, "Food cout link is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 4, description = "")
	public void VerifyMyAccountMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyMyAccountMenu()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean menuopen=comm.Openlinks(deshboard.menu_link1);
				if (menuopen) {		

					Boolean myAccount=comm.Openlinks(menu.myAccountlink);
					if (myAccount) {	

						comm.Getactualtext(myAcc.userName_get);
						comm.Getactualtext(myAcc.location_get);

						Boolean userNameContact=comm.TextField(myAcc.userNameContactInfo, "QA");
						s_assert.assertTrue(userNameContact, "userNameContact is not working");

						/*	Boolean emailContact=comm.TextField(myAcc.emailContactInfo, "prince@appypie.com");
						s_assert.assertTrue(emailContact, "emailContact is not working");*/

						Boolean phoneNoContact=comm.TextField(myAcc.phoneNoContactInfo, "1234567890");
						s_assert.assertTrue(phoneNoContact, "phoneNoContact is not working");

						Boolean updateBtnContact=comm.Openlinks(myAcc.updateBtnContactInfo);
						if (updateBtnContact) {		
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(updateBtnContact, "updateBtnContact is not working");


						Boolean usernameBilling=comm.TextField(myAcc.usernameBillingAddress, "Anurag Singh");
						s_assert.assertTrue(usernameBilling, "usernameBilling is not working");

						Boolean phoneNoBilling=comm.TextField(myAcc.phoneNoBillingAddress, "1234567890");
						s_assert.assertTrue(phoneNoBilling, "phoneNoBilling is not working");

						Boolean addressBilling=comm.TextField(myAcc.addressBillingAddress, "Noida NSEZ");
						s_assert.assertTrue(addressBilling, "addressBilling is not working");

						Boolean cityBilling=comm.TextField(myAcc.cityBillingAddress, "Noida");
						s_assert.assertTrue(cityBilling, "cityBilling is not working");

						Boolean stateBilling=comm.TextField(myAcc.stateBillingAddress, "Uttar Pradesh");
						s_assert.assertTrue(stateBilling, "stateBilling is not working");

						Boolean zipBilling=comm.TextField(myAcc.zipBillingAddress, "201301");
						s_assert.assertTrue(zipBilling, "zipBilling is not working");

						Boolean countryBilling=comm.Openlinks(myAcc.countryBillingAddress);
						if (countryBilling) {
							
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								checkout.countryselect();
								PageElement.changeContextToWebView(driver);
							}
							else {
								Boolean icountry=comm.Openlinks(myAcc.i_countryUpdateBillingAddress);
								if (icountry) {
									driver.context("NATIVE_APP");
									Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
									s_assert.assertTrue(idone, "iDone Button is not working!!");
									PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(icountry, "i_country is not selected for Update Billing Address");
							}
						}
						s_assert.assertTrue(countryBilling, "countryBilling is not working");

						Boolean updateBtnBilling=comm.Openlinks(myAcc.updateBtnBillingAddress);
						if (updateBtnBilling) {		
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(updateBtnBilling, "updateBtnBilling is not working");

						if (!globledeviceName.equals("iPhone")) {
							Boolean deliverCheckBox=comm.checkbox(myAcc.checkBoxDeliveryAddress);
							if (deliverCheckBox) {
								System.out.println("Already Selected");
							}
							else{
								Boolean checkBoxDelivery=comm.Openlinks(myAcc.checkBoxDeliveryAddress);
								if (checkBoxDelivery) {		

									Boolean usernameDelivery=comm.TextField(myAcc.usernameDeliveryAddress, "anurag singh");
									s_assert.assertTrue(usernameDelivery, "usernameDelivery is not working");

									Boolean phoneNoDelivery=comm.TextField(myAcc.phoneNoDeliveryAddress, "1234567890");
									s_assert.assertTrue(phoneNoDelivery, "phoneNoDelivery is not working");

									Boolean addressDelivery=comm.TextField(myAcc.addressDeliveryAddress, "Noida NSEZ");
									s_assert.assertTrue(addressDelivery, "addressDelivery is not working");

									Boolean cityDelivery=comm.TextField(myAcc.cityDeliveryAddress, "Noida");
									s_assert.assertTrue(cityDelivery, "cityDelivery is not working");

									Boolean stateDelivery=comm.TextField(myAcc.stateDeliveryAddress, "Uttar Pradesh");
									s_assert.assertTrue(stateDelivery, "stateDelivery is not working");

									Boolean zipDelivery=comm.TextField(myAcc.zipDeliveryAddress, "201301");
									s_assert.assertTrue(zipDelivery, "zipDelivery is not working");

									Boolean countryDelivery=comm.Openlinks(myAcc.countryDeliveryAddress);
									if (countryDelivery) {
										driver.context("NATIVE_APP");
										if (!globledeviceName.equals("iPhone")) {
											driver.context("NATIVE_APP");
											checkout.countryselect();
											PageElement.changeContextToWebView(driver);
										}
										else {
											Boolean icountry=comm.Openlinks(myAcc.i_countryDeliveryAddress);
											if (icountry) {
												driver.context("NATIVE_APP");
												Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
												s_assert.assertTrue(idone, "iDone Button is not working...");
												PageElement.changeContextToWebView(driver);
											}
											s_assert.assertTrue(icountry, "i_country is not selected for Update Delivery Address");
										}
									}
									s_assert.assertTrue(countryDelivery, "countryDelivery is not working");

									Boolean updateBtnDelivery=comm.Openlinks(myAcc.updateBtnDeliveryAddress);
									if (updateBtnDelivery) {		
										comm.IfAlertpresent();
									}
									s_assert.assertTrue(updateBtnDelivery, "updateBtnDelivery is not working");

								}
								s_assert.assertTrue(checkBoxDelivery, "checkBoxDelivery is not working");
							}
						}
						else {

							Boolean checkBoxDelivery=comm.Openlinks(myAcc.checkBoxDeliveryAddress);
							if (checkBoxDelivery) {		

								Boolean usernameDelivery=comm.TextField(myAcc.usernameDeliveryAddress, "anurag singh");
								s_assert.assertTrue(usernameDelivery, "usernameDelivery is not working");

								Boolean phoneNoDelivery=comm.TextField(myAcc.phoneNoDeliveryAddress, "1234567890");
								s_assert.assertTrue(phoneNoDelivery, "phoneNoDelivery is not working");

								Boolean addressDelivery=comm.TextField(myAcc.addressDeliveryAddress, "Noida NSEZ");
								s_assert.assertTrue(addressDelivery, "addressDelivery is not working");

								Boolean cityDelivery=comm.TextField(myAcc.cityDeliveryAddress, "Noida");
								s_assert.assertTrue(cityDelivery, "cityDelivery is not working");

								Boolean stateDelivery=comm.TextField(myAcc.stateDeliveryAddress, "Uttar Pradesh");
								s_assert.assertTrue(stateDelivery, "stateDelivery is not working");

								Boolean zipDelivery=comm.TextField(myAcc.zipDeliveryAddress, "201301");
								s_assert.assertTrue(zipDelivery, "zipDelivery is not working");

								Boolean countryDelivery=comm.Openlinks(myAcc.countryDeliveryAddress);
								if (countryDelivery) {
									driver.context("NATIVE_APP");
									if (!globledeviceName.equals("iPhone")) {
										driver.context("NATIVE_APP");
										checkout.countryselect();
										PageElement.changeContextToWebView(driver);
									}
									else {
										Boolean icountry=comm.Openlinks(myAcc.i_countryDeliveryAddress);
										if (icountry) {
											driver.context("NATIVE_APP");
											Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
											s_assert.assertTrue(idone, "iDone Button is not working...");
											PageElement.changeContextToWebView(driver);
										}
										s_assert.assertTrue(icountry, "i_country is not selected for Update Delivery Address");
									}
								}
								s_assert.assertTrue(countryDelivery, "countryDelivery is not working");

								Boolean updateBtnDelivery=comm.Openlinks(myAcc.updateBtnDeliveryAddress);
								if (updateBtnDelivery) {		
									comm.IfAlertpresent();
								}
								s_assert.assertTrue(updateBtnDelivery, "updateBtnDelivery is not working");

							}
							s_assert.assertTrue(checkBoxDelivery, "checkBoxDelivery is not working");
						
							
						}
						
				
					}
					s_assert.assertTrue(myAccount, "My Account is not working");
				}
				s_assert.assertTrue(menuopen, "Menu link is not working");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VerifyFavoriteMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyFavoriteMenu()");
		boolean exception = false;
		try {

			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean menuopen=comm.Openlinks(deshboard.menu_link1);
				if (menuopen) {	
					Boolean favorite=comm.Openlinks(menu.favoritelink);
					if (favorite) {		
						comm.Getactualtext(comm.header_gettext);
						try{
							comm.getListofLink(fav.favList_get);

							Boolean openn=comm.Openlinks(fav.openFavProduct);
							if (openn) {
								Boolean backbtn=comm.Openlinks(comm.BackButton1);
								s_assert.assertTrue(backbtn, "backbtn is not working after open fav product link");
							}
							s_assert.assertTrue(openn, "Fav product link is not open");
						}
						catch (Exception e) {
							System.out.println("Favorite List is not present");
						}
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "backbtn is not working");
					}
					s_assert.assertTrue(favorite, "favorite link is not working");
				}
				s_assert.assertTrue(menuopen, "Menu link is not working");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VerifyOfferedMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyOfferedMenu()");
		boolean exception = false;
		try {

			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean menuopen=comm.Openlinks(deshboard.menu_link1);
				if (menuopen) {	
					Boolean offered=comm.Openlinks(menu.offeredlink);
					if (offered) {
						comm.Getactualtext(comm.header_gettext);

						try{
							comm.getListofLink(offer.offeredList_get);

							Boolean openn=comm.Openlinks(offer.openOfferedProduct);
							if (openn) {
								Boolean backbtn=comm.Openlinks(comm.BackButton1);
								s_assert.assertTrue(backbtn, "backbtn is not working after open fav product link");
							}
							s_assert.assertTrue(openn, "Offered product link is not open");

						}
						catch (Exception e) {
							System.out.println("Offered List is not present");
						}
						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "backbtn is not working");

					}
					s_assert.assertTrue(offered, "offered link is not working");
				}
				s_assert.assertTrue(menuopen, "Menu link is not working");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 7, description = "")
	public void VerifyMyOrdersMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyMyOrdersMenu()");
		boolean exception = false;
		try {

			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean menuopen=comm.Openlinks(deshboard.menu_link1);
				if (menuopen) {	
					Boolean myOrder=comm.Openlinks(menu.myOrderlink);
					if (myOrder) {	
						comm.Getactualtext(comm.header_gettext);
						comm.getListofLink(myorder.pendingStatus_get);
						comm.getListofLink(myorder.completedStatus_get);
						comm.getListofLink(myorder.myOrderList_get);

						Boolean foodpandaPendingg=comm.Openlinks(myorder.foodpandaPending);
						if (foodpandaPendingg) {
							comm.Getactualtext(myorder.time_get);
							comm.Getactualtext(myorder.estimatedDeliveryTime_get);

							Boolean call=comm.Openlinks(myorder.contactSuppotP);
							if (call) {
								driver.context("NATIVE_APP");
								if (!globledeviceName.equals("iPhone")) {
									TimeUnit.SECONDS.sleep(3);
									Boolean oknative=comm.Openlinks(restaurantdetails.OkNativeBtn);
									s_assert.assertTrue(oknative, "Ok button is not working");
								
								}
								else {
									Boolean icallcancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
									s_assert.assertTrue(icallcancle, "iCall cancle button is not working");
								}
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(call, "contactSuppot link is not working");
						}
						s_assert.assertTrue(foodpandaPendingg, "foodpandaPending is not working");


						Boolean backbtn=comm.Openlinks(comm.BackButton1);
						s_assert.assertTrue(backbtn, "backbtn is not working");

					}
					s_assert.assertTrue(myOrder, "myOrder link is not working");
				}
				s_assert.assertTrue(menuopen, "Menu link is not working");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 8, description = "")
	public void VerifyCartMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyCartMenu()");
		boolean exception = false;
		try {

			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean menuopen=comm.Openlinks(deshboard.menu_link1);
				if (menuopen) {	
					Boolean cart=comm.Openlinks(menu.cartlink);
					if (cart) {		
						comm.Getactualtext(comm.header_gettext);
						TimeUnit.SECONDS.sleep(3);
						Boolean continueOrdering=comm.Openlinks(this.cart.continueOrderinglink);
						s_assert.assertTrue(continueOrdering, "continueOrdering is not working");
					}
					s_assert.assertTrue(cart, "cart link is not working");
				}
				s_assert.assertTrue(menuopen, "Menu link is not working");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 9, description = "")
	public void VerifyHeaderSearch() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyHeaderSearch()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean headerSearchh=comm.Openlinks(deshboard.headerSearch);
				if (headerSearchh) {
					comm.Getactualtext(comm.header_gettext);
					Boolean search=comm.TextField(deshboard.enterSearch, "Noida");
					if (search) {		
						Boolean selectDrop=comm.Openlinks(deshboard.selectDropcity);
						if (selectDrop) {		
							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "backbtn is not working");
						}
						s_assert.assertTrue(selectDrop, "selectDrop is not working");
					}
					s_assert.assertTrue(search, "search location is not working");
				}
				s_assert.assertTrue(headerSearchh, "headerSearch is not working");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 10, description = "")
	public void VerifyHyperLink() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyHyperLink()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean FP=deshboard.Openlinks(deshboard.foodPandaRestaurant_link);
				if (FP) {

					Boolean showmore=restaurantdetails.Openlinks(restaurantdetails.showMore_link);
					if (showmore) {
						String cuisinetext=restaurantdetails.Getactualtext(restaurantdetails.cuisine_gettext);
						s_assert.assertNotNull(cuisinetext, "Cuisine Info is getting null value");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
						Boolean hide=comm.Openlinks(restaurantdetails.hideall_link);
						s_assert.assertTrue(hide, "Hide all link is not working");
					}
					s_assert.assertTrue(showmore, "Show More link is not Open");

					Boolean hreflink=comm.Openlinks(restaurantdetails.hyperlink);
					if (hreflink) {
						driver.context("NATIVE_APP");	
						if (!globledeviceName.equals("iPhone")) {
							comm.Getactualtext(comm.header_gettext_native);

							Boolean back=comm.Openlinks(comm.BackButtonNative);
							s_assert.assertTrue(back, "Back button is not working on Href link page");
						}
						else {
							Boolean iback=comm.Openlinks(comm.i_BackButtonNative);
							s_assert.assertTrue(iback, "i_Back button is not working on Href link page");
						}
					
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(hreflink, "Href link is not working");


				}
				s_assert.assertTrue(FP, "Food Panda Restaurant link is not open");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 11, description = "")
	public void VerifySortBySubCatgoryProduct() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifySortBySubCatgoryProduct()");
		boolean exception = false;
		try {
			Boolean foodcourt=deshboard.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}

				Boolean FP=deshboard.Openlinks(deshboard.foodPandaRestaurant_link);
				if (FP) {
					Boolean viewmenu=restaurantdetails.Openlinks(restaurantdetails.viewMenu_link);
					if (viewmenu) {
						Boolean categoryopen=category.Openlinks(category.categories_link);
						if (categoryopen) {

							Boolean sortBy=comm.Openlinks(category.sortBydroplink);
							if (sortBy) {	
								
								if (!globledeviceName.equals("iPhone")) {
									driver.context("NATIVE_APP");
									Boolean LH=comm.Openlinks(category.LHNative);
									s_assert.assertTrue(LH, "LH is not working");
									PageElement.changeContextToWebView(driver);
								}
								else {
									Boolean iLH=comm.Openlinks(category.i_LHNative);
									s_assert.assertTrue(iLH, "i_LH is not working");
								}
						

							
								if (!globledeviceName.equals("iPhone")) {
									driver.context("NATIVE_APP");
									Boolean HL=comm.Openlinks(category.HLNative);
									s_assert.assertTrue(HL, "HL is not working");
									PageElement.changeContextToWebView(driver);
								}
								else {
									Boolean iHL=comm.Openlinks(category.i_HLNative);
									s_assert.assertTrue(iHL, "i_HL is not working");
								}
								
							}
							s_assert.assertTrue(sortBy, "sortBy is not working");

						}
						s_assert.assertTrue(categoryopen, "category is not open");
					}
					s_assert.assertTrue(viewmenu, "View Menu link isNot Open.");
				}
				s_assert.assertTrue(FP, "Food Panda Restaurant link is not open");
			}
			s_assert.assertTrue(foodcourt, "Food Code Module is not Open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 12, description = "")
	public void VerifyDeliveryAndPickUpTAB() throws Exception {
		SoftAssert s_assert = new SoftAssert();	
		Logger.info("Test Case:  VerifyDeliveryAndPickUpTAB()");
		boolean exception = false;
		try {
			Boolean foodcourt=comm.Openlinks(deshboard.foodCourtModulelink);
			if (foodcourt) {
				TimeUnit.SECONDS.sleep(3);
				Boolean menulink=comm.Openlinks(deshboard.menu_link1);
				if (menulink) {
					TimeUnit.SECONDS.sleep(3);
					Boolean login=comm.IselementPresent(deshboard.loginlink);
					if (login) {
						comm.Openlinks(deshboard.loginlink);
						TimeUnit.SECONDS.sleep(3);
						PageElement.login(driver, deshboard.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else{
						System.out.println("User is Already Ready");
						comm.Openlinks(menu.mainMenulink);
					}
				}
				TimeUnit.SECONDS.sleep(3);
				Boolean FP=comm.Openlinks(deshboard.foodPandaRestaurant_link);
				if (FP) {
					TimeUnit.SECONDS.sleep(3);
					Boolean viewmenu=comm.Openlinks(restaurantdetails.viewMenu_link);
					if (viewmenu) {
						TimeUnit.SECONDS.sleep(7);

						Boolean addToCart1=comm.Openlinks(category.addtoCartOnCatgPage);
						if (addToCart1) {
							TimeUnit.SECONDS.sleep(3);
							Boolean cartLink1=comm.Openlinks(category.cartlink);
							if (cartLink1) {
								TimeUnit.SECONDS.sleep(3);

								Boolean checoutbtn=cart.Openlinks(cart.checkout_btn);
								if (checoutbtn){
									Boolean Deliverytab=comm.Openlinks(checkout.DeliveryTAB);
									if (Deliverytab) {	
										Boolean viewStoreTiming=comm.Openlinks(checkout.viewStoreTimingbtn);
										if (viewStoreTiming) {
											comm.Getactualtext(comm.header_gettext);

											comm.Getactualtext(checkout.openingTime_gettext);
											comm.Getactualtext(checkout.openingTimeList_gettext);

											comm.Getactualtext(checkout.customerServingTiming_gettext);
											comm.Getactualtext(checkout.customerServingTimingList_gettext);

											Boolean backbtn=comm.Openlinks(comm.BackBtn);
											s_assert.assertTrue(backbtn, "backbtn is not working");
										}
										s_assert.assertTrue(viewStoreTiming, "viewStoreTiming is not working");
									}
									s_assert.assertTrue(Deliverytab, "Delivery Tab is not working");

									driver.context("NATIVE_APP");
									comm.SwipetopTobottom();
									PageElement.changeContextToWebView(driver);


									Boolean Pickuptab=comm.Openlinks(checkout.PickupTAB);
									if (Pickuptab) {
									/*	Boolean address=comm.Openlinks(checkout.adressclickHbride);
										if (address) {	
											driver.context("NATIVE_APP");
											
											Boolean selectaddress=comm.Openlinks(checkout.selectaddressNative);
											//s_assert.assertTrue(selectaddress, "selectaddress is not working");
											PageElement.changeContextToWebView(driver);
										}
										s_assert.assertTrue(address, "address is not working");*/
										//*******************Prince



										Boolean date=comm.Openlinks(checkout.pickup_date);	
										if (date) {

											Boolean slectDate=comm.Openlinks(checkout.set_date);
											if (slectDate) {
												System.out.println("You are ordering in weekdays");
											} 
											else

											{
												Boolean slectDate2=comm.Openlinks(checkout.set_date_Weekend);	
												s_assert.assertTrue(slectDate2, "set date is not working");
												System.out.println("You are ordering in weekend");
											}
											s_assert.assertTrue(slectDate, "set date is not working");

											Boolean slectDone=comm.Openlinks(checkout.date);	
											s_assert.assertTrue(slectDone, "Date done button is not working");

										}

										s_assert.assertTrue(date, "Delivery Tab is not working");

										//*******************Prince(end)

										Boolean estimatedDelivery=comm.Openlinks(checkout.estimatedDeliverytime2);
										if (estimatedDelivery) {	
											driver.context("NATIVE_APP");
											if (!globledeviceName.equals("iPhone")) {
												Boolean pm=comm.Openlinks(checkout.pmNative);
												//s_assert.assertTrue(pm, "PM time is not working");

												Boolean Time=comm.Openlinks(checkout.time);
												//s_assert.assertTrue(Time, "Time is not working");

												Boolean setbtn=comm.Openlinks(checkout.time_Set_btn_native);
												//	s_assert.assertTrue(setbtn, "set btn is not working");
											}
											else {
												Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
												s_assert.assertTrue(idone, "iDone Button is not working");
											}
											PageElement.changeContextToWebView(driver);
										}
										s_assert.assertTrue(estimatedDelivery, "estimatedDeliverytime is not working");

										Boolean viewStoreTiming=comm.Openlinks(checkout.viewStoreTimingPickupTab);
										if (viewStoreTiming) {	
											Boolean backbtnn=comm.Openlinks(comm.BackBtn);
											s_assert.assertTrue(backbtnn, "back btn is not working");
										}
										s_assert.assertTrue(viewStoreTiming, "viewStoreTiming is not working");


										Boolean instructions=comm.TextField(checkout.instructionsPickUpTAB, "Appypie Noida");
										s_assert.assertTrue(instructions, "instructions is not working");

										Boolean billingCheckBox=comm.checkbox(checkout.billingAddressCheckBoxPickUpTAb);
										if (billingCheckBox) {
											System.out.println("Already Selected");
										}
										else{
											Boolean checkBoxBilling=comm.Openlinks(checkout.billingAddressCheckBoxPickUpTAb);
											if (checkBoxBilling) {		

												Boolean UNBilling=comm.TextField(checkout.usernameBillingAddress, "QA");
												s_assert.assertTrue(UNBilling, "UNBilling is not working");

												Boolean phoneNOBilling=comm.TextField(checkout.phoneNoBillingAddress, "1234567890");
												s_assert.assertTrue(phoneNOBilling, "phoneNOBilling is not working");

												Boolean emailBilling=comm.TextField(checkout.emailAddressBillingAddress, "prince@appypie.com");
												s_assert.assertTrue(emailBilling, "emailBilling is not working");

												Boolean addressBilling=comm.TextField(checkout.addressBillingAddress, "Noida NSEZ");
												s_assert.assertTrue(addressBilling, "addressBilling is not working");

												Boolean cityBilling=comm.TextField(checkout.cityBillingAddress, "Noida");
												s_assert.assertTrue(cityBilling, "cityBilling is not working");

												Boolean stateBilling=comm.TextField(checkout.stateBillingAddress, "Uttar Pradesh");
												s_assert.assertTrue(stateBilling, "stateBilling is not working");

												Boolean zipBilling=comm.TextField(checkout.zipBillingAddress, "201301");
												s_assert.assertTrue(zipBilling, "zipBilling is not working");

												Boolean countryBilling=comm.Openlinks(checkout.countryBillingAddress);
												if (countryBilling) {
													driver.context("NATIVE_APP");
													if (!globledeviceName.equals("iPhone")) {
														driver.context("NATIVE_APP");
														checkout.countryselect();
														PageElement.changeContextToWebView(driver);
													}
													else {
														Boolean icountry=comm.Openlinks(checkout.i_countryBillingAddress);
														s_assert.assertTrue(icountry, "i_country is not selected for Billing Address");
													}
												}
												s_assert.assertTrue(countryBilling, "countryBilling is not working");





												Boolean confirmBtn=comm.Openlinks(checkout.confirmBtnBillingAddress);
												if (confirmBtn) {		
													comm.Getactualtext(comm.header_gettext);

													comm.Getactualtext(checkout.orderPreviewHeading_gettext);
													comm.Getactualtext(checkout.itemHeading_gettext);
													comm.Getactualtext(checkout.itemName_PaymentDetails_gettext);
													comm.Getactualtext(checkout.billingAddressHeading_gettext);
													/*comm.Getactualtext(checkout.namebilling_gettext);
													comm.Getactualtext(checkout.mobilebilling_gettext);
													comm.Getactualtext(checkout.emailIDbilling_gettext);
													comm.Getactualtext(checkout.billingAddress_gettext);
													comm.Getactualtext(checkout.pickUpAddressHeading_gettext);
													comm.Getactualtext(checkout.namepickUp_gettext);
													comm.Getactualtext(checkout.mobilepickUp_gettext);
													comm.Getactualtext(checkout.emailidpickUp_gettext);
													comm.Getactualtext(checkout.pickUpAddress_gettext);*/
													Boolean checoutagainn=comm.Openlinks(checkout.checkoutAgain);
													if (checoutagainn) {		
														comm.IfAlertpresent();
													}
													s_assert.assertTrue(checoutagainn, "checoutagain is not working");

													Boolean PaywithCC=comm.Openlinks(OrderPre.phone);
													if (PaywithCC) {

														Boolean call=comm.Openlinks(OrderPre.callme);
														if (call) {
															driver.context("NATIVE_APP");
															if (!globledeviceName.equals("iPhone")) {
																Boolean oknative=comm.Openlinks(restaurantdetails.OkNativeBtn);
																s_assert.assertTrue(oknative, "Ok button is not working");
															}
															else {
																Boolean icancle=PageElement.Accessibilitylinks(PageElement.i_cancel);
																s_assert.assertTrue(icancle, "iCancle call button is not working");
															}
														
															PageElement.changeContextToWebView(driver);

															//comm.Getactualtext(comm.header_gettext);

															comm.Getactualtext(OrderPre.orderconfirmationHeading_getText);
															comm.Getactualtext(OrderPre.orderconfirmationDetails_getText);
															comm.Getactualtext(OrderPre.oderIDPaymentType_getText);
															//	comm.Getactualtext(OrderPre.productNamePayment_getText);
															comm.Getactualtext(OrderPre.billingPickUpAddress_getText);

															Boolean continueOrdering=comm.Openlinks(OrderPre.continueOrderingBtnthnakspage);
															if (continueOrdering) {		
																comm.IfAlertpresent();
															}
															s_assert.assertTrue(continueOrdering, "continueOrdering is not working");

														}
														s_assert.assertTrue(call, "Call link is not working0?:  ");
													}
													s_assert.assertTrue(PaywithCC, "Paywithcreditcard payment gatway not open");
												}
												s_assert.assertTrue(confirmBtn, "confirmBtn Billing address is not working");
											}
											s_assert.assertTrue(checkBoxBilling, "checkBoxBilling is not working");
										}
									}
									s_assert.assertTrue(Pickuptab, "Pickup Tab is not working");
								}
								s_assert.assertTrue(checoutbtn, "Check out button is not present");
							}
							s_assert.assertTrue(cartLink1, "Cart1 link is not open");
						}
						s_assert.assertTrue(addToCart1, "addToCart1 link is not working on category page");
					}
					s_assert.assertTrue(viewmenu, "View Menu link isNot Open.");
				}
				s_assert.assertTrue(FP, "foodPanda lis is not open");
			}
			s_assert.assertTrue(foodcourt, "Food cout link is not present");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			System.out.println("====================");
			PageElement.printExceptionTrace(e);
			System.out.println("====================");
			exception = true;
			s_assert.assertFalse(exception, "\n" + deshboard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



}


