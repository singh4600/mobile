package com.appypie.tests;


import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieLinkedinPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;



public class AppypieLinkedinTest extends TestSetup {

	AppypieLinkedinPage linkedin;
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	

	@BeforeTest
	@Override
	public void pageSetUp() {
		linkedin = new AppypieLinkedinPage(driver);
	}

	//@Test
	public void verifyLinkedInPage(){
		Logger.info("********Test Method Start: verifyLinkedInPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			linkedin.openLinkedInPage();
			Thread.sleep(2000);
			boolean Open = linkedin.identifyLinkedInOpen();
			if (Open) {
				String header = PageElement.getPageHeader(driver);
				PageElement.tapBackButton(driver);
				asser.assertEquals(PageElement.getAppName(driver), "Automate");
				asser.assertEquals(header, "Linkedin");
			} else {
				Logger.info("Linkedin Page is not open from main menu");
			}
			asser.assertTrue(Open, "Linkedin Page is not Open by clicking the main menu icon");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the Linkedin page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();     
	}

	@Test
	public void verifyLinkedInUrl() {
		Logger.info("********Test Method Start: verifyLinkedInUrl********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			linkedin.openLinkedInPage();
			Thread.sleep(2000);
			linkedin.openLinkedInUrl();
			boolean info = linkedin.checklinkedInOpen();     
			asser.assertTrue(info, "LinkedIn url is not opening or feeds are not present in the LinkedIn url");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the LinkedIn URL'S", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
