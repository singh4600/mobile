package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieFourSquarePage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypirFourSquareTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieFourSquarePage fsquare;
	AppypieMenuPage menu;

	@Override
	@BeforeTest
	public void pageSetUp() {
		fsquare = new AppypieFourSquarePage(driver);
		menu = new AppypieMenuPage(driver);
	}
	
	@Test
	public void verifyFourSquarePage() {
		Logger.info("Test Methods start: verifyFourSquarePage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("foursquare");
			boolean pageOpen = PageElement.isContentOpenInNative(driver,"Four Square");
			asser.assertTrue(pageOpen,"FourSquare url is not open in native");
		} catch (Exception e) {
			Logger.error("Error occurs while verifying FourSquare page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

}
