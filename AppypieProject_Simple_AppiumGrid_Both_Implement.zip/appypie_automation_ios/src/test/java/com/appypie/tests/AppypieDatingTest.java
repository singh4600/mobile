package com.appypie.tests;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.datingpages.DatingHomePage;
import com.appypie.pages.datingpages.DatingMenuPage;
import com.appypie.pages.datingpages.MessagesPage;
import com.appypie.pages.datingpages.MyMatchPage;
import com.appypie.pages.datingpages.MyProfilePage;
import com.appypie.pages.datingpages.NotificationPage;
import com.appypie.pages.datingpages.UserFormPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.FileHandler;
import com.appypie.util.ImageUtil;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class AppypieDatingTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	DatingHomePage home;
	DatingMenuPage menu;
	MessagesPage msg;
	MyMatchPage match;
	MyProfilePage profile;
	AppypieMenuPage app;
	UserFormPage form;
	NotificationPage notify;

	@Override
	@BeforeTest
	public void pageSetUp() {
		home = new DatingHomePage(driver);
		menu = new DatingMenuPage(driver);
		msg = new MessagesPage(driver);
		match = new MyMatchPage(driver);
		profile = new MyProfilePage(driver);
		app = new AppypieMenuPage(driver);
		form = new UserFormPage(driver);
		notify = new NotificationPage(driver);
	}

	public boolean verifyDatingLoginAndHome(String mail, String pwd) {
		boolean success = false;
		boolean loginPage = false;
		try {
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (!login) {
				Logger.info("user is already login into the app");
				Thread.sleep(4000);
				if (home.isDatingHomePageOpen()) {
					home.clickMenu();
					if (menu.isDatingMenuOpen()) {
						String profile = menu.getprofileEmail();
						if (profile.equals(mail)) {
							success = true;
							menu.closeMenu();
							Thread.sleep(2000);
						} else {
							menu.profileLogOut();
							Thread.sleep(3000);
							app.openPage("dating");
							loginPage = true;
						}
					} else {
						Logger.error("Dating menu is not open");
					}
				} else {
					Logger.error("user is login into dating page but home page is not open");
				}
			} else {
				loginPage = true;
			}
			if (loginPage) {
				LoginUtil.loginIntoPage(driver, mail, pwd);
				Thread.sleep(5000);
				if (home.isDatingHomePageOpen()) {
					success = true;
				} else {
					Logger.error("login is not successful in dating page");
				}
			}
		} catch (Exception e) {
			Logger.error("exception occurs while login into dating page", e);
		}
		return success;
	}

	public boolean registerNewUser() {
		boolean loginPage = false;
		boolean newUser = false;
		try {
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (!login) {
				if (home.isDatingHomePageOpen()) {
					home.clickMenu();
					Thread.sleep(1000);
					menu.profileLogOut();
					Thread.sleep(1000);
					app.openPage("dating");
					if (LoginUtil.isLoginPageOpen(driver))
						loginPage = true;
				} else {
					if (form.isRegistrationFormOpen()) {
						newUser = true;
					} else {
						Logger.info("dating page is not open from main menu");
					}
				}
			} else {
				Logger.info("login page is open");
				loginPage = true;
			}
			if (loginPage) {
				LoginUtil.signUp(driver);
				if (LoginUtil.isSignUpOpen(driver)) {
					LoginUtil.registerUserForDating(driver);
					if (form.isRegistrationFormOpen()) {
						newUser = true;
					} else {
						Logger.info("registration form is not open with new user registration");
					}
				} else {
					Logger.info("Sign up page is not open");
				}
			} else {
				Logger.info("login page is not open again after logout existing user from dating page or registration form is already open");
			}

		} catch (Exception e) {
			Logger.error("login with new user is not successful",e);
		}
		return newUser;
	}

	 @Test
	public void verifyDatingPage() {
		Logger.info("********Test Method Start: verifyDatingPage********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean login = LoginUtil.isLoginPageOpen(driver);
			if (login) {
				LoginUtil.loginIntoPage(driver, "pk@pk.com", "12345678");
				Thread.sleep(2000);
			} else {
				Logger.info("user is already login into the app");
			}
			asser.assertTrue(home.isDatingHomePageOpen(), "Dating page is not open from main menu");
		} catch (Exception e) {
			Logger.error("Error occurs while opening the dating page", e);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	 @Test
	public void verifyHomeandMainMenuInDating() {
		Logger.info("********Test Methods start: verifyHomeandMainMenuInDating********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean loginSuccess = verifyDatingLoginAndHome("pk@pk.com", "12345678");
			if (loginSuccess) {
				Thread.sleep(2000);
				home.clickMenu();
				boolean menuOpen = menu.isDatingMenuOpen();
				if (menuOpen) {
					menu.clickMainMenu();
					asser.assertTrue(home.isDatingHomePageOpen(),
							"Home page is not open upon clicking on main menu in Dating");
				} else {
					Logger.info("Dating menu is not open upon clicking on menu button from Dating home page");
					asser.assertTrue(menuOpen, "Dating menu is not open");
				}
			} else {
				asser.assertTrue(loginSuccess, "login failure in dating page or home page is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying home and menu button from Dating menu", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	 @Test
	public void verifyMyProfileFunctionalities() {
		Logger.info("********Test Methods start: verifyMyProfileFunctionalities********");
		asser = new SoftAssert();
		boolean exception = false;
		String url1 = "";
		String url2 = "";
		try {
			app.openPage("dating");
			boolean homePage = verifyDatingLoginAndHome("pk@pk.com", "12345678");
			if (homePage) {
				home.clickMenu();
				boolean menuOpen = menu.isDatingMenuOpen();
				if (menuOpen) {
					menu.clickMyProfile();
					boolean profileOpen = profile.isProfilePageOpen();
					if (profileOpen) {
						profile.clickEditProfile();
						boolean editProfileOpen = profile.isEditProfileOpen();
						if (editProfileOpen) {
							// *********verify update profile without image and
							// update profile button on header****
							profile.removeProfileImg("one");
							profile.removeProfileImg("two");
							profile.updateProfileFromHeaderLink();
							String warning = PageElement.getWarningText(driver);
							asser.assertEquals(warning, "Please Upload at least one pic");
							if (warning != "")
								PageElement.closeWarningSingleBtn(driver,"Ok");

							// *******Verification of upload
							// profile***************
							profile.clickProfileImg("one");
							PageElement.closeWarningSingleBtn(driver, "Upload Image from Gallery");
								// *******Verification of upload image from gallery********
								//profile.openGallery();
								Thread.sleep(3000);
								PageElement.tapOnScreen(driver, 0.24, 0.24);
								Thread.sleep(2000);
//								if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
//									PageElement.tapOnScreen(driver, 0.05, 0.15);
//									Thread.sleep(2000);
//								}
								url1 = profile.getImageUrl("one");
							

//							profile.clickProfileImg("two");
//							PageElement.closeWarningSingleBtn(driver, "Upload Image from Gallery");
//							//	profile.openGallery();
//								Thread.sleep(3000);
//								PageElement.tapOnScreen(driver, 0.52, 0.24);
//								Thread.sleep(2000);
////								if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
////									PageElement.tapOnScreen(driver, 0.05, 0.15);
////									Thread.sleep(2000);
////								}	
//								url2 = profile.getImageUrl("two");
							
							profile.enterCompanyName("Appypie");
							profile.updateProfile();
							Thread.sleep(2000);
							asser.assertEquals(profile.getProfileDetail(), "TestName, 28");
							Thread.sleep(2000);
							asser.assertTrue(profile.getCompanyName().contains("Appypie"),"company name is not updated");
							asser.assertNotNull(url1, "first profile image is not uploaded");
							//asser.assertNotNull(url2, "second profile image is not uploaded");
							asser.assertNotNull(profile.getImageUrlonMyProfile(),
									"uploaded image is not displayed on my profile");
						} else {
							asser.assertTrue(profileOpen, "edit profile is not open from myprofile page");
						}
					} else {
						asser.assertTrue(profileOpen, "profile page is not open from main menu");
					}
				} else {
					Logger.info("Dating menu is not open upon clicking on menu button from Dating home page");
					asser.assertTrue(menuOpen, "Dating menu is not open");
				}
			} else {
				Logger.info("Dating page is not open in app");
				asser.assertTrue(homePage, "login failure in dating page or home page is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying myprofile functionalities", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyUserRegisterSearchAndNotifications() {
		Logger.info("********Test Methods start: verifyUserRegisterSearchAndNotifications********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean homePage = registerNewUser();
			if (homePage) {
				// *********verification of distance slider********
				 form.identifyUser("female");
				// form.movedistanceSlider(); 
				// *********submission of blank form********
				form.saveUserDetail();
				String warning_blank = PageElement.getWarningText(driver);
				asser.assertEquals(warning_blank, "Please select DOB");
				if (warning_blank != "") {
					PageElement.closeWarningSingleBtn(driver,"Ok");
				}
				// *********verification of dob********
				form.enterdob("6/11/2017");
				form.saveUserDetail();
				String warning_dob = PageElement.getWarningText(driver);
				asser.assertEquals(warning_dob, "Sorry! You are under 18");
				if (warning_dob != "") {
					PageElement.closeWarningSingleBtn(driver,"Ok");
				}

				// *********verification of about us********
				form.enterdob("6/11/1989");
				form.saveUserDetail();
				String warning_about = PageElement.getWarningText(driver);
				asser.assertEquals(warning_about, "Please fill in the empty blanks");
				if (warning_about != "") {
					PageElement.closeWarningSingleBtn(driver,"Ok");
				}

				// *********verification of title********
				form.enterdob("6/11/1989");
				form.enterAboutMe("Passionate");
				form.saveUserDetail();
				String warning_title = PageElement.getWarningText(driver);
				asser.assertEquals(warning_title, "Please enter title");
				if (warning_title != "") {
					PageElement.closeWarningSingleBtn(driver,"Ok");
				}
				// *********verification of details save********
				form.enterdob("6/11/1989");
				form.enterAboutMe("Passionate");
				form.enterTitle("Activeuser" + FileHandler.fileReader("UserValue"));
				form.moveAgeSlider();
				form.saveUserDetail();
				Thread.sleep(2000);
				form.clickAcceptContinue();
				Thread.sleep(1000);
				//form.clickNextOnProfileUpload();
				// *********verification of details save without upload profile picture********
				profile.uploadPhoto();
				String warning_upload = PageElement.getWarningText(driver);
				asser.assertEquals(warning_upload, "Please Upload at least one pic");
				if (warning_upload != "") {
					PageElement.closeWarningSingleBtn(driver,"Ok");
					Thread.sleep(1000);
				}

				// *******Verification of upload profile***************
				profile.clickProfileImg("one");
				PageElement.closeWarningSingleBtn(driver, "Upload Image from Gallery");
				
					// *******Verification of upload image from gallery********
					//profile.openGallery();
					Thread.sleep(3000);
					PageElement.tapOnScreen(driver, 0.24, 0.24);
					Thread.sleep(2000);
				

				// *** verification of partner search***
				profile.uploadPhoto();
				Thread.sleep(5000);
				boolean partner = home.isPartnerSearchSuccess();
				if (partner) {
					// //*** verification of profileOpen***
					// home.openProfile();
					// boolean detailOpen= profile.isProfileDetailPageOpen();
					// if(detailOpen){
					// PageElement.tapBackButton(driver);
					// }else{
					// asser.assertTrue(detailOpen, "profile detail is not open
					// from home page");
					// }
					// *** verification of message page Open from header***
					Thread.sleep(5000);
					home.clickMessages();
					boolean msgOpen = msg.isMessagePageOpen();
					asser.assertTrue(msgOpen, "Messages are not open from icon on home page");
					if (msgOpen) {
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}
                   
					// *** verification of Notification page Open from header***
					home.clickNotifications();
					boolean notificationOpen = notify.isNotificationPageOpen();
					asser.assertTrue(notificationOpen, "Notifications are not open from icon on home page");
					if (notificationOpen) {
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}

					// *** verification of sending the notifications***
					home.acceptMatch();
					Thread.sleep(3000);
					home.clickMenu();
					menu.profileLogOut();
					app.openPage("dating");
					boolean matchedProfile = verifyDatingLoginAndHome("pk@pk.com", "12345678");
					if (matchedProfile) {
						home.clickNotifications();
						boolean partnerNotificationOpen = notify.isNotificationPageOpen();
						asser.assertTrue(partnerNotificationOpen, "Notification page is not open from header options");
						if (partnerNotificationOpen) {
							asser.assertTrue(notify.isNotifiedUserExist(),
									"Notification from current user doesn't exist");
							PageElement.tapBackButton(driver);
							Thread.sleep(1000);
						}
						home.acceptMatch();

					} else {
						asser.assertTrue(matchedProfile, "login with matched profile is not successful");
					}
				} else {
					asser.assertTrue(partner, "matching profile is not visible with new user");
				}
			} else {
				asser.assertTrue(homePage, "New user sign up is not successful or registration form is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying user registrationfunctionalities", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyMyMatchAndProfileBlock() {
		Logger.info("********Test Methods start: verifyMyMatchAndProfileBlock********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean homePage = verifyDatingLoginAndHome("aa@aa.com", "12345678");
			if (homePage) {
				Thread.sleep(2000);
				home.clickMenu();
				boolean menuOpen = menu.isDatingMenuOpen();
				if (menuOpen) {
					menu.clickMyMatches();
					Thread.sleep(2000);
					boolean myMatchOpen = match.isMyMatchPageOpen();
					if (myMatchOpen) {
						asser.assertTrue(match.isMatchedUserPresent(), "matched user is not present");
						match.blockUser();
						Thread.sleep(2000);
						asser.assertTrue(match.isUserBlocked(), "block button text is not changed on matched user");
						Thread.sleep(2000);
						match.clickUser();
						boolean desc = match.isProfileDescOpen();
						asser.assertTrue(desc, "user profile is not open from my match page");
						if (desc) {
							PageElement.tapBackButton(driver);
							Thread.sleep(1000);
						}
						if (match.isMyMatchPageOpen()) {
							PageElement.tapBackButton(driver);
							Thread.sleep(1000);
						}
						home.clickMenu();
						menu.profileLogOut();
						app.openPage("dating");
						boolean secondUser = verifyDatingLoginAndHome("pk@pk.com", "12345678");
						if (secondUser) {
							Thread.sleep(2000);
							home.clickMenu();
							menu.clickMyMatches();
							asser.assertFalse(match.isBlockUserExist(),
									"user is not blocked : it is showing in matched user profile");
						} else {
							asser.assertTrue(secondUser, "login with second user is not successful");
						}
					} else {
						asser.assertTrue(myMatchOpen, "myMatch page is not open");
					}
				} else {
					Logger.info("Dating menu is not open upon clicking on menu button from Dating home page");
					asser.assertTrue(menuOpen, "Dating menu is not open");
				}
			} else {
				Logger.info("Dating page is not open in app");
				asser.assertTrue(homePage, "login failure in dating page or home page is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying mymatch and block functionalities", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	 @Test
	public void verifychat() {
		Logger.info("********Test Methods start: verifychat********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean homePage = verifyDatingLoginAndHome("bb@bb.com", "12345678");
			if (homePage) {
				home.clickMenu();
				boolean menuOpen = menu.isDatingMenuOpen();
				if (menuOpen) {
					Thread.sleep(2000);
					menu.clickMessages();
					boolean msgOpen = msg.isMessagePageOpen();
					if (msgOpen) {
						boolean present = msg.isUserPresent();
						if (present) {
							msg.openChatWindow("sender");
							boolean chat = msg.isChatPageOpen();
							if (chat) {
								msg.typeMessage("Hello User");
								msg.sendMessage();
								Thread.sleep(1000);
								PageElement.tapBackButton(driver);
								Thread.sleep(1000);
								if (msg.isMessagePageOpen()) {
									PageElement.tapBackButton(driver);
									Thread.sleep(1000);
								}
								home.clickMenu();
								menu.profileLogOut();
								app.openPage("dating");
								boolean partner = verifyDatingLoginAndHome("pk@pk.com", "12345678");
								if (partner) {
									Thread.sleep(2000);
									home.clickMenu();
									Thread.sleep(2000);
									menu.clickMessages();
									boolean receiver = msg.isReceiverPresent();
									if (receiver) {
										asser.assertTrue(msg.isMessageCounterExist(),
												"recent received msg counter is not present");
										msg.openChatWindow("receiver");
										asser.assertEquals(msg.getMessage(), "Hello User", "message is not received");
									} else {
										asser.assertTrue(receiver, "Receiver is not present");
									}
								} else {
									asser.assertTrue(partner, "login with second user is not successful");
								}

							} else {
								asser.assertTrue(chat, "chat page is not open");
							}
						} else {
							asser.assertTrue(present, "user is ot present for chat");
						}
					} else {
						asser.assertTrue(msgOpen, "message page is not open from main menu");
					}
				} else {
					Logger.info("Dating menu is not open upon clicking on menu button from Dating home page");
					asser.assertTrue(menuOpen, "Dating menu is not open");
				}
			} else {
				Logger.info("Dating page is not open in app");
				asser.assertTrue(homePage, "login failure in dating page or home page is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while verifying mymatch and block functionalities", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifySettinginMenu() {
		Logger.info("********Test Methods start: verifySettinginMenu********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean homePage = verifyDatingLoginAndHome("bb@bb.com", "12345678");
			if (homePage) {
				home.clickMenu();
				boolean menuOpen = menu.isDatingMenuOpen();
				if (menuOpen) {
					menu.clicksetting();
					boolean settingOpen = form.isRegistrationFormOpen();
					asser.assertTrue(settingOpen, "user settings is not open from main menu");
					if (settingOpen) {
						Thread.sleep(1000);
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}
					asser.assertTrue(home.isDatingHomePageOpen(), "back button is not working on setting page");
				} else {
					Logger.info("Dating menu is not open upon clicking on menu button from Dating home page");
					asser.assertTrue(menuOpen, "Dating menu is not open");
				}
			} else {
				Logger.info("Dating page is not open in app");
				asser.assertTrue(homePage, "login failure in dating page or home page is not open");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while veriying settings in menu", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}

	@Test
	public void verifyTermsCondition() {
		Logger.info("********Test Methods start: verifyTermsCodition********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean homePageforTC = verifyDatingLoginAndHome("bb@bb.com", "12345678");
			asser.assertTrue(homePageforTC, "home page is not open again after coming back from setting page");
			if (homePageforTC) {
				home.clickMenu();
				boolean menuforTC = menu.isDatingMenuOpen();
				asser.assertTrue(menuforTC, "Dating menu is not open again when verifying termsCondition");
				if (menuforTC) {
					menu.clickTermCond();
					boolean tcOpen = menu.isTcPageOpen();
					asser.assertTrue(tcOpen, "termsCondition page is not open from main menu");
					if (tcOpen) {
						Thread.sleep(1000);
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}
					asser.assertTrue(home.isDatingHomePageOpen(), "back button is not working on tc page");
				}
			}

		} catch (Exception ex) {
			Logger.error("Exception occurs while veriying terms condition in dating", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyPrivacyPolicy() {
		Logger.info("********Test Methods start: verifyPrivacyPolicy********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			app.openPage("dating");
			boolean homePageforprivacy = verifyDatingLoginAndHome("bb@bb.com", "12345678");
			asser.assertTrue(homePageforprivacy, "home page is not open again after coming back from setting page");
			if (homePageforprivacy) {
				home.clickMenu();
				boolean menuforprivacy = menu.isDatingMenuOpen();
				asser.assertTrue(menuforprivacy, "Dating menu is not open again when verifying termsCondition");
				if (menuforprivacy) {
					menu.clickPrivacyPolicy();
					boolean privacyPageOpen = menu.isPrivacyPolicyPageOpen();
					asser.assertTrue(privacyPageOpen, "termsCondition page is not open from main menu");
					if (privacyPageOpen) {
						Thread.sleep(1000);
						PageElement.tapBackButton(driver);
						Thread.sleep(1000);
					}
					asser.assertTrue(home.isDatingHomePageOpen(), "back button is not working on privacy policy page");
				}
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs while veriying privacy policy in dating", ex);
			exception = true;
			Assert.assertFalse(exception,"\n"+PageElement.printExceptionTrace(ex));
		}
		asser.assertAll();
	}		

	
}
