package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.Store.CommanClassStore;
import com.appypie.pages.Store.StorePage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieStoreTest extends TestSetup {



	private static final Logger Logger = Log.createLogger();

	CommanClassStore comm;
	StorePage store;


	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		comm=new CommanClassStore(driver);
		store=new StorePage(driver);

	}


	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/
	@Test(priority = 0, description = "")
	public void VerifyMenu() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenu()");
		boolean exception = false;
		try {
			Boolean openstoremodule=comm.Openlinks(store.Storelink);
			if (openstoremodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Store");

				Boolean menu=comm.Openlinks(store.Menulink);
				if (menu) {
					Boolean logintext=comm.IselementPresent(store.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						//store.login();

						PageElement.login(driver, store.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else {
						System.out.println("User is already Login");
						comm.Openlinks(store.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	


				Boolean menulink=comm.Openlinks(store.Menulink);
				if (menulink) {

					comm.Getactualtext(store.username_gettext);
					comm.Getactualtext(store.address_gettext);

					Boolean menulist=comm.getListofLink(store.menulist_gettext);
					if (menulist) {
						Boolean myshop=comm.Openlinks(store.myshop);
						s_assert.assertTrue(myshop, "My shop link is not working");

						Boolean menulink2=comm.Openlinks(store.Menulink);
						if (menulink2) {
							Boolean cartlink=comm.Openlinks(store.cart);
							s_assert.assertTrue(cartlink, "cart link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink2, "Menu link is not working for menu list getting");


						Boolean menulink3=comm.Openlinks(store.Menulink);
						if (menulink3) {
							Boolean featuredProductlink=comm.Openlinks(store.featuredProduct);
							s_assert.assertTrue(featuredProductlink, "featured Product link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink3, "Menu link is not working for menu list getting");

						Boolean menulink4=comm.Openlinks(store.Menulink);
						if (menulink4) {
							Boolean offerlink=comm.Openlinks(store.offer);
							s_assert.assertTrue(offerlink, "offer link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink4, "Menu link is not working for menu list getting");

						Boolean menulink5=comm.Openlinks(store.Menulink);
						if (menulink5) {
							Boolean myorderlink=comm.Openlinks(store.myorder);
							if (myorderlink) {
								comm.Getactualtext(store.oderHeading_MyOrder_gettext);

								Boolean billingaddress=comm.Openlinks(store.billingaddressTAB);
								if (billingaddress) {
									comm.Getactualtext(store.billingaddressTAB_gettext);
								}
								s_assert.assertTrue(billingaddress, "billing address TAB is not open"); 

								Boolean shippingaddress=comm.Openlinks(store.shippingaddressTAB);
								if (shippingaddress) {
									comm.Getactualtext(store.shippingaddressTAB_gettext);
								}
								s_assert.assertTrue(shippingaddress, "shipping address TAB is not open"); 

								Boolean orderdetailstab=comm.Openlinks(store.orderDetailsTAB);
								if (orderdetailstab) {
									Boolean oderlist=comm.getListofLink(store.oderDetailslist_MyOrder_gettext);
									if (oderlist) {
										Boolean viewBtn=comm.Openlinks(store.viewItemsBtn_MyOrderlink);
										if (viewBtn) {
											Boolean postReview=comm.Openlinks(store.postReviewBtn);
											if (postReview) {
												Boolean backBtnPostreview=comm.Openlinks(comm.BackButton1);
												s_assert.assertTrue(backBtnPostreview, "Back Button is not open after click post review Btn"); 
											}
											s_assert.assertTrue(postReview, "postReview is not open"); 

											Boolean reorder=comm.Openlinks(store.reorderBtn);
											if (reorder) {
												Boolean backBtnPostreview=comm.Openlinks(comm.BackButton1);
												s_assert.assertTrue(backBtnPostreview, "Back Button is not open after click post Reorder Btn"); 
											}
											s_assert.assertTrue(reorder, "reorder Btn is not open"); 
											
											Boolean cancel=comm.Openlinks(store.cancelBtn);
											if (cancel) {
												s_assert.assertEquals(cancel, "Cancle","Cancle Button is not wroking");
												String cancleheader=comm.Getactualtext(comm.header_gettext);
												if (cancleheader.equalsIgnoreCase("Cancle")) {
													Boolean backBtnPostreview=comm.Openlinks(comm.BackButton1);
													s_assert.assertTrue(backBtnPostreview, "Back Button is not open after click post cancel Btn");
												}
												else {
													
													Boolean backBtnPostreview=comm.Openlinks(comm.BackButton1);
													s_assert.assertTrue(backBtnPostreview, "Back Button is not open after click post cancel Btn");
												}
												
											}
										}
										s_assert.assertTrue(viewBtn, "view Btn  is not open"); 
									}
									s_assert.assertTrue(oderlist, "Order details list is not prsent");
								}
								s_assert.assertTrue(orderdetailstab, "order details TAB is not open"); 
							}
							s_assert.assertTrue(myorderlink, "myorder link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink5, "Menu link is not working for menu list getting");

						Boolean menulink6=comm.Openlinks(store.Menulink);
						if (menulink6) {
							Boolean myaccountlink=comm.Openlinks(store.myaccount);
							s_assert.assertTrue(myaccountlink, "myaccount link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink6, "Menu link is not working for menu list getting");

						Boolean menulink7=comm.Openlinks(store.Menulink);
						if (menulink7) {
							Boolean wishlistlink=comm.Openlinks(store.wishlist);
							s_assert.assertTrue(wishlistlink, "wishlist link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink7, "Menu link is not working for menu list getting");

						Boolean menulink8=comm.Openlinks(store.Menulink);
						if (menulink8) {
							Boolean termconditionslink=comm.Openlinks(store.termconditions);
							s_assert.assertTrue(termconditionslink, "Term Conditions link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink8, "Menu link is not working for menu list getting");

						Boolean menulink9=comm.Openlinks(store.Menulink);
						if (menulink9) {
							Boolean privacypolicylink=comm.Openlinks(store.privacypolicy);
							s_assert.assertTrue(privacypolicylink, "privacy policy link is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink9, "Menu link is not working for menu list getting");

						Boolean menulink10=comm.Openlinks(store.Menulink);
						if (menulink10) {
							PageElement.searchMenu(driver,store.searchMenuItem, "LCD");
							PageElement.tapDeviceOk(driver);

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back button is not working");
						}
						s_assert.assertTrue(menulink10, "Menu link is not working");


					}
					s_assert.assertTrue(menulist, "Menu List is not getting");
				}
				s_assert.assertTrue(menulink, "Menu link is not working");
			}
			s_assert.assertTrue(openstoremodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 1, description = "")
	public void VerifyShortSearch() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyShortSearch()");
		boolean exception = false;
		try {
			Boolean openstoremodule=comm.Openlinks(store.Storelink);
			if (openstoremodule) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Store");

				Boolean menu=comm.Openlinks(store.Menulink);
				if (menu) {
					Boolean logintext=comm.IselementPresent(store.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						PageElement.login(driver, store.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else {
						System.out.println("User is already Login");
						comm.Openlinks(store.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");	


				Boolean search=comm.Openlinks(store.searchlink);
				if (search) {
					Boolean searchenter=comm.TextField(store.searchTextlink, "Phone and camera");
					s_assert.assertTrue(searchenter, "Search text filed is not enter data");
					PageElement.tapDeviceOk(driver);

					Boolean backbtn=comm.Openlinks(comm.BackButton1);
					s_assert.assertTrue(backbtn, "back Button is not working after search");
				}
				s_assert.assertTrue(search, "Search link is not working");

				Boolean sortby=comm.Openlinks(store.sortBylink);
				if (sortby) {
					

					if (!globledeviceName.equals("iPhone")) {
						driver.context("NATIVE_APP");
						Boolean sortbylist=comm.getListofLink(store.sortBylistNative_gettext);
						s_assert.assertTrue(sortbylist, "SortBy list is not getting");

						Boolean LH=comm.Openlinks(store.LHlinknativ);
						s_assert.assertTrue(LH, "Low to high radio button is not click");
						PageElement.changeContextToWebView(driver);
					}
					else {
						Boolean i_sortbylist=comm.getListofLink(store.i_sortBylistNative_gettext);
						s_assert.assertTrue(i_sortbylist, "i_SortBy list is not getting");
						
						Boolean i_LH=comm.Openlinks(store.i_LHlinknativ);
						if (i_LH) {
							driver.context("NATIVE_APP");
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone,"iDone button is not working");
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(i_LH, "i_Low to high radio button is not click");
					}
				}
				s_assert.assertTrue(sortby, "SortBy link is not working");

				Boolean sortby1=comm.Openlinks(store.sortBylink);
				if (sortby) {
					
					if (!globledeviceName.equals("iPhone")) {
						driver.context("NATIVE_APP");
						/*Boolean sortbylist=comm.getListofLink(store.sortBylistNative_gettext);
						s_assert.assertTrue(sortbylist, "SortBy list is not getting");*/

						Boolean HL=comm.Openlinks(store.HLlinknativ);
						s_assert.assertTrue(HL, "high to Low radio button is not click");
						PageElement.changeContextToWebView(driver);
					}
					else {
						Boolean i_HL=comm.Openlinks(store.i_HLlinknativ);
						if (i_HL) {
							driver.context("NATIVE_APP");
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone,"iDone button is not working");
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(i_HL, "i_high to Low radio button is not click");
					}
				}
				s_assert.assertTrue(sortby1, "SortBy link is not working");

				Boolean sortby2=comm.Openlinks(store.sortBylink);
				if (sortby) {
					
					if (!globledeviceName.equals("iPhone")) {
						driver.context("NATIVE_APP");
						/*Boolean sortbylist=comm.getListofLink(store.sortBylistNative_gettext);
						s_assert.assertTrue(sortbylist, "SortBy list is not getting");*/

						Boolean populatity=comm.Openlinks(store.populatitylinknativ);
						if (populatity) {
							driver.context("NATIVE_APP");
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone,"iDone button is not working");
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(populatity, "populatity radio button is not click");
						PageElement.changeContextToWebView(driver);
					}
					else {
						Boolean i_populatity=comm.Openlinks(store.i_populatitylinknativ);
						if (i_populatity) {
							driver.context("NATIVE_APP");
							Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
							s_assert.assertTrue(idone,"iDone button is not working");
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(i_populatity, "i_populatity radio button is not click");
					}
				}
				s_assert.assertTrue(sortby2, "SortBy link is not working");

				Boolean housingTAB=comm.Openlinks(store.housinglinkTAB);
				s_assert.assertTrue(housingTAB, "Housing Tab link is not working");

				/*Boolean backbtn=comm.Openlinks(comm.BackButton2);
				s_assert.assertTrue(backbtn, "back button is not working");*/

				Boolean EC=comm.Openlinks(store.electroniclinkTAB);
				if (EC) {
					Boolean subproduct=comm.Openlinks(store.productlinkonMainPage);
					if (subproduct) {
						Boolean lcd=comm.Openlinks(store.lcdDroplist);
						if (lcd) {
							
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								Boolean lcdlist=comm.getListofLink(store.lcdlistnative);
								s_assert.assertTrue(lcdlist, "LCD list is not getting");

								Boolean colour=comm.Openlinks(store.lcdcolournative);
								s_assert.assertTrue(colour, "Colour ratio btn not working");

								PageElement.changeContextToWebView(driver);
							}
							else {
								Boolean i_lcdlist=comm.getListofLink(store.i_lcdlistnative);
								if (i_lcdlist) {
									driver.context("NATIVE_APP");
									Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
									s_assert.assertTrue(idone,"iDone button is not working");
									PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(i_lcdlist, "i_LCD list is not getting");

								Boolean i_colour=comm.Openlinks(store.i_lcdcolournative);
								if (i_colour) {
									driver.context("NATIVE_APP");
									Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
									s_assert.assertTrue(idone,"iDone button is not working");
									PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(i_colour, "i_Colour ratio btn not working");
							}
							
						}
						s_assert.assertTrue(lcd,"LCD Drop list not working");

						Boolean like=comm.Openlinks(store.likeBtn);
						if (like) {
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(like, "like btn is not open");

						Boolean share=comm.Openlinks(store.shareBtn);
						if (share) {
							if (!globledeviceName.equals("iPhone")) {
								comm.sharelink(comm.getsharebyItem_getlink);
							}
							else {
								driver.context("NATIVE_APP");
								Boolean icancleshare=PageElement.Accessibilitylinks(PageElement.i_cancel);
								s_assert.assertTrue(icancleshare, "iShare cancle button is not working");
								PageElement.changeContextToWebView(driver);
							}
						}
						s_assert.assertTrue(share, "share btn is not open");

						Boolean comment=comm.Openlinks(store.commentBtn);
						if (comment) {
							Boolean BackButton=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(BackButton, "Back Button  is not open after open comment"); 
						}
						s_assert.assertTrue(comment, "comment btn is not open");

						Boolean more_less=comm.Openlinks(store.more_lessBtn);
						if (more_less) {
							Boolean less=comm.Openlinks(store.more_lessBtn);
							s_assert.assertTrue(less, "less btn is not open"); 
						}
						s_assert.assertTrue(more_less, "more_less is not open"); 

						Boolean addcart=comm.Openlinks(store.addtocartlink);
						s_assert.assertTrue(addcart, "Add to cart link is not working");
						comm.IfAlertpresent();
					}
					s_assert.assertTrue(subproduct, "Product link is not working");
				}
				s_assert.assertTrue(EC, "Electronic is not working");

			}
			s_assert.assertTrue(openstoremodule, "Store Module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifyDeshboard() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDeshboard()");
		boolean exception = false;
		try {
			Boolean openstoremodule=comm.Openlinks(store.Storelink);
			if (openstoremodule) {
				TimeUnit.SECONDS.sleep(5);
				Boolean menu=comm.Openlinks(store.Menulink);
				if (menu) {
					Boolean logintext=comm.IselementPresent(store.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						PageElement.login(driver, store.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else {
						System.out.println("User is already Login");
						comm.Openlinks(store.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Store");

				String maincategory=comm.Getactualtext(store.getmaincategory);
				s_assert.assertNotNull(maincategory,"maincategory is getting Null Value" );

				String getsubcategory=comm.Getactualtext(store.getsubcategory);
				s_assert.assertNotNull(getsubcategory,"getsubcategory is getting Null Value" );

				Boolean opensubcategorylink=comm.Openlinks(store.subcategorylink);
				if (opensubcategorylink) {
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Phone and Camera");

					Boolean subcatgProduclist=comm.getListofLink(store.subcatgProductlist_gettext);
					s_assert.assertTrue(subcatgProduclist, "subcatg Product list is not getting");

					Boolean checkcameraProductdetailslink=comm.Openlinks(store.detailproductcameralink);
					if (checkcameraProductdetailslink) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Products");

						/*	String =comm.Getactualtext(store.);
						s_assert.assertEquals(comm.Getactualtext(store.), "");
						s_assert.assertNotNull(, " is getting Null value");*/

						String checkcameraNameOnproductpage=comm.Getactualtext(store.getproductnameinaddtocartpage);
						//s_assert.assertEquals(checkcameraNameOnproductpage, "Canon Camera");
						s_assert.assertNotNull(checkcameraNameOnproductpage, "camera Name On product pageis getting Null value");

						String checkcameraPriceOnproductpage=comm.Getactualtext(store.getproductPriceinaddtocartpage);
						//s_assert.assertEquals(checkcameraPriceOnproductpage, "25000.00");
						s_assert.assertNotNull(checkcameraPriceOnproductpage, "camera Price On product pageis getting Null value");

						Boolean  checkAddToCartforCamera=comm.Openlinks(store.addtocartcarmera_phonelink);
						if (checkAddToCartforCamera) {
							
							comm.IfAlertpresent();
							
							Boolean cartlink123=comm.Openlinks(store.cartlinkafterContinueShopping);
							s_assert.assertTrue(cartlink123, "Cart link is not working");
							
							
							s_assert.assertEquals(comm.Getactualtext(comm.header_gettext),"Cart");

							String ProductName=comm.Getactualtext(store.getproductnamecartpage);
							s_assert.assertNotNull(ProductName, "Product Name is getting Null value");

							String ProductPrice=comm.Getactualtext(store.getpricecartpage);
							s_assert.assertNotNull(ProductPrice, "Product Price is getting Null value");

							String ProductQuantity=comm.GetAttributevalue(store.getproductquantitycartpage);
							s_assert.assertNotNull(ProductQuantity, "Product Quantity is getting Null value");

							String ProductSubTotal=comm.Getactualtext(store.getSubtotalAmount);
							s_assert.assertNotNull(ProductSubTotal, "Product SubTotal is getting Null value");

							String ProductGrandTotal=comm.Getactualtext(store.getGrandTotalAmount);
							s_assert.assertNotNull(ProductGrandTotal, "Product Grand Total is getting Null value");

							String ProductTotalPayableAmount=comm.Getactualtext(store.getTotalpayableAmount);
							s_assert.assertNotNull(ProductTotalPayableAmount, "Product Total Payable Amount is getting Null value");

							
							if (!globledeviceName.equals("iPhone")) {
								driver.context("NATIVE_APP");
								comm.SwipeBottomToTop();
								TimeUnit.SECONDS.sleep(3);
								Boolean ContinueShoppinglink=comm.Openlinks(store.getContinueShopping);
								if (ContinueShoppinglink){
									PageElement.changeContextToWebView(driver);
									Boolean cartlink=comm.Openlinks(store.cartlinkafterContinueShopping);
									s_assert.assertTrue(cartlink, "Cart link is not working after link on Continue Shopping link");
								}
								s_assert.assertTrue(ContinueShoppinglink, "Continue Shopping text is Working");
								PageElement.changeContextToWebView(driver);
							}
							else {

								comm.SwipeBottomToTop();
								PageElement.changeContextToWebView(driver);
								
								TimeUnit.SECONDS.sleep(3);
								Boolean ContinueShoppinglinkpresent=comm.IselementPresent(store.i_getContinueShopping);
								if (ContinueShoppinglinkpresent) {
									Boolean i_ContinueShoppinglink=comm.Openlinks(store.i_getContinueShopping);
									if (i_ContinueShoppinglink){
										
										Boolean cartlink=comm.Openlinks(store.cartlinkafterContinueShopping);
										//s_assert.assertTrue(cartlink, "Cart link is not working after link on Continue Shopping link1");
									}
									s_assert.assertTrue(i_ContinueShoppinglink, "i_Continue Shopping text is Working");
								}
								else {
									System.out.println("Continue Shopping link is not present on cart page");
								}
								
							}

							Boolean checkfirstTimeProductQuantityincrease=comm.Openlinks(store.checkincreaseproductlink);
							if (checkfirstTimeProductQuantityincrease) {
								String getfirstTimequantity=comm.GetAttributevalue(store.getproductquantitycartpage);
								s_assert.assertNotNull(getfirstTimequantity, "first time Product quantit is getting Null value");
							}
							s_assert.assertTrue(checkfirstTimeProductQuantityincrease, "first time Product Quantity increase btn not working");

							Boolean checkSecondTimeProductQuantityincrease=comm.Openlinks(store.checkincreaseproductlink);
							if (checkSecondTimeProductQuantityincrease) {
								String getSecondTimequantity=comm.GetAttributevalue(store.getproductquantitycartpage);
								s_assert.assertNotNull(getSecondTimequantity, "Second time Product quantit is getting Null value");
							}
							s_assert.assertTrue(checkSecondTimeProductQuantityincrease, "Second time Product Quantity increase btn not working");

							Boolean checkfirstTimeProductQuantityDecrease=comm.Openlinks(store.checkdecreaseproductlink);
							if (checkfirstTimeProductQuantityDecrease) {
								String getfirstTimequantity=comm.GetAttributevalue(store.getproductquantitycartpage);
								s_assert.assertNotNull(getfirstTimequantity, "first time Product quantit is getting Null value");
							}
							s_assert.assertTrue(checkfirstTimeProductQuantityDecrease, "first time Product Quantity increase btn not working");

							Boolean checkSecondTimeProductQuantityDecrease=comm.Openlinks(store.checkdecreaseproductlink);
							if (checkSecondTimeProductQuantityDecrease) {
								String getSecondTimequantity=comm.GetAttributevalue(store.getproductquantitycartpage);
								s_assert.assertNotNull(getSecondTimequantity, "Second time Product quantit is getting Null value");
							}
							s_assert.assertTrue(checkSecondTimeProductQuantityDecrease, "Second time Product Quantity increase btn not working");

							Boolean checkCouponenter=comm.TextField(store.checkcouponcodecartpage, "12345");
							if (checkCouponenter) {
								Boolean clickcouponapplybtn=comm.Openlinks(store.checkcouponcodeapplybuttoncartpage);
								if (clickcouponapplybtn) {
									comm.IfAlertpresent();
								}
								s_assert.assertTrue(clickcouponapplybtn, "Apply btn not working of coupon code");
							}
							s_assert.assertTrue(checkCouponenter, "Enter coupon code is not present");

							Boolean CheckOutbutton=comm.Openlinks(store.checkoutlink);
							if (CheckOutbutton) {
								s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Order Details");

								Boolean name=comm.TextField(store.getname, "anurag");
								s_assert.assertTrue(name, "Name text filed is not present");

								Boolean Telephone=comm.TextField(store.getTelephone, "9540198626");
								s_assert.assertTrue(Telephone, "Telephone text filed is not present");

								Boolean Email=comm.TextField(store.getEmail, "anurag@yopmail.com");
								s_assert.assertTrue(Email, "Email text filed is not present");

								Boolean Address=comm.TextField(store.getAddress, "NSEZ");
								s_assert.assertTrue(Address, "Address text filed is not present");

								Boolean City=comm.TextField(store.getCity, "Noida");
								s_assert.assertTrue(City, "City text filed is not present");

								Boolean State=comm.TextField(store.getState, "UTTAR PRADESH");
								s_assert.assertTrue(State, "State text filed is not present");

								Boolean Zip=comm.TextField(store.getZip, "201301");
								s_assert.assertTrue(Zip, "Zip text filed is not present");

								Boolean country=comm.Openlinks(store.Country);
								if (country) {
									
									if (!globledeviceName.equals("iPhone")) {
										driver.context("NATIVE_APP");
										comm.countryselect();
										PageElement.changeContextToWebView(driver);
									}
									else {
										Boolean icountry=comm.Openlinks(store.i_Country);
										if (icountry) {
											driver.context("NATIVE_APP");
											Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
											s_assert.assertTrue(idone,"iDone button is not working");
											PageElement.changeContextToWebView(driver);
										}
										s_assert.assertTrue(icountry, "i_country is not selected");
									}
								}
								s_assert.assertTrue(country, "country is not present");

								Boolean paynowbtn=comm.Openlinks(store.paynowlink);
								if (paynowbtn) {
									TimeUnit.SECONDS.sleep(10);
									comm.Getactualtext(comm.header_gettext);
									

									Boolean pp=comm.Openlinks(store.paypal);
									if (pp) {
										String ppmessage=comm.Getactualtext(store.paypal_gettext);
										s_assert.assertNotNull(ppmessage, "Pay pal message is getting Null value");
									}
									s_assert.assertTrue(pp, "Paypal link is not working");

									Boolean pclink=comm.Openlinks(store.pc);
									if (pclink) {
										String pcmessage=comm.Getactualtext(store.pc_gettext);
										s_assert.assertNotNull(pcmessage, "Pay pal credit card message is getting Null value");
									}
									s_assert.assertTrue(pclink, "Paypal credit card link is not working");

									Boolean cclink=comm.Openlinks(store.cc);
									if (cclink) {
										String ccmessage=comm.Getactualtext(store.cc_gettext);
										s_assert.assertNotNull(ccmessage, "credit card message is getting Null value");
									}
									s_assert.assertTrue(cclink, "credit card link is not working");

									Boolean codlink=comm.Openlinks(store.cod);
									if (codlink) {
										String codmessage=comm.Getactualtext(store.cod_gettext);
										s_assert.assertNotNull(codmessage, "COD message is getting Null value");
									}
									s_assert.assertTrue(codlink, "COD link is not working");

									Boolean Confirmbtn=comm.Openlinks(store.Confirmpaynowlink);
									if (Confirmbtn) {
										comm.Getactualtext(comm.header_gettext);

										String message=comm.Getactualtext(store.ContinueShoppinglink_gettext);
										s_assert.assertNotNull(message, "Message is getting Null value on Thank you page");

										Boolean ContinueShopping=comm.Openlinks(store.ContinueShoppinglink);
										s_assert.assertTrue(ContinueShopping, "Continue Shopping link is not working");
									}
									s_assert.assertTrue(Confirmbtn, "Confirm button is not working");


								}
								s_assert.assertTrue(paynowbtn, "Pay now button is not working");
							}
							s_assert.assertTrue(CheckOutbutton, "Checkout button is not working");
						}
						s_assert.assertTrue(checkAddToCartforCamera, "AddToCart for Camera link is not open");
					}
					s_assert.assertTrue(checkcameraProductdetailslink, "camera Product details link is not open");
				}
				s_assert.assertTrue(opensubcategorylink, "Sub category link is not open");
			}
			s_assert.assertTrue(openstoremodule, "Store Module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.getStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyCheckOut() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyCheckOut()");
		boolean exception = false;
		try {
			Boolean openstoremodule=comm.Openlinks(store.Storelink);
			if (openstoremodule) {
				Boolean menu=comm.Openlinks(store.Menulink);
				if (menu) {
					Boolean logintext=comm.IselementPresent(store.loginlink);
					if (logintext) {
						System.out.println("User Is not Login");
						PageElement.login(driver, store.loginlink, "appypie2016@gmail.com", "12345678");
					}
					else {
						System.out.println("User is already Login");
						comm.Openlinks(store.closeMenu);
					}
				}
				s_assert.assertTrue(menu, "Menu link is not working");

				Boolean opensubcategorylink=comm.Openlinks(store.subcategorylink);
				if (opensubcategorylink) {

					Boolean checkcameraProductdetailslink=comm.Openlinks(store.detailproductcameralink);
					if (checkcameraProductdetailslink) {

						Boolean  checkAddToCartforCamera=comm.Openlinks(store.addtocartcarmera_phonelink);
						if (checkAddToCartforCamera) {
							
							comm.IfAlertpresent();
							Boolean cartlink=comm.Openlinks(store.cartlinkafterContinueShopping);
							if (cartlink) {
								Boolean CheckOutbutton=comm.Openlinks(store.checkoutlink);
								if (CheckOutbutton) {
									s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Order Details");

									Boolean name=comm.TextField(store.getname, "anurag");
									s_assert.assertTrue(name, "Name text filed is not present");

									Boolean Telephone=comm.TextField(store.getTelephone, "9540198626");
									s_assert.assertTrue(Telephone, "Telephone text filed is not present");

									Boolean Email=comm.TextField(store.getEmail, "anurag@yopmail.com");
									s_assert.assertTrue(Email, "Email text filed is not present");

									Boolean Address=comm.TextField(store.getAddress, "NSEZ");
									s_assert.assertTrue(Address, "Address text filed is not present");

									Boolean City=comm.TextField(store.getCity, "Noida");
									s_assert.assertTrue(City, "City text filed is not present");

									Boolean State=comm.TextField(store.getState, "UTTAR PRADESH");
									s_assert.assertTrue(State, "State text filed is not present");

									Boolean Zip=comm.TextField(store.getZip, "201301");
									s_assert.assertTrue(Zip, "Zip text filed is not present");

									Boolean country=comm.Openlinks(store.Country);
									if (country) {
										if (!globledeviceName.equals("iPhone")) {
											driver.context("NATIVE_APP");
											comm.countryselect();
											PageElement.changeContextToWebView(driver);
										}
										else {
											Boolean icountry=comm.Openlinks(store.i_Country);
											s_assert.assertTrue(icountry, "i_country is not selected");
										}
									}
									s_assert.assertTrue(country, "country is not present");

									Boolean shippingAddressDifferent=comm.Openlinks(store.shippingAddressDifferentCheckBox);
									if (shippingAddressDifferent) {
										Boolean UN=comm.TextField(store.username_shippingAddress, "QA");
										s_assert.assertTrue(UN, "user is not working");

										Boolean phone=comm.TextField(store.phoneNo_shippingAddress, "1234567890");
										s_assert.assertTrue(phone, "phone is not working");

										Boolean address=comm.TextField(store.address_shippingAddress, "Noida NSEZ");
										s_assert.assertTrue(address, "address is not working");

										Boolean city=comm.TextField(store.city_shippingAddress, "Noida");
										s_assert.assertTrue(city, "City is not working");

										Boolean state=comm.TextField(store.state_shippingAddress, "Uttar Pradesh");
										s_assert.assertTrue(state, "state is not working");

										Boolean zip=comm.TextField(store.zip_shippingAddress, "201301");
										s_assert.assertTrue(zip, "ZIP is not working");

										Boolean countryshiiping=comm.Openlinks(store.country_shippingAddress);
										if (countryshiiping) {
											
											if (!globledeviceName.equals("iPhone")) {
												comm.countryselect();
											}
											else {
												Boolean icountry=comm.Openlinks(store.i_country_shippingAddress);
												if (icountry) {
													driver.context("NATIVE_APP");
													Boolean idone=PageElement.Accessibilitylinks(PageElement.i_done);
													s_assert.assertTrue(idone,"iDone button is not working");
													PageElement.changeContextToWebView(driver);
												}
												s_assert.assertTrue(icountry, "i_country is not selected");
											}
											
										}
										s_assert.assertTrue(countryshiiping, "country is not open"); 

										Boolean shippingAddressUpdate=comm.Openlinks(store.update_shippingAddress);
										if (shippingAddressUpdate) {
											comm.IfAlertpresent();
										}
										s_assert.assertTrue(shippingAddressUpdate, "shipping Address Update  is not open"); 

									}
									s_assert.assertTrue(shippingAddressDifferent, "shipping Address Different check Box is not check"); 


									Boolean paynowbtn=comm.Openlinks(store.paynowlink);
									if (paynowbtn) {
										comm.Getactualtext(comm.header_gettext);
										Boolean Confirmbtn=comm.Openlinks(store.Confirmpaynowlink);
										if (Confirmbtn) {
											comm.Getactualtext(comm.header_gettext);
											Boolean ContinueShopping=comm.Openlinks(store.ContinueShoppinglink);
											s_assert.assertTrue(ContinueShopping, "Continue Shopping link is not working");
										}
										s_assert.assertTrue(Confirmbtn, "Confirm button is not working");
									}
									s_assert.assertTrue(paynowbtn, "Pay now button is not working");
								}
								s_assert.assertTrue(CheckOutbutton, "Checkout button is not working");
							}
							s_assert.assertTrue(cartlink, "Cart link is notwoking");
						}
						s_assert.assertTrue(checkAddToCartforCamera, "AddToCart for Camera link is not open");
					}
					s_assert.assertTrue(checkcameraProductdetailslink, "camera Product details link is not open");
				}
				s_assert.assertTrue(opensubcategorylink, "Sub category link is not open");
			}
			s_assert.assertTrue(openstoremodule, "Store Module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.getStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



}
