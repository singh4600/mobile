package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieDocumentPage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.CommanClass;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieDocumentPageTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieMenuPage menu;
	AppypieDocumentPage document;

	@Override
	@BeforeTest
	public void pageSetUp() {
		menu = new AppypieMenuPage(driver);
		document = new AppypieDocumentPage(driver);
	}

	@Test
	public void verifyDocumentPageandBackbtn() {
		Logger.info("Test Methods start: verifyDocumentPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("document");
			boolean pageOpen = document.isDocumentPageOpen();
			asser.assertTrue(pageOpen, "Document page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from document page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the document page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifygoogleDrive() {
		Logger.info("Test Methods start: verifygoogleDrive");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("document");
			boolean pageOpen = document.isDocumentPageOpen();
			asser.assertTrue(pageOpen, "Document page is not open");
			if (pageOpen) {

				if (!globledeviceName.equals("iPhone")) {
					document.openGoogleDrive();
					asser.assertTrue(document.isDriveOpen(), "google Drive is  not open from document pages");
				}
				else {
					Boolean igoogledrive=CommanClass.Openlinks(document.gDrive);
					asser.assertTrue(CommanClass.IselementPresent(document.search), "Google Drive is not Open");
					if (igoogledrive) {
						Boolean gettingStarted=CommanClass.Openlinks(document.gettingStarted);
						
						driver.context("NATIVE_APP");
						asser.assertTrue(CommanClass.IselementPresent(document.i_gettingStartedHeader), "GeetingStarted PDF is not Open");
						if (gettingStarted) {
							asser.assertTrue(CommanClass.Openlinks(document.i_BackBtngettingStartedHeader),"i_BackBtngettingStartedHeader xpath is not working");
							PageElement.changeContextToWebView(driver);
							asser.assertTrue(CommanClass.IselementPresent(document.search), "iBack Button is not working on Geeting Started page");
						}
						PageElement.changeContextToWebView(driver);
						Boolean Test=CommanClass.Openlinks(document.gettingStarted);
						driver.context("NATIVE_APP");
						asser.assertTrue(CommanClass.IselementPresent(document.i_headerTEST), "Test PDF is not Open");
						if (Test) {
							asser.assertTrue(CommanClass.Openlinks(document.i_BackBtnTEST),"i_BackBtnTEST link is not working");
							PageElement.changeContextToWebView(driver);
							asser.assertTrue(CommanClass.IselementPresent(document.search), "iBack Button is not working on Test page");
						}
						
						
						
					}
					
					
					
					
			
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening the google drive ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyOneDrive() {
		Logger.info("Test Methods start: verifyOneDrive");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("document");
			boolean pageOpen = document.isDocumentPageOpen();
			asser.assertTrue(pageOpen, "Document page is not open");
			if (pageOpen) {
				document.openOneDrive();
				asser.assertTrue(document.isDriveOpen(), "One Drive is  not open from document pages");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while opening one drive ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyGridView() {
		Logger.info("Test Methods start: verifyGridView");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("document");
			boolean pageOpen = document.isDocumentPageOpen();
			asser.assertTrue(pageOpen, "Document page is not open");
			if (pageOpen) {
				document.openOneDrive();
				boolean driveOpen = document.isDriveOpen();
				asser.assertTrue(driveOpen, "One Drive is  not open from document pages");
				if (driveOpen) {
					document.clickGridView();
					Thread.sleep(1000);
					asser.assertTrue(document.isGridViewDisplayed(), "Grid view is not displayed in One drive");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying grid view ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyDriveContentInNative() {
		Logger.info("Test Methods start: verifyDriveContentInNative");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("document");
			boolean pageOpen = document.isDocumentPageOpen();
			asser.assertTrue(pageOpen, "Document page is not open");
			if (pageOpen) {
				document.openGoogleDrive();
				boolean driveOpen = document.isDriveOpen();
				asser.assertTrue(driveOpen, "One Drive is  not open from document pages");
				if (driveOpen) {
					document.openDriveContent();
					asser.assertTrue(PageElement.isContentOpenInNative(driver, ""),"Drive content i not open in native");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying drive content in native ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifySearchInDrive() {
		Logger.info("Test Methods start: verifySearchInDrive");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("document");
			boolean pageOpen = document.isDocumentPageOpen();
			asser.assertTrue(pageOpen, "Document page is not open");
			if (pageOpen) {
				document.openGoogleDrive();
				boolean driveOpen = document.isDriveOpen();
				asser.assertTrue(driveOpen, "Google Drive is  not open from document pages");
				if (driveOpen) {
					document.typeSearchKeyWord("TES");
					Thread.sleep(1000);
					asser.assertTrue(document.isOnKeyUpSearchWorking(), "Search in drive is not working");
				}
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Search in drive", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
