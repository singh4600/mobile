package com.appypie.tests.logintests;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.pages.loginpages.AppypieSignUpPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.LoginServiceHandler;
import com.appypie.util.PageElement;

public class AppypieAutoapprovalOnTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieSignUpPage signup;
	AppypieLoginPage login;

	@Override
	@BeforeTest
	public void pageSetUp() {
		signup = new AppypieSignUpPage(driver);
		login = new AppypieLoginPage(driver);
	}

	@Test(groups={"signup","autoapproval"})
	public void verifySignUpWithAutoApprovalBlankFormandName() {
		Logger.info("********Test Method Starts: verifySignUpWithAutoApprovalBlankFormandName********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					signup.submitSignUp();
					String warning = PageElement.getWarningText(driver);
					asser.assertEquals(warning, "Mandatory fields can't be left blank");
					if (warning != "") {
						PageElement.closeWarningSingleBtn(driver, "OK");
					}
					// verification of name only
					signup.enterName();
					signup.submitSignUp();
					asser.assertEquals(PageElement.getWarningText(driver), "Mandatory fields can't be left blank");
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying sign up with autoapproval blank form and name", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(groups={"signup","autoapproval"})
	public void verifySignUpWithAutoApprovalforEmail() {
		Logger.info("********Test Method Starts: verifySignUpWithAutoApprovalforEmail********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					signup.enterName();
					signup.enterInvalidEmail();
					signup.submitSignUp();
					String warning = PageElement.getWarningText(driver);
					asser.assertEquals(warning, "Please enter a valid Email");
					if (warning != "") {
						PageElement.closeWarningSingleBtn(driver, "OK");
						Thread.sleep(500);
					}
					signup.entervalidEmail();
					signup.submitSignUp();
					asser.assertEquals(PageElement.getWarningText(driver), "Mandatory fields can't be left blank");
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying sign up with autoapproval and email", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(groups={"signup","autoapproval"})
	public void verifySignUpWithAutoApprovalforPhoneAndPassword() {
		Logger.info("********Test Method Starts: verifySignUpWithAutoApprovalforPhoneAndPassword********");
		PageElement.changeContextToWebView(driver);
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					signup.enterName();
					signup.entervalidEmail();
					signup.enterPhone();
					signup.shortPassword();
					signup.submitSignUp();
					String warning = PageElement.getWarningText(driver);
					asser.assertEquals(warning, "Password length should be minimum 8 characters.");
					if (warning != "") {
						PageElement.closeWarningSingleBtn(driver, "OK");
						Thread.sleep(500);
					}
					// verification of confirm password
					signup.enterPassword();
					signup.enterWrongConfirmPassword();
					signup.submitSignUp();
					String pwd_warning = PageElement.getWarningText(driver);
					asser.assertEquals(pwd_warning, "Password don't match.Try again");
					if (pwd_warning != "") {
						PageElement.closeWarningSingleBtn(driver, "OK");
						Thread.sleep(500);
					}	
				}
				signup.enterConfirmPassword();
				signup.submitSignUp();
				asser.assertEquals(PageElement.getWarningText(driver), "Mandatory fields can't be left blank");
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying sign up with autoapproval and phone and password", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test(dependsOnGroups={"signup"},alwaysRun=true)
	public void verifySignUpWithAutoApprovalcompleteForm() {
		Logger.info("********Test Method Starts: verifySignUpWithAutoApprovalcompleteForm********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					signup.enterName();
					signup.entervalidEmail();
					signup.enterPhone();
					signup.enterPassword();
					signup.enterConfirmPassword();
					signup.selectGender();
					signup.enterState();
					signup.selectCountry();
					signup.selectCheckBox();
					signup.enterText();
					signup.selectList();
					signup.clickRadio();
					signup.submitSignUp();
					Thread.sleep(1000);
					boolean menuOpen = new AppypieMenuPage(driver).isPageExist("about");
					asser.assertTrue(menuOpen, "sign up is not successful");
					if (!menuOpen) {
						asser.assertEquals(PageElement.getWarningText(driver), "No warning",
								"Sign up form is not submitted succesfully");
					}else{
					signup.setUserValue();
					}
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying sign up with autoapproval complete form", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@BeforeGroups(groups={"signup","autoapproval"})
	public String  autoapprovalPrecondition() {
		String status = "";
		int value=2;
		System.out.println("Before Group for LDAP called");
		List<String> list = new ArrayList<String>();
		list.add("auto_aproval");
		try {
			String response = LoginServiceHandler.getSettingValues(list);
		    status = response.substring(response.indexOf("status\":\"") + 9, response.lastIndexOf("\"}"));
			if (status.toUpperCase().equals("success".toUpperCase())) {
				value = Integer.parseInt(String.valueOf(response.charAt(response.indexOf("auto_aproval\":\"") + 15)));
				if(value!=1){
					TreeMap<String,Integer> map= new TreeMap<String,Integer>();
					map.put("auto_aproval", 1);
				    status = LoginServiceHandler.updateUserSetting(map);	
				    driver.resetApp();
				    driver.context("NATIVE_APP");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	public void autoApprovalOff(){
	   asser = new SoftAssert();
	   System.out.println("Before Group for sign up called");
	   
	}

}
