package com.appypie.tests.logintests;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieMenuPage;
import com.appypie.pages.loginpages.AppypieLoginPage;
import com.appypie.pages.loginpages.AppypieSignUpPage;
import com.appypie.pages.loginpages.AppypieVerificationCodePage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.LoginServiceHandler;
import com.appypie.util.PageElement;

public class AppypieEmailVerificationTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieSignUpPage signup;
	AppypieLoginPage login;
	AppypieVerificationCodePage verification;

	@Override
	@BeforeTest
	public void pageSetUp() {
		signup = new AppypieSignUpPage(driver);
		login = new AppypieLoginPage(driver);
		verification= new AppypieVerificationCodePage(driver);
	}
	
	@Test(groups={"emailverify"})
	public void verifyEmailVerification() {
		Logger.info("********Test Method Starts: verifyEmailVerification********");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			PageElement.changeContextToWebView(driver);
			boolean loginPageOpen = login.isLoginPageOpen();
			asser.assertTrue(loginPageOpen, "login page is not open on the app");
			if (loginPageOpen) {
				Thread.sleep(1000);
				login.openSignUpPage();
				boolean signUpOpen = signup.isSignUpPageOpen();
				asser.assertTrue(signUpOpen, "sign up page is not open");
				if (signUpOpen) {
					signup.enterName();
					signup.entervalidEmail();
					signup.enterPhone();
					signup.enterPassword();
					signup.enterConfirmPassword();
					signup.selectGender();
					signup.enterState();
					signup.selectCountry();
					signup.selectCheckBox();
					signup.enterText();
					signup.selectList();
					signup.clickRadio();
					signup.submitSignUp();
					Thread.sleep(1000);
					String msg= PageElement.getWarningText(driver);
					asser.assertTrue(msg.contains("Verification code has been sent to"), "registration failure in email verification");
					if(msg!=""){
						PageElement.closeWarningSingleBtn(driver, "OK");
						Thread.sleep(500);
					}
					asser.assertTrue(verification.isEmailVerificationPageOpen(), "verification code page is not open");
					if(msg.contains("Verification code has been sent to")){
						signup.setUserValue();
					}
				}
			}

		} catch (Exception e) {
			Logger.error("Error occurs while verifying sign up with email verification functionality", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@BeforeGroups(groups={"emailverify"})
	public String  autoapprovalPrecondition() {
		String status = "";
		int value=2;
		System.out.println("Before Group for Email verification called");
		List<String> list = new ArrayList<String>();
		list.add("email_verification");
		try {
			String response = LoginServiceHandler.getSettingValues(list);
		    status = response.substring(response.indexOf("status\":\"") + 9, response.lastIndexOf("\"}"));
			if (status.toUpperCase().equals("success".toUpperCase())) {
				value = Integer.parseInt(String.valueOf(response.charAt(response.indexOf("email_verification\":\"") + 21)));
				if(value!=1){
					TreeMap<String,Integer> map= new TreeMap<String,Integer>();
					map.put("email_verification", 1);
				    status = LoginServiceHandler.updateUserSetting(map);	
				    driver.resetApp();
				    driver.context("NATIVE_APP");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	@AfterGroups(groups={"emailverify"})
	public void ldapPostCondition(){
		try{
			TreeMap<String,Integer> map= new TreeMap<String,Integer>();
			map.put("email_verification", 0);
		    LoginServiceHandler.updateUserSetting(map);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
