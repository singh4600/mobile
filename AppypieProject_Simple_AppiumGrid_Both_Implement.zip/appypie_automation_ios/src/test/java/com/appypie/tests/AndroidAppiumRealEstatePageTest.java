package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.RealEstate.AddPropertyPage;
import com.appypie.pages.RealEstate.AddPropertytypeRealEsatePage;
import com.appypie.pages.RealEstate.CanatplaceRealEstatePage;
import com.appypie.pages.RealEstate.CommanRealEstate;
import com.appypie.pages.RealEstate.DeshboardRealEstatePage;
import com.appypie.pages.RealEstate.FilterPage;
import com.appypie.pages.RealEstate.MenuRealEstate;
import com.appypie.pages.RealEstate.ReviewRealEstatePage;
import com.appypie.pages.RealEstate.SendInquiryRealEstatePage;
import com.appypie.pages.RealEstate.UpdatePropertyRealEsatePage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.MobileElement;

public class AndroidAppiumRealEstatePageTest extends TestSetup {

	public By i_backbtnhyperLink= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeButton");
	 public By i_cancelCall= By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	
	
	private static final Logger Logger = Log.createLogger();

	AddPropertytypeRealEsatePage addPropertytype;
	CanatplaceRealEstatePage canatplace;
	DeshboardRealEstatePage deshboard;
	MenuRealEstate menu;
	CommanRealEstate comm;
	ReviewRealEstatePage review;
	SendInquiryRealEstatePage sendInquiry;
	UpdatePropertyRealEsatePage updateproperty;
	AddPropertyPage addProperty;
	FilterPage filter;

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		addPropertytype=new AddPropertytypeRealEsatePage(driver);
		canatplace=new CanatplaceRealEstatePage(driver);
		deshboard=new DeshboardRealEstatePage(driver);
		menu=new MenuRealEstate(driver);
		comm=new CommanRealEstate(driver);
		review=new ReviewRealEstatePage(driver);
		sendInquiry=new SendInquiryRealEstatePage(driver);
		updateproperty=new UpdatePropertyRealEsatePage(driver);
		addProperty=new AddPropertyPage(driver);
		filter=new FilterPage(driver);

	}


	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Verify() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + comman.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VerifyRealEstateModuleOpen() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyRealEstateModuleOpen()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				comm.Getactualtext(comm.header_gettext);

				Boolean homeshila =comm.IselementPresent(deshboard.Homeshilalink);
				s_assert.assertTrue(homeshila, "Homeshila is not present");

				Boolean dreamHouse =comm.IselementPresent(deshboard.dreamHouselink);
				s_assert.assertTrue(dreamHouse, "Dream House is not present");

				Boolean backbt=comm.Openlinks(deshboard.backbtn);
				s_assert.assertTrue(backbt, "back button is not working on deshboard page");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifyDreamHouse() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyDreamHouse()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				//deshboard.Login();	
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							//comm.Openlinks(menu.login_gettext);
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");

						}
						else{
							System.out.println("User Is already login");

							Boolean mainmenuu=comm.IselementPresent(menu.mainMenulink);
							if (mainmenuu) {
								comm.Openlinks(menu.mainMenulink);
							}
							else{
								System.out.println("Main Menu Not present");
							}
						}
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");



					Boolean propertypresent=comm.getListofLink(deshboard.propertylist_gettext);
					s_assert.assertTrue(propertypresent, "Property list is not present");

					Boolean fav=comm.Openlinks(deshboard.Favlink);
					s_assert.assertTrue(fav, "favourite link is not working");

					Boolean share=comm.Openlinks(deshboard.sharelink);
					if (share) {
						driver.context("NATIVE_APP");

						if (!globledeviceName.equals("iPhone")) {
							Boolean sharelist=comm.getListofLink(deshboard.sharelistNative_gettext);
							if (sharelist) {
								driver.navigate().back();
							}
							s_assert.assertTrue(sharelist, "Share list is not geting");
						}
						else {
							Boolean sharelist=comm.getListofLink(PageElement.i_share);
							if (sharelist) {
								Boolean icancel=PageElement.Accessibilitylinks(PageElement.i_cancel);
								s_assert.assertTrue(icancel,"i_cancleshare Button is not working");
							}
							s_assert.assertTrue(sharelist, "Share list is not geting");
						}
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(share, "Share link is not working");
					TimeUnit.SECONDS.sleep(2);
					Boolean search=comm.Openlinks(deshboard.searchlink);
					if (search) {
						Boolean searchtext=comm.TextField(deshboard.searchTextlink, "Rajiv Chowk, New Delhi, Delhi, India");
						if (searchtext) {
							/*	-------down cast driver--------------
							 * AndroidDriver driver1= (AndroidDriver)driver;
							driver1.pressKeyCode(AndroidKeyCode.ENTER);*/
							PageElement.tapDeviceOk(driver); 

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "back Button is not working");

							String Propertyname=comm.Getactualtext(comm.header_gettext);
							s_assert.assertNotNull(Propertyname, "Property header name is null after search perporty on search filed");
						}
						s_assert.assertTrue(searchtext, "Search text is not working");
					}
					s_assert.assertTrue(search, "Search link is not working");

					Boolean filterBy=comm.IselementPresent(deshboard.filterBylink);
					s_assert.assertTrue(filterBy, "Fileter By link is not present");

					Boolean sortBy=comm.IselementPresent(deshboard.sortBylink);
					s_assert.assertTrue(sortBy, "Sort By link is not present");

					Boolean call=comm.Openlinks(deshboard.calllink);
					if (call) {
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							Boolean oknative=comm.Openlinks(deshboard.OkNativeBtn);
							s_assert.assertTrue(oknative, "Ok button is not working");
						}
						else {
							Boolean oknative=PageElement.Accessibilitylinks(deshboard.i_cancelCallAcc);
							s_assert.assertTrue(oknative, "i_cancel call button is not working");
						}
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(call, "Call link is not working0?:  ");

					Boolean map=comm.Openlinks(deshboard.maplink);
					if (map) {
						driver.context("NATIVE_APP");

						if (!globledeviceName.equals("iPhone")) {
							comm.Getactualtext(comm.header_gettext_native);
							Boolean backnati=comm.Openlinks(comm.BackButtonNative);
							s_assert.assertTrue(backnati, " Native Back Button is not working");
						}
						else {
							comm.Getactualtext(PageElement.i_header_gettext_native);
							Boolean backnati=comm.Openlinks(PageElement.i_backbutton);
							s_assert.assertTrue(backnati, " i_Back Button is not working");
						}

						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(map, "Map link is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not open");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifyRatingAndReview()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyRatingAndReview()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				//deshboard.Login();	
				comm.Getactualtext(comm.header_gettext);

				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");
						}
						else{
							System.out.println("User Is already login");
							Boolean mainmenuu=comm.IselementPresent(menu.mainMenulink);
							if (mainmenuu) {
								comm.Openlinks(menu.mainMenulink);
							}
							else{
								System.out.println("Main Menu Not present");
							}
						}
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
					Boolean firstPropertry=comm.Openlinks(deshboard.firstPropertylink);
					if (firstPropertry) {
						comm.Getactualtext(comm.header_gettext);

						Boolean rating=comm.Openlinks(canatplace.rating_Reviewlink);
						if (rating) {
							comm.Getactualtext(review.reviewsHeading_gettext);

							comm.TwoValueReturn(review.reviewlist_gettext, review.ratingStarList_gettext);

							Boolean fav=comm.Openlinks(review.favlink);
							if (fav) {
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(fav, "Fav link is not working");

							Boolean call=comm.IselementPresent(review.calllink);
							s_assert.assertTrue(call, "Call link is not present");

							Boolean map=comm.IselementPresent(review.maplink);
							s_assert.assertTrue(map, "Map link is not present");

							Boolean reviewlink=comm.Openlinks(review.reviewlink);
							if (reviewlink) {
								comm.Getactualtext(comm.header_gettext);

								Boolean star=comm.IselementPresent(review.star1link);
								if (star) {
									comm.Openlinks(review.star1link);
									comm.Openlinks(review.star2link);
									comm.Openlinks(review.star3link);
									comm.Openlinks(review.star4link);
									comm.Openlinks(review.star5link);
								}
								s_assert.assertTrue(star, "Star is not present");

								Boolean reviewcomment=comm.TextField(review.editreviewtext, "Good to Go Live");
								if (reviewcomment) {
									Boolean submitbtn=comm.Openlinks(review.submitlink);
									if (submitbtn) {
										comm.IfAlertpresent();
									}
									s_assert.assertTrue(submitbtn, "Submit Button is not working");
								}
								s_assert.assertTrue(reviewcomment, "Review Text filed is not present");
							}
							s_assert.assertTrue(reviewlink, "Review link is not working");
						}
						s_assert.assertTrue(rating, "Rating_Review link is not working");

					}
					s_assert.assertTrue(firstPropertry, "First Pproperty link is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyFirstProperty() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFirstProperty()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				//deshboard.Login();	
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");
						}
						else{
							System.out.println("User Is already login");
							Boolean mainmenuu=comm.IselementPresent(menu.mainMenulink);
							if (mainmenuu) {
								comm.Openlinks(menu.mainMenulink);
							}
							else{
								System.out.println("Main Menu Not present");
							}
						}
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
					Boolean firstPropertry=comm.Openlinks(deshboard.firstPropertylink);
					if (firstPropertry) {
						comm.Getactualtext(comm.header_gettext);

						Boolean fav=comm.Openlinks(canatplace.fav);
						if (fav) {
							//	deshboard.Login();	
							comm.IfAlertpresent();
						}
						s_assert.assertTrue(fav, "Fav Btn link is not working");

						Boolean nextimg=comm.Openlinks(canatplace.nextImagelink);
						if (nextimg) {
							Boolean imgopen=comm.Openlinks(canatplace.imgOpenlink);
							if (imgopen) {
								Boolean banckbtn=comm.Openlinks(canatplace.backbtnAfterImgOpenlink);
								//s_assert.assertTrue(banckbtn, "Back Btn is not working after open img");
							}
							s_assert.assertTrue(imgopen, "Image open link is not working");
						}
						s_assert.assertTrue(nextimg, "Next Image link is not working");


						Boolean call=comm.IselementPresent(canatplace.calllink);
						s_assert.assertTrue(call, "Call link is not working");

						Boolean map=comm.Openlinks(canatplace.maplink);
						if (map) {
							driver.context("NATIVE_APP");
							if (!globledeviceName.equals("iPhone")) {
								comm.Getactualtext(comm.header_gettext_native);
								Boolean backnati=comm.Openlinks(comm.BackButtonNative);
								s_assert.assertTrue(backnati, " Native Back Button is not working");
							}
							else {
								comm.Getactualtext(PageElement.i_header_gettext_native);
								Boolean backnati=comm.Openlinks(PageElement.i_backbutton);
								s_assert.assertTrue(backnati, " i_Back Button is not working");
							}
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(map, "map link is not working");

						String forRent=comm.Getactualtext(canatplace.forRent_place_gettext);
						s_assert.assertNotNull(forRent, "For Rent Get Test getting Null value");

						Boolean amenitiesList=comm.getListofLink(canatplace.amentieslist_gettext);
						s_assert.assertTrue(amenitiesList, "Amenities list is not getting");

						Boolean propertyDetails=comm.getListofLink(canatplace.propertyDetailslist_gettext);
						s_assert.assertTrue(propertyDetails, "property Details list is not getting");

						boolean propertyDescription=comm.IselementPresent(canatplace.propertyDescription_gettext);
						if (propertyDescription) {
							driver.context("NATIVE_APP");
							comm.SwipeBottomToTop();
							PageElement.changeContextToWebView(driver);
							Boolean readmore=comm.Openlinks(canatplace.readmorelink);
							if (readmore) {
								String propertyDescriptiontext=comm.Getactualtext(canatplace.propertyDescription_gettext);
								s_assert.assertNotNull(propertyDescriptiontext, "property Description is getting Null value");
							}
							//s_assert.assertTrue(readmore, "read More link is not working");
						}
						s_assert.assertTrue(propertyDescription, "property Description is not present");

						Boolean sendinquiry=comm.Openlinks(canatplace.sendInquirybtn);
						if (sendinquiry) {

							comm.Getactualtext(comm.header_gettext);

							String requestinfoheading=comm.Getactualtext(sendInquiry.requestInfoheading_gettext);
							s_assert.assertNotNull(requestinfoheading, "Request info heading is getting Null Value");

							Boolean clearnametext=comm.ClearTextField(sendInquiry.nametext);
							if (clearnametext) {
								Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
								if (clickcheckbtn) {
									comm.IfAlertpresent();
									Boolean name=comm.TextField(sendInquiry.nametext, "QA");
									s_assert.assertTrue(name, "Name text filed is not present");
								}
								s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
							}
							s_assert.assertTrue(clearnametext, "Name text filed is not present");


							Boolean clearEmailtext=comm.ClearTextField(sendInquiry.emailtext);
							if (clearEmailtext) {
								Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
								if (clickcheckbtn) {
									comm.IfAlertpresent();
									Boolean email=comm.TextField(sendInquiry.emailtext, "prince@appypie.com");
									s_assert.assertTrue(email, "Email text filed is not present");
								}
								s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
							}
							s_assert.assertTrue(clearEmailtext, "Email text filed is not present");

							Boolean clearphonetext=comm.ClearTextField(sendInquiry.phonetext);
							if (clearphonetext) {
								Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
								if (clickcheckbtn) {
									comm.IfAlertpresent();
									Boolean phone=comm.TextField(sendInquiry.phonetext, "9540198626");
									s_assert.assertTrue(phone, "phone text filed is not present");
								}
								s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
							}
							s_assert.assertTrue(clearphonetext, "phone text filed is not present");

							Boolean clearsummarytext=comm.ClearTextField(sendInquiry.messagetext);
							if (clearsummarytext) {
								Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
								if (clickcheckbtn) {
									comm.IfAlertpresent();
									Boolean message=comm.TextField(sendInquiry.messagetext, "Good to go live");
									s_assert.assertTrue(message, "message text filed is not present");
								}
								s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
							}
							s_assert.assertTrue(clearsummarytext, "summary text filed is not present");

							Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
							if (clickcheckbtn) {
								comm.Getactualtext(comm.AlertHeader_gettext);
								comm.Getactualtext(comm.AlertText_gettext);
								comm.Openlinks(comm.AlertYes);
								TimeUnit.SECONDS.sleep(10);
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
						}
						s_assert.assertTrue(sendinquiry, "Send Inquiry link is not working");
					}
					s_assert.assertTrue(firstPropertry, "First Pproperty link is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");
		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifyMenuFavourities()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenuFavourities()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");
							comm.Openlinks(deshboard.menulink);
						}
						else{
							System.out.println("User Is already login");
						}

						comm.Openlinks(deshboard.menulink);

						Boolean menulist=comm.getListofLink(menu.menuList_gettext);
						s_assert.assertTrue(menulist, "Menu list is not getting");

						Boolean fav=comm.Openlinks(menu.favouriteslink);
						if (fav) {
							/*String propname=comm.Getactualtext(menu.favProperityName_gettext);
							s_assert.assertNotNull(propname, "Fav Propperty Name is getting Null value");

							String propDetails=comm.Getactualtext(menu.favProperityDetails_gettext);
							s_assert.assertNotNull(propDetails, "Fav prop Details is getting Null value");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "Back Btn is not working");
							Boolean menuu1=comm.Openlinks(deshboard.menulink);
							s_assert.assertTrue(menuu1, "Menu liknk is not working after fav click");*/

						}
						s_assert.assertTrue(fav, "favourite list is not working");

					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 5, description = "")
	public void VerifyMenuAddProperty()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenuAddProperty()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");
							comm.Openlinks(deshboard.menulink);
						}
						else{
							System.out.println("User Is already login");
						}

						comm.Openlinks(deshboard.menulink);

						Boolean addprop=comm.Openlinks(menu.addPropertylink);
						if (addprop) {
							comm.Getactualtext(comm.header_gettext);

							Boolean list=comm.getListofLink(addProperty.addPropertyList_gettext);
							s_assert.assertTrue(list, "Add Property List is not getting");

							Boolean apartment=comm.Openlinks(addProperty.apartmentlink);
							if (apartment) {
								Boolean next=comm.Openlinks(addProperty.nextBtn);
								if (next) {
									Boolean location=comm.TextField(addProperty.locationEnter, "Noida");
									if (location) {
										Boolean sugg=comm.Openlinks(addProperty.suggesstionlink);
										if (sugg) {
											Boolean next1=comm.Openlinks(addProperty.next1Btn);
											if (next1) {
												comm.Getactualtext(comm.header_gettext);

												Boolean rentout=comm.Openlinks(addProperty.rentoutproperty);
												s_assert.assertTrue(rentout, "rentout Property TAB is not working");

												Boolean sellPrope=comm.Openlinks(addProperty.sellProperty);
												s_assert.assertTrue(sellPrope, "sellProperty TAB is not working");

												Boolean builderd=comm.Openlinks(addProperty.builder);
												s_assert.assertTrue(builderd, "builder TAB is not working");

												Boolean brokerr=comm.Openlinks(addProperty.broker);
												s_assert.assertTrue(brokerr, "broker TAb is not working");

												Boolean Ownerr=comm.Openlinks(addProperty.Owner);
												s_assert.assertTrue(Ownerr, "Owner TAB is not working");

												Boolean bedRoomss=comm.Openlinks(addProperty.bedRooms);
												s_assert.assertTrue(bedRoomss, "bedRooms is not working");

												Boolean bathroomss=comm.Openlinks(addProperty.bathrooms);
												s_assert.assertTrue(bathroomss, "bathrooms is not working");

												Boolean projectNamee=comm.TextField(addProperty.projectName,"Appypie");
												s_assert.assertTrue(projectNamee, "projectName is not working");

												Boolean totalFloorr=comm.Openlinks(addProperty.totalFloor);
												s_assert.assertTrue(totalFloorr, "totalFloor drop list is not working");

												driver.context("NATIVE_APP");

												if (!globledeviceName.equals("iPhone")) {
													Boolean FloorNoNativee=comm.Openlinks(addProperty.totalFloorNoNative);
													s_assert.assertTrue(FloorNoNativee, "FloorNoNative is not working");
												}
												else {
													MobileElement element = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
													element.setValue("1");
													Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
													s_assert.assertTrue(done, "i_Done button is not wokring");
													
													/*Boolean FloorNoNativee=comm.Openlinks(addProperty.i_totalFloorNoNative);
													if (FloorNoNativee) {
														Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
														s_assert.assertTrue(done, "i_Done button is not wokring");
													}
													s_assert.assertTrue(FloorNoNativee, "FloorNoNative is not working");*/
													
													
												}
												PageElement.changeContextToWebView(driver);

												Boolean propertyFloorr=comm.Openlinks(addProperty.propertyFloor);
												s_assert.assertTrue(propertyFloorr, "propertyFloor drop list is not working");

												driver.context("NATIVE_APP");

												if (!globledeviceName.equals("iPhone")) {
													Boolean propertyFloorNoNativee=comm.Openlinks(addProperty.propertyFloorNoNative);
													s_assert.assertTrue(propertyFloorNoNativee, "propertyFloorNoNativee is not working");
												}
												else {
													MobileElement element = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
													element.setValue("1");
													Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
													s_assert.assertTrue(done, "i_Done button is not wokring");

													/*Boolean propertyFloorNoNativee=comm.Openlinks(addProperty.i_propertyFloorNoNative);
													if (propertyFloorNoNativee) {
														Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
														s_assert.assertTrue(done, "i_Done button is not wokring propertyFloorNoNativee");
													}
													s_assert.assertTrue(propertyFloorNoNativee, "propertyFloorNoNativee is not working");*/
													
												}
												
												PageElement.changeContextToWebView(driver);


												Boolean phornnoo=comm.TextField(addProperty.phoneNo,"1234567890");
												s_assert.assertTrue(phornnoo, "phoneNo is not working");

												Boolean propertyAreaa=comm.TextField(addProperty.propertyArea,"1250");
												s_assert.assertTrue(propertyAreaa, "propertyArea  is not working");

												Boolean sqmtt=comm.Openlinks(addProperty.sqmt);
												s_assert.assertTrue(sqmtt, "sqmt droplist is not working");

												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													Boolean sqmtnativee=comm.Openlinks(addProperty.sqmtnative);
													s_assert.assertTrue(sqmtnativee, "sqmtnative dro list is not working");
												}
												else {
													
													MobileElement element = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
													element.setValue("Sqft");
													Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
													s_assert.assertTrue(done, "i_Done button is not wokring");
													
													/*Boolean sqmtnativee=comm.Openlinks(addProperty.i_sqmtnative);
													if (sqmtnativee) {
														Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
														s_assert.assertTrue(done, "i_Done button is not wokring sqmtnativee");
														
													}
													s_assert.assertTrue(sqmtnativee, "sqmtnative dro list is not working");*/
												}
												
												PageElement.changeContextToWebView(driver);

												Boolean reservedParkingg=comm.TextField(addProperty.reservedParking,"Appypie");
												s_assert.assertTrue(reservedParkingg, "reservedParking is not working");

												Boolean countparkingg=comm.Openlinks(addProperty.countparking);
												s_assert.assertTrue(countparkingg, "countparking drop list is not working");

												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													Boolean countparkingnONativee=comm.Openlinks(addProperty.countparkingnONative);
													s_assert.assertTrue(countparkingnONativee, "countparkingnONative drop list is not working");
												}
												else {
													
													MobileElement element = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
													element.setValue("1");
													Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
													s_assert.assertTrue(done, "i_Done button is not wokring");
													
													/*Boolean countparkingnONativee=comm.Openlinks(addProperty.i_countparkingnONative);
													if (countparkingnONativee) {
														Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
														s_assert.assertTrue(done, "i_Done button is not wokring countparkingnONativee");
													}
													s_assert.assertTrue(countparkingnONativee, "countparkingnONative drop list is not working");*/
												}
												
												PageElement.changeContextToWebView(driver);

												Boolean nextt=comm.Openlinks(addProperty.next3);
												s_assert.assertTrue(nextt, "Next btn is not working property details Page");

												Boolean expectedRentt=comm.TextField(addProperty.expectedRent,"25000");
												s_assert.assertTrue(expectedRentt, "expectedRent is not working");

												Boolean depositt=comm.TextField(addProperty.deposit,"25000");
												s_assert.assertTrue(depositt, "deposit is not working");

												Boolean leaseDurationn=comm.Openlinks(addProperty.leaseDuration);
												s_assert.assertTrue(leaseDurationn, "leaseDuration is not working ");

												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													Boolean leaseDurationtimeNativee=comm.Openlinks(addProperty.leaseDurationtimeNative);
													s_assert.assertTrue(leaseDurationtimeNativee, "leaseDurationtimeNative is not working ");
												}
												else {
													MobileElement element = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
													element.setValue("Minimum lease duration");
													Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
													s_assert.assertTrue(done, "i_Done button is not wokring");
													
													/*Boolean leaseDurationtimeNativee=comm.Openlinks(addProperty.i_leaseDurationtimeNative);
													if (leaseDurationtimeNativee) {
														Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
														s_assert.assertTrue(done, "i_Done button is not wokring leaseDurationtimeNativee");
													}
													s_assert.assertTrue(leaseDurationtimeNativee, "leaseDurationtimeNative is not working ");*/
												}
												
												PageElement.changeContextToWebView(driver);

												Boolean leaseDurationtextt=comm.TextField(addProperty.leaseDurationtext,"25");
												s_assert.assertTrue(leaseDurationtextt, "leaseDurationtext is not working ");

												Boolean avaliabilityy=comm.Openlinks(addProperty.avaliability);
												s_assert.assertTrue(avaliabilityy, "avaliability is not working ");

												driver.context("NATIVE_APP");
												if (!globledeviceName.equals("iPhone")) {
													Boolean avaliabilityNativee=comm.Openlinks(addProperty.avaliabilityNative);
													s_assert.assertTrue(avaliabilityNativee, "avaliabilityNative is not working ");
												}
												else {
													
													MobileElement element = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
													element.setValue("Available Now");
													Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
													s_assert.assertTrue(done, "i_Done button is not wokring");
													
													/*Boolean avaliabilityNativee=comm.Openlinks(addProperty.i_avaliabilityNative);
													if (avaliabilityNativee) {
														Boolean done=comm.Openlinks(PageElement.i_Donebtn_Keyboard);
														s_assert.assertTrue(done, "i_Done button is not wokring avaliabilityNativee");
													}
													s_assert.assertTrue(avaliabilityNativee, "avaliabilityNative is not working ");*/
												}
										
												PageElement.changeContextToWebView(driver);

												Boolean amenitiess=comm.Openlinks(addProperty.amenities);
												if (amenitiess) {
													comm.Getactualtext(comm.header_gettext);
													Boolean amenitieslist=comm.getListofLink(addProperty.amenitieslist_gettext);
													s_assert.assertTrue(amenitieslist, "amenities list is not getting");

													Boolean amenitiesselectAlll=comm.Openlinks(addProperty.amenitiesselectAll);
													s_assert.assertTrue(amenitiesselectAlll, "amenitiesselectAll is not working ");

													Boolean amenitiesdoneBtnn=comm.Openlinks(addProperty.amenitiesdoneBtn);
													s_assert.assertTrue(amenitiesdoneBtnn, "amenitiesdoneBtn is not working ");
												}
												s_assert.assertTrue(amenitiess, "amenities is not working ");

												Boolean videoo=comm.Openlinks(addProperty.video);
												s_assert.assertTrue(videoo, "video is not working ");

												Boolean youtubee=comm.Openlinks(addProperty.youtube);
												s_assert.assertTrue(youtubee, "youtube is not working ");

												Boolean galleryy=comm.Openlinks(addProperty.gallery);
												s_assert.assertTrue(galleryy, "gallery is not working ");

												Boolean uploadbtnn=comm.Openlinks(addProperty.uploadbtn);
												s_assert.assertTrue(uploadbtnn, "uploadbtn is not working ");

												Boolean canclelinkk=comm.Openlinks(addProperty.canclelink);
												s_assert.assertTrue(canclelinkk, "canclelink is not working ");

												Boolean descriptionn=comm.TextField(addProperty.description,"Appypie");
												s_assert.assertTrue(descriptionn, "description is not working ");

												Boolean doneBtnn=comm.Openlinks(addProperty.doneBtn);
												if (doneBtnn) {
													comm.IfAlertpresent();
												}
												s_assert.assertTrue(doneBtnn, "doneBtn is not working ");
											}
											s_assert.assertTrue(next1, "2nd Next Button is not working");
										}
										s_assert.assertTrue(sugg, "Suggesstion is not working");
									}
									s_assert.assertTrue(location, "Location text is not working");
								}
								s_assert.assertTrue(next, "Next Button is not working");
							}
							s_assert.assertTrue(apartment, "Apartment link is not working");
						}
						s_assert.assertTrue(addprop, "addProperty list is not working");
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VerifyMenuUpdateProperty() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMenuUpdateProperty()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");	
							comm.Openlinks(deshboard.menulink);
						}
						else{
							System.out.println("User Is already login");
						}

						comm.Openlinks(deshboard.menulink);

						Boolean updateProperty=comm.Openlinks(menu.updatePropertylink);
						if (updateProperty) {
							comm.Getactualtext(comm.header_gettext);

							Boolean editUpdatePropertyy=comm.Openlinks(addProperty.editUpdateProperty);
							s_assert.assertTrue(editUpdatePropertyy, "editUpdateProperty  is not working");

							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "backbtn list is not working");

							Boolean deleteUpdatePropertyy=comm.Openlinks(addProperty.deleteUpdateProperty);
							if (deleteUpdatePropertyy) {
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(deleteUpdatePropertyy, "deleteUpdate Property is not working");


						}
						s_assert.assertTrue(updateProperty, "updateProperty list is not working");

					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 7, description = "")
	public void VerifyMapHomePage() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMapHomePage()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");	
						}
						else{
							System.out.println("User Is already login");
							comm.Openlinks(menu.mainMenulink);
						}

						Boolean map=comm.Openlinks(deshboard.mapHeaderlink);
						if (map) {
							comm.Getactualtext(comm.header_gettext);
							Boolean backbtn=comm.Openlinks(comm.BackButton1);
							s_assert.assertTrue(backbtn, "Back Button is not working");
						}
						s_assert.assertTrue(map, "Map link is not working");


						Boolean headersearchlinkk=comm.Openlinks(deshboard.headersearchlink);
						if (headersearchlinkk) {

							Boolean enterlocationn=comm.TextField(deshboard.enterlocation,"Noida");
							s_assert.assertTrue(enterlocationn, "enter location is not working");

							Boolean noida=comm.Openlinks(deshboard.selectNoida);
							s_assert.assertTrue(noida, "noida is not working");
						}
						s_assert.assertTrue(headersearchlinkk, "header search link is not working");

					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 8, description = "")
	public void VerifySaleProperty()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySaleProperty()");
		boolean exception = false;
		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");	
						}
						else{
							System.out.println("User Is already login");
							comm.Openlinks(menu.mainMenulink);
						}

						try{
							String saledetails=driver.findElement(deshboard.saleProperty_gettext).getText();
							System.out.println(saledetails);
						}
						catch (Exception e) {
							System.out.println("anurag111");
							String saledetails=driver.findElement(deshboard.saleProperty_gettext1).getText();
							System.out.println(saledetails);
						}

						Boolean saleporplink=false;
						try{
							saleporplink=driver.findElements(deshboard.salePropertylink).size()!=0;
							driver.findElement(deshboard.salePropertylink).click();

						}catch (Exception e) {
							System.out.println("anurag222");
							saleporplink=driver.findElements(deshboard.salePropertylink1).size()!=0;
							driver.findElement(deshboard.salePropertylink1).click();
						}


						//Boolean saleporplink=comm.Openlinks(deshboard.salePropertylink);
						if (saleporplink) {
							comm.Getactualtext(comm.header_gettext);

							Boolean next=comm.Openlinks(canatplace.nextBtn);
							if (next) {
								Boolean vide=comm.Openlinks(canatplace.video);
								if (vide) {
									driver.context("NATIVE_APP");
									if (!globledeviceName.equals("iPhone")) {
										driver.navigate().back();
									}
									else {

										Boolean ibackbtn=comm.Openlinks(PageElement.i_backbuttonFullPath);
										s_assert.assertTrue(ibackbtn, "i_banck butto is not working Video Page");
										
									}
									/*
									 Boolean backbtnnative=comm.Actionclick(comm.BackButtonNative);
									s_assert.assertTrue(backbtnnative,"Back Button is not working");*/
									
									PageElement.changeContextToWebView(driver);
								}
								s_assert.assertTrue(vide, "Video Btn is not working");
							}
							s_assert.assertTrue(next, "Next Img Btn is not working");

							Boolean addressTAB=comm.Openlinks(canatplace.addresslink);
							if (addressTAB) {
								driver.context("NATIVE_APP");
								if (!globledeviceName.equals("iPhone")) {
									driver.navigate().back();
								}
								else {
									Boolean ibackbtn=comm.Openlinks(PageElement.i_backbutton);
									s_assert.assertTrue(ibackbtn, "i_banck butto is not working Address TAB");
								}
								/*Boolean backbtnnative=comm.Actionclick(comm.BackButtonNative);
								s_assert.assertTrue(backbtnnative,"Back Button is not working");*/
								
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(addressTAB, "addressTAB link is not working");

							Boolean hyperlinkk=comm.Openlinks(canatplace.hyperlink);
							if (hyperlinkk) {
								driver.context("NATIVE_APP");
								if (!globledeviceName.equals("iPhone")) {
									driver.navigate().back();
								}
								else {
									Boolean ibackbtn=comm.Openlinks(deshboard.i_backbtnhyperLink);
									s_assert.assertTrue(ibackbtn, "i_banck butto is not working hyperlink page");
								}
								/*Boolean backbtnnative=comm.Actionclick(comm.BackButtonNative);
								s_assert.assertTrue(backbtnnative,"Back Button is not working");*/
								
								PageElement.changeContextToWebView(driver);
							}
							//s_assert.assertTrue(hyperlinkk, "hyperlink link is not working");


							Boolean sendinquiry=comm.Openlinks(canatplace.sendInquirybtn);
							if (sendinquiry) {

								Boolean clearnametext=comm.ClearTextField(sendInquiry.nametext);
								if (clearnametext) {
									Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
									if (clickcheckbtn) {
										comm.IfAlertpresent();
										Boolean name=comm.TextField(sendInquiry.nametext, "QA");
										s_assert.assertTrue(name, "Name text filed is not present");
									}
									s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
								}
								s_assert.assertTrue(clearnametext, "Name text filed is not present");


								Boolean clearEmailtext=comm.ClearTextField(sendInquiry.emailtext);
								if (clearEmailtext) {
									Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
									if (clickcheckbtn) {
										comm.IfAlertpresent();
										Boolean email=comm.TextField(sendInquiry.emailtext, "prince@appypie.com");
										s_assert.assertTrue(email, "Email text filed is not present");
									}
									s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
								}
								s_assert.assertTrue(clearEmailtext, "Email text filed is not present");

								Boolean clearphonetext=comm.ClearTextField(sendInquiry.phonetext);
								if (clearphonetext) {
									Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
									if (clickcheckbtn) {
										comm.IfAlertpresent();
										Boolean phone=comm.TextField(sendInquiry.phonetext, "9540198626");
										s_assert.assertTrue(phone, "phone text filed is not present");
									}
									s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
								}
								s_assert.assertTrue(clearphonetext, "phone text filed is not present");

								Boolean clearsummarytext=comm.ClearTextField(sendInquiry.messagetext);
								if (clearsummarytext) {
									Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
									if (clickcheckbtn) {
										comm.IfAlertpresent();
										Boolean message=comm.TextField(sendInquiry.messagetext, "Good to go live");
										s_assert.assertTrue(message, "message text filed is not present");
									}
									s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
								}
								s_assert.assertTrue(clearsummarytext, "summary text filed is not present");

								Boolean clickcheckbtn=comm.Openlinks(sendInquiry.checkAvailabilityBtn);
								if (clickcheckbtn) {
									comm.Getactualtext(comm.AlertHeader_gettext);
									comm.Getactualtext(comm.AlertText_gettext);
									comm.Openlinks(comm.AlertNo);
									TimeUnit.SECONDS.sleep(10);
									comm.IfAlertpresent();
								}
								s_assert.assertTrue(clickcheckbtn, "Check Availability Button is not present");
							}
							s_assert.assertTrue(sendinquiry, "Send Inquiry link is not working");
						}
						s_assert.assertTrue(saleporplink, "Sale Property link is not working");
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 9, description = "")
	public void VerifyFilter()  {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFilter()");
		boolean exception = false;

		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");	
						}
						else{
							System.out.println("User Is already login");
							comm.Openlinks(menu.mainMenulink);
						}

						Boolean filterBy=comm.Openlinks(deshboard.filterBylink);
						if (filterBy) {
							comm.Getactualtext(comm.header_gettext);

							Boolean rentt=comm.Openlinks(filter.rentTab);
							s_assert.assertTrue(rentt, "Rent TAB is not working");

							Boolean sell=comm.Openlinks(filter.sellTab);
							s_assert.assertTrue(sell, "sell TAB is not working");

							//------------------
							comm.SeekBar(filter.distanceBAR, "slider");


							//-------------------
							Boolean listby=comm.Openlinks(filter.listedBylink);
							if (listby) {
								/*	Boolean =comm.Openlinks(filter.);
								s_assert.assertTrue(, "  is not working");*/
								Boolean ownercheckboxx=comm.Openlinks(filter.ownercheckbox);
								s_assert.assertTrue(ownercheckboxx, "owner check box is not working");

								Boolean builderCheckboxx=comm.Openlinks(filter.builderCheckbox);
								s_assert.assertTrue(builderCheckboxx, "builder Check box  is not working");

								Boolean brokerCheckboxx=comm.Openlinks(filter.brokerCheckbox);
								s_assert.assertTrue(brokerCheckboxx, "broker Check box  is not working");

							}
							s_assert.assertTrue(listby, "List By link is not working");

							Boolean propertyTypee=comm.Openlinks(filter.propertyType);
							if (propertyTypee) {
								/*	Boolean =comm.Openlinks(filter.);
								s_assert.assertTrue(, "  is not working");*/
								Boolean villachCheckboxx=comm.Openlinks(filter.villachCheckbox);
								s_assert.assertTrue(villachCheckboxx, "villach Check box is not working");

								Boolean hostelCheckboxx=comm.Openlinks(filter.hostelCheckbox);
								s_assert.assertTrue(hostelCheckboxx, "hostel Check box  is not working");


								comm.ScrollPerticularSection(filter.apartimentCheckbox);
								Boolean apartimentCheckboxx=comm.Openlinks(filter.apartimentCheckbox);
								s_assert.assertTrue(apartimentCheckboxx, "apartiment Check box  is not working");

							}
							s_assert.assertTrue(propertyTypee, "property Type link is not working");

							TimeUnit.SECONDS.sleep(5);
							comm.SwipeBottomToTop();

							comm.SeekBar(filter.priceBAR, "sliderprice");

							Boolean bed=comm.Openlinks(filter.bedRooms);
							s_assert.assertTrue(bed, "BedRooms link is not working");

							Boolean bathRoomm=comm.Openlinks(filter.bathRoom);
							s_assert.assertTrue(bathRoomm, "bathRoom link is not working");

							Boolean applyBtnn=comm.Openlinks(filter.applyBtn);
							s_assert.assertTrue(applyBtnn, "apply Btn is not working");
						}
						s_assert.assertTrue(filterBy, "Fileter By link is not present");
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 10, description = "")
	public void VerifySortBy() {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifySortBy()");
		boolean exception = false;

		try {
			Boolean RS=comm.Openlinks(deshboard.realEstateModulelink);
			if (RS) {
				Boolean dreamHouse =comm.Openlinks(deshboard.dreamHouselink);
				if (dreamHouse) {
					Boolean menuu=comm.Openlinks(deshboard.menulink);
					if (menuu) {
						Boolean login=comm.IselementPresent(menu.login_gettext);
						if (login) {
							comm.Openlinks(menu.login_gettext);
							PageElement.login(driver, menu.login_gettext, "appypie2016@gmail.com", "12345678");	
						}
						else{
							System.out.println("User Is already login");
							comm.Openlinks(menu.mainMenulink);
						}

						Boolean sortBy=comm.Openlinks(deshboard.sortBylink);
						if (sortBy) {
							comm.Getactualtext(comm.header_gettext);

							Boolean sortBylist=comm.getListofLink(filter.sortBylist_gettext);
							s_assert.assertTrue(sortBylist, " sortBylist is not getting");

							Boolean recentAdded=comm.Openlinks(filter.recentAddedRediobtn);
							s_assert.assertTrue(recentAdded, "Recent Added Radio Button is not working");

							Boolean priceHtoL=comm.Openlinks(filter.priceHtoLRediobtn);
							s_assert.assertTrue(priceHtoL, "price H to L Radio Button is not working");

							Boolean priceLtoH=comm.Openlinks(filter.priceLtoHRediobtn);
							s_assert.assertTrue(priceLtoH, "price L to H Radio Button is not working");

							Boolean distance=comm.Openlinks(filter.distanceRediobtn);
							s_assert.assertTrue(distance, "istance Radio Button is not working");

							Boolean applyBtnn=comm.Openlinks(filter.applyBtnsortBy);
							s_assert.assertTrue(applyBtnn, "Apply Button is not working");
						}
						s_assert.assertTrue(sortBy, "sort By link is not present");
					}
					s_assert.assertTrue(menuu, "Menu liknk is not working");
				}
				s_assert.assertTrue(dreamHouse, "Dream House is not present");
			}
			s_assert.assertTrue(RS,"Real Estate module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


}
