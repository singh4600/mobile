package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.NavigationPage;
import com.appypie.pages.Photo.CommanClassPhoto;
import com.appypie.pages.Photo.PhotoPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;
public class AndroidAppiumPhotoPageTest extends TestSetup {
	//AppypiePhotoPage photo; 
	private static final Logger Logger= Log.createLogger();

	CommanClassPhoto comm;
	PhotoPage photo;


	@BeforeTest
	@Override
	public void pageSetUp() {
		//photo=new AppypiePhotoPage(driver);
		comm=new CommanClassPhoto(driver);
		photo=new PhotoPage(driver);
	}

	//---------------------------------------------------------------------------------------------------- 

	@Test(priority = 0, description = "")
	public void VerifyPhotoModule() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyPhotoModule()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");
				Boolean backbtn=comm. Openlinks(photo.backBtnHomePage);
				s_assert.assertTrue(backbtn, "Back Button is not working on Photo Home Page");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +  e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VerifyFaceBook() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFaceBook()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");

				Boolean fb=comm.Openlinks(photo.clickFacebook);
				if (fb) {
					TimeUnit.SECONDS.sleep(10);
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Facebook");
					String un=comm.Getactualtext(photo.fbuser_gettext);
					s_assert.assertNotNull(un, "Photo User is getting Null value");

					String photoCount=comm.Getactualtext(photo.fbPhotoCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean FBphoto=comm.Openlinks(photo.FBphotoOpen);
					if (FBphoto) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Facebook");

						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);
						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend FB photo");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(FBphoto, "First photo is not open of FB");

					Boolean backbtnFBpage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnFBpage, "Back Button is not working FB page");
				}
				s_assert.assertTrue(fb, "Facebook link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VerifyFlickrPhotoStream() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFlickr()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");
				Boolean Flickr=comm.Openlinks(photo.clickFlickr);
				if (Flickr) {
					TimeUnit.SECONDS.sleep(10);

					comm.Openlinks(photo.photoStremTAB);

					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Flickr");
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean flickrphoto=comm.Openlinks(photo.flickrphotoOpen);
					if (flickrphoto) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Flickr");
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);
						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend flickr photo");
						driver.context("NATIVE_APP");
						//comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(flickrphoto, "First photo is not open of flickr");

					Boolean showmoreText=comm.scroll_at_a_particular_element(photo.showMorelink);
					if (showmoreText) {
						System.out.println("scroll_at_a_particular_element");
					}
					else{
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop1(500);
						comm.SwipeBottomToTop1(500);
						comm.SwipeBottomToTop1(500);
						PageElement.changeContextToWebView(driver);
					}


					Boolean showmore=comm.IselementPresent(photo.showMorelink);
					if (showmore) {
						Boolean show=comm.Openlinks(photo.showMorelink);
						if (show) {
							driver.context("NATIVE_APP");
							comm.SwipeBottomToTop();
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(show, "Show More link is not working");
					}
					else{
						System.out.println("Show More Link is not present");
					}


					Boolean backbtnFlickrpage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnFlickrpage, "Back Button is not working flickr page");
				}
				s_assert.assertTrue(Flickr, "Flickr link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +  e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VerifyPinterest() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyPinterest()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");
				Boolean Pinterest=comm.Openlinks(photo.clickPinterest);
				if (Pinterest) {
					TimeUnit.SECONDS.sleep(10);
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Pinterest");
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean Pinterestphoto=comm.Openlinks(photo.flickrphotoOpen);
					if (Pinterestphoto) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Pinterest");
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);
						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend Pinterest photo");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(Pinterest, "First photo is not open of Pinterest");

					Boolean backbtnPinterestpage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnPinterestpage, "Back Button is not working Pinterest page");
				}
				s_assert.assertTrue(Pinterest, "Pinterest link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +  e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 4, description = "")
	public void VerifyInstagram() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyInstagram()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");
				Boolean Instagram=comm.Openlinks(photo.clickInstagram);
				if (Instagram) {
					TimeUnit.SECONDS.sleep(10);
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Instagram");
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean Instagramphoto=comm.Openlinks(photo.flickrphotoOpen);
					if (Instagramphoto) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Instagram");
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);

						String like=comm.Getactualtext(photo.like_gettext);
						s_assert.assertNotNull(like, "Like gettext is getting Null value");


						String comment=comm.Getactualtext(photo.comment_gettext);
						s_assert.assertNotNull(comment, "Comment gettext is getting Null value");

						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend Instagram photo");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);

						Boolean loadmoree=comm.Openlinks(photo.loadMore);
						if (loadmoree) {
							TimeUnit.SECONDS.sleep(10);
							driver.context("NATIVE_APP");
							comm.SwipeBottomToTop();
							PageElement.changeContextToWebView(driver);
						}
						s_assert.assertTrue(loadmoree, "Load More Link i snot working");
					}
					s_assert.assertTrue(Instagramphoto, "First photo is not open of Instagram");

					Boolean backbtnInstagrampage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnInstagrampage, "Back Button is not working Instagram page");
				}
				s_assert.assertTrue(Instagram, "Instagram link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +  e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 5, description = "")
	public void VerifyCustom() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");
				Boolean Custom=comm.Openlinks(photo.clickCustom);
				if (Custom) {
					TimeUnit.SECONDS.sleep(10);
					s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Custom");
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean Customphoto=comm.Openlinks(photo.flickrphotoOpen);
					if (Customphoto) {
						s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Custom");
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);
						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend Custom photo");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(Customphoto, "First photo is not open of Instagram");

					Boolean backbtnInstagrampage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnInstagrampage, "Back Button is not working Custom page");
				}
				s_assert.assertTrue(Custom, "Custom link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" +  e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 6, description = "")
	public void VerifyOneDrive() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyOneDrive()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				comm.Getactualtext(comm.header_gettext);
				Boolean OneDrive=comm.Openlinks(photo.clickOneDrive);
				if (OneDrive) {
					TimeUnit.SECONDS.sleep(15);
					comm.Getactualtext(comm.header_gettext);
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean OneDrivephoto=comm.Openlinks(photo.flickrphotoOpen);
					if (OneDrivephoto) {
						comm.Getactualtext(comm.header_gettext);
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);
						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend OneDrive photo");

						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(OneDrivephoto, "First photo is not open of Instagram");

					Boolean backbtnInstagrampage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnInstagrampage, "Back Button is not working OneDrive page");
				}
				s_assert.assertTrue(OneDrive, "OneDrive link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority = 7, description = "")
	public void VerifyFlickrSet() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyFlickrSet()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Photo");
				Boolean Flickr=comm.Openlinks(photo.clickFlickr);
				if (Flickr) {
					Boolean set=comm.Openlinks(photo.setTAB);
					if (set) {
						TimeUnit.SECONDS.sleep(10);
						String UN=comm.Getactualtext(photo.flickrUser_gettext);
						s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

						String photoCount=comm.Getactualtext(photo.flickCount_gettext);
						s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

						Boolean flickrphoto=comm.Openlinks(photo.firstsetlink);
						if (flickrphoto) {
							Boolean photset=comm.Openlinks(photo.firstphotopenFirstSet);
							if (photset) {
								comm.swipingHorizontal(100);
								TimeUnit.SECONDS.sleep(10);
								Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
								s_assert.assertTrue(backbtn, "Back Button is not working on opend flickr photo");
								driver.context("NATIVE_APP");
								comm.SwipeBottomToTop();
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(photset, "Photo Open is not working");

							Boolean backbtnFlickrpage=comm.Openlinks(comm.BackButton2);
							s_assert.assertTrue(backbtnFlickrpage, "Back Button is not working flickr page");
						}
						s_assert.assertTrue(flickrphoto, "First photo is not open of flickr");
					}
					s_assert.assertTrue(set, "Set link is not working");
				}
				s_assert.assertTrue(Flickr, "Flickr link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 8, description = "")
	public void Verify360Image() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  Verify360Image()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				comm.Getactualtext(comm.header_gettext);
				Boolean image360=comm.Openlinks(photo.image360link);
				if (image360) {

					TimeUnit.SECONDS.sleep(10);
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean photset=comm.Openlinks(photo.firstphotopenFirstSet);
					if (photset) {
						TimeUnit.SECONDS.sleep(10);
						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							comm.swipingHorizontal(100);
							comm.Openlinks(comm.BackButtonNative);
							comm.SwipeBottomToTop();
						}
						else {
							comm.swipingHorizontal(100);
							driver.context("NATIVE_APP");
							Boolean iback =comm.Openlinks(comm.i_BackButtonNative);
							s_assert.assertTrue(iback, "iBack Button is not working");
							comm.SwipeBottomToTop();
						}
						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(photset, "Photo Open is not working");
				}
				s_assert.assertTrue(image360, "image360 link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 9, description = "")
	public void VerifyMyGalleryCamera() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMyGalleryCamera()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				//s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Images");
				comm.Getactualtext(comm.header_gettext);
				Boolean image=comm.Openlinks(photo.myGallerylink);
				if (image) {
					TimeUnit.SECONDS.sleep(20);
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean photset=comm.Openlinks(photo.firstphotopenFirstSet);
					if (photset) {
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);

						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							Boolean Tab=comm.Openlinks(photo.tab);
							s_assert.assertTrue(Tab, "TAB  is not open");
						}
						else {
							Boolean Tab=comm.Openlinks(photo.i_tab);
							s_assert.assertTrue(Tab, "iTAB  is not open");
						}
						 
						PageElement.changeContextToWebView(driver);


						Boolean openspam=comm.Openlinks(photo.spamopen);
						if (openspam) {
							Boolean report=comm.Openlinks(photo.reportAsSpam);
							if (report) {
								comm.IfAlertpresent();
							}
							s_assert.assertTrue(report, "reportAsSpam is not open"); 
						}
						s_assert.assertTrue(openspam, "openspam  is not open"); 

						Boolean openspam1=comm.Openlinks(photo.spamopen);
						if (openspam) {
							Boolean cancelspam=comm.Openlinks(photo.cancel);
							s_assert.assertTrue(cancelspam, "cancel spam is not open"); 
						}
						s_assert.assertTrue(openspam1, "openspam1  is not open");


						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend flickr photo");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);

						Boolean addphoto=comm.Openlinks(photo.addphotolink);
						if (addphoto) {
							Boolean camera=comm.Openlinks(photo.cameralink);
							if (camera) {
								driver.context("NATIVE_APP");
								if (!globledeviceName.equals("iPhone")) {
									NavigationPage.verifyrunTimePermissions(driver);
									driver.navigate().back();
								}
								else {
									
									Boolean ipermission=comm.IselementPresent(NavigationPage.i_permissionCameraOther);
									if (ipermission) {
										Boolean iok=comm.Openlinks(NavigationPage.i_permissionCameraOther);
										s_assert.assertTrue(iok, "iOK button is not working");
									}
									else {
									/*	Boolean icameraclick=comm.Openlinks(photo.i_cameraclick);
										s_assert.assertTrue(icameraclick,"iCamera click is not working");*/
										
										Boolean icameracancle=comm.Openlinks(photo.i_cameraCancle);
										s_assert.assertTrue(icameracancle,"iCamera Cancle is not working");
									}
								}
								PageElement.changeContextToWebView(driver);
							}
							s_assert.assertTrue(camera, "Camera link is not working");
						}
						s_assert.assertTrue(addphoto, "Add Photo link is not working");
					}
					s_assert.assertTrue(photset, "Photo Open is not working");

					Boolean backbtnFlickrpage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnFlickrpage, "Back Button is not working flickr page");
				}
				s_assert.assertTrue(image, "image360 link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 10, description = "")
	public void VerifyMyGalleryGallery() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VerifyMyGalleryGallery()");
		boolean exception = false;
		try {
			Boolean openphoto=comm.Openlinks(photo.openPhotoModule);
			if (openphoto) {
				//s_assert.assertEquals(comm.Getactualtext(comm.header_gettext), "Images");
				comm.Getactualtext(comm.header_gettext);
				Boolean image=comm.Openlinks(photo.myGallerylink);
				if (image) {
					TimeUnit.SECONDS.sleep(20);
					String UN=comm.Getactualtext(photo.flickrUser_gettext);
					s_assert.assertNotNull(UN, "Photo Heading is getting Null value");

					String photoCount=comm.Getactualtext(photo.flickCount_gettext);
					s_assert.assertNotNull(photoCount, "Photo Count is getting Null value");

					Boolean photset=comm.Openlinks(photo.firstphotopenFirstSet);
					if (photset) {
						comm.swipingHorizontal(100);
						TimeUnit.SECONDS.sleep(10);

						driver.context("NATIVE_APP");
						if (!globledeviceName.equals("iPhone")) {
							Boolean Tab=comm.Openlinks(photo.tab);
							s_assert.assertTrue(Tab, "TAB  is not open"); 
						}
						else {
							Boolean Tab=comm.Openlinks(photo.i_tab);
							s_assert.assertTrue(Tab, "iTAB  is not open");
						}
						
						PageElement.changeContextToWebView(driver);

						Boolean backbtn=comm.Openlinks(photo.backBtnPhoto);
						s_assert.assertTrue(backbtn, "Back Button is not working on opend flickr photo");
						driver.context("NATIVE_APP");
						comm.SwipeBottomToTop();
						PageElement.changeContextToWebView(driver);

						Boolean addphoto1=comm.Openlinks(photo.addphotolink);
						if (addphoto1) {
							Boolean gallary=comm.Openlinks(photo.gallerylink);
							if (gallary) {
								driver.context("NATIVE_APP");
								if (!globledeviceName.equals("iPhone")) {
									Boolean selectphoto=comm.Openlinks(photo.clickselectphoto);
									if (selectphoto) {
										Boolean ok=comm.Openlinks(photo.clickuploadOkbutton);
										TimeUnit.SECONDS.sleep(20);
										s_assert.assertTrue(ok, "Ok button of photo upload is not working");
									}
									s_assert.assertTrue(selectphoto, "Select photo is not select");
								}
								else {
									Boolean igallerypermission=comm.IselementPresent(PageElement.i_ok);
									if (igallerypermission) {
										Boolean iok=comm.Openlinks(PageElement.i_ok);
										s_assert.assertTrue(iok, "Gallery Permission iOK button is not working");
									}
									else {
										Boolean iCameraRoll=comm.IselementPresent(PageElement.i_CameraRoll);
										if (iCameraRoll) {
											Boolean icamroolopen=comm.Openlinks(PageElement.i_CameraRoll);
											if (icamroolopen) {
												Boolean ifirstphotselect=comm.Openlinks(PageElement.i_SelectFirstPhoto);
												if (ifirstphotselect) {
													Boolean idone=comm.Openlinks(PageElement.i_DoneBtn); 
													s_assert.assertTrue(idone, "iDone button is not selected");
												}
												s_assert.assertTrue(ifirstphotselect, "iSelect first phot is not selected");
											}
											s_assert.assertTrue(icamroolopen, "iCamera Roll is not open");
										}
										else {
											
										}
									}
								}
								PageElement.changeContextToWebView(driver);
								Boolean commment=comm.TextField(photo.addcomment, "Appypie Commnet");
								if (commment) {
									TimeUnit.SECONDS.sleep(2);
									Boolean sendd=comm.Openlinks(photo.send);
									if (sendd) {
										Boolean sendd1=comm.Openlinks(photo.send);
										s_assert.assertTrue(sendd1, "Send1 Comment  is not open"); 
										TimeUnit.SECONDS.sleep(2);
										comm.IfAlertpresent();
									}
									s_assert.assertTrue(sendd, "Send Comment  is not open"); 
								}
								s_assert.assertTrue(commment, "comment is not working");
							}
							s_assert.assertTrue(gallary, "gallary link is not working");
						}
						s_assert.assertTrue(addphoto1, "Add Photo link is not working");
					}
					s_assert.assertTrue(photset, "Photo Open is not working");

					Boolean backbtnFlickrpage=comm.Openlinks(comm.BackButton2);
					s_assert.assertTrue(backbtnFlickrpage, "Back Button is not working flickr page");
				}
				s_assert.assertTrue(image, "image360 link is not open");
			}
			s_assert.assertTrue(openphoto, "Photo module is not open");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + comm.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
}





















