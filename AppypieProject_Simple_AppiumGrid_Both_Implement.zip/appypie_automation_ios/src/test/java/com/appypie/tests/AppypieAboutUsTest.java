package com.appypie.tests;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieAboutUsPage;
import com.appypie.pages.AppypieMenuPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AppypieAboutUsTest extends TestSetup {
	private static final Logger Logger = Log.createLogger();
	SoftAssert asser;
	AppypieAboutUsPage about;
	AppypieMenuPage menu;

	@BeforeTest
	@Override
	public void pageSetUp() {
		about = new AppypieAboutUsPage(driver);
		menu = new AppypieMenuPage(driver);
	}

	@Test
	public void verifyAboutUsPageandBackbtn() {
		Logger.info("Test Methods start: verifyAboutUsPageandBackbtn");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				PageElement.tapBackButton(driver);
				Thread.sleep(1000);
				asser.assertTrue(menu.isPageExist("about"), "Back Button from About US page is not working");
			}

		} catch (Exception e) {
			Logger.error("Error occurs while opening the About US page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}

	@Test
	public void verifyAboutUsPageContents() {
		Logger.info("Test Methods start: verifyAboutUsPageContents");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				asser.assertNotNull(about.getPageText("description"), "description text is not visible");
				asser.assertNotNull(about.getPageText("designation"), "designation text is not visible");
				asser.assertNotNull(about.getPageText("founded"), "founded option text is not visible");
				asser.assertNotNull(about.getPageText("mission"), "mission option text is not visible");
				asser.assertNotNull(about.getPageText("vision"), "vision option text is not visible");
				asser.assertNotNull(about.getPageText("award"), "award option text is not visible");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying the content of about us page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
/*
	@Test
	public void verifyLinkedinOnAboutUsPage() {
		Logger.info("Test Methods start: verifyLinkedinOnAboutUsPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				about.openOptionsOnPage("linkedin");
				asser.assertTrue(PageElement.isContentOpenInNative(driver,"About Us"),"LinkedIn option from abouts us page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying linked in of about us page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}*/
	
	@Test
	public void verifyCallOnAboutUsPage() {
		Logger.info("Test Methods start: verifyCallOnAboutUsPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				about.openOptionsOnPage("call");
				asser.assertTrue(about.isFeatureOpenInNative("call"),"Call option from abouts us page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Call on about us page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyMailOnAboutUsPage() {
		Logger.info("Test Methods start: verifyMailOnAboutUsPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				about.openOptionsOnPage("mail");
				asser.assertTrue(about.isFeatureOpenInNative("mail"),"mail option from abouts us page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying mail on about us page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifySkypeOnAboutUsPage() {
		Logger.info("Test Methods start: verifySkypeOnAboutUsPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				about.openOptionsOnPage("skype");
				asser.assertTrue(about.isFeatureOpenInNative("skype"),"Skype option from abouts us page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying Skype on about us page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
	
	@Test
	public void verifyDeepLinkonAboutUsPage() {
		Logger.info("Test Methods start: verifyDeepLinkonAboutUsPage");
		asser = new SoftAssert();
		boolean exception = false;
		try {
			menu.openPage("about");
			boolean pageOpen = about.isAboutUsPageOpen();
			asser.assertTrue(pageOpen, "About US page is not open");
			if (pageOpen) {
				about.openOptionsOnPage("deeplink");
				asser.assertTrue(PageElement.isContentOpenInNative(driver, ""),"DeepLink option from abouts us page is not working");
			}
		} catch (Exception e) {
			Logger.error("Error occurs while verifying deepLink on about us page ", e);
			exception = true;
			Assert.assertFalse(exception, "\n" + PageElement.printExceptionTrace(e));
		}
		asser.assertAll();
	}
}
