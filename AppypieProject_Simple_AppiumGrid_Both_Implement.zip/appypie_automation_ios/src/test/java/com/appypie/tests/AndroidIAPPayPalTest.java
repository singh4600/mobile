package com.appypie.tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.appypie.pages.AppypieIAPPayPalPage;
import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

public class AndroidIAPPayPalTest extends TestSetup {
	AppypieIAPPayPalPage paypal;
	private static final Logger Logger = Log.createLogger();

	// --------------------------------------------------------------------------------------------------
	@BeforeTest
	@Override
	public void pageSetUp() {
		paypal=new AppypieIAPPayPalPage(driver);
	}



	// ----------------------------------------------------------------------------------------------------
	/*	@Test(priority = 0, description = "")
	public void Veriy() throws Exception {
		Logger.info("Test Case:  ()");
		boolean exception = false;
		try {


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + membersCard.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority = 0, description = "")
	public void VeriyOpenIAPmodule() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyOpenIAPmodule()");
		boolean exception = false;
		try {
			Boolean iapopen=paypal.Openlinks(paypal.iapPayPalModule_link);
			if(iapopen){
				s_assert.assertEquals(paypal.Getactualtext(paypal.header_gettext), "IAP With Paypal");
			}
			s_assert.assertTrue(iapopen, "IAP With Paypal module is not open");

			Boolean backbtn=paypal.Openlinks(paypal.BackButton);
			s_assert.assertTrue(backbtn, "Bck Button is not working");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + paypal.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 1, description = "")
	public void VeriyViewAllAndMyCollection() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyViewAll()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(5);
			Boolean iapopen=paypal.Openlinks(paypal.iapPayPalModule_link);
			s_assert.assertTrue(iapopen, "IAP With Paypal module is not open");

			Boolean viewall=paypal.Openlinks(paypal.viewAll_btn);
			if (viewall) {
				String titleVideo=paypal.Getactualtext(paypal.titleVideo_Viewall_gettext);
				s_assert.assertNotNull(titleVideo, "Video Title is getting null value");

				String descVideo=paypal.Getactualtext(paypal.descriptionVideo_Viewall_gettext);
				s_assert.assertNotNull(descVideo, "Video description is getting null value");

				String titleGeeks=paypal.Getactualtext(paypal.titleGeeks_Viewall_gettext);
				s_assert.assertNotNull(titleGeeks, "Geeks Title is getting null value");

				String descGeeks=paypal.Getactualtext(paypal.descriptionGeek_Viewall_gettext);
				s_assert.assertNotNull(descGeeks, "Geeks description is getting null value");
			}
			s_assert.assertTrue(viewall, "view all is not working");

			Boolean myCollection=paypal.Openlinks(paypal.myCollection_btn);
			if (myCollection) {

				String restore=paypal.Getactualtext(paypal.RestorePurchases_gettext);
				if (restore.equalsIgnoreCase("Restore Purchases")) {
					Boolean restorebtm=paypal.Openlinks(paypal.Rrestore_btn);
					if (restorebtm) {
						paypal.Login();
						Boolean restorebtm1=paypal.Openlinks(paypal.Rrestore_btn);
						s_assert.assertTrue(restorebtm1, "Restore Button is not working");
					}
					s_assert.assertTrue(restorebtm, "Restore Button is not working");

				}
			}
			else{
				Logger.info("Restore is Not present");
			}


		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + paypal.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 2, description = "")
	public void VeriyVideo() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyVideo()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(5);
			Boolean iapopen=paypal.Openlinks(paypal.iapPayPalModule_link);
			s_assert.assertTrue(iapopen, "IAP With Paypal module is not open");

			Boolean viewall=paypal.Openlinks(paypal.viewAll_btn);
			if (viewall) {

				Boolean subscribeNow=paypal.Openlinks(paypal.subscribeNowBtnVideo);
				if (subscribeNow) {
					Boolean login=paypal.IselementPresent(paypal.username);
					if (login) {
						TimeUnit.SECONDS.sleep(3);
						paypal.Login();
						Boolean subscribeNow1=paypal.Openlinks(paypal.subscribeNowBtnGeeks);
						s_assert.assertTrue(subscribeNow1, "subscribeNow1 is not open for video");
					}
					else{
						System.out.println("User is Already Ready");
					}
					String popuheading=paypal.Getactualtext(paypal.chooseYourPaymentHeading_gettext);
					s_assert.assertNotNull(popuheading,"Pop heading is getting Null Value");

					Boolean payment=paypal.Openlinks(paypal.cancelpay);
					s_assert.assertTrue(payment, "payment Cancel is not open"); 

					/*		Boolean buymonthly=paypal.Openlinks(paypal.buymonthlylink);
					if (buymonthly) {
						driver.context("NATIVE_APP");
						s_assert.assertEquals(paypal.Getactualtext(paypal.header_gettext_native), "Payment");

					Boolean backnative=paypal.Openlinks(paypal.BackButtonNative);
						if (backnative) {
							paypal.IfAlertpresentNative(paypal.headingpopupNative_gettext);
							paypal.YesButtonAlertNative(paypal.yesbtnPopupNaive);

						}
						s_assert.assertTrue(backnative, "back Button is not working on payment page");

						PageElement.changeContextToWebView(driver);
					}
					s_assert.assertTrue(buymonthly, "Buy monthly link is not working");*/
				}
				s_assert.assertTrue(subscribeNow, "subscribeNow is not open for video");

			}
			s_assert.assertTrue(viewall, "view all is not working");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + paypal.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority = 3, description = "")
	public void VeriyGeeks() throws Exception {
		SoftAssert s_assert = new SoftAssert();
		Logger.info("Test Case:  VeriyGeeks()");
		boolean exception = false;
		try {
			TimeUnit.SECONDS.sleep(5);
			Boolean iapopen=paypal.Openlinks(paypal.iapPayPalModule_link);
			s_assert.assertTrue(iapopen, "IAP With Paypal module is not open");

			Boolean viewall=paypal.Openlinks(paypal.viewAll_btn);
			if (viewall) {

				Boolean subscribeNow=paypal.Openlinks(paypal.subscribeNowBtnGeeks);
				if (subscribeNow) {
					Boolean login=paypal.IselementPresent(paypal.username);
					if (login) {
						TimeUnit.SECONDS.sleep(3);
						paypal.Login();
						Boolean subscribeNow1=paypal.Openlinks(paypal.subscribeNowBtnGeeks);
						s_assert.assertTrue(subscribeNow1, "subscribeNow1 is not open for video");
					}
					else{
						System.out.println("User is Already Ready");
					}
					
					TimeUnit.SECONDS.sleep(30);
					
					PageElement.changeContextToWebView(driver);

					try{	
						System.out.println("catch block");
						driver.context("NATIVE_APP");
						paypal.Openlinks(paypal.cancelpayment1);
						
					
					}
					catch (Exception e) {
						PageElement.changeContextToWebView(driver);
						paypal.Openlinks(paypal.cancelpayment);
						System.out.println("try block");
					}


					/*driver.context("NATIVE_APP");
					s_assert.assertEquals(paypal.Getactualtext(paypal.header_gettext_native), "Payment");

					Boolean backnative=paypal.Openlinks(paypal.BackButtonNative);
					if (backnative) {
						paypal.IfAlertpresentNative(paypal.headingpopupNative_gettext);
						paypal.YesButtonAlertNative(paypal.yesbtnPopupNaive);

					}
					s_assert.assertTrue(backnative, "back Button is not working on payment page");

					PageElement.changeContextToWebView(driver);*/

				}
				s_assert.assertTrue(subscribeNow, "subscribeNow is not open for video");

			}
			s_assert.assertTrue(viewall, "view all is not working");

		} catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e);
			exception = true;
			s_assert.assertFalse(exception, "\n" + paypal.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


}