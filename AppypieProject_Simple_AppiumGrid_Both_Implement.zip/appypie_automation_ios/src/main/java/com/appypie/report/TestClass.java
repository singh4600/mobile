package com.appypie.report;


import java.util.TreeMap;

public class TestClass {
	
	public static void checkTreeMap(){
		TreeMap tmap= new TreeMap();
		tmap.put("2",6);
		tmap.put("3",9);
		tmap.put("4",8);
		
		System.out.println(tmap.size());
		for(int i=0;i<tmap.size();i++){
			
		}
		
		String input="{\"method\":\"changeSetting\",\"appId\":\"41b6f8247838\",\"updateList\":{\"auto_aproval\":0,\"email_verification\":0}}";
	}
	
	public static void main(String[] arr){
		checkTreeMap();
	}
	

}
