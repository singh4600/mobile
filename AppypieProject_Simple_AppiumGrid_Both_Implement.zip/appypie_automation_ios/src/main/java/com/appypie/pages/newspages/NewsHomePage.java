package com.appypie.pages.newspages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class NewsHomePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By newsheader = By.xpath("//div[@class='navbar']//div[text()='News']");
	By hollywoodFeed = By.xpath("//div[@class='navbar']//div[text()='hollywood']");
	By bollywoodFeed = By.xpath("//div[@class='navbar']//div[text()='Bollywood']");
	By setting = By.xpath("//a[contains(@onclick,'Appyscript.openSetting')]");
	By newsMenu = By.xpath("//a[contains(@onclick,'Appyscript.popupPage')]");
	By NewsFirstFeedName = By.xpath("//li[@index='0']//div[@class='text-detail']/h4");
	By NewsFirstFeedDate = By.xpath("//li[@index='0']//div[@class='text-detail']//span[@class='date']/small");

	By NewsSecondFeedName = By.xpath("//li[@index='1']//div[@class='text-detail']/h4");
	By NewsSecondFeedDate = By.xpath("//li[@index='1']//div[@class='text-detail']//span[@class='date']/small");

	public NewsHomePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isHomePageOpen() {
		boolean open = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, newsMenu, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public boolean isHollywoodFeedsOpen() {
		boolean open = false;
		WebElement feedPage = ElementWait.waitForOptionalElement(driver, hollywoodFeed, 10);
		if (feedPage != null && feedPage.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public boolean isBollywoodFeedsOpen() {
		boolean open = false;
		WebElement feedPage = ElementWait.waitForOptionalElement(driver, bollywoodFeed, 10);
		if (feedPage != null && feedPage.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public void openMenu() {
		WebElement menu = ElementWait.waitForOptionalElement(driver, newsMenu, 10);
		if (menu != null && menu.isDisplayed()) {
			menu.click();
		}
	}
	
	public void openSettings() {
		WebElement option = ElementWait.waitForOptionalElement(driver, setting, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}
	
	public void openFeeds(String number) {
		WebElement feeds;
		if (number.equals("one"))
			feeds = ElementWait.waitForOptionalElement(driver, NewsFirstFeedName, 10);
		else
			feeds = ElementWait.waitForOptionalElement(driver, NewsSecondFeedName, 10);
		if (feeds != null && feeds.isDisplayed()) {
			feeds.click();
		}
	}


	public String getFirstNewsListingName() {
		String name = "";
		WebElement list1 = ElementWait.waitForOptionalElement(driver, NewsFirstFeedName, 10);
		if (list1 != null && list1.isDisplayed()) {
			name = list1.getText();
		}
		return name;
	}

	public String getSecondNewsListingName() {
		String name = "";
		WebElement list2 = ElementWait.waitForOptionalElement(driver, NewsSecondFeedName, 10);
		if (list2 != null && list2.isDisplayed()) {
			name = list2.getText();
		}
		return name;
	}

	public String getFirstNewsListingDate() {
		String date = "";
		WebElement list1 = ElementWait.waitForOptionalElement(driver, NewsFirstFeedDate, 10);
		if (list1 != null && list1.isDisplayed()) {
			date = list1.getText();
		}
		return date;
	}

	public String getSecondNewsListingDate() {
		String date = "";
		WebElement list2 = ElementWait.waitForOptionalElement(driver, NewsSecondFeedDate, 10);
		if (list2 != null && list2.isDisplayed()) {
			date = list2.getText();
		}
		return date;
	}
}
