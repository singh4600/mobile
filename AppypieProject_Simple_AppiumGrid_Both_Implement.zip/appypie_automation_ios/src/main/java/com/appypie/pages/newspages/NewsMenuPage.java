package com.appypie.pages.newspages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class NewsMenuPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By home = By.xpath("//a[contains(@onclick,'Appyscript.clickHome')]");
	By mainMenu = By.xpath("//a[@class='popupToPage'][text()='Main Menu']");
	By news = By.xpath("//a[@class='popupToPage'][text()='NEWs']");
	By bollywood = By.xpath("//a[@class='popupToPage'][text()='Bollywood']");
	By hollywood = By.xpath("//a[@class='popupToPage'][text()='hollywood']");
	By bookmark = By.xpath("//a[@class='popupToPage'][text()='Bookmarks']");

	By search = By.xpath("//input[@type='search']");
	By closeSearch = By.xpath("//a[contains(@onclick,'Appyscript.popupClose')]");

	public NewsMenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isNewsMenuOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(2000);
		WebElement menu = ElementWait.waitForOptionalElement(driver, bookmark, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickHome() {
		WebElement option = ElementWait.waitForOptionalElement(driver, home, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickMainMenu() {
		WebElement option = ElementWait.waitForOptionalElement(driver, mainMenu, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickNews() {
		WebElement option = ElementWait.waitForOptionalElement(driver, news, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickBollywood() {
		WebElement option = ElementWait.waitForOptionalElement(driver, bollywood, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickHollywood() {
		WebElement option = ElementWait.waitForOptionalElement(driver, hollywood, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickBookmark() {
		WebElement option = ElementWait.waitForOptionalElement(driver, bookmark, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void closeMenu() {
		WebElement close = ElementWait.waitForOptionalElement(driver, closeSearch, 10);
		if (close != null && close.isDisplayed()) {
			close.click();
		}
	}

	public void typeSearchKeyWord(String data) {
		PageElement.sendKey(driver, search, data);

	}
}
