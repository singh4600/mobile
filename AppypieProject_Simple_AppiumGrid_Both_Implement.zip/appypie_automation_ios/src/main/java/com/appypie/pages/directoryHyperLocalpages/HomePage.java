package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class HomePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By directoryMenu = By.xpath("//a[contains(@onclick,'Appyscript.openMenuPage')]");
	By filterIcon = By.xpath("//i[contains(@class,'icon iconz-filter')]");
	By location = By.xpath("//span[contains(@class,'locate icon-location')]");
	By directorycategories = By.xpath("//ul[contains(@class,'main-cat-listing')]//li[@data-heading='alpha directory 789']");
	By homeSearch = By.xpath("//div[@data-page='services-page']//div[@id='search-box']//input[@id='search']");
	By searchbtn = By.xpath("//div[@data-page='services-page']//div[@id='search-box']//a[@id='btnSearch']");
	By searchbtn1 = By.id("txtSearch");
	By searchOption = By.xpath("//div[@data-page='services-page']//div[@id='search-box']//ul[@id='res']/li");
	By closeSearch = By.xpath("//a[contains(@onclick,'menuHide')]");
	By alphaDirectory = By.xpath("//ul[@class='main-cat-listing clearfix sr_bx_space']/li[2]");
	//********* Locators for hyperlocal*********************
	By hl_Categories= By.xpath("//li[contains(@onclick,'Appyscript.hyperListing')][contains(@onclick,'four')]");
	By hl_search= By.xpath("//div[@data-page='hyperlocal-page']//div[@class='search-box']//input[@id='txtSearch']");
	By hl_search1= By.xpath("//div[@data-page='hyperlocal-page']//div[@class='search-box']//input[@id='txtSearch']");
	By hl_searchbtn = By.xpath("//div[@data-page='hyperlocal-page']//div[@class='search-box']//a[@id='btnSearch']");
	By hl_Menu = By.xpath("//a[contains(@onclick,'Appyscript.openHyperLocalMenuPage')]");
	
	
	
	public HomePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isHomePageOpen() {
		boolean open = false;
		WebElement element_filter = ElementWait.waitForOptionalElement(driver, filterIcon, 20);
		if (element_filter != null) {
			open = true;
		} else {
			Logger.info("Directory Home Page is not Open");
		}
		return open;
	}

	public boolean isHomePageOpenHyperlocal() {
		boolean open = false;
		WebElement element_filter = ElementWait.waitForOptionalElement(driver, filterIcon, 20);
		if (element_filter != null) {
			open = true;
		} else {
			Logger.info("Hyperlocal Home Page is not Open");
		}
		return open;
	}
	
	public boolean isHomePageOpenDirectory() {
		boolean open = false;
		WebElement element_filter = ElementWait.waitForOptionalElement(driver, homeSearch, 20);
		if (element_filter != null && element_filter.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Directory Home Page is not Open");
		}
		return open;
	}
	
	public boolean checkCategories(String page) {
		boolean present = false;
		WebElement element_list = null;
		if (page.equals("dir"))
			element_list = ElementWait.waitForOptionalElement(driver, directorycategories, 20);
		else {
			element_list = ElementWait.waitForOptionalElement(driver, hl_Categories, 20);
		}
		if (element_list != null && element_list.isDisplayed()) {
			present = true;
		} else {
			Logger.info("Listing is not present in the directory page");
		}
		return present;
	}

	public void clickFilterIcon() {
		WebElement element_filter = ElementWait.waitForOptionalElement(driver, filterIcon, 20);
		if (element_filter != null) {
			element_filter.click();
		} else {
			Logger.info("Filter icon is not visible on directory page");
		}
	}

	public void openLocation() {
		WebElement loc = ElementWait.waitForOptionalElement(driver, location, 20);
		if (loc != null) {
			loc.click();
		} else {
			Logger.info("location icon is not visible on directory page");
		}
	}

	public void openPageMenu(String page) {
		WebElement menu;
		if (page.equals("dir"))
			menu = ElementWait.waitForOptionalElement(driver, directoryMenu, 20);
		else
			menu = ElementWait.waitForOptionalElement(driver, hl_Menu, 20);
		if (menu != null) {
			menu.click();
		} else {
			Logger.info("Menu icon is not visible on Home page");
		}
	}

	public void openCategoryfromMainList(String page) throws InterruptedException {
		WebElement cat;
		Thread.sleep(3000);
		if (page.equals("dir"))
			cat = ElementWait.waitForOptionalElement(driver, directorycategories, 20);
		else {
			cat = ElementWait.waitForOptionalElement(driver, hl_Categories, 20);
		}
		if (cat != null) {
			cat.click();
		} else {
			Logger.info(" category is not present in the page");
		}
	}

	public void typeOnSearch(String page, String content) {
		if (page.equals("dir"))
			PageElement.sendKey(driver, homeSearch, content);
		else
			PageElement.sendKey(driver, searchbtn1, content);

	}
	
	public boolean isSearchTextDisplayed() {
		boolean display = false;
		WebElement search = ElementWait.waitForOptionalElement(driver, searchbtn1, 10);
		if (search != null && search.isDisplayed()) {
			display = true;
		} 
		return display;
	}

	public boolean isSearchOptionsVisible() {
		boolean present = false;
		WebElement search = ElementWait.waitForOptionalElement(driver, searchOption, 5);
		if (search != null && search.isDisplayed()) {
			present = true;
		} else {
			Logger.info("OnKeyDown is not working on Directory home page search");
		}
		return present;
	}

	public void clickOnSerach(String page) {
		if (page.equals("dir"))
			PageElement.locateClickableElement(driver, searchbtn);
		else
			PageElement.locateClickableElement(driver, searchbtn1);
	}

	public void clickOnSearchOptions() {
		driver.findElement(searchOption).click();
	}

	public void closeSearchMenu() {
		WebElement close = ElementWait.waitForOptionalElement(driver, closeSearch, 10);
		if (close != null && close.isDisplayed()) {
			close.click();
		} else {
			Logger.info("close button is not visible on search menu");
		}
	}
	
	public boolean openAlphaDirectory() {
		boolean open = false;
		WebElement element_filter = ElementWait.waitForOptionalElement(driver, alphaDirectory, 20);
		if (element_filter != null && element_filter.isDisplayed()) {
			element_filter.click();
			open = true;
		} else {
			Logger.info("alpha Directory Page is not Open");
		}
		return open;
	}	
	
}
