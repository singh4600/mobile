package com.appypie.pages.Loyaltycard;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class LoyaltycardPage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	CommanClassLoyaltycard comm;
	SoftAssert s_assert = new SoftAssert();

	// --------Default-----------------------------------
	//--------click Event-----------------------------------
	//public By = By.xpath("");
	public By BackButtonLink= By.xpath("//*[@class='link back']");

	
	public By singleCodelink= By.xpath("//*[@id='flip0']//*[contains(@class,'main_banner')]");
	public By firstNo_singleCodelink= By.xpath("//*[contains(@id,'circleTags1')]");
	
	public By uniqueCodeslink= By.xpath("//*[@id='flip1']//*[contains(@class,'main_banner')]");
	public By first_uniqueCodes= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	public By singlecodewithdailylimitlink= By.xpath("//*[@id='flip2']//*[contains(@class,'main_banner')]");
	public By first_singlecodewithdailylimit= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	public By manualCheckInlink= By.xpath("//*[@id='flip3']//*[contains(@class,'main_banner')]");
	public By first_manualCheckIn= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	public By manualCheckInWithDailylimtlink= By.xpath("//*[@id='flip4']//*[contains(@class,'main_banner')]");
	public By first_manualCheckInWithDailylimt= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	public By invalidlink= By.xpath("//*[@id='flip5']//*[contains(@class,'main_banner')]");
	public By first_invalid= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	
	public By oneCardlink= By.xpath("//*[@id='flip6']//*[contains(@class,'main_banner')]");
	public By oneNo_oneCardlink= By.xpath("//*[contains(@id,'loyalbox1')]");
	public By redeemitoneNo_oneCardlink= By.xpath("//*[contains(@class,'redeem-page')]//*[contains(@onclick,'Appyscript.loyatystamp')]");
	
	public By dailyLimitlink= By.xpath("//*[@id='flip7']//*[contains(@class,'main_banner')]");
	public By firstNo_dailyLimitlink= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	public By manulCheckInWithDailyLimitlink= By.xpath("//*[@id='flip8']//*[contains(@class,'main_banner')]");
	public By first_manulCheckInWithDailyLimit= By.xpath("//*[contains(@id,'loyalbox1')]");
	
	public By manulCheckInlink= By.xpath("//*[@id='flip9']//*[contains(@class,'main_banner')]");
	
	
	public By Message_gettext=By.xpath("//*[contains(@class,'brifDiscription')]");
	public By heading_gettext=By.xpath("//*[contains(@id,'forshopper')]//h1[1]");
	public By desc_gettext=By.xpath("//*[contains(@id,'forshopper')]//*[contains(@id,'brifDiscription')]");
	public By QRbtn= By.xpath("//*[contains(@onclick,'Appyscript.QrCode')]");
	public By securityCodebtn= By.xpath("//*[contains(text(),' Validate by typing the security code  ')]");
	public By securityCodeText= By.xpath("//*[contains(@id,'loyaltyPassword')]");
	public By validateBtn= By.xpath("//*[text()=' Validate ']");
	public By cancelBtn= By.xpath("//*[text()=' Cancel ']");
	

	public By extranallink_uniquecode= By.xpath("//*[@id='flip1']//*[contains(@class,'card-discription')]//*[contains(@onclick,'opendeeplinkpage')]");
	public By extranallink2_uniquecode= By.xpath("//*[contains(@class,'brifDiscription')]//*[contains(@onclick,'opendeeplinkpage')]");
	
	public By headingSCWDL_gettext=By.xpath("//*[contains(@id,'forshopper')]//h1[2]");
	public By descSCWDL_gettext=By.xpath("//*[contains(@id,'forshopper')]//*[contains(@id,'brifDiscription')]");
	
	public By headingMCI_gettext=By.xpath("//*[@id='foruser']/center/h1");
	public By descMCI_gettext=By.xpath("//*[@id='foruser']/center//*[contains(@id,'brifDiscription')]");
	
	public By headingMCWDL_gettext=By.xpath("//*[@id='foruser']/center/h1[2]");
	public By descMCWDL_gettext=By.xpath("//*[@id='foruser']/center//*[contains(@id,'brifDiscription')]");
	
	public By invoiceNotext= By.xpath("//*[contains(@id,'invoicetextfield')]");
	public By addBtn= By.xpath("//*[contains(@id,'addBtn')]");
	
	public By uploadbtn= By.xpath("//*[contains(@id,'imageUploadBtn')]");
	public By clickgallerylink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[2]");
	public By clickselectphoto=By.xpath("//android.widget.ImageView[@index='0']");
	public By clickcameralink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[1]");
	

	
	//---------------------------------------------------------------------------------------
	public By loyaltycardmodulelink= By.xpath("//a[@data-productid='loyalty']"); 
	public By singlecodeCard_TClink=By.xpath("//*[@id='flip0']/div/div[1]/a"); 
	public By uniqueCodesCard_TClink=By.xpath("//*[@id='flip1']/div/div[1]/a");
	public By singlecodewithdailylimitCard_TClink=By.xpath("//*[@id='flip2']/div/div[1]/a");
	public By manualcheckinCard_TClink=By.xpath("//*[@id='flip3']/div/div[1]/a");
	public By manualcheckinwithdailylimitCard_TClink=By.xpath("//*[@id='flip4']/div/div[1]/a");
	public By invalidCard_TClink=By.xpath("//*[@id='flip5']/div/div[1]/a");
	public By oneCard_TClink=By.xpath("//*[@id='flip6']/div/div[1]/a");
	public By dailyLimit_TClink=By.xpath("//*[@id='flip7']/div/div[1]/a");
	public By manulCheckInWithDailyLimit_TClink=By.xpath("//*[@id='flip8']/div/div[1]/a");
	public By manulCheckIn_TClink=By.xpath("//*[@id='flip9']/div/div[1]/a");


	public By singlecodeCard_TClink_Close=By.xpath("//*[@id='flip0']/div/div[2]/a"); 
	public By uniqueCodesCard_TClink_Close=By.xpath("//*[@id='flip1']/div/div[2]/a");
	public By singlecodewithdailylimitCard_TClink_Close=By.xpath("//*[@id='flip2']/div/div[2]/a");
	public By manualcheckinCard_TClink_Close=By.xpath("//*[@id='flip3']/div/div[2]/a");
	public By manualcheckinwithdailylimitCard_TClink_Close=By.xpath("//*[@id='flip4']/div/div[2]/a");
	public By invalidCard_TClink_Close=By.xpath("//*[@id='flip5']/div/div[2]/a");
	public By oneCard_TClink_Close=By.xpath("//*[@id='flip6']/div/div[2]/a");
	public By dailyLimit_TClink_Close=By.xpath("//*[@id='flip7']/div/div[2]/a");
	public By manulCheckInWithDailyLimit_TClink_Close=By.xpath("//*[@id='flip8']/div/div[2]/a");
	public By manulCheckIn_TClink_Close=By.xpath("//*[@id='flip9']/div/div[2]/a");

	
	//public By = By.xpath("");
	
	

	//---------Get Text Event----------------------------
	//public By _gettext=By.xpath("");
	public By header_gettext=By.xpath("//div[@class='navbar']/div[2]/div[2]");  
	public By allcardTitle_gettext=By.xpath("//*[contains(@class,'card-title')]");
	public By allcarddiscription_gettext=By.xpath("//*[contains(@class,'card-discription')]");
	public By allcardtime_gettext=By.xpath("//*[contains(@class,'eventTime')]");


	public By singlecodeCardTitle_gettext=By.xpath("//*[@id='flip0']//*[contains(text(),'Single code')]");
	public By singlecodeCardDesc_gettext=By.xpath("//*[@id='flip0']//*[contains(@class,'card-discription arial mediumContent')]");
	public By singlecodeCardDate_gettext=By.xpath("//*[@id='flip0']//*[contains(@class,'eventTime')]");
	
	public By uniqueCodesCardTitle_gettext=By.xpath("//*[@id='flip1']//*[contains(text(),'Unique Codes')]");
	public By uniqueCodesCardDesc_gettext=By.xpath("//*[@id='flip1']//*[contains(@class,'card-discription arial mediumContent')]");
	public By uniqueCodesCardDate_gettext=By.xpath("//*[@id='flip1']//*[contains(@class,'eventTime')]");
	
	public By singlecodewithdailylimitCardTitle_gettext=By.xpath("//*[@id='flip2']//*[contains(text(),'Single code with daily limit')]");
	public By singlecodewithdailylimitCardDesc_gettext=By.xpath("//*[@id='flip2']//*[contains(@class,'card-discription arial mediumContent')]");
	public By singlecodewithdailylimitCardDate_gettext=By.xpath("//*[@id='flip2']//*[contains(@class,'eventTime')]");
	
	public By manualcheckinCardTitle_gettext=By.xpath("//*[@id='flip3']//*[contains(text(),'Manual check in')]");
	public By manualcheckinCardDesc_gettext=By.xpath("//*[@id='flip3']//*[contains(@class,'card-discription arial mediumContent')]");
	public By manualcheckinCardDate_gettext=By.xpath("//*[@id='flip3']//*[contains(@class,'eventTime')]");
	
	public By manualcheckinwithdailylimitCardTitle_gettext=By.xpath("//*[@id='flip4']//*[contains(text(),'Manual check in with daily limit')]");
	public By manualcheckinwithdailylimitCardDesc_gettext=By.xpath("//*[@id='flip4']//*[contains(@class,'card-discription arial mediumContent')]");
	public By manualcheckinwithdailylimitCardDate_gettext=By.xpath("//*[@id='flip4']//*[contains(@class,'eventTime')]");
	
	public By invalidCardTitle_gettext=By.xpath("//*[@id='flip5']//*[contains(text(),'Invalid')]");
	public By invalidCardDesc_gettext=By.xpath("//*[@id='flip5']//*[contains(@class,'card-discription arial mediumContent')]");
	public By invalidCardDate_gettext=By.xpath("//*[@id='flip5']//*[contains(@class,'eventTime')]");

	public By oneCardTitle_gettext=By.xpath("//*[@id='flip6']//*[contains(text(),'One card')]");
	public By oneCardDesc_gettext=By.xpath("//*[@id='flip6']//*[contains(@class,'card-discription arial mediumContent')]");
	public By oneCardDate_gettext=By.xpath("//*[@id='flip6']//*[contains(@class,'eventTime')]");
	
	public By dailyLimitTitle_gettext=By.xpath("//*[@id='flip7']//*[contains(text(),'DAILY LIMIT')]");
	public By dailyLimitDesc_gettext=By.xpath("//*[@id='flip7']//*[contains(@class,'card-discription arial mediumContent')]");
	public By dailyLimitDate_gettext=By.xpath("//*[@id='flip7']//*[contains(@class,'eventTime')]");
	
	public By manualCheckInWithDailyLimitTitle_gettext=By.xpath("//*[@id='flip8']//*[contains(text(),'M WTH DAILY LIMIT')]");
	public By manualCheckInWithDailyLimitDesc_gettext=By.xpath("//*[@id='flip8']//*[contains(@class,'card-discription arial mediumContent')]");
	public By manualCheckInWithDailyLimitDate_gettext=By.xpath("//*[@id='flip8']//*[contains(@class,'eventTime')]");
	
	public By manualCheckInTitle_gettext=By.xpath("//*[@id='flip9']//*[contains(text(),'M Check in')]");
	public By manualCheckInDesc_gettext=By.xpath("//*[@id='flip9']//*[contains(@class,'card-discription arial mediumContent')]");
	public By manualCheckInDate_gettext=By.xpath("//*[@id='flip9']//*[contains(@class,'eventTime')]");
	
	
	
//----------------------------TC---------------------------
	public By singlecodeCard_TC_title_gettext=By.xpath("//*[@id='flip0']//*[contains(@class,'back-screen')]/h2");
	public By singlecodeCard_TC_gettext=By.xpath("//*[@id='flip0']//*[contains(@class,'terms-text')]");
	
	public By uniqueCodesCard_TC_title_gettext=By.xpath("//*[@id='flip1']//*[contains(@class,'back-screen')]/h2");
	public By uniqueCodesCard_TC_gettext=By.xpath("//*[@id='flip1']//*[contains(@class,'terms-text')]");
	
	public By singlecodewithdailylimitCard_TC_title_gettext=By.xpath("//*[@id='flip2']//*[contains(@class,'back-screen')]/h2");
	public By singlecodewithdailylimitCard_TC_gettext=By.xpath("//*[@id='flip2']//*[contains(@class,'terms-text')]");
	
	public By  manualcheckinCard_TC_title_gettext=By.xpath("//*[@id='flip3']//*[contains(@class,'back-screen')]/h2");
	public By manualcheckinCard_TC_gettext=By.xpath("//*[@id='flip3']//*[contains(@class,'terms-text')]");
	
	public By manualcheckinwithdailylimitCard_TC_title_gettext=By.xpath("//*[@id='flip4']//*[contains(@class,'back-screen')]/h2");
	public By manualcheckinwithdailylimitCard_TC_gettext=By.xpath("//*[@id='flip4']//*[contains(@class,'terms-text')]");
	
	public By invalidCard_TC_title_gettext=By.xpath("//*[@id='flip5']//*[contains(@class,'back-screen')]/h2");
	public By invalidCard_TC_gettext=By.xpath("//*[@id='flip5']//*[contains(@class,'terms-text')]");

	public By oneCard_TC_title_gettext=By.xpath("//*[@id='flip6']//*[contains(@class,'back-screen')]/h2");
	public By oneCard_TC_gettext=By.xpath("//*[@id='flip6']//*[contains(@class,'terms-text')]");

	public By DailyLimit_TC_title_gettext=By.xpath("//*[@id='flip7']//*[contains(@class,'back-screen')]/h2");
	public By DailyLimit_TC_gettext=By.xpath("//*[@id='flip7']//*[contains(@class,'terms-text')]");
	
	public By manualCheckInWithDailyLimit_TC_title_gettext=By.xpath("//*[@id='flip8']//*[contains(@class,'back-screen')]/h2");
	public By manualCheckInWithDailyLimit_TC_gettext=By.xpath("//*[@id='flip8']//*[contains(@class,'terms-text')]");
	
	public By manulaChekIn_TC_title_gettext=By.xpath("//*[@id='flip9']//*[contains(@class,'back-screen')]/h2");
	public By manulaChekIn_TC_gettext=By.xpath("//*[@id='flip9']//*[contains(@class,'terms-text')]");
	
	
	//---------------------------------
	public By username=By.xpath("//*[@id='loginid']");
	public By password=By.xpath("//*[@id='loginpass']");
	public By LoginBtn=By.xpath("//*[contains(@class,'appypie-login login-page')]/ul/li[5]");
	public By Acceptandcontinue=By.xpath("//a[@class='arial mediumContent']");

	//-------------------------------------------------------------------------------------------------------------
	static SoftAssert softassert;
	//By Page= By.xpath("");

	public LoyaltycardPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
		comm=new CommanClassLoyaltycard(driver);
	}

	public void Login() throws InterruptedException{
		Boolean UN=comm.IselementPresent(username);
		if (UN) {
			Boolean email=comm.TextField(username, "prince@appypie.com");
			s_assert.assertTrue(email, "Email field is not enter value");

			Boolean pass=comm.TextField(password, "12345678");
			s_assert.assertTrue(pass, "Pass field is not enter value");

			Boolean login=comm.Openlinks(LoginBtn);
			s_assert.assertTrue(login, "login field is not click ");

			try{
				driver.findElement(Acceptandcontinue).click();
			}catch (Exception e) {
				System.out.println("Accept and continue is Not present");
			}
		}else{
			System.out.println("User is already Login");
		}

		//----------------------------Menu page---------------------------------------------------
	}

}