package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ProfilePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By profilePic = By.id("profileImageDir");
	By profileName = By.id("profileName");
	By saveProfile = By.xpath("//button[contains(@onclick,'Appyscript.saveProfilePic')]");
	By cancelUploadImage = By.xpath("//span[@class='modal-button'][text()='Cancel']");
	By backBtn = By.xpath("//a[contains(@class,'close link')]");

	public ProfilePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isProfilePageOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement page = ElementWait.waitForOptionalElement(driver, saveProfile, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Profile page is not open upon clicking on update profile from directory menu");
		}
		return open;
	}

	public void updateImage() {
		ElementWait.waitForOptionalElement(driver, profilePic, 20).click();
	}

	public void editProfileName(String pname) {
		WebElement name = ElementWait.waitForOptionalElement(driver, profileName, 10);
		name.clear();
		name.sendKeys(pname);
	}

	public void saveProfile() {
		ElementWait.waitForOptionalElement(driver, saveProfile, 10).click();
	}

	public void cancelUploadPopup() {
		PageElement.locateClickableElement(driver, cancelUploadImage);
	}

	public String getProfileName() {
		return driver.findElement(profileName).getAttribute("value");
	}

	public void backOnProfilePage() {
		WebElement back = ElementWait.waitForOptionalElement(driver, backBtn, 10);
		if (back != null && back.isDisplayed()) {
			back.click();
		} else {
			Logger.info("back button is not displayed on profile update page");
		}

	}
}
