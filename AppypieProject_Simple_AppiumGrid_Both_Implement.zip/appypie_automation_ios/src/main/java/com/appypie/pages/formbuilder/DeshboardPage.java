package com.appypie.pages.formbuilder;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class DeshboardPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger = Log.createLogger();
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");

	public By formBuilderModule_link = By.xpath("//a[@data-productid='formbuilder']");
	public By appointment_link= By.xpath("//*[@data-identifire='app']");
	public By inquire_link= By.xpath("//*[@data-identifire='quote']");
	public By custome= By.xpath("//*[@data-identifire='custom']");
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By getListPresentfileds=By.xpath("//*[contains(@class,'appypie-list')]");
	
	
	
	
	
	// ------------------For Default Method-----------------
	public By AlertHeader_gettext = By.xpath("//*[@class='modal-title']");
	public By AlertText_gettext = By.xpath("//*[@class='modal-text']");
	public By AlertOkButton = By.xpath("//*[@class='modal-button modal-button-bold']");
	public By BackButton = By.xpath("//*[@class='link back']");
	public By BackButtonNative = By.id("icon1_button");

	public By BackButtonNativeforsigngoogle = By.className("android.widget.ImageButton");

	
	public By header_gettext = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	public By header_gettext_native = By.id("text_Tittle");

	public DeshboardPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}

	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext) {
		try {
			String gettextmessage = ElementWait.waitForOptionalElement(driver, gettext, 50).getText();
			Logger.info("Inner Page Text is :" + gettextmessage);
			return gettextmessage;
		} catch (Exception e) {
			System.out.println("Error getting text:  " + e);
		}
		return runningTest1;
	}

	public void IfAlertpresent()  {
		boolean alert = false;
		alert = driver.findElements(By.xpath("//*[@class='modal-title']")).size() != 0;
		if (alert) {
			System.out.println("Alert is present");
			Boolean alerttext=IselementPresent(AlertText_gettext);
			if (alerttext) {
				getPagetext(driver, AlertText_gettext);
			}
			else{
				System.out.println("Alert text Message is not present.");
			}
			AlertOkButtonMethod();
		} else {
			System.out.println("Alert is Not present");
		}
	}

	public void AlertOkButtonMethod()  {
		WebElement open = ElementWait.waitForOptionalElement(driver, AlertOkButton, 50);
		if (open != null && open.isDisplayed()) {
			open.click();
			try {
				TimeUnit.SECONDS.sleep(2);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
		} else {
			System.out.println("Alert Ok Button is not present ");
		}
	}

	public void AlertHandle(){
		try{
			driver.switchTo().alert().accept();
		}
		catch (NoAlertPresentException e) {
			System.out.println("NoAlertPresentException");
		}
		

	}
	
	
	public void swipingHorizontal(int Number)  {
		driver.context("NATIVE_APP");
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e1) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e1.printStackTrace();
		}

		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);

			// Find swipe start and end point from screen's with and height.
			// Find startx point which is at right side of screen.
			int startx = (int) (size.width * 0.70);
			// Find endx point which is at left side of screen.
			int endx = (int) (size.width * 0.30);
			// Find vertical point where you wants to swipe. It is in middle of
			// screen height.
			int starty = size.height / 2;
			// System.out.println("startx = " + startx + " ,endx = " + endx + "
			// , starty = " + starty);
			// Swipe from Right to Left.
			//driver.swipe(startx, starty, endx, starty, 300); //------example------------
			driver.swipe(startx, starty, endx, starty, Number);
			TimeUnit.SECONDS.sleep(2);

			/*
			 * //Swipe from Left to Right. driver.swipe(endx, starty, startx, starty, 3000); 
			 * Thread.sleep(2000);
			 */
		} catch (Exception e) {
			System.out.println("Errpr in swipingHorizontal()");
		}
		PageElement.changeContextToWebView(driver);
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}

	}

	public void SwipetopTobottom()  {
		driver.context("NATIVE_APP");
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e1) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e1.printStackTrace();
		}
		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);
			// Find swipe start and end point from screen's with and height.
			// Find starty point which is at bottom side of screen.
			int starty = (int) (size.height * 0.80);
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle
			// of screen width.
			int startx = size.width / 2;
			// System.out.println("starty = " + starty + " ,endy = " + endy + "
			// , startx = " + startx); // ye wala h ================
			// Swipe from Bottom to Top.
			// driver.swipe(startx, starty, startx, endy, 3000);
			TimeUnit.SECONDS.sleep(3);
			// Swipe from Top to Bottom.
			driver.swipe(startx, endy, startx, starty, 3000);
			TimeUnit.SECONDS.sleep(3);
		} catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		PageElement.changeContextToWebView(driver);
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}
	}

	public void SwipeBottomToTop()  {
		// driver.context("NATIVE_APP");
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e1) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e1.printStackTrace();
		}
		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);
			// Find swipe start and end point from screen's with and height.
			// Find starty point which is at bottom side of screen.
			int starty = (int) (size.height * 0.80);
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle
			// of screen width.
			int startx = size.width / 2;
			// System.out.println("starty = " + starty + " ,endy = " + endy + "
			// , startx = " + startx); // ye wala h ================
			// Swipe from Bottom to Top.
			driver.swipe(startx, starty, startx, endy, 3000);
			TimeUnit.SECONDS.sleep(3);
			// Swipe from Top to Bottom.
			// driver.swipe(startx, endy, startx, starty, 3000);
			TimeUnit.SECONDS.sleep(3);
		} catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		// PageElement.changeContextToWebView(driver);
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}
	}

	// =====================================================================================

	// ---------------------------Methods--------------------------------------------------s
	public void BackButtonNative(By link)  {

		driver.context("NATIVE_APP");

		WebElement open = ElementWait.waitForOptionalElement(driver, link, 20);
		if (open != null && open.isDisplayed()) {
			open.click();
			try {
				TimeUnit.SECONDS.sleep(2);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
		} else {
			System.out.println("Native Back Button is not present ");
		}
		PageElement.changeContextToWebView(driver);
	}

	public boolean Openlinks(By link)  {
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e1) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e1.printStackTrace();
		}
		boolean links = false;
		boolean exception = false;
		try{
		
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			linkpresent.click();
			TimeUnit.SECONDS.sleep(4);
			links = true;
			//System.out.println(linkpresent.getText()+" : is selected/Click");
		} else {
			System.out.println(link+"  Link is not present");
		}
		}
		catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			exception = true;
			System.out.println(exception+"\n" + printExceptionTrace(e));
		}
		return links;
	}
	
	public void click_JavascriptExecutor(By link){
		WebElement element = driver.findElement(link);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public boolean Syncing_BufferingContent(By link)    // Wait finction
	{
		System.out.println("user enter the loding section");
		Boolean message=false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			while(driver.findElements(link).size()!= 0){}
			try {
				TimeUnit.SECONDS.sleep(2);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
			System.out.println("user out the loding section");
		}
		else{
			System.out.println("Syncing Content loding box is not present");
		}
		return message;
	}
	
	public boolean TextField(By link, String entertext) {
		boolean links = false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			links = true;
			linkpresent.clear();
			linkpresent.sendKeys(entertext);
			try {
				driver.hideKeyboard();
			} catch (Exception e) {
				System.out.println("hideKeyboard()");
			}
			System.out.println(entertext+" : is Enter data");
		} else {
			System.out.println(("Link is not present"));
		}
		return links;
	}
	
	public boolean ClearTextField(By link) {
		boolean links = false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			links = true;
			linkpresent.clear();
			try {
				driver.hideKeyboard();
			} catch (Exception e) {
				System.out.println("hideKeyboard()");
			}
			System.out.println(linkpresent.getText()+" : is Enter data");
		} else {
			System.out.println(("Link is not present"));
		}
		return links;
	}

	public String Getactualtext(By gettext)  {
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}
		String Actualtext = null;
		WebElement element = ElementWait.waitForOptionalElement(driver, gettext, 20);
		if (element != null && element.isDisplayed()) {
			Actualtext = element.getText();
			System.out.println("Get Text:  " + Actualtext);
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
		}
		return Actualtext;
	}

	public String GetAttributevalue(By gettext){
		String Actualtext = null;
		WebElement element = ElementWait.waitForOptionalElement(driver, gettext, 20);
		if (element != null && element.isDisplayed()) {
			Actualtext = element.getAttribute("value");
			System.out.println("Get Value:  " + Actualtext);
		}
		return Actualtext;
	}

	public boolean getListofLink(By link)  {
		boolean text = false;
		int i=0;
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}
		List<MobileElement> listpresent = driver.findElements(link);
		if(listpresent!=null){
			List<MobileElement> allSuggestions = driver.findElements(link);
			for (WebElement suggestion : allSuggestions) {
				i++;
				System.out.println(i+"). "+suggestion.getText());
				
			}
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
			text = true;
		}
		else{
			System.out.println("List is not present");
		}
		return text;


	}



	public boolean IselementPresent(By textvalue)  {
		boolean text = false;
		WebElement textpresent = ElementWait.waitForOptionalElement(driver, textvalue, 20);
		if (textpresent != null && textpresent.isDisplayed()) {
			text = true;
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
			System.out.println(textpresent.getText()+" : is Present");
		} else {
			System.out.println(("Link is not present"));
		}
		return text;
	}



	public String printExceptionTrace(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}


	public void countryselect() {
		//driver.context("NATIVE_APP");
		driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("+ "new UiSelector().text(\"India\"));")).click();
		//PageElement.changeContextToWebView(driver);

	}

	public boolean Actionclick(By link) {
		boolean text = false;
		WebElement element = ElementWait.waitForOptionalElement(driver, link, 20);
		if (element != null && element.isDisplayed()) {
			Actions action = new Actions(driver);
			action.moveToElement(element).click().perform();
			try {
				TimeUnit.SECONDS.sleep(2);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
			text=true;
		}
		else{
			System.out.println("Link is not Present");
		}
		return text;

	}

	public boolean compareStrings(String actualStr, String expectedStr){
		SoftAssert s_assert = new SoftAssert();
		try{
			//If this assertion will fail, It will throw exception and catch block will be executed.
			Assert.assertEquals(actualStr, expectedStr);
		}catch(Throwable t){
			//This will throw soft assertion to keep continue your execution even assertion failure.
			//Use here hard assertion "Assert.fail("Failure Message String")" If you wants to stop your test on assertion failure.
			s_assert.fail("Actual String '"+actualStr+"' And Expected String '"+expectedStr +"' Do Not Match.");
			//If Strings will not match, return false.
			return false;
		}
		//If Strings match, return true.
		return true;
	}

	public void slider(By link){
		WebElement slider = ElementWait.waitForOptionalElement(driver, link, 20);
		if (slider != null && slider.isDisplayed()) {}
	      Actions move = new Actions(driver);
        Action action = (Action) move.dragAndDropBy(slider, 30, 0).build();
        action.perform();
	} 
	
	public void CheckingChkbox(WebElement chkbx1){
		boolean checkstatus;
		checkstatus=chkbx1.isSelected();
		if (checkstatus==true){
		    System.out.println("Checkbox is already checked");  
		}
		else
		{
		    chkbx1.click();
		    System.out.println("Checked the checkbox");
		}
		}
	
	public void ScrollPerticularSection(By link)  {
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}

		//Locate element for which you wants to retrieve x y coordinates.
		WebElement Image = driver.findElement(link);

		//Used points class to get x and y coordinates of element.
		Point point = Image.getLocation();
		int xcord = point.getX();
		System.out.println("Element's Position from left side Is:  "+xcord +" pixels.");
		int ycord = point.getY();
		System.out.println("Element's Position from top side Is:  "+ycord +" pixels.");

		//---------------------------------------------------------
		//Get the size of screen.
		size = driver.manage().window().getSize();  

		//Find swipe start and end point from screen's with and height.
		//Find startx point which is at right side of screen.
		int startx = (int) (size.width * 0.70);
		//Find endx point which is at left side of screen.
		int endx = (int) (size.width * 0.30);
		//Set Y Coordinates of screen where tabs display.
		int YCoordinates = ycord;  

		//Swipe tabs from Right to Left.
		driver.swipe(startx, YCoordinates, endx, YCoordinates, 100);  


		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}
	}

	
	public void getCoordinates_DigitalSignature(By link){
		WebElement Image = driver.findElement(link);

		//Used points class to get x and y coordinates of element.
		Point point = Image.getLocation();
		int xcord = point.getX();
		System.out.println("Element's Position from left side Is:  "+xcord +" pixels.");
		int ycord = point.getY();
		System.out.println("Element's Position from top side Is:  "+ycord +" pixels.");

		
		//-----------------------------------
		TouchAction touchAction4 = new TouchAction(driver);
		touchAction4.press(367,1070).moveTo(300,512).release();
		driver.performTouchAction(touchAction4);

	}
	
	public boolean TwoValueReturn(By link1, By link2){
	
		boolean text = false;
		
		List<MobileElement> Getlist1 =  driver.findElements(link1);    
		List<MobileElement> Getlist2 =  driver.findElements(link2);  
		     
		if(Getlist1!=null){
			text=true;
		for(int i=0;i<Getlist1.size();i++){
		count++;
		System.out.println(count+"). "+Getlist1.get(i).getText()+">>>"+Getlist2.get(i).getText());
		}
	}
		return text;
	
	}
	
	public void listvalueclick(By link,String value){
	List<MobileElement> list = driver.findElements(link);
	for (WebElement element : list) 
	{ 
	  if(element.getAttribute("value").equals(value)) 
	 { 
	   element.click(); 
	 } 
	}
	}
	
	
	public void SeekBar(By link,String id)  {
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			System.out.println("Error:  TimeUnit.SECONDS");
			e.printStackTrace();
		}
		//Click on Seek Bar.
		  driver.findElement(link).click();
	}
	
	 public void tapOn(WebElement element){
	        new TouchAction(driver).tap(element).perform();
	    }
	 public boolean checkbox(By link){
			boolean check=false;
			WebElement checkboxelement = ElementWait.waitForOptionalElement(driver, link, 20);
			if (checkboxelement != null && checkboxelement.isDisplayed()){
				if (checkboxelement.isSelected()) {
					System.out.println("Check box is selected");
					check=true;
				}
				else{
					System.out.println("Check box is not selected");
				}
			}
			return check;
		}
	
		public void sharelink(By shareid) {
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
			driver.context("NATIVE_APP");
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
			System.out.println("To check and get share by links in the phone.");
			List<MobileElement> allSuggestions = driver.findElements(shareid);
	        for (WebElement suggestion : allSuggestions)
	        {
	        System.out.println("Share By Items:   "+suggestion.getText());
	        }
	        driver.navigate().back();
	        PageElement.changeContextToWebView(driver);
	        try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				System.out.println("Error:  TimeUnit.SECONDS");
				e.printStackTrace();
			}
		}
	 
		public void getCoordinates(By link) {
			//Locate element for which you wants to retrieve x y coordinates.
			WebElement Image = driver.findElement(link);

			//Used points class to get x and y coordinates of element.
			Point point = Image.getLocation();
			int xcord = point.getX();
			System.out.println("Element's Position from left side Is:  "+xcord +" pixels.");
			int ycord = point.getY();
			System.out.println("Element's Position from top side Is:  "+ycord +" pixels.");
		}
	
	
}
