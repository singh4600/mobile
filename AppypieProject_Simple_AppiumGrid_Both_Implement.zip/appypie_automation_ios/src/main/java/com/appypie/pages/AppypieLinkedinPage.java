package com.appypie.pages;

import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieLinkedinPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	By linkedInPage = By.xpath("//a[@data-productid='linkedin']");
	By linkedInUrl = By.xpath("//a[@class='appypie-list'][@data-page='linkedin']");
	By home = By.id("text_Tittle");
	By nativebackbtn = By.id("icon1_button");

	By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='Linkedin']");

	public AppypieLinkedinPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openLinkedInPage() {
		WebElement googleOpen = ElementWait.waitForOptionalElement(driver, linkedInPage, 20);
		if (googleOpen != null && googleOpen.isDisplayed())
			googleOpen.click();
		else {
			Logger.error("LinkedIn page is not present in main menu");
		}
	}

	public boolean identifyLinkedInOpen() {
		boolean open = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, linkedInUrl, 20);
		if (url != null && url.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openLinkedInUrl() {
		WebElement url = ElementWait.waitForOptionalElement(driver, linkedInUrl, 20);
		url.click();
	}

	public boolean checklinkedInOpen() throws InterruptedException {
		boolean open = false;
		WebElement element_home = null;
		Set<String> contextNames = driver.getContextHandles();
		driver.context("NATIVE_APP");
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
			element_home = ElementWait.waitForOptionalElement(driver, home, 20);
			if (element_home != null && element_home.isDisplayed()) {
				open = true;
				Thread.sleep(3000);
				driver.findElement(nativebackbtn).click();
			} else {
				Logger.error("Linked in home page is not open upon clicking on linked in feeds");
			}
		} else {
			element_home = ElementWait.getIosNativeElement(driver, i_nativeView, 20);
			if (element_home != null) {
				open = true;
				Thread.sleep(3000);
				Set<String> contextNames1 = driver.getContextHandles();
				PageElement.tapOnScreen(driver, 0.05, 0.05);
			} else {
				Logger.error("Linked in homes Url is not open in native after clicking on view button from feed in ios");
			}
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
}
