package com.appypie.pages.OrderFoodPages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class ProductDetailPage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	public By selectcolorlink= By.xpath("//a[contains(@onclick,'foodSelectOpen')]"); //specific  item drop list
	public By Choose1link= By.xpath("//*[contains(@class,'foodordering-select')]/li[1]"); // choose specific  item check box
	public By Choose2link= By.xpath("//*[contains(@class,'foodordering-select')]/li[2]"); // choose specific  item check box
	public By Donelink= By.xpath("//*[@class='foodordering-done']"); // done button on selected specific 
	public By addincartlink= By.xpath("//*[@id='addtocartid']"); // add to cart button after select specific item 
	public By Donebtn= By.xpath("//a[@class='foodordering-done']"); // done button on selected specific 
	public By imgnative= By.xpath("//android.widget.Image[@index='0']");
	public By imgnative1= By.xpath("//*[contains(@class,'swiper-container product-swiper swiper-container-horizontal swiper-container-android')]/div[1]//*[contains(@class,'swiper-wrapper')]/div[1]");
	public By playvideo= By.xpath("//*[contains(@onclick,'openVideoStreamFood')]");
	//---------Get Text Event----------------------------
	//public By _gettext=By.xpath("");
	public By ProductName_gettext=By.xpath("//*[@id='productName']");
	public By Productprice_gettext=By.xpath("//p[@class='price']");
	public By heading_gettext=By.xpath("//*[@class='product-description']/h3");
	public By discription_gettext=By.xpath("//*[contains(@class,'description')]//*[@id='pDiscription']");
	public By quantity_gettext=By.xpath("//*[@id='quantity']");
	//---------------------------------------------------
	public ProductDetailPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}
	

	public void AddToCart(){
		WebElement openAddToCartclick= ElementWait.waitForOptionalElement(driver, addincartlink, 40);
		if(openAddToCartclick!=null && openAddToCartclick.isDisplayed())
			openAddToCartclick.click();
		else{
			System.out.println("AddToCartclick page is not present");
		}
	}





	public void Done(){
		WebElement openDone= ElementWait.waitForOptionalElement(driver, Donebtn, 40);
		if(openDone!=null && openDone.isDisplayed())
			openDone.click();
		else{
			System.out.println("Done page is not present.");
		}
	}
	
	
	
}
