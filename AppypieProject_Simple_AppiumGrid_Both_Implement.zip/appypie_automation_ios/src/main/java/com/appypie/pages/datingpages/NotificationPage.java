package com.appypie.pages.datingpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.FileHandler;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class NotificationPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By notificationList = By.xpath("//ul[@class='notification_list']/li");
	By NotificationHeader = By.xpath("//div[@class='navbar']//div[text()='Notifications']");

	public NotificationPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isNotificationPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, NotificationHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isNotificationExist() {
		boolean exist = false;
		WebElement notifications = ElementWait.waitForOptionalElement(driver, notificationList, 20);
		if (notifications != null && notifications.isDisplayed()) {
			exist = true;
		}
		return exist;
	}

	public boolean isNotifiedUserExist() {
		boolean exist = false;
		String user = "ActiveUser" + FileHandler.fileReader("UserValue");
		By userName = By.xpath("//div[@class='nf-profile-info']//span[@class='trunkTxt'][text()='" + user + "']");
		WebElement notify = ElementWait.waitForOptionalElement(driver, userName, 10);
		if (notify != null && notify.isDisplayed()) {
			exist = true;
		}
		return exist;

	}
}
