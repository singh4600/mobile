package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieDBPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By dbPage = By.xpath("//a[@data-productid='appypiedb']");
	By dbHeader = By.xpath("//div[@class='navbar']//div[text()='DB']");
	By searchBtn = By.id("btnSearch");
	By searchField = By.id("txtSearch");
	By entry = By.xpath("//li[contains(@onclick,'Appyscript.appypiedbDetail')]");
	By dob = By.xpath("//div[@class='info-right']/ul/li[1]//strong[@class='name searchnow']");
	By email = By.xpath("//div[@class='info-right']/ul/li[2]//strong[@class='name searchnow']");
	By name = By.xpath("//div[@class='info-right']/ul/li[3]//strong[@class='name searchnow']");
	By title = By.xpath("//div[@class='info-right']/ul/li[4]//strong[@class='name searchnow']");

	By detail = By.className("bodypan");
	By fb = By.className("icon-facebook");
	By google = By.className("icon-googleplus-rect");
	By linkedin = By.className("icon-linkedin-1");
	By pinterest = By.className("icon-pinterest-1");
	By twitter = By.className("icon-twitter-bird-1");

	public AppypieDBPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}


	public boolean isDBPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, dbHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String getSearchBoxClass() {
		String name = "";
		WebElement search = ElementWait.waitForOptionalElement(driver, searchField, 20);
		if (search != null) {
			name = search.getAttribute("class");
		}
		return name;
	}

	public boolean isDataDetailOpen() {
		boolean open = false;
		WebElement data = ElementWait.waitForOptionalElement(driver, detail, 20);
		if (data != null && data.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickSearch() {
		WebElement search = ElementWait.waitForOptionalElement(driver, searchBtn, 20);
		if (search != null && search.isDisplayed()) {
			search.click();
		}
	}

	public String getDetails(String data) {
		String value = null;
		WebElement detail = null;
		if (data.equals("dob"))
			detail = ElementWait.waitForOptionalElement(driver, dob, 10);
		else if (data.equals("email"))
			detail = ElementWait.waitForOptionalElement(driver, email, 10);
		else if (data.equals("name"))
			detail = ElementWait.waitForOptionalElement(driver, name, 10);
		else
			detail = ElementWait.waitForOptionalElement(driver, title, 10);
		if (detail != null && detail.isDisplayed()) {
			value = detail.getText();
		}
		return value;
	}

	public void clickData() {
		WebElement data = ElementWait.waitForOptionalElement(driver, entry, 20);
		if (data != null && data.isDisplayed()) {
			data.click();
		}
	}

	public void openSocial(String type) {
		WebElement social = null;
		if (type.equals("fb"))
			social = ElementWait.waitForOptionalElement(driver, fb, 10);
		else if (type.equals("google"))
			social = ElementWait.waitForOptionalElement(driver, google, 10);
		else if (type.equals("linkedin"))
			social = ElementWait.waitForOptionalElement(driver, linkedin, 10);
		else if (type.equals("pinterest"))
			social = ElementWait.waitForOptionalElement(driver, pinterest, 10);
		else
			social = ElementWait.waitForOptionalElement(driver, twitter, 10);
		if (social != null && social.isDisplayed()) {
			social.click();
		}
	}

}
