package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieMapPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By location = By.xpath("//li[contains(@onclick,'Appyscript.singlemap')][contains(@onclick,'onsis')]");
	By mapHeader = By.xpath("//div[@class='navbar']//div[text()='Map']");
	By warningOption1 = By.xpath("//span[@class='modal-button'][text()='Get Directions']");

	By locationBtn = By.id("com.google.android.apps.maps:id/mylocation_button");
	By map = By.xpath("//android.view.View[@content-desc='Map']");

	public AppypieMapPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isMapPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, mapHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickLocation() {
		WebElement loc = ElementWait.waitForOptionalElement(driver, location, 20);
		if (loc != null && loc.isDisplayed()) {
			loc.click();
		} else {
			Logger.error("Desired location is not available");
		}
	}

	public boolean isPopUpDisplayed() {
		boolean display = false;
		WebElement warn = ElementWait.waitForOptionalElement(driver, warningOption1, 20);
		if (warn != null && warn.isDisplayed()) {
			display = true;
		}
		return display;
	}

	public void clickOptions(String option) {
		By links = By.xpath("//span[@class='modal-button'][text()='" + option + "']");
		WebElement element = ElementWait.waitForOptionalElement(driver, links, 20);
		if (element != null && element.isDisplayed()) {
			element.click();
		}
	}

	public boolean isMapOptionsOpenInNative(String option) throws InterruptedException {
		boolean open = false;
		WebElement nativeOpen = null;
		driver.context("NATIVE_APP");
		if (option.equals("direction")) {
			nativeOpen = ElementWait.waitForOptionalElement(driver, locationBtn, 20);
		} else {
			nativeOpen = ElementWait.waitForOptionalElement(driver, map, 20);
		}
		if (nativeOpen != null && nativeOpen.isDisplayed()) {
			open = true;
			Thread.sleep(1000);
			driver.navigate().back();
			Thread.sleep(500);
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}

}
