package com.appypie.pages.datingpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MyProfilePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By editProfile = By.xpath("//a[contains(@onclick,'Appyscript.datingPhotoProfileEdit')]");
	By profileDetail = By.xpath("//div[@class='profile-des']//h2[contains(@class,'user-name')]");
	By companyDetail = By.xpath("//div[@class='profile-des']//p[contains(@class,'user-des')]");
	By updateProfile = By.xpath("//button[contains(@onclick,'Appyscript.saveProfileDetails')]");
	By profileUpdateOnHeader = By.xpath("//a[contains(@onclick,'Appyscript.saveProfileDetails')]");
	By uploadPic = By.id("picupload1");
	By imgurl1 = By.xpath("//div[@class='row uploaded-img']/div[1]/img");
	By imgurl2 = By.xpath("//img[@id='picupload2']");
	By uploadSecondPic = By.id("picupload2");
	By removePic1 = By.id("close1");
	By removePic2 = By.id("close2");
	By company = By.id("company");
	By gallery = By.xpath("//span[contains(@class,'modal-button')][text()='Gallery']");
	By profileimg = By.xpath("//div[contains(@class,'swiper-slide-active')][@id='datingimageslide']/img");
	
	By uploadPhoto = By.xpath("//button[contains(@onclick,'Appyscript.uploadprofilepic')]");
	

	public MyProfilePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isProfilePageOpen() {
		boolean open = false;
		WebElement profile = ElementWait.waitForOptionalElement(driver, editProfile, 20);
		if (profile != null && profile.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public boolean isProfileDetailPageOpen() {
		boolean open = false;
		WebElement profile = ElementWait.waitForOptionalElement(driver, profileDetail, 20);
		if (profile != null && profile.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickEditProfile() {
		WebElement profileEdit = ElementWait.waitForOptionalElement(driver, editProfile, 20);
		if (profileEdit != null && profileEdit.isDisplayed()) {
			profileEdit.click();
		}
	}
	
	public void uploadPhoto() {
		WebElement pic = ElementWait.waitForOptionalElement(driver, uploadPhoto, 20);
		if (pic != null && pic.isDisplayed()) {
			pic.click();
		}
	}

	public boolean isEditProfileOpen() {
		boolean open = false;
		WebElement profileEdit = ElementWait.waitForOptionalElement(driver, profileUpdateOnHeader, 20);
		if (profileEdit != null && profileEdit.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String getProfileDetail() {
		String detail = "";
		WebElement info = ElementWait.waitForOptionalElement(driver, profileDetail, 10);
		if (info != null && info.isDisplayed()) {
			detail = info.getText();
		} else {
			Logger.info("profile detail is not displayed");
		}
		return detail;
	}

	public void clickProfileImg(String number) {
		WebElement img;
		if (number.equals("one"))
			img = ElementWait.waitForOptionalElement(driver, uploadPic, 10);
		else
			img = ElementWait.waitForOptionalElement(driver, uploadSecondPic, 10);
		if (img != null && img.isDisplayed()) {
			img.click();
		}
	}

	public void removeProfileImg(String number) {
		WebElement img;
		if (number.equals("one"))
			img = ElementWait.waitForOptionalElement(driver, removePic1, 10);
		else
			img = ElementWait.waitForOptionalElement(driver, removePic2, 10);
		if (img != null && img.isDisplayed()) {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + img.getLocation().x + ")");
			img.click();
		}
	}

	public void openGallery() {
		PageElement.locateClickableElement(driver, gallery);
	}

	public void enterCompanyName(String data) {
		PageElement.sendKey(driver, company, data);
	}

	public void updateProfile() {
		PageElement.locateClickableElement(driver, updateProfile);
	}

	public void updateProfileFromHeaderLink() {
		PageElement.locateClickableElement(driver, profileUpdateOnHeader);
	}

	public String getImageUrl(String number) {
		String url = "";
		WebElement info;
		if (number.equals("one"))
			info = ElementWait.waitForOptionalElement(driver, imgurl1, 10);
		else
			info = ElementWait.waitForOptionalElement(driver, imgurl2, 10);
		if (info != null && info.isDisplayed()) {
			url = info.getAttribute("checkimage");
		} else {
			Logger.info("image is not displayed");
		}
		return url;
	}

	public String getImageUrlonMyProfile() {
		String url = "";
		WebElement info = ElementWait.waitForOptionalElement(driver, profileimg, 10);
		if (info != null && info.isDisplayed()) {
			url = info.getAttribute("style");
			if (url.contains("url")) {
				url = url.substring(url.indexOf("url(") + 5, url.indexOf("\")"));
			}
		} else {
			Logger.info("image is not displayed");
		}
		return url;
	}

	public String getCompanyName() {
		String detail = "";
		WebElement info = ElementWait.waitForOptionalElement(driver, companyDetail, 20);
		if (info != null && info.isDisplayed()) {
			detail = info.getText();
		} else {
			Logger.info("company name is not displayed");
		}
		return detail;
	}
	
}
