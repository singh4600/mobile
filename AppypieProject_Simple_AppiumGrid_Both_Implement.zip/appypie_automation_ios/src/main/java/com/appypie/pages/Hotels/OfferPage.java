package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class OfferPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By backBtn= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	
		
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By Hotellist_gettext=By.xpath("//*[(@data-page='accommodation-offerpage' and @class='page navbar-through no-toolbar page-on-center')]/div[1]/ul/li");

	

	public OfferPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}

