package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppHomePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By directoryfolder = By.xpath("//a[@data-productidentifier='folder_1495518509933_71'][@data-productid='folder']");
	By directoryPage = By.xpath("//a[@data-productid='services']");
	By hyperlocal = By.xpath("//a[@data-productid='hyperlocal']");
	//********************Prince*********
	By tc = By.xpath("//*[@id='termscondition']");

	public AppHomePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void opendirectoryFolder() {
		WebElement folder = ElementWait.waitForOptionalElement(driver, directoryfolder, 20);
		if (folder != null && folder.isDisplayed()) {
			folder.click();
		} else {
			Logger.info("directory folder not exist in main menu");
		}
	}

	public boolean openDirectoryPage() {
		boolean dirctoryPage=false;
		WebElement element_directory = ElementWait.waitForOptionalElement(driver, directoryPage, 20);
		if (element_directory != null) {
			element_directory.click();
			dirctoryPage=true;
		} else {
			Logger.info("Directory  page is not present in the app or flow is not main Menu");
		}
		return dirctoryPage;
	}


	public boolean isDirectoryExist() {
		boolean exist = false;
		WebElement element_directory = ElementWait.waitForOptionalElement(driver, directoryPage, 20);
		if (element_directory != null) {
			exist = true;
		} else {
			Logger.info("Directory  page is not present in the app or flow is not main Menu");
		}
		return exist;
	}

	public boolean openHyperlocal() {
		boolean hyprlcl=false;
		WebElement element_hl = ElementWait.waitForOptionalElement(driver, hyperlocal, 20);
		if (element_hl != null && element_hl.isDisplayed()) {
			element_hl.click();
			hyprlcl=true;
		} else {
			Logger.info("Hyperlocal page is not present in the app or flow is not main Menu");
		}
		return hyprlcl;
	}

	public boolean isHyperlocalExist() {
		boolean exist = false;
		WebElement element_hyperlocal = ElementWait.waitForOptionalElement(driver, hyperlocal, 20);
		if (element_hyperlocal != null) {
			exist = true;
		} else {
			Logger.info("Hyperlocal  page is not present in the app or flow is not main Menu");
		}
		return exist;
	}


	//********************Prince*********
	
		public void tapOnTC() {
			WebElement T_C = ElementWait.waitForOptionalElement(driver, tc, 20);
			if (T_C != null && T_C.isDisplayed()) {
				T_C.click();
			} else {
				Logger.info("directory/Hyperlocal T&C page not exist while opening the page first time");
			}
		}



}
