package com.appypie.pages.OrderFoodPages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class CartPage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");
	public By removeProductlink=By.xpath("//*[contains(@class,'user_tab')]/div[2]/a");
	public By Incrementproductbtn= By.xpath("//*[@class='add']"); 
	public By Decrementproductbtn= By.xpath("//*[@class='less']");
	public By CouponTextfieldbtn= By.xpath("//*[@id='couponCode']");
	public By CouponApplyBtn= By.xpath("//a[@class='apply arial mediumContent']");
	public By continueOrderinglink=By.xpath("//*[contains(@onclick,'foodGoToHomePage();')]");
	public By CheckoutBtn= By.xpath("//a[contains(@onclick,'foodProceedToPay')]"); // check out button.
	public By tipinc=By.xpath("//*[@id='tipAmountSlider']");
	//---------Get Text Event----------------------------
	//public By _gettext=By.xpath("");
	
	public By productName_gettext=By.xpath("//*[@id='user_tab1']/div/div/div/h3"); // verify Item name on checkout page
	public By productcolour_gettext=By.xpath("//*[@id='user_tab1']/div/div/div/div[1]");
	public By ProductQuentity_gettext=By.xpath("//*[@id='qty1']");
	public By TotalPayableAmount_gettext=By.xpath("//strong[@id='grandTotal']/span");

	
	public By PaymentDetailsHeading_gettext=By.xpath("//*[@id='user_tab3']/div/h4");
	public By Subtotal_gettext=By.xpath("//li[@id='subtotalecom']/span");
	public By Discount_gettext=By.xpath("//li[@id='discountecom']/span");  
	public By Delivery_gettext=By.xpath("//li[@id='deliverychargeecom']/span");
	public By Tax_gettext=By.xpath("//li[@id='taxecomecom']/span");
	public By Tip_gettext=By.xpath("//span[@id='tipAmount']");
	public By miscTax_gettext=By.xpath("//*[@id='miscTaxecom']");
	public By grandTotal_gettext=By.xpath("//*[@id='gtotal']");
	public By GrandTotal_gettext=By.xpath("//li[@id='gtotal']/span");

	//---------------------------------------------------
	public CartPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}
	
	public static String verifyAttributevalue(AppiumDriver<MobileElement> driver, By getAttribute){
		Actual=ElementWait.waitForOptionalElement(driver,getAttribute,50).getAttribute("value");
		System.out.println("Actual value:  "+Actual);
		return Actual;
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}

	public void Couponcode() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,CouponTextfieldbtn ,20);
		if(open!=null && open.isDisplayed()){
			open.sendKeys("abcde");
		}
		else{
			System.out.println("Check Coupon code on Cart page is not present");
		}
	}

	public void CouponcodeApply() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,CouponApplyBtn ,20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(5);
			String msg=driver.findElement(By.xpath("//div[@class='modal-text']")).getText();
			if(msg.equalsIgnoreCase("Invalid Coupon")){
				System.out.println("Invalid coupon");
				driver.findElement(By.xpath("//*[@class='modal-button modal-button-bold']")).click();
			}
			else
				System.out.println("coupon ia apply");
		}
		else{
			System.out.println("Check Coupon code on Cart page is not present");
		}
	}


	public void PorductIncrement() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,Incrementproductbtn ,20);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			System.out.println("Increment button on Cart page is not present");
		}
	}

	public void PorductDecrement() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,Decrementproductbtn ,20);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			System.out.println("Decrement button on Cart page is not present");
		}
	}
	public void ProductDetailsWithAllPrice(){
		System.out.println("Product Name:");
		getPagetext(driver, productName_gettext);
		System.out.println("Product Color:");
		getPagetext(driver, productcolour_gettext);
		System.out.println("check product quanitity and payment details");
		//getPagetext(driver, getProductQuentityincheckout);
		verifyAttributevalue(driver, ProductQuentity_gettext);
		System.out.println("check subtotal");
		getPagetext(driver, Subtotal_gettext);
		System.out.println("check Discount");
		getPagetext(driver, Discount_gettext);
		System.out.println("check Delivery");
		getPagetext(driver, Delivery_gettext);
		System.out.println("check Tax");
		getPagetext(driver, Tax_gettext);
		System.out.println("check Tip");
		getPagetext(driver, Tip_gettext);
		System.out.println("check Grand Total");
		getPagetext(driver, GrandTotal_gettext);
		System.out.println("check Total Payable Amount");
		getPagetext(driver, TotalPayableAmount_gettext);
	}
	

	public void checkout(){
		WebElement opencheckout= ElementWait.waitForOptionalElement(driver, CheckoutBtn, 40);
		if(opencheckout!=null && opencheckout.isDisplayed())
			opencheckout.click();
		else{
			System.out.println("checkout Button is not present in main menu");
		}
	}
	
	public void AlldetailsofProduct(){
		try{
		Getactualtext(productName_gettext);
		Getactualtext(productcolour_gettext);
		Getactualtext(ProductQuentity_gettext);
		Getactualtext(PaymentDetailsHeading_gettext);
		Getactualtext(Subtotal_gettext);
		Getactualtext(Discount_gettext);
		Getactualtext(Delivery_gettext);
		Getactualtext(Tax_gettext);
		Getactualtext(Tip_gettext);
		Getactualtext(GrandTotal_gettext);
		Getactualtext(TotalPayableAmount_gettext);
		}catch (Exception e) {
			System.out.println("Details not preent:  "+e);
		}
	}
	
	public String Getactualtext(By gettext) {
		String Actualtext = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, gettext, 20);
		if (element != null && element.isDisplayed()) {
			Actualtext = element.getText();
			System.out.println("Get Text:  " + Actualtext);
		}
		return Actualtext;
	}
	
}
