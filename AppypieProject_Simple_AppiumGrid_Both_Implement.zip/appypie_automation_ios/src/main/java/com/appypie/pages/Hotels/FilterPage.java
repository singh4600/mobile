package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class FilterPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By cancellink= By.xpath("//*[contains(@class,'close  link close-popup')]");
	public By resetlink= By.xpath("//*[contains(@onclick,'Appyscript.hotelresetparamsearch')]");
	public By sliderrangelink= By.xpath("//*[contains(@id,'accommodationrangGet')]/div[1]/div[1]/div[1]");
	public By bungalow_checkbox= By.xpath("//*[contains(@id,'roomtypefilter')]//*[contains(text(),'Bungalow')]");
	public By guesthouse_checkbox= By.xpath("//*[contains(@id,'roomtypefilter')]//*[contains(text(),'Guest house')]");
	public By hotel_checkbox= By.xpath("//*[contains(@id,'roomtypefilter')]//*[contains(text(),'Hotel')]");
	public By villa_checjbox= By.xpath("//*[contains(@id,'roomtypefilter')]//*[contains(text(),'Villa')]");
	public By rating_1_Starlink= By.xpath("//*[contains(@class,'htRating')]/li[1]");
	public By rating_2_Starlink= By.xpath("//*[contains(@class,'htRating')]/li[2]");
	public By rating_3_Starlink= By.xpath("//*[contains(@class,'htRating')]/li[3]");
	public By rating_4_Starlink= By.xpath("//*[contains(@class,'htRating')]/li[4]");
	public By rating_5_Starlink= By.xpath("//*[contains(@class,'htRating')]/li[5]");
	public By searchBtn= By.xpath("//*[contains(@class,'toolbarButton')]");
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By priceRangeHeading_gettext=By.xpath("//*[contains(@class,'hotelRangSlider')]/h2");
	public By priceMin_gettext=By.xpath("//*[contains(@id,'hotelRangeValueMin')]");
	public By priceMax_gettext=By.xpath("//*[contains(@id,'hotelRangeValueMax')]");
	public By accommodationTypeHeading_gettext=By.xpath("//*[contains(@id,'roomtypefilter')]/h2");
	public By accommodationType_list_gettext=By.xpath("//*[contains(@id,'roomtypefilter')]//*[contains(@class,'on ')]");
	public By ratingHeading_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/h2");
	public By rating_list_gettext=By.xpath("//*[contains(@class,'htRating')]/li");
	
	
	//*[@id="59954e03bc1f4674d0f8cafe"]/text()
	

	public FilterPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}