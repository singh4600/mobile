package com.appypie.pages.newspages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SettingPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	By settingPage= By.xpath("//div[@class='navbar']//div[text()='Settings']");
	By noneOption= By.xpath("//input[@id='alert_recieve1'][@value='none']");
	By dontSendAlert=By.id("do_not_disturb");
	By startTime=By.id("txtTime1");
	By endTime=By.id("txtTime2");
	By saveSetting= By.xpath("//div[contains(@onclick,'Appyscript.setSetting')]");
	
	public SettingPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}
	
	public boolean isSettingPageOpen() {
		boolean open = false;
		WebElement settings=null;
	    settings = ElementWait.waitForOptionalElement(driver, settingPage, 10);
		if (settings != null && settings.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public void clickNone(){
		WebElement none=ElementWait.waitForOptionalElement(driver, noneOption, 5);
		if(none!=null && none.isDisplayed()){
			none.click();
		}
	}
	
	public void clickDontSendAlert(){
		WebElement alert=ElementWait.waitForOptionalElement(driver, dontSendAlert, 5);
		if(alert!=null && alert.isDisplayed()){
			alert.click();
		}
	}
	
	public void updateSetting() throws InterruptedException{
		clickNone();
		clickDontSendAlert();
		Thread.sleep(2000);
		PageElement.locateClickableElement(driver, saveSetting);
	}

}
