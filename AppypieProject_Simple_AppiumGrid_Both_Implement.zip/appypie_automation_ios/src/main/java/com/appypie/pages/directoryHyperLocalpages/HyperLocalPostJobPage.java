package com.appypie.pages.directoryHyperLocalpages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class HyperLocalPostJobPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By cat = By.id("hyperLocal_catid");
	By subCat = By.id("hyperLocal_Subcatid");
	By title = By.xpath("//input[contains(@id,'jobTitle')]");
	By budget = By.xpath("//input[contains(@id,'budget')]");
	By dollar = By.id("currency_Pj");
	By scheduleHours = By.id("ActivateSchedule");
	By days = By.xpath("//div[contains(@class,'form formTimeInput')]");
	By summary = By.id("summary_Pj");

	By image = By.xpath("//a[@href='#tab1']");
	By addMoreImg = By.xpath("//span[contains(@onclick,'addMoreClick2')]");

	By youTube = By.xpath("//a[@href='#tab2']");
	By youtubeHolder = By.id("youtubeUrl_Pj");

	By url = By.xpath("//div[@class='row']//input[@id='url']");
	By addMoreUrl = By.xpath("//input[@id='url']/following-sibling::a[contains(@onclick,'addInput')]");
	By closeMoreUrl = By
			.xpath("//div[@class='myInput']//input[@id='url']/following-sibling::a[contains(@onclick,'removeInput')]");

	By email = By.xpath("//div[@class='row']//input[@id='email']");
	By addMoreEmail = By.xpath("//input[@id='email']/following-sibling::a[contains(@onclick,'addInput')]");
	By closeMoreEmail = By.xpath(
			"//div[@class='myInput']//input[@id='email']/following-sibling::a[contains(@onclick,'removeInput')]");

	By phone = By.xpath("//div[@class='row']//input[@id='call']");
	By addMorePhone = By.xpath("//input[@id='call']/following-sibling::a[contains(@onclick,'addInput')]");
	By closeMorePhone = By
			.xpath("//div[@class='myInput']//input[@id='call']/following-sibling::a[contains(@onclick,'removeInput')]");

	By location = By.id("add_Pj");
	By postJob = By.xpath("//button[contains(@onclick,'addPostJobClick')]");

	By popUp = By.xpath("//span[contains(@class,'modal-button')]");
	By launchAddCheckBox = By.id("chkMapPj");

	public HyperLocalPostJobPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isPostJobPageOpen() {
		boolean open = false;
		WebElement job = ElementWait.waitForOptionalElement(driver, title, 20);
		if (job != null && job.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Post Job page is not open from Hyperlocal main menu");
		}
		return open;
	}

	public boolean imageUploadinPostJob() throws InterruptedException {
		boolean open = false;
		WebElement img = ElementWait.waitForOptionalElement(driver, image, 20);
		if (img != null && img.isDisplayed()) {
			img.click();
			WebElement imgUpload = ElementWait.waitForOptionalElement(driver, addMoreImg, 20);
			if (imgUpload != null && imgUpload.isDisplayed()) {
				imgUpload.click();
				WebElement uploadPopUp = ElementWait.waitForOptionalElement(driver, popUp, 20);
				if (uploadPopUp != null && uploadPopUp.isDisplayed()) {
					open = true;
					PageElement.cancelPopup(driver);
					Thread.sleep(1000);
				} else {
					Logger.info("image upload pop up doesn't appears");
				}
			} else {
				Logger.error("Plus sign for image upload is not visible on add listing form");
			}
		} else {
			Logger.error("Upload image field is not visible on add listing form");
		}
		return open;
	}

	public void clickYouTubeOption() {
		driver.findElement(youTube).click();
	}

	public void enterYouTubeUrl() {
		PageElement.sendKey(driver, youtubeHolder, "https://www.youtube.com/watch?v=QNgE9-0sNjQ");
	}

	public boolean isYouTubeHolderExist() {
		boolean present = false;
		WebElement holder = ElementWait.waitForOptionalElement(driver, youtubeHolder, 10);
		if (holder != null && holder.isDisplayed()) {
			if (holder.getAttribute("placeholder").equals("YouTube URL")) {
				present = true;
			}
		}
		return present;
	}

	public void selectCategory(String value) {
		PageElement.selectByValue(driver, cat, value);
	}

	public void clickLaunchAddressCheckBox() {
		WebElement box = ElementWait.waitForOptionalElement(driver, launchAddCheckBox, 10);
		if (box != null && !box.isSelected()) {
			box.click();
		}
	}

	public void enterTtile(String data) {
		PageElement.sendKey(driver, title, data);
	}

	public void enterUrl(String data) {
		PageElement.sendKey(driver, url, data);
	}

	public void enterEmail(String data) {
		PageElement.sendKey(driver, email, data);
	}

	public void enterPhone(String data) {
		PageElement.sendKey(driver, phone, data);
	}

	public void enterBudget(String data) {
		PageElement.sendKey(driver, budget, data);
	}

	public void selectSubCategory() {
		try {
			WebElement item = ElementWait.waitForOptionalElement(driver, subCat, 5);
			if (item != null) {
				Select element = new Select(item);
				element.selectByIndex(1);
			}
		} catch (Exception e) {
			Logger.error(" Exception occurs while searching the Drop down Value: " + e.getMessage(), e);
			throw (e);
		}

	}

	public void clickScheduleHourCheckbox() {
		PageElement.locateClickableElement(driver, scheduleHours);
	}

	public boolean isScheduleHoursDisplayed() {
		boolean display = false;
		WebElement hours = ElementWait.waitForOptionalElement(driver, days, 5);
		if (hours != null && hours.isDisplayed()) {
			display = true;
		}
		return display;
	}

	public void clickAddMore(String element) throws NullPointerException {
		if (element.equals("url"))
			ElementWait.waitForOptionalElement(driver, addMoreUrl, 5).click();
		else if (element.equals("email"))
			ElementWait.waitForOptionalElement(driver, addMoreEmail, 5).click();
		else
			ElementWait.waitForOptionalElement(driver, addMorePhone, 5).click();
	}

	public void clickCloseAddMore(String element) throws NullPointerException {
		if (element.equals("url"))
			ElementWait.waitForOptionalElement(driver, closeMoreUrl, 5).click();
		else if (element.equals("email"))
			ElementWait.waitForOptionalElement(driver, closeMoreEmail, 5).click();
		else
			ElementWait.waitForOptionalElement(driver, closeMorePhone, 5).click();
	}

	public void submitJob() {
		driver.findElement(postJob).click();
	}

	public int getelementCount(String element) {
		List<MobileElement> list;
		if (element.equals("url"))
			list = ElementWait.getAllElement(driver, url);
		else if (element.equals("email"))
			list = ElementWait.getAllElement(driver, email);
		else
			list = ElementWait.getAllElement(driver, phone);
		return list.size();
	}
}
