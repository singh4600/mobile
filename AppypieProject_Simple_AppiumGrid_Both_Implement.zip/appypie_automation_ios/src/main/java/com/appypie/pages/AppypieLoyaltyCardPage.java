package com.appypie.pages;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class AppypieLoyaltyCardPage {
	PageElement pageutil;
	Dimension size;
	int count=0;
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//------------------Alert Popup-----------------
	public By AlertHeader_gettext=By.xpath("//*[@class='modal-title']");
	public By AlertText_gettext=By.xpath("//*[@class='modal-text']");
	public By AlertOkButton=By.xpath("//*[@class='modal-button modal-button-bold']");

	public AppypieLoyaltyCardPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
		pageutil=new PageElement();
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}

	public void IfAlertpresent() throws InterruptedException{
		boolean alert= false;
		alert=driver.findElements(By.xpath("//*[@class='modal-title']")).size()!=0;
		if(alert){
			System.out.println("Alert is present");
			getPagetext(driver, AlertHeader_gettext);
			getPagetext(driver, AlertText_gettext);
			AlertOkButtonMethod();
		}
		else{
			System.out.println("Alert is Not present");
		}
	}

	public void AlertOkButtonMethod() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, AlertOkButton, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Alert Ok Button is not present ");
		}
	}
	public void swipingHorizontal() throws InterruptedException {
		driver.context("NATIVE_APP");   
		TimeUnit.SECONDS.sleep(2);

		try{
			//Get the size of screen.
			size = driver.manage().window().getSize();
			//System.out.println(size);

			//Find swipe start and end point from screen's with and height.
			//Find startx point which is at right side of screen.
			int startx = (int) (size.width * 0.70);
			//Find endx point which is at left side of screen.
			int endx = (int) (size.width * 0.30);
			//Find vertical point where you wants to swipe. It is in middle of screen height.
			int starty = size.height / 2;
			//  System.out.println("startx = " + startx + " ,endx = " + endx + " , starty = " + starty);
			//Swipe from Right to Left.
			driver.swipe(startx, starty, endx, starty, 300);
			TimeUnit.SECONDS.sleep(2);

			/*	  //Swipe from Left to Right.
		  driver.swipe(endx, starty, startx, starty, 3000);
		  Thread.sleep(2000);*/
		}catch (Exception e) {
			System.out.println("Errpr in swipingHorizontal()");
		}
		PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);

	}
	public void SwipetopTobottom() throws InterruptedException{
		driver.context("NATIVE_APP");   
		TimeUnit.SECONDS.sleep(2);
		try{
			//Get the size of screen. 
			size = driver.manage().window().getSize(); 
			//System.out.println(size); 
			//Find swipe start and end point from screen's with and height. 
			//Find starty point which is at bottom side of screen. 
			int starty = (int) (size.height * 0.80); 
			//Find endy point which is at top side of screen. 
			int endy = (int) (size.height * 0.20); 
			//Find horizontal point where you wants to swipe. It is in middle of screen width. 
			int startx = size.width / 2; 
			//System.out.println("starty = " + starty + " ,endy = " + endy + " , startx = " + startx); // ye wala h ================
			//Swipe from Bottom to Top. 
			//driver.swipe(startx, starty, startx, endy, 3000); 
			TimeUnit.SECONDS.sleep(3);
			//Swipe from Top to Bottom. 
			driver.swipe(startx, endy, startx, starty, 3000); 
			TimeUnit.SECONDS.sleep(3);
		}catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);

	}


	public boolean isOpen(AppiumDriver<MobileElement> driver, By text) {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, text, 10);
		if (login != null && login.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String printExceptionTrace(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	//=====================================================================================	
	//--------click Event-----------------------------------
	//By = By.xpath("");
	By BackButtonLink= By.xpath("//*[@class='link back']");

	public	By loyaltycardmodulelink= By.xpath("//a[@data-productid='loyalty']"); 
	By singlecodeCard_TClink=By.xpath("//*[@id='flip0']/div/div[1]/a"); 
	By uniqueCodesCard_TClink=By.xpath("//*[@id='flip1']/div/div[1]/a");
	By singlecodewithdailylimitCard_TClink=By.xpath("//*[@id='flip2']/div/div[1]/a");
	By manualcheckinCard_TClink=By.xpath("//*[@id='flip3']/div/div[1]/a");
	By manualcheckinwithdailylimitCard_TClink=By.xpath("//*[@id='flip4']/div/div[1]/a");
	By invalidCard_TClink=By.xpath("//*[@id='flip5']/div/div[1]/a");


	By singlecodeCard_TClink_Close=By.xpath("//*[@id='flip0']/div/div[2]/a"); 
	By uniqueCodesCard_TClink_Close=By.xpath("//*[@id='flip1']/div/div[2]/a");
	By singlecodewithdailylimitCard_TClink_Close=By.xpath("//*[@id='flip2']/div/div[2]/a");
	By manualcheckinCard_TClink_Close=By.xpath("//*[@id='flip3']/div/div[2]/a");
	By manualcheckinwithdailylimitCard_TClink_Close=By.xpath("//*[@id='flip4']/div/div[2]/a");
	By invalidCard_TClink_Close=By.xpath("//*[@id='flip5']/div/div[2]/a");

	//*[@id="flip0"]/div/div[2]/a

	//---------Get Text Event----------------------------
	//public By _gettext=By.xpath("");
	public By header_gettext=By.xpath("//div[@class='navbar']/div[2]/div[2]");  
	public By allcardTitle_gettext=By.xpath("//*[contains(@class,'card-title')]");
	public By allcarddiscription_gettext=By.xpath("//*[contains(@class,'card-discription')]");
	public By allcardtime_gettext=By.xpath("//*[contains(@class,'eventTime')]");


	public By singlecodeCardTitle_gettext=By.xpath("//*[@id='flip0']//*[contains(text(),'Single code')]");
	public By uniqueCodesCardTitle_gettext=By.xpath("//*[@id='flip1']//*[contains(text(),'Unique Codes')]");
	public By singlecodewithdailylimitCardTitle_gettext=By.xpath("//*[@id='flip2']//*[contains(text(),'Single code with daily limit')]");
	public By manualcheckinCardTitle_gettext=By.xpath("//*[@id='flip3']//*[contains(text(),'Manual check in')]");
	public By manualcheckinwithdailylimitCardTitle_gettext=By.xpath("//*[@id='flip4']//*[contains(text(),'Manual check in with daily limit')]");
	public By invalidCardTitle_gettext=By.xpath("//*[@id='flip5']//*[contains(text(),'Invalid')]");


	public By singlecodeCard_TC_gettext=By.xpath("//*[@id='flip0']//*[contains(@class,'terms-text')]");
	public By uniqueCodesCard_TC_gettext=By.xpath("//*[@id='flip1']//*[contains(@class,'terms-text')]");
	public By singlecodewithdailylimitCard_TC_gettext=By.xpath("//*[@id='flip2']//*[contains(@class,'terms-text')]");
	public By manualcheckinCard_TC_gettext=By.xpath("//*[@id='flip3']//*[contains(@class,'terms-text')]");
	public By manualcheckinwithdailylimitCard_TC_gettext=By.xpath("//*[@id='flip4']//*[contains(@class,'terms-text')]");
	public By invalidCard_TC_gettext=By.xpath("//*[@id='flip5']//*[contains(@class,'terms-text')]");


	//---------------------------Methods--------------------------------------------------s
	/*	public void () throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println(" is not present ");
		}
	}*/

	public void BackButton() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, BackButtonLink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Back Button after video link click is not present ");
		}
	}

	public void Loyaltycardmodule() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,loyaltycardmodulelink , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(5);
		}
		else{
			System.out.println("loyalty card module is not present ");
		}
	}
	//-------------------------
	public void Open(By dataPage) {
		WebElement data = ElementWait.waitForOptionalElement(driver, dataPage, 20);
		if (data != null && data.isDisplayed()) {
			data.click();
		} else {
			System.out.println(dataPage + " page is not present in the app or flow is not main Menu");
		}
	}

	public boolean isPresent(By gettext) {
		boolean open = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, gettext, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}
	//-------------------
	public void SinglecodeCard() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, singlecodeCardTitle_gettext, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("single code Card is not present ");
		}
	}

	public void UniqueCodesCard() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,uniqueCodesCardTitle_gettext , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("unique Codes Card is not present ");
		}
	}

	public void SinglecodewithdailylimitCard() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,singlecodewithdailylimitCardTitle_gettext , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("single code with daily limit Card is not present ");
		}
	}

	public void ManualcheckinCard() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,manualcheckinCardTitle_gettext , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("manual check in Card is not present ");
		}
	}

	public void ManualcheckinwithdailylimitCard() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,manualcheckinwithdailylimitCardTitle_gettext , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("manual check in with daily limit Card is not present ");
		}
	}

	public void InvalidCard() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,invalidCardTitle_gettext , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Invalid Card is not present ");
		}
	}

	public void SinglecodeCardTC() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, singlecodeCard_TClink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("singlecodeCard_TC link is not present ");
		}
	}

	public void UniqueCodesCard_TC() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,uniqueCodesCard_TClink , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("uniqueCodesCard_TC link is not present ");
		}
	}

	public void SinglecodewithdailylimitCard_TC() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, singlecodewithdailylimitCard_TClink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("singlecodewithdailylimitCard_TC link is not present ");
		}
	}

	public void ManualcheckinCard_TC() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, manualcheckinCard_TClink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("manualcheckinCard_TC link is not present ");
		}
	}

	public void ManualcheckinwithdailylimitCard_TC() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,manualcheckinwithdailylimitCard_TClink , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("manualcheckinwithdailylimitCard_TC link is not present ");
		}
	}

	public void InvalidCard_TC() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, invalidCard_TClink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("invalidCard_TC link is not present ");
		}
	}

	public void SinglecodeCard_TC_Close() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,singlecodeCard_TClink_Close , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("singlecodeCard_TClink_Close is not present ");
		}
	}

	public void UniqueCodesCard_TC_Close() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,uniqueCodesCard_TClink_Close , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("uniqueCodesCard_TClink_Close is not present ");
		}
	}

	public void SinglecodewithdailylimitCard_TC_Close() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,singlecodewithdailylimitCard_TClink_Close , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("singlecodewithdailylimitCard_TClink_Close is not present ");
		}
	}

	public void ManualcheckinCard_TC_Close() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,manualcheckinCard_TClink_Close , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("manualcheckinCard_TClink_Close is not present ");
		}
	}

	public void ManualcheckinwithdailylimitCard_TC_Close() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,manualcheckinwithdailylimitCard_TClink_Close , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("manualcheckinwithdailylimitCard_TC_Close is not present ");
		}
	}

	public void InvalidCard_TC_Close() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,invalidCard_TClink_Close , 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("invalidCard_TC  Close is not present ");
		}
	}
}
