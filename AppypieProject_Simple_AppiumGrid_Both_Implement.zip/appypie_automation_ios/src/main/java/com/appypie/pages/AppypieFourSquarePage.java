package com.appypie.pages;

import org.apache.log4j.Logger;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieFourSquarePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	public AppypieFourSquarePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

}
