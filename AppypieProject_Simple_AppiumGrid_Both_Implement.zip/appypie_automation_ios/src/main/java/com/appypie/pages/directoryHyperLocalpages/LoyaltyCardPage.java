package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class LoyaltyCardPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	By loyaltyCard= By.xpath("//ul[@class='loyaltyCrad-view']//li[@id='flip']");
	By cardOpen= By.xpath("//div[contains(@onclick,'Appyscript.ServiceLoyaltyCard')]");
	By cardDetailPage= By.id("checkdivtwo");
	
	public LoyaltyCardPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}
	
	public boolean isLoyaltyCardOpen(){
		boolean open = false;
		WebElement page= ElementWait.waitForOptionalElement(driver, loyaltyCard, 20);
		if (page!=null && page.isDisplayed()) {
			open = true;
		} 
		return open;
	}
	
	public void openLoyaltyCard(){
		WebElement card= ElementWait.waitForOptionalElement(driver, cardOpen, 10);
		if(card!=null && card.isDisplayed()){
		  card.click();
		}
	}
	
	public boolean isCardDetailOpen(){
		boolean open = false;
		WebElement detail= ElementWait.waitForOptionalElement(driver, cardDetailPage, 20);
		if (detail!=null && detail.isDisplayed()) {
			open = true;
		} 
		return open;
	}

}
