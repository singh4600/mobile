package com.appypie.pages;

import java.awt.Robot;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypiefacebookPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By facebookPage = By.xpath("//a[@data-productid='facebook']");
	By facebookWebsitePage = By.xpath("//a[@data-productidentifier='facebook_1505400206681_22']");
	By facebookUrl = By.xpath("//a[@class='appypie-list'][@data-page='facebook']");
	By invalidUrl = By.xpath("//a[@class='appypie-list'][@data-page='facebook'][@data-index='1']");
	By fbFeeds = By.className("tweet-user");
	By feeds = By.className("tweet_feeds");
	By loadMore = By.id("loadMoreBTn");
	By viewButton = By.xpath("//a[contains(@onclick,'Appyscript.followFacebook')]");
	By likes = By.xpath("//div[@class='tweet-user-details']//div[@class='tweet']");
	By webview = By.id("text_Tittle");
	By nativebackbtn = By.id("icon1_button");

	By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='Facebook']");

	public AppypiefacebookPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openFacebookPage(String type) {
		WebElement fbOpen = null;
		if (type.equals("feeds"))
			fbOpen = ElementWait.waitForOptionalElement(driver, facebookPage, 20);
		else
			fbOpen = ElementWait.waitForOptionalElement(driver, facebookWebsitePage, 20);
		if (fbOpen != null && fbOpen.isDisplayed())
			fbOpen.click();
		else {
			Logger.error("facebook page is not present in main menu");
		}
	}

	public boolean identifyFacebookOpen() {
		boolean open = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, facebookUrl, 20);
		if (url != null && url.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openfacebookUrl() {
		WebElement url = ElementWait.waitForOptionalElement(driver, facebookUrl, 20);
		url.click();
	}

	public void clickInvalidUrl() throws NullPointerException {
		WebElement url = ElementWait.waitForOptionalElement(driver, invalidUrl, 20);
		if (url != null && url.isDisplayed())
			url.click();
	}

	public boolean checkFacebookFeeds() {
		boolean feed = false;
		WebElement feeds = ElementWait.waitForOptionalElement(driver, fbFeeds, 20);
		if (feeds != null && feeds.isDisplayed()) {
			feed = true;
		} else {
			Logger.error("Feeds are not present in the facebookurl");
		}
		return feed;
	}

	public boolean checkScrollOptionandLoadMore() {
		boolean present = false;
		WebElement btn = ElementWait.waitForOptionalElement(driver, loadMore, 20);
		if (btn != null && btn.isDisplayed()) {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + btn.getLocation().x + ")");
			btn.click();
			present = true;
		} else {
			Logger.info("Load more button is not present in the facebok url");
		}
		return present;
	}
	public int getNumberOfFeeds() {
		List<WebElement> number = ElementWait.waitForAllOptionalElements(driver, feeds, 20);
		return number.size();
	}

	public boolean clickViewButton() throws InterruptedException {
		boolean open = false;
		WebElement view = null;
		WebElement viewbtn = ElementWait.waitForOptionalElement(driver, viewButton, 20);
		if (viewbtn != null && viewbtn.isDisplayed()) {
			viewbtn.click();
			Thread.sleep(1000);
			driver.context("NATIVE_APP");
			Thread.sleep(2000);
			if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				view = ElementWait.waitForOptionalElement(driver, webview, 20);
				if (view != null && view.isDisplayed()) {
					open = true;
					Thread.sleep(3000);
					driver.findElement(nativebackbtn).click();
				} else {
					Logger.error("facebook url is not open in native after clicking on view button from feed");
				}
			} else {
				view = ElementWait.getIosNativeElement(driver, i_nativeView, 10);
				if (view != null) {
					open = true;
					Thread.sleep(3000);
					PageElement.tapOnScreen(driver, 0.05, 0.05);
				} else {
					Logger.error("FaceBook Url is not open in native after clicking on view button from feed in ios");
				}
			}
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.error("view button is not displayed on the facbook feeds");
		}
		return open;
	}

	public String getLikes() throws NullPointerException {
		return ElementWait.waitForOptionalElement(driver, likes, 20).getText();
	}

}
