package com.appypie.pages.newspages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class FeedDetailPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By theme = By.xpath("//li[contains(@onclick,'Appyscript.newsTheme')]");
	By share = By.xpath("//li[contains(@onclick,'Appyscript.newsShare')]");
	By comment = By.xpath("//li[@class='comments-btn'][contains(@onclick,'Appyscript.newsCommentsPage')]");
	By font = By.xpath("//li[contains(@onclick,'Appyscript.newsTextSize')]");
	By bookmark = By.xpath("//li[contains(@onclick,'Appyscript.newsBookmarks')]");
	By postcomment = By.xpath("//div[contains(@class,'swiper-slide-active')]//div[contains(@onclick,'Appyscript.newsCommentsPage')]");
	By back = By.xpath("//ul[@class='news-btns']//li[@class='back-btn']//a[@class='back']");

	By feedText = By.xpath("//div[contains(@class,'swiper-slide-active')]//div[@class='news-detail-page']/h2");
	By feedDate = By.xpath("//div[contains(@class,'swiper-slide-active')]//div[@class='news-detail-page']/h2");

	By feedVideo = By.xpath("//a[contains(@onclick,'openYouTubeVedioNews')]");
	By pdf = By.xpath("//div[contains(@class,'swiper-slide-active')]//a[contains(@onclick,'Appyscript.openPdfReaderFile')]");
	By youtube = By.className("android.view.ViewGroup");

	By nativePdfHeader = By.id("text_Tittle");
	By nativebackbtn = By.id("icon1_button");
	public By native1backbtn = By.id("back");
	By i_pdf = By.xpath("//div[contains(@class,'swiper-slide-active')]//a[contains(@onclick,'Appyscript.newsOpenPDF')]");
	

	public FeedDetailPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isFeedDetailOpen() {
		boolean open = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, bookmark, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickTheme() {
		WebElement option = ElementWait.waitForOptionalElement(driver, theme, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public String getThemeStatus() {
		String status = "";
		WebElement element_theme = ElementWait.waitForOptionalElement(driver, theme, 10);
		if (element_theme != null && element_theme.isDisplayed()) {
			status = element_theme.getAttribute("class");
		}
		return status;
	}

	public void clickShare() {
		WebElement option = ElementWait.waitForOptionalElement(driver, share, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickcommentOnHeader() {
		WebElement option = ElementWait.waitForOptionalElement(driver, comment, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickFontBtn() {
		WebElement option = ElementWait.waitForOptionalElement(driver, font, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void clickBookMark() {
		WebElement option = ElementWait.waitForOptionalElement(driver, bookmark, 10);
		if (option != null && option.isDisplayed()) {
			if (!option.getAttribute("class").equals("bookmark-btn on"))
				option.click();
			else {
				Logger.info("feed is already bookmarked");
			}
		}
	}
	
	public void removeBookMark() {
		WebElement option = ElementWait.waitForOptionalElement(driver, bookmark, 10);
		if (option != null && option.isDisplayed()) {
			if (option.getAttribute("class").equals("bookmark-btn on"))
				option.click();
			else {
				Logger.info("feed is not bookmarked");
			}
		}
	}

	public void clickPostBtn() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, postcomment, 10);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

	public void clickBackBtn() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, back, 10);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

	public String getFeedText() {
		String text = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, feedText, 10);
		if (element != null && element.isDisplayed()) {
			text = element.getText();
		}
		return text;
	}

	public String getFeedDate() {
		String date = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, feedDate, 10);
		if (element != null && element.isDisplayed()) {
			date = element.getText();
		}
		return date;
	}

	public void swipeFeedPage() throws InterruptedException {
		driver.context("NATIVE_APP");
		TouchAction tapCoordinates = new TouchAction(driver);
		Dimension size = driver.manage().window().getSize();
		int scrollstartX = (int) (size.width * .80);
		int scrollendX = (int) (size.height * .30);
		int scrollY = (int) (size.height * .97);
		driver.swipe(scrollstartX, scrollY, scrollendX, scrollY, 40000);
		Thread.sleep(1000);
		PageElement.changeContextToWebView(driver);
	}

	
	
	public void openVideo() {
		WebElement video = ElementWait.waitForOptionalElement(driver, feedVideo, 10);
		if (video != null && video.isDisplayed()) {
			video.click();
		}
	}

	public void openPDF() throws InterruptedException {
		WebElement file = null;
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase()))
			file = ElementWait.waitForOptionalElement(driver, pdf, 10);
		else
			file = ElementWait.waitForOptionalElement(driver, i_pdf, 10);
		if (file != null && file.isDisplayed()) {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + file.getLocation().x + ")");
			file.click();
		}
	}

	public boolean isPdfOrVideoOpen(String type) throws InterruptedException {
		boolean open = false;
		WebElement element_home;
		driver.context("NATIVE_APP");
		if (type.equals("pdf"))
			element_home = ElementWait.waitForOptionalElement(driver, nativePdfHeader, 20);
		else
			element_home = ElementWait.waitForOptionalElement(driver, youtube, 20);
		if (element_home != null && element_home.isDisplayed()) {
			open = true;
			Thread.sleep(3000);
		} else {
			Logger.error(type+" from news feeds is not open");
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
	
	public void clickNativeBack(By link){
		driver.context("NATIVE_APP");
		driver.findElement(link).click();
		PageElement.changeContextToWebView(driver);
	}
}
