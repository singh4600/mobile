package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EnquiryFormPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By name = By.id("rsName");
	By phone = By.id("rsPhone");
	By address = By.id("rsAddress");
	By budget = By.id("rsBudget");
	By description = By.id("rsRequirement");

	By uploadImg = By.xpath("//span[contains(@onclick,'addMoreClick2')]");
	By submitEnquiry = By.xpath("//button[contains(@onclick,'Appyscript.submitRequestFormCustom')]");

	public EnquiryFormPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isEnquiryFormOpen() {
		boolean open = false;
		WebElement form = ElementWait.waitForOptionalElement(driver, name, 20);
		if (form != null) {
			open = true;
		} else {
			Logger.info("Enquiry form is not open");
		}
		return open;
	}

	public void submitForm() {
		driver.findElement(submitEnquiry).click();
	}

	public void clickAddMore() {
		driver.findElement(uploadImg).click();
	}

	public void enterName() {
		PageElement.sendKey(driver, name, "pawan");
	}

	public void enterBlankName() {
		PageElement.sendKey(driver, name, "");
	}

	public void enterPhone() {
		PageElement.sendKey(driver, phone, "9654586");
	}

	public void enterAddr() {
		PageElement.sendKey(driver, address, "i/5 4th Avenue");
	}

	public void enterBlankAddr() {
		PageElement.sendKey(driver, address, "");
	}

	public void enterBudget() {
		PageElement.sendKey(driver, budget, "Too High no need to worry");
	}

	public void enterDescription() {
		PageElement.sendKey(driver, description, "Automation Testing Purpose");
	}
}
