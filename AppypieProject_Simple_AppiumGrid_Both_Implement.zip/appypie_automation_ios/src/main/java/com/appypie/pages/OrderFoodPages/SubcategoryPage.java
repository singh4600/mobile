package com.appypie.pages.OrderFoodPages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class SubcategoryPage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");
	
	public By sortBylink=By.xpath("//*[contains(@id,'searchpopup')]");

	
	public By Subcategoryproductlink= By.xpath("//*[contains(@class,'productList')]/li[2]//img[1]"); // Subcategory  
	public By likeBtn=By.xpath("//*[contains(@onclick,'Appyscript.foodAddRemoveProductWishlist')]");
	public By starBtn=By.xpath("//*[contains(@onclick,'Appyscript.foodProductReviewList')]");
	public By shareBtn=By.xpath("//*[contains(@onclick,'foodShareProduct')]");
	
	
	public By AddToCartlink= By.xpath("//a[contains(@onclick,'Appyscript.foodAddToCartProduct')]"); // Add to cart button
	public By shortbylink= By.id("searchpopup");
	public By SortByradiobtn= By.name("Sort By");
	public By LowtoHighradobtn= By.xpath("//*[@index='1']");
	public By i_LowtoHighradobtn= By.xpath("//*[@id='searchpopup']/option[2]");
	public By HightoLowradiobtnlink= By.xpath("//*[@index='1']");
	public By i_HightoLowradiobtnlink= By.xpath("//*[@id='searchpopup']/option[3]");
	
	
	
	
	//---------Get Text Event----------------------------
	//public By _gettext=By.xpath("");
	public By shortBylist_gettext=By.xpath("//*[contains(@id,'searchpopup')]/option");
	public By shortBylink=By.xpath("//*[contains(@id,'searchpopup')]");
	
	public By subcategoryitems_gettext=By.xpath("//*[contains(@class,'productList')]//h1"); // verify subcategory item name
	public By subcategoryitemsprice_gettext=By.xpath("//*[contains(@class,'productList')]//*[contains(@class,'product_price')]");
	//--------------------------------
	public SubcategoryPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}
	

	
/*	public void Subcategory(){
		WebElement openSubcategory= ElementWait.waitForOptionalElement(driver, subcategorylink, 20);
		if(openSubcategory!=null && openSubcategory.isDisplayed()){
			openSubcategory.click();
		}
		else{
			System.out.println("Subcategory link is not present ");
		}
	}*/

	public void AddToCart(){
		WebElement openAddToCartclick= ElementWait.waitForOptionalElement(driver, AddToCartlink, 20);
		if(openAddToCartclick!=null && openAddToCartclick.isDisplayed())
			openAddToCartclick.click();
		else{
			System.out.println("AddToCartlink is not present");
		}
	}
	
	public void Shortby() throws InterruptedException{
		WebElement opn= ElementWait.waitForOptionalElement(driver, shortbylink, 20);
		if(opn!=null && opn.isDisplayed())
			opn.click();
		else{
			System.out.println("shortby link is not present");
		}
		TimeUnit.SECONDS.sleep(5);
		driver.context("NATIVE_APP");
		driver.findElement(LowtoHighradobtn).click();
		
		PageElement.changeContextToWebView(driver); 
		
		WebElement open01= ElementWait.waitForOptionalElement(driver, shortbylink, 20);
		if(open01!=null && open01.isDisplayed())
			open01.click();
		else{
			System.out.println("shortby link is not present");
		}
		TimeUnit.SECONDS.sleep(5);
		driver.context("NATIVE_APP");
		
		driver.findElement(SortByradiobtn).click();
	
		
	PageElement.changeContextToWebView(driver); 
		
		WebElement open02= ElementWait.waitForOptionalElement(driver, shortbylink, 20);
		if(open02!=null && open02.isDisplayed())
			open02.click();
		else{
			System.out.println("shortby link is not present");
		}
		TimeUnit.SECONDS.sleep(5);
		driver.context("NATIVE_APP");
		
		driver.findElement(HightoLowradiobtnlink).click();
			
		PageElement.changeContextToWebView(driver);
	
		
		
	}
	
	
}
