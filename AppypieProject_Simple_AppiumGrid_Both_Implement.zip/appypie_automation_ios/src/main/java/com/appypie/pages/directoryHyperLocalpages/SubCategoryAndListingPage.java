package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SubCategoryAndListingPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By subcategory = By.xpath("//ul[@id='subPageListing']//li[@data-index='0']");
	By searchD = By.xpath("//div[@id='search-box']");
	By categorylist = By.xpath("//li[@id='serviceinnerSubHeaderPage']//img[@data-listid='2907484']");
	By rating = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@class='hyper-addons']//a[@id='Ratng2907484']");
	By coupon = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@class='hyper-addons']//a[contains(@onclick,'openCoupanPage')]");
	By loyality= By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@class='hyper-addons']//a[contains(@onclick,'openLoyaltyPage')]");
	By share = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@class='hyper-addons']//a[@class='icon-share-1'][contains(@header,'alpha 123')]");
	By locationonList = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@class='hyper-addons']//a[@class='icon-location-2'][contains(@headerval,'alpha 123')]");
	By checkIn = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@class='hyper-addons']//a[@class='icon-ok-4'][contains(@headercheckin,'alpha 123')]");
	By sharepopUp = By.className("android.widget.TextView");
	//By googleMap= By.xpath("//android.view.View[@content-desc='Google Map']");
	By googleMap=By.className("android.widget.FrameLayout");
	
	//********* Locators for hyperlocal*********************
	By hl_catlist = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@data-pagedatatype='sublistListHyperLocal']//span[text()='four 44']");
	By hl_rating = By.xpath("//span[@class='hyper-addons']//a[@id='Ratng5937a19bbc1f4659b98b4567']");
	By hl_share = By.xpath("//span[@class='hyper-addons']//a[@class='icon-share-1'][contains(@header,'four 44')]");
	By hl_call=By.xpath("//a[contains(@onclick,'Appyscript.dialogListHyperForCall')][@data-call='8877445566']");
	By hl_location=By.xpath("//a[contains(@onclick,'Appyscript.showServicePageMapNew')][contains(@onclick,'four 44')]");
	
	By i_hl_call=By.xpath("//a[contains(@onclick,'Appyscript.MakeCall')]");
	By i_call_native=By.xpath("//XCUIElementTypeStaticText[@name='Call']");
	By i_cancel=By.xpath("//XCUIElementTypeButton[@name='Cancel']");
	
	

	public SubCategoryAndListingPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isSubCategoryPageOpen() {
		boolean open = false;
		WebElement subCat = ElementWait.waitForOptionalElement(driver, subcategory, 20);
		if (subCat != null && subCat.isDisplayed()) {
			open = true;
		} else {
			Logger.info("SubCategory is not exist in the category  or page is not open");
		}
		return open;
	}

	public boolean isSubCategoryPageOpenDirectory() {
		boolean open = false;
		WebElement subCat = ElementWait.waitForOptionalElement(driver, searchD, 20);
		if (subCat != null && subCat.isDisplayed()) {
			open = true;
		} else {
			Logger.info("SubCategory is not exist in the category  or page is not open");
		}
		return open;
	}
	public boolean isListingPresentinCategory(String page) {
		boolean present = false;
		WebElement list;
		if (page.contains("dir"))
			list = ElementWait.waitForOptionalElement(driver, categorylist, 20);
		else
			list = ElementWait.waitForOptionalElement(driver, hl_catlist, 20);
		if (list != null && list.isDisplayed()) {
			present = true;
		} else {
			Logger.error("Listing is not present in the category ");
		}
		return present;
	}

	public void openListing(String page) {
		if (page.contains("dir"))
			driver.findElement(categorylist).click();
		else
			driver.findElement(hl_catlist).click();
	}

	public void openRating(String page) {
		WebElement rateIcon;
		if (page.contains("dir"))
			rateIcon = ElementWait.waitForOptionalElement(driver, rating, 20);
		else
			rateIcon = ElementWait.waitForOptionalElement(driver, hl_rating, 20);
		if (rateIcon != null && rateIcon.isDisplayed()) {
			rateIcon.click();
		} else {
			Logger.error("Rating icon is not present on listing");
		}
	}

	public void openShare(String page) {
		WebElement shareIcon;
		if (page.contains("dir"))
			shareIcon = ElementWait.waitForOptionalElement(driver, share, 20);
		else
			shareIcon = ElementWait.waitForOptionalElement(driver, hl_share, 20);
		if (shareIcon != null && shareIcon.isDisplayed()) {
			shareIcon.click();
		} else {
			Logger.error("Share icon is not present on listing");
		}
	}

	public boolean isSharePopUpOpen() throws InterruptedException {
		boolean sbtn = false;
		driver.context("NATIVE_APP");
		WebElement shareoption = ElementWait.waitForOptionalElement(driver, sharepopUp, 10);
		if (shareoption != null && shareoption.isDisplayed()) {
			driver.navigate().back();
			Thread.sleep(500);
			sbtn = true;
			//driver.context("WEBVIEW_com.snappy.appypie");
			PageElement.changeContextToWebView(driver);
		}
		return sbtn;
	}

	public void openCoupon() {
		WebElement couponIcon = ElementWait.waitForOptionalElement(driver, coupon, 20);
		if (couponIcon != null && couponIcon.isDisplayed()) {
			couponIcon.click();
		} else {
			Logger.error("Coupon icon is not present on directory listing");
		}
	}
	
	public void openLoyaltyCard() {
		WebElement loyalityCard = ElementWait.waitForOptionalElement(driver, loyality, 20);
		if (loyalityCard != null && loyalityCard.isDisplayed()) {
			loyalityCard.click();
		} else {
			Logger.error("Loyality icon is not present on directory listing");
		}
	}

	public void openLocation(String page) {
		WebElement locationIcon;
		if (page.contains("dir"))
			locationIcon = ElementWait.waitForOptionalElement(driver, locationonList, 20);
		else
			locationIcon = ElementWait.waitForOptionalElement(driver, hl_location, 20);
		if (locationIcon != null && locationIcon.isDisplayed()) {
			locationIcon.click();
		} else {
			Logger.error("Location icon is not present on directory listing");
		}
	}
	
	public boolean isGoogleMapOpen(String i_text) throws InterruptedException {
		boolean open = false;
		WebElement map=null;
		driver.context("NATIVE_APP");
		Thread.sleep(3000);
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
			map = ElementWait.waitForOptionalElement(driver, googleMap, 10);
		if (map != null && map.isDisplayed()) {
			driver.navigate().back();
			Thread.sleep(500);
			open = true;
		}
		}else{
			By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='" + i_text + "']");
			map = ElementWait.waitForOptionalElement(driver, i_nativeView, 30);
			if (map != null) {
				open = true;
				Thread.sleep(3000);
				PageElement.tapOnScreen(driver, 0.05, 0.05);
			} else {
				Logger.info("google map  is not open in ios native");
			}
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}

	public void openCheckIn() {
		WebElement checkInIcon = ElementWait.waitForOptionalElement(driver, checkIn, 20);
		if (checkInIcon != null && checkInIcon.isDisplayed()) {
			checkInIcon.click();
		} else {
			Logger.error("CheckIn icon is not present on directory listing");
		}
	}
	
	public void openCallinHyperLocal() {
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
			WebElement call = ElementWait.waitForOptionalElement(driver, hl_call, 20);
			if (call != null && call.isDisplayed()) {
				call.click();
			} else {
				Logger.error("Call icon is not present on directory listing");
			}
		} else {
          WebElement call= ElementWait.waitForOptionalElement(driver, i_hl_call, 20);
          if(call!=null){
        	  call.click();
          }
		}
	}
	
	public boolean isCallOpeninIOS() throws InterruptedException{
		boolean open= false;
		driver.context("NATIVE_APP");
		WebElement call = ElementWait.waitForOptionalElement(driver, i_call_native, 20);
		if(call!=null){
			open=true;
			Thread.sleep(2000);
			driver.findElement(i_cancel).click();
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
}
