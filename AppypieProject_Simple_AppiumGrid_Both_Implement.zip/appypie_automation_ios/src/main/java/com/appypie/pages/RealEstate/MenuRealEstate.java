package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MenuRealEstate {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	
	public By mainMenulink= By.xpath("//*[contains(text(),'Main Menu')]");
	public By favouriteslink= By.xpath("//*[contains(text(),'Favourites')]");
	public By addPropertylink= By.xpath("//*[contains(text(),'Add Property')]");
	public By updatePropertylink= By.xpath("//*[contains(text(),'Update Property')]");
		
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By menuList_gettext=By.xpath("//*[contains(@class,'realestate-navs arial')]/ul/li");
	public By login_gettext=By.xpath("//*[text() =' Login/Signup']");
	
	public By favProperityName_gettext=By.xpath("");
	public By favProperityDetails_gettext=By.xpath("//*[contains(@class,'pages ')]/div[2]//ul//div[2]//*[contains(@class,'hyper-catNamebox')]");
	

	public MenuRealEstate(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}