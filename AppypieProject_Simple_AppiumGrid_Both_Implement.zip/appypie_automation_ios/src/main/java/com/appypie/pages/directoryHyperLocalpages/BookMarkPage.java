package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BookMarkPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By bookmarkedList = By.xpath("//span[@data-heading='Bookmarks']//span[text()='alpha 123']");
	By mapOnListing = By.id("googleMap2907484");

	// ********* Locators for hyperlocal*********************
	By bookMarkIcon = By.id("bookmark");
	By hl_bookmarkedList = By.xpath("//li[@id='serviceinnerSubHeaderPage']//span[@data-pagedatatype='pageDataListHyperLocal']//span[text()='four 44']");
	By hl_mapOnListing = By.id("googleMaphyperLocal5937a19bbc1f4659b98b4567");
	By delBookMark=  By.xpath("//span[contains(@class,'modal-button')][text()='Yes']");

	public BookMarkPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isBookMarkedListExist(String page) throws InterruptedException {
		boolean present = false;
		WebElement list;
		Thread.sleep(1000);
		if (page.equals("dir"))
			list = ElementWait.waitForOptionalElement(driver, bookmarkedList, 20);
		else
			list = ElementWait.waitForOptionalElement(driver, hl_bookmarkedList, 20);
		if (list != null && list.isDisplayed()) {
			present = true;
		} else {
			Logger.info("Bookmarked list is not present while opening bookmark from main menu");
		}
		return present;
	}

	public void openBookMarkList(String page) {
		if (page.equals("dir"))
			driver.findElement(bookmarkedList).click();
		else
			driver.findElement(hl_bookmarkedList).click();
	}

	public boolean islistingOpenFromBookMarkPage(String page) {
		boolean open = false;
		WebElement listPage;
		if (page.equals("dir"))
			listPage = ElementWait.waitForOptionalElement(driver, mapOnListing, 20);
		else
			listPage = ElementWait.waitForOptionalElement(driver, hl_mapOnListing, 20);
		if (listPage != null && listPage.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Directory listing page is not open upon clicking on listing from bookmark page");
		}
		return open;
	}

	public void clickBookMarkIcon() {
		WebElement icon = ElementWait.waitForOptionalElement(driver, bookMarkIcon, 5);
		if (icon != null && icon.isDisplayed()) {
			icon.click();
		} else {
			Logger.info("BookMark icon is not visible on listing");
		}
	}
	
	public void clickDeleteBookMark() {
		PageElement.locateClickableElement(driver, delBookMark);
	}
}
