package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieTextPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By textFolder = By.xpath("//a[@data-productidentifier='folder_1500360788866_71'][@data-productid='folder']");
	By textPage = By.xpath("//a[@data-productidentifier='textpage_1490789476588_23--folder_1500360788866_71']");
	By revtextPage = By.xpath("//a[@data-productidentifier='textpage_1500361722384_23--folder_1500360788866_71']");

	By pageheading = By.xpath("//div[@class='service-details']/h2");
	By img = By.xpath("//img[contains(@onclick,'Appyscript.openGallary')]");
	By youtube = By.xpath("//div[contains(@onclick,'Appyscript.playYoutubeWatch')]");
	By share = By.xpath("//a[contains(@onclick,'Appyscript.textShareProduct')]");
	By email = By.xpath("//a[contains(@onclick,'openEmail')]");
	By deepLink = By.xpath("//a[contains(@href,'javascript:opendeeplinkpage')]");

	By imgText = By.xpath("//div[contains(@class,'textPara arial')]/div/strong/u/i");
	By videoText = By.xpath("//div[contains(@class,'textPara arial')]/p[3]/i");

	By revList = By.xpath("//div[contains(@onclick,'Appyscript.playYoutubeWatch')]/following-sibling::center/img");
	By nativeImg = By.id("img");
	By progress = By.id("progressBar");
	By nativeTitle = By.id("text_Tittle");
	
	By mailbox= By.id("com.google.android.gm:id/from_account_name");

	public AppypieTextPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openTextFolder() {
		WebElement folder = ElementWait.waitForOptionalElement(driver, textFolder, 20);
		if (folder != null && folder.isDisplayed()) {
			folder.click();
		} else {
			Logger.info("Text folder not exist in main menu");
		}
	}
	
	public boolean isTextFolderOpen() {
		boolean open = false;
		WebElement folder = ElementWait.waitForOptionalElement(driver, textPage, 20);
		if (folder != null && folder.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openTextPage(String type) throws NullPointerException {
		By Pagetype = null;
		if (type.equals("reverse")) {
			Pagetype = revtextPage;
		} else {
			Pagetype = textPage;
		}
		WebElement page = ElementWait.waitForOptionalElement(driver, Pagetype, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		} else {
			Logger.info("Text page not exist in Text folder");
		}
	}

	public boolean isTextPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, pageheading, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String getPageHeading(String type) {
		String text = "";
		WebElement heading = null;
		if (type.equals("img")) {
			heading = ElementWait.waitForOptionalElement(driver, imgText, 20);
		} else if (type.equals("video")) {
			heading = ElementWait.waitForOptionalElement(driver, videoText, 20);
		} else {
			heading = ElementWait.waitForOptionalElement(driver, pageheading, 20);
		}
		if (heading != null && heading.isDisplayed()) {
			text = heading.getText();
		}
		return text;
	}

	public void openShare() {
		WebElement option = ElementWait.waitForOptionalElement(driver, share, 20);
		if (option != null && option.isDisplayed()) {
			option.click();
		} else {
			Logger.info("Share Option is not present");
		}
	}

	public void openEmail() {
		WebElement option_mail = ElementWait.waitForOptionalElement(driver, email, 20);
		if (option_mail != null && option_mail.isDisplayed()) {
			option_mail.click();
		} else {
			Logger.info("Email Option is not present");
		}
	}

	public void openDeepLink() {
		WebElement option_link = ElementWait.waitForOptionalElement(driver, deepLink, 20);
		if (option_link != null && option_link.isDisplayed()) {
			option_link.click();
		} else {
			Logger.info("Deeplink Option is not present");
		}
	}

	public void openYouTube() {
		WebElement video = ElementWait.waitForOptionalElement(driver, youtube, 20);
		if (video != null && video.isDisplayed()) {
			video.click();
		} else {
			Logger.info("Youtube video not exist");
		}
	}

	public void openImage() {
		WebElement image = ElementWait.waitForOptionalElement(driver, img, 20);
		if (image != null && image.isDisplayed()) {
			image.click();
		} else {
			Logger.info("Image in text page is  not exist");
		}
	}

	public boolean isListInRevOrder() {
		boolean order = false;
		WebElement list = ElementWait.waitForOptionalElement(driver, revList, 20);
		if (list != null && list.isDisplayed()) {
			order = true;
		}
		return order;
	}

	public boolean isImgOpenInNative() throws InterruptedException {
		boolean open = false;
		driver.context("NATIVE_APP");
		WebElement img = ElementWait.waitForOptionalElement(driver, nativeImg, 20);
		if (img != null && img.isDisplayed()) {
			open = true;
			driver.navigate().back();
			Thread.sleep(500);
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
	
	public boolean isMailBoxOpen() throws InterruptedException {
		boolean open = false;
		driver.context("NATIVE_APP");
		WebElement email = ElementWait.waitForOptionalElement(driver, mailbox, 20);
		if (email != null && email.isDisplayed()) {
			open = true;
			try {
                driver.hideKeyboard();
                } catch (Exception e) {
                }
			driver.navigate().back();
			Thread.sleep(500);
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
}
