package com.appypie.pages;



import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;


import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class AppypieQuizPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By quizfolder = By.xpath("//a[@data-productidentifier='folder_1493904815136_71'][@data-productid='folder']");
	By quizpage = By.xpath("//a[@data-productid='quiz']");
	By invalidquizpage = By.xpath("//a[@data-productidentifier='quiz_1493723093572_46--folder_1493904815136_71'][@data-productid='quiz']");
	By quizpagewithlogin = By.xpath(
			"//a[@data-productidentifier='quiz_1493965084765_46--folder_1493904815136_71'][@data-productid='quiz']");
	By welcomeScren = By.xpath("//div[@class='quiz-welcome']//div[@class='conditionTag']");
	By startquizBtn = By.xpath("//a[@onclick='startQuizMain(this)']");
	By question = By.xpath("//div[@id='form-0']//div[@class='quiz-area']//p[contains(@class,'question')]");
	By questioncounter = By.xpath("//*[@id='quiz_timer']/span[1]");
	By timer = By.xpath("//div[@id='quiz_timer']//span[@class='timeMoveRight']/span[2]");
	By submitBtn = By.xpath("//a[contains(@class,'quiz_submit')]");
	By prevBtn = By.xpath("//a[contains(@class,'quiz_previous')]");
	By nextBtn = By.xpath("//a[contains(@class,'quiz_next')]");
	By finishBtn = By.xpath("//a[contains(@class,'quiz_finish')]");
	By firstOption = By.xpath("//div[@class='quiz-area']/ul/li[1]");
	By secondOption = By.xpath("//div[@class='quiz-area']/ul/li[2]");
	By thirdOption = By.xpath("//div[@class='quiz-area']/ul/li[3]");
	By fourthOption = By.xpath("//div[@class='quiz-area']/ul/li[4]");
	By image = By.xpath("//div[@class='question-media']/img");
	By audio = By.xpath("//div[@class='question-media']//audio[contains(@controlslist,'nodownload')]");
	By video = By.xpath("//div[@id='form-2']/div/div//a[contains(@onclick,'Appyscript.playYoutubeWatch')]");
	By warning = By.xpath("//div[@class='modal-text']");
	By ok = By.xpath("//span[contains(@class,'modal-button')]");
	By resultpage = By.xpath("//div[@class='quiz-end-content']/h1");
	By quizend = By.xpath("//a[@rel='quiz-end']");
	By thankPage = By.xpath("//h2[text()='Thanks']");
	By shareBtn = By.xpath("//a[@class='share icon-share-1']");
	By sharepopUp = By.className("android.widget.TextView");

	By youtube = By.id("text_Tittle");
	By audioplayer = By.id("text_Tittle");

	By noData = By.xpath("//div[@class='msg-container']//span[@class='icon appyicon-no-data']");
	
	

	public AppypieQuizPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openQuizFolder() {
		WebElement folder = ElementWait.waitForOptionalElement(driver, quizfolder, 20);
		if (folder != null && folder.isDisplayed()) {
			folder.click();
		} else {
			Logger.info("Quiz folder not exist in main menu");
		}
	}

	public void openQuizPage(String type) throws NullPointerException {
		By quiztype = null;
		if (type.equals("invalid"))
			quiztype = invalidquizpage;
		else if (type.equals("withlogin"))
			quiztype = quizpagewithlogin;
		else
			quiztype = quizpage;
		WebElement page = ElementWait.waitForOptionalElement(driver, quiztype, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		} else {
			Logger.info("Quiz page not exist in main menu");
		}
	}

	public boolean viewWelcomeScreen() throws NullPointerException {
		boolean open = false;
		String text = ElementWait.waitForOptionalElement(driver, welcomeScren, 20).getText();
		if (text.toUpperCase().contains("welcome".toUpperCase()))
			open = true;
		else {
			Logger.info("Welcome screen is not displayed after opening the quiz page");
		}
		return open;
	}

	public void clickStartQuizButton() {
		WebElement start = ElementWait.waitForOptionalElement(driver, startquizBtn, 20);
		if (start != null && start.isDisplayed())
			start.click();
		else
			Logger.info(" StartQuiz button is not displayed on welcome screen");
	}

	public String checkQuestionsVisibility() {
		return ElementWait.waitForOptionalElement(driver, question, 20).getText();
	}

	public String getQuestionCounterAndTimer(String type) throws InterruptedException {
		String counter = "";
		int count = 0;
		int maxTries = 4;
		WebElement qc = null;
		while (true) {
			try {
				if (type.equals("timer"))
					qc = ElementWait.waitForOptionalElement(driver, timer, 10);
				else
					qc = ElementWait.waitForOptionalElement(driver, questioncounter, 10);
				if (qc != null && qc.isDisplayed()) {
					counter = qc.getText();
				}
				
				return counter;
			} catch (WebDriverException e) {
				Thread.sleep(500);
				Logger.info("Stale element occurs in getiing the question counter, retry value: " + count + " :");
				if (++count == maxTries) {
					throw e;
				}
			}	
		}
	}

	public void swipeScreen() throws InterruptedException {
		// By
		// select=By.xpath("//div[@id='form-0']//div[@class='quiz-area']/ul/li[1]");
		// WebElement start= ElementWait.waitForOptionalElement(driver,
		// select,20);
		// Map<String, Object> params = new HashMap<String, Object>();
		// params.put("direction", "left");
		// params.put("element", ((RemoteWebElement) start).getId());
		// driver.executeScript("mobile: scroll", params);

		driver.context("NATIVE_APP");
		TouchAction tAction = new TouchAction(driver);
		tAction.press(128, 943).moveTo(128, 255);
		driver.performTouchAction(tAction);
		Thread.sleep(2000);
		// driver.context("WEBVIEW_com.snappy.appypie");
		PageElement.changeContextToWebView(driver);
	}

	public void tapNextButton() throws NullPointerException, InterruptedException {
		Thread.sleep(1000);
		ElementWait.waitForOptionalElement(driver, nextBtn, 20).click();
		
	}

	public void tapPrevButton() throws NullPointerException, InterruptedException {
		Thread.sleep(1000);
		ElementWait.waitForOptionalElement(driver, prevBtn, 20).click();
	}

	public void tapSubmitButton() throws NullPointerException, InterruptedException {
		Thread.sleep(1000);
		ElementWait.waitForOptionalElement(driver, submitBtn, 20).click();
	}

	public void tapfinishButton() throws NullPointerException, InterruptedException {
		Thread.sleep(1000);
		ElementWait.waitForOptionalElement(driver, finishBtn, 20).click();
	}

	public String getClickOptions(String option, String question) throws InterruptedException {
		String value = "";
		int count = 0;
		int maxTries = 3;
		while (true) {
			try {
				By select = By.xpath("//div[@id='form-" + question + "']//div[@class='quiz-area']/ul/li["+option+"]");
				WebElement check = ElementWait.waitForOptionalElement(driver, select, 20);
				if (check != null && check.isDisplayed()) {
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + check.getLocation().x + ")");
					
					check.click();
					value = check.getAttribute("class");
				}
				return value;
			} catch (StaleElementReferenceException e) {
				Thread.sleep(500);
				Logger.info("Stale element occurs while clicking the options, retry value: " + count + " :");
				if (++count == maxTries) {
					throw e;
				}
			}
		}
	}

	public String checkResultPageOpen() {
		return ElementWait.waitForOptionalElement(driver, resultpage, 10).getText();
	}

	public String getWarning() {
		String text = "";
		WebElement element_warning = ElementWait.waitForOptionalElement(driver, warning, 5);
		if (element_warning != null && element_warning.isDisplayed()) {
			text = element_warning.getText();
			PageElement.locateClickableElement(driver, ok);
		} else {
			Logger.info("Warning is not displayed after clicking on submit button");
		}
		return text;
	}

	public int getCountfromQuestionStatus(String type) {
		String icon = null;
		if (type.equals("skip"))
			icon = "icon-block-4";
		else if (type.equals("notattempt"))
			icon = "icon-back-in-time";
		else if (type.equals("correct"))
			icon = "icon-ok-4";
		else
			icon = "icon-cancel";
		By status = By.xpath("*[@class='question-status']//*[@class='"+icon+"']");
		//
		List<WebElement> answers = ElementWait.waitForAllOptionalElements(driver, status, 20);
		return answers.size();
	}

	public int getCountFromQuizContent(String number) {
		By status = By.xpath("//div[@class='quiz-end-content']/ul/li[" + number + "]");
		String answer = ElementWait.waitForOptionalElement(driver, status, 20).getText();
		if (number.equals("5"))
			return Integer.parseInt(answer.split(" ")[3]);
		else
			return Integer.parseInt(answer.split(" ")[2]);

	}

	public boolean clickQuizSubmitOnResultPage() throws InterruptedException {
		boolean thanks = false;
		WebElement submitQuiz = ElementWait.waitForOptionalElement(driver, quizend, 5);
		if (submitQuiz != null && submitQuiz.isDisplayed()) {
			submitQuiz.click();
			Thread.sleep(5000);
			WebElement element_thnakPage = ElementWait.waitForOptionalElement(driver, thankPage, 20);
			if (element_thnakPage != null && element_thnakPage.isDisplayed()) {
				thanks = true;
			} else {
				Logger.info("thanks Page is not displayed upon clicking submit button  on quiz end");
			}
		} else {
			Logger.info("Submit button is not displayed on quiz end");
		}
		return thanks;
	}

	public boolean clickShareButton() throws InterruptedException {
		boolean open = false;
		WebElement share = ElementWait.waitForOptionalElement(driver, shareBtn, 10);
		if (share != null && share.isDisplayed()) {
			share.click();
			Thread.sleep(2000);
			driver.context("NATIVE_APP");
			WebElement shareoption = ElementWait.waitForOptionalElement(driver, sharepopUp, 10);
			if (shareoption != null && shareoption.isDisplayed()) {
				driver.navigate().back();
				Thread.sleep(500);
				open = true;
			} else {
				Logger.error("Share pop up is not open upon clicking share btn on quiz result page");
			}
			// driver.context("WEBVIEW_com.snappy.appypie");
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.info("Share Button is not visible on Quiz Result Screen");
		}
		return open;
	}

	public boolean imageExist() throws InterruptedException {
		boolean present = false;
		Thread.sleep(1000);
		WebElement element_img = ElementWait.waitForOptionalElement(driver, image, 20);
		if (element_img != null && element_img.isDisplayed()) {
			present = true;
		}
		return present;
	}

	public void clickAudioVideo(String type) {
		WebElement element_audio = null;
		if (type.equals("audio")) {
			element_audio = ElementWait.waitForOptionalElement(driver, audio, 20);
		} else {
			element_audio = ElementWait.waitForOptionalElement(driver, video, 20);
		}
		if (element_audio != null && element_audio.isDisplayed())
			element_audio.click();
	}

	public boolean isAudioVideoExist(String type,String name) throws InterruptedException {
		boolean open = false;
		WebElement nativeelement = null;
		driver.context("NATIVE_APP");
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
			if (type.equals("audio")) {
				System.out.println("user enter the loding section");
				Boolean message = false;
				message = driver.findElements(By.id("android:id/progress")).size() != 0;
				if (message) {
					while (driver.findElements(By.id("android:id/progress")).size() != 0) {
					}
					Thread.sleep(2000);
					System.out.println("user out the loding section");
				} else {
					System.out.println("Syncing Content loding box is not present");
				}
				nativeelement = ElementWait.waitForOptionalElement(driver, audioplayer, 10);
			} else {
				nativeelement = ElementWait.waitForOptionalElement(driver, youtube, 10);
			}
			if (nativeelement != null && nativeelement.isDisplayed()) {
				driver.navigate().back();
				Thread.sleep(500);
				open = true;
			} else {
				Logger.error("Player is not open in native");
			}
		} else {
			By i_youtube= By.xpath("//XCUIElementTypeStaticText[@name='"+name+"']");
			if (type.equals("audio")) {

			} else {
				nativeelement = ElementWait.waitForOptionalElement(driver, i_youtube, 10);
			}
			if (nativeelement != null) {
				PageElement.tapOnScreen(driver, 0.04, 0.04);
				Thread.sleep(500);
				open = true;
			} else {
				Logger.error("Player is not open in native");
			}
		}
		// driver.context("WEBVIEW_com.snappy.appypie");
		PageElement.changeContextToWebView(driver);
		return open;
	}

	public boolean checkInvalidQuiz() {
		boolean icon = false;
		WebElement element_nodata = ElementWait.waitForOptionalElement(driver, noData, 20);
		if (element_nodata != null && element_nodata.isDisplayed()) {
			icon = true;
		}
		return icon;
	}

	/*
	 * public void getAnswerToast() throws TesseractException{ File imageFile=
	 * ImageUtil.takeScreenshot(driver, "QuizAnswer"); File img= new
	 * File("screenshots" + "/" + "quiz.png"); ITesseract instance = new
	 * Tesseract1(); File tessDataFolder =
	 * LoadLibs.extractTessResources("tessdata");
	 * instance.setDatapath(tessDataFolder.getAbsolutePath()); String result =
	 * instance.doOCR(img); System.out.println(result); }
	 */
}
