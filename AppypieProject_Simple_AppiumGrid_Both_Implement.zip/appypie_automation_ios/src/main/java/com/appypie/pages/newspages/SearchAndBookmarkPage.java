package com.appypie.pages.newspages;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SearchAndBookmarkPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By searchheader = By.xpath("//div[@class='navbar']//div[text()='Search']");
	By bookmarkheader = By.xpath("//div[@class='navbar']//div[contains(text(),'Bookmark')]");

	public SearchAndBookmarkPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isSearchPageOpen() {
		boolean open = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, searchheader, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isBookmarkPageOpen() {
		boolean open = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, bookmarkheader, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public List<Object> isFeedsPresent() {
		List<Object> data = new ArrayList<Object>();
		boolean present = false;
		boolean noData = false;
		String list = new NewsHomePage(driver).getFirstNewsListingName();
		if (list != "") {
			Logger.info(" Listing is present");
			present = true;
		} else {
			noData = PageElement.checkNoDataOptionInUrl(driver);
		}
		data.add(list);
		data.add(present);
		data.add(noData);
		return data;
	}
	
	public void openBookMarkFeed(){
		new NewsHomePage(driver).openFeeds("one");
	}
}
