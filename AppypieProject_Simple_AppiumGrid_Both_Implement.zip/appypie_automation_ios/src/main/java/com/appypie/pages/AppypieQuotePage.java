package com.appypie.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieQuotePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By quote = By.id("quoteContent");
	By favouriteBtnOnHeader = By.id("openFavouritePage");
	By shareBtn = By.xpath("//i[contains(@onclick,'shareQuote')]");
	By favBtn = By.id("btn_Fav");
	By favQuotesPage = By.xpath("//div[@class='navbar']//div[contains(text(),'Favourite')]");
	By favQuotes = By.xpath("//div[@id='favouriteQuote_txt']//p[@id='quoteContent']");

	public AppypieQuotePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isQuotePageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, favouriteBtnOnHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isQuotePresent() {
		boolean present = false;
		WebElement data = ElementWait.waitForOptionalElement(driver, quote, 20);
		if (data != null && data.isDisplayed()) {
			present = true;
		}
		return present;
	}
	
	public String getQuoteText(){
		return ElementWait.waitForOptionalElement(driver, quote, 5).getText();
	}

	public void clickShare() {
		WebElement share = ElementWait.waitForOptionalElement(driver, shareBtn, 20);
		if (share != null && share.isDisplayed()) {
			share.click();
		}
	}

	public void openFavouriteQuotePage() {
		WebElement page = ElementWait.waitForOptionalElement(driver, favouriteBtnOnHeader, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		}
	}

	public void markQuoteFavourite() {
		WebElement quote = ElementWait.waitForOptionalElement(driver, favBtn, 20);
		if (quote != null && quote.isDisplayed()) {
			String className = quote.getAttribute("class");
			if (className.contains("favColor")) {
				Logger.info("Quote is already marked as favourite");
			} else {
				quote.click();
			}
		}
	}

	public boolean isFavouriteQuotePageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, favQuotesPage, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isMarkedQuoteVisibleInFavourites(String favQuoteText) {
		boolean present = false;
		String quoteText = "";
		List<WebElement> quotes = ElementWait.waitForAllOptionalElements(driver, favQuotes, 20);
		if (quotes.size() != 0) {
			for (WebElement text : quotes) {
				quoteText = text.getText();
				if (quoteText.equals(favQuoteText)) {
					present = true;
					break;
				}
			}
		}
		return present;
	}
}
