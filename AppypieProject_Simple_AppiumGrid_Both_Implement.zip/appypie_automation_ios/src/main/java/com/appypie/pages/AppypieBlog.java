package com.appypie.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieBlog {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By blogPage = By.xpath("//a[@data-productid='blog']");
	By blogPageContent = By.xpath("//a[@class='appypie-list'][@data-page='blog']");
	By wordpressoption = By.xpath("//a[@class='appypie-list'][@data-identifire='wordpress']");
	By firstSubListHeading = By.xpath("//ul[@class='list']/li[1]//div[@class='text-detail']/h4");
	By firstSubListcontent = By.xpath("//ul[@class='list']/li[1]//div[@class='text-detail']/div");
	By heading = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	By slideBottomHeading = By.xpath("//div[@class='navbar']/div[1]/div[2]");
	By listing = By.xpath("//ul[@class='list']//li[contains(@onclick,'Appyscript.BlogDetailsPage')]");
	By backbtn = By.xpath("//div[@class='navbar']/div[2]//a[@href='index'][contains(@class,'link back')]");
	By listPage = By.xpath("//div[@class='blog-content']/h1/span");
	By fontBtn = By.xpath("//li[contains(@onclick,'Appyscript.BlogFontsSize')]");
	By fontpopUp = By.className("modal-title");
	By cancel = By.xpath("//span[text()='Cancel']");

	By noData = By.className("msg-container");
	By nativeListHeader = By.id("text_Tittle");
	By view = By.className("android.webkit.WebView");
	By shareBtn = By.xpath("//li[contains(@onclick,'Appyscript.BlogShare')]");
	// By sharepopUp= By.id("android:id/title");
	By sharepopUp = By.className("android.widget.TextView");
	// For Blogger option of Blog
	By bloggeroption = By.xpath("//a[@class='appypie-list'][@data-identifire='blogger']");
	By bloggerImg = By.xpath("//ul[@class='list']/li[2]/img");

	// For Feedburner option of Blog
	By feedburner = By.xpath("//a[@class='appypie-list'][@data-identifire='burner']");

	// For tumblr option of Blog
	By tumblr = By.xpath("//a[@class='appypie-list'][@data-identifire='tumbler']");
	By deepLink = By.xpath("//div[@class='blog-content']/h1");
	By deepLinkView = By.className("android.webkit.WebView");
	
	// For Custom  Blog
	By postComment= By.xpath("//div[contains(@onclick,'Appyscript.bolgsCommentsPage')]");
	By commentBox= By.id("text");
	By savePost= By.xpath("//div[contains(@onclick,'Appyscript.DoneBlogPastComment')]");
	By comments= By.xpath("//div[@class='user-comments']/ul/li");

	public AppypieBlog(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openBlogPage() {
		WebElement element_blogPage = ElementWait.waitForOptionalElement(driver, blogPage, 20);
		if (element_blogPage != null) {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element_blogPage.getLocation().x + ")");
			element_blogPage.click();
		} else {
			Logger.info("Blog page is not present in the app or flow is not main Menu");
		}

	}

	public boolean identifyBlogPageOpen() {
		boolean blogContent = false;
		WebElement element_blogPageContent = ElementWait.waitForOptionalElement(driver, blogPageContent, 20);
		if (element_blogPageContent.isDisplayed())
			blogContent = true;
		return blogContent;
	}

	public void openBlogUrls(String blogType) {
		By wordpressoption = By.xpath("//a[@class='appypie-list'][@data-identifire='" + blogType + "']");
		WebElement element_wordpress = ElementWait.waitForOptionalElement(driver, wordpressoption, 20);
		element_wordpress.click();

	}

	public boolean getListing() {
		boolean list = false;
		WebElement element_listing = ElementWait.waitForOptionalElement(driver, listing, 20);
		if (element_listing != null) {
			Logger.info("Listing is visible");
			list = true;
		} else {
			WebElement element_noListing = ElementWait.waitForOptionalElement(driver, noData, 10);
			if (element_noListing != null && element_noListing.isDisplayed()) {
				Logger.error("No Data Found icon is  visible on screen: Wrong URl of blog");
			}
		}
		return list;
	}

	public String listHeading() throws NullPointerException {
		return ElementWait.waitForOptionalElement(driver, firstSubListHeading, 30).getText();
	}

	public String listContent() throws NullPointerException {
		return driver.findElement(firstSubListcontent).getText();
	}

	public void openListing() throws NullPointerException {
		WebElement element_listing = ElementWait.waitForOptionalElement(driver, listing, 20);
		element_listing.click();
	}

	public String getListPageContent() throws NullPointerException, InterruptedException {
		Thread.sleep(1000);
		return ElementWait.waitForOptionalElement(driver, listPage, 20).getText();
	}

	public boolean getImage() {
		Boolean ImagePresent = false;
		WebElement ImageFile = ElementWait.waitForOptionalElement(driver, bloggerImg, 30);
		if (ImageFile != null) {
			ImagePresent = (Boolean) ((JavascriptExecutor) driver).executeScript(
					"return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
					ImageFile);
			if (!ImagePresent)
				Logger.info("Image not displayed.");
			else
				Logger.info("Image displayed.");
		} else {
			Logger.info("Image tag is not present or images are hide from Backend");
		}
		return ImagePresent;
	}

	public boolean openListInNative(String blogType) throws InterruptedException {
		boolean open = false;
		WebElement listHeading;
		if (blogType.equals("tumbler")) {
			listHeading = ElementWait.waitForOptionalElement(driver, deepLink, 20);
		} else {
			listHeading = ElementWait.waitForOptionalElement(driver, listPage, 20);
		}
		if (listHeading != null) {
			String text=listHeading.getText();
			listHeading.click();
			Thread.sleep(2000);
			driver.context("NATIVE_APP");
			if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				WebElement nativeView = ElementWait.waitForOptionalElement(driver, nativeListHeader, 20);
				if (nativeView != null && nativeView.isDisplayed()) {
					open = true;
					Thread.sleep(3000);
					driver.navigate().back();
				} else {
					Logger.info("Listing is not open in antive browser");
				}
			} else {
				open = PageElement.isContentOpenInNative(driver, text);
			}
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.error("Heading of list page is not displayed");
		}
		return open;
	}

	public void clickShareBtn() throws InterruptedException {
		WebElement btn = ElementWait.waitForOptionalElement(driver, shareBtn, 20);
		if (btn != null)
			btn.click();
		else {
			Logger.info("share button is not visible");
		}

	}

	public boolean fontBtn() throws InterruptedException {
		Thread.sleep(2000);
		boolean fbtn = false;
		WebElement btn = ElementWait.waitForOptionalElement(driver, fontBtn, 20);
		btn.click();
		WebElement element_warning = ElementWait.waitForOptionalElement(driver, fontpopUp, 10);
		if (element_warning != null && element_warning.isDisplayed()) {
			PageElement.locateClickableElement(driver, cancel);
			fbtn = true;
		}
		return fbtn;
	}
	
	public void openCommentPage() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, postComment, 20);
		if (btn != null && btn.isDisplayed())
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + btn.getLocation().x + ")");
			btn.click();
	}

	public boolean isCommentPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, commentBox, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void postComment() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, savePost, 20);
		if (btn != null && btn.isDisplayed())
			btn.click();
	}

	public void writeComment(String data) {
		PageElement.sendKey(driver, commentBox, data);
	}

	public int getCommentsCount() {
		int size = 0;
		List<WebElement> post = ElementWait.waitForAllOptionalElements(driver, comments, 20);
		if (post != null) {
			size = post.size();
		}
		return size;
	}
	
}