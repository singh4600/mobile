package com.appypie.pages.Audio;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AudioPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By bufferingNative= By.id("message");
	public By bufferingRadioNative= By.name("Buffering");
	public By clickAudioModule= By.xpath("//a[@data-productid='audio']"); 
	public By clickSoundCloud=By.xpath("//i[@class='icon-soundcloud-1']"); 
	public By clickMediaRss=By.xpath("//i[@class='icon-rss']");
	public By clickRadioStream=By.xpath("//i[@class='icon-rss-alt']");
	public By clickCustom=By.xpath("//i[@class='icon-indent-left']");
	public By clickBackbutton=By.xpath("//i[@class='icon icon-left-open-2']");
	public By clickBackbuttonfornative=By.id("icon1_button");

	//-----------------------------SoundCloud------------------------------------
	public By PlayStopBtn= By.xpath("//android.widget.ImageButton[@index='2']");
	public By i_PlayStopBtn= By.xpath("//XCUIElementTypeButton[@name=\"Stop\"]");
	public By i_PlayStopCustomeBtn= By.xpath("//XCUIElementTypeButton[@name=\"Stop\"]");
	public By shuffalBtn=By.id("bt_shuffal");
	public By i_shuffalBtn=By.xpath("//XCUIElementTypeButton[@name='shuffleoff']");
	public By shareBtn=By.id("bt_share");
	public By i_shareBtn=By.xpath("//XCUIElementTypeButton[@name=\"Share\"]");
	public By i_shareRadioBtn=By.xpath("//XCUIElementTypeButton[@name=\"audioshare\"]");
	public By muteBtn=By.id("bt_mute");
	public By i_muteBtn=By.xpath("//XCUIElementTypeButton[@name=\"Mute\"]");
	public By i_muteCustomeBtn=By.xpath("//XCUIElementTypeButton[@name=\"Mute\"]");
	public By PreviousBtn=By.id("btnPrevious");
	public By BackwardBtn=By.id("btnBackward");
	public By ForwardBtn=By.id("btnForward");
	public By NextBtn=By.id("btnNext");
	
	//---------------get text sound cloud------------------
	
	public By songlabel_getText= By.id("songDescLabel");
	public By time_getText= By.id("tv_start");
	public By headingSong_getText= By.id("title_list");
	public By songlist_getText= By.id("songTitle");
	
	
	//-----------------------------Media RSS------------------------------------
	public By clickmediarssPlay_Stop_Btn=By.xpath("//android.widget.ImageButton[@index='2']");
	
	public By clickmediarsspousebtn=By.id("btnStop");
	public By clickmediarssplaybtn=By.id("btnPlay");
	public By clickmediarssshuffalBtn=By.id("bt_shuffal");
	public By clickmediarssshareBtn=By.id("bt_share");
	public By clickmediarssmuteBtn=By.id("bt_mute");
	public By clickmediarssPreviousBtn=By.id("btnPrevious");
	public By clickmediarssBackwardBtn=By.id("btnBackward");
	public By clickmediarssForwardBtn=By.id("btnForward");
	public By clickmediarssNextBtn=By.id("btnNext");
	public By clickmediarssBtn=By.id("");
	
//---------------radio stream-----------  
	public By clickradiostreamStopBtn=By.id("BtnStop");
	public By clickradiostreamPlayBtn=By.id("BtnPlay");
	public By i_clickradiostreamPlayBtn=By.xpath("//XCUIElementTypeButton[@name=\"Stop\"]");
	public By clickradiostreamshareBtn=By.id("bt_share");
	public By clickradiostreamMutebtn=By.id("bt_mute");
	public By clickradiostreamAlermbtn=By.id("btn2");
	public By i_clickradiostreamAlermbtn=By.xpath("//XCUIElementTypeButton[@name=\"alarm icon\"]");
	public By clickradiostreambackBtnAtAlermpage=By.id("icon1_button");
	public By addAlarm=By.id("addalarm");
	public By i_addAlarm=By.xpath("//XCUIElementTypeButton[@name=\"+\"]");
	public By setTimelink=By.id("timetxt");
	public By i_setTimelink=By.xpath("timetxt");
	public By cancelBtnclocklink=By.id("button2");
	public By checkalllink=By.id("chk_all");
	public By checkMondaylink=By.id("chk_monday");
	public By addbtn=By.id("setalarm");
	public By cancelbtn=By.id("cancelalarm");
	public By i_cancelbtn=By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	public By repeat_get=By.id("lnrchk1");
	public By alarm_get=By.xpath("txt_lable");
	

	//By get=By.xpath("");

	public By getAllaudioLink=By.xpath("//a[@class='appypie-list']/span[2]");
	
	//-------------media Rss get text-------------------
	public By getSongDesclable=By.id("songDescLabel");
	public By getheadertitlelist=By.id("title_list");
	public By mediaRssSongDescription=By.id("songTitle");
	
	//----------------------Radio Stream-------------------
	public By getradioName=By.id("radioName");
	public By getradioStatus=By.id("radioStatus");
	
	
	
	public By getsharebyItem=By.className("android.widget.TextView");

	public AudioPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
	
	public void clickmediarssPlay_stop_btton() throws Exception{	
		WebElement Open= ElementWait.waitForOptionalElement(driver,clickmediarssPlay_Stop_Btn , 20);
		if(Open!=null && Open.isDisplayed())
		{
			Open.click();
		}
		else{
			System.out.println("click mediarss Play_Stop_Btn is not present");
		}
	}
	

}