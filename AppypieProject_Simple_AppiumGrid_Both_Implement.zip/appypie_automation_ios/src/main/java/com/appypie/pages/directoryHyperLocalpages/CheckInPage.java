package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class CheckInPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By checkInMap = By.id("googleMapcheckin");
	By checkinBtn = By.id("checkedinbutton");

	public CheckInPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isCheckInPageOpen() {
		boolean open = false;
		WebElement map = ElementWait.waitForOptionalElement(driver, checkInMap, 20);
		if (map != null && map.isDisplayed()) {
			open = true;
		} else {
			Logger.info("CheckINpage is not open");
		}
		return open;
	}

	public void clickCheckInBtn() {
		PageElement.locateClickableElement(driver, checkinBtn);
	}
	
	public String getCheckInBtnContent(){
		return ElementWait.waitForOptionalElement(driver, checkinBtn, 10).getText();
	}

}
