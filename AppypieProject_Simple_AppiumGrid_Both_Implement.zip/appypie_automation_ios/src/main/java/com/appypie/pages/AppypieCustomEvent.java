package com.appypie.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class AppypieCustomEvent {
	private static final Logger Logger= Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	public By pagelink = By.xpath("//a[@data-productid='event']");
	public By getPageItem = By.xpath("//*[contains(@class,'arial largeHeading')]");
	public By getpageItem = By.xpath("//div[@class='pages ']");
	public By mapAdres = By.xpath("//ul[@class='event-map-detail map-venue-list']");
	By header_gettext = By.id("pageTitle");
	By map = By.xpath("//a[contains(@onclick,'startMap()')]");
	By mapbckbtn = By.xpath("//a[contains(@onclick,'ce_mapClosed()')]");
	By map_addressback_btn = By.xpath("//li[contains(@onclick,'ce_getVenueDetails(1)')]");
	By filter = By.xpath("//div[@class='right']//a[contains(@onclick,'Appyscript.popupPage')]");
	By filterback = By.xpath("//a[contains(@onclick,'ce_checkFilter();')]");
	By filterdate = By.id("dateFilter");
	public By datefld_natv = By.xpath("//android.view.View[@text='7']");
	static By datefld_natv2 = By.xpath("//android.view.View[@text='7']");
	public By datefld_cacl_ntv = By.xpath("//android.widget.Button[contains(@resource-id,'button2')]");
	public By datefld_set_ntv = By.xpath("//android.widget.Button[contains(@resource-id,'button1')]");
	public By datefldclr_ntv = By.xpath("//android.widget.Button[contains(@resource-id,'button3')]");
	public By fltr_apply_btn = By.xpath("//div[@class='toolbar']");
	By header_search = By.id("CE_locationName");
	By cross_search = By.xpath("//*[contains(@class,'location-search')]/a");
	By Typserch = By.id("ceLocationText");
	By click_on_search_reslt = By.xpath("//*[@id='ceLocationResults']/li[2]");
	By resultpage = By.xpath("//*[@class='events-list']/li[2]");
	By home_searc =By.id("ce_btnSearch");
	By m_search = By.id("txtSearch");
	By comedypage = By.xpath("//div[@class='pages ']//div[@data-page][2]//div[@data-id]");
	By Clk_subcategory = By.xpath("//*[@class='events-list']/li[1]");
	public By subcategory_Page_list = By.xpath("//*[contains(@class,'eventslist')]");
	By Music_A_r = By.xpath("//ul[@class='events-list']/li[1]/div[2]");
	By Bookmarks = By.id("bookmarkIcon");
	By Bookmarks_ok = By.xpath("//*[@class='modal-button modal-button-bold']");
	By Bookmarks_Back = By.xpath("//a[contains(@onclick,'back2Home')]");
	public By Bookmarks_Alert = By.xpath("//div[contains(@class,'modal modal-in')]");
	By Rating = By.xpath("//a[contains(@class,'rating-icon')]");
	public By User_Rating = By.xpath("//div[contains(@class,'page-content')]");
	By map_on_description = By.xpath("//a[contains(@class,'icon-location-2')]");
	By share = By.xpath("//a[contains(@class,'icon-share-1')]");
	By sharelistNative_gettext=By.xpath("//android.widget.GridView[@index='0']");
	By Terms_conditions = By.xpath("//a[contains(@onclick,'ce_expandTerms(this)')]");
	By Terms_conditions_text = By.id("txtSearch");
	By Book_botton = By.xpath("//*[contains(@class,'toolbar-inner')]");
	By Booking_ReviewPage = By.id("btn-payment");
	By Clk_address = By.xpath("//ul[contains(@class,'content-list event-list')]");
	public By Tkt_link = By.xpath("//section[@class='section-events day-page event-back']");
	By Classic = By.xpath("//*[@type='Classic']");
	By Gold = By.xpath("//*[@type='Gold']");
	By Platinum = By.xpath("//*[@type='Platinum']");
	By clk_tkt_num = By.xpath("//div[contains(@class,'swiper-slide swiper-slide-next')]");
	By clk_continue = By.xpath("//div[contains(@class,'toolbar-inner')]");
	By promocode = By.id("promocode");
	By promo_apply = By.xpath("//a[contains(@onclick,'applyPromo()')]");
	By makepayment = By.xpath("//a[contains(@onclick,'makePayment();')]"); 
	By G_Login = By.xpath("//a[contains(@onclick,'ce_loginFromMakePayment()')]");
	By cnfrm_pyment = By.xpath("//a[contains(@onclick,'ce_initGuestLogin()')]");
	By Paypal = By.xpath("//*[contains(@label,'PayPal Express')]");
	By Stripe = By.xpath("//*[contains(@label,'Stripe')]");
	By Payatcounter = By.xpath("//*[contains(@label,'Pay At Counter')]");
	By Payatcounter_confirm = By.xpath("//div[contains(@id,'tabpac')]//a[@class='BtText arial mediumContent']");
	By AddTo_Calender = By.xpath("//*[@class='tabs']/div[1]/ul[1]/li[1]/div[3]/a[2]");
	By Add_to_gallery = By.xpath("//a[contains(@onclick,'saveTicket()')]");
	By FinalConfirm = By.xpath("//a[contains(@onclick,'back2Home()')]");
	By Guest_name_fld = By.id("guestName"); 
	By FreeEvents = By.xpath("//*[@class='events-list']/li[3]/div[2]");
	By FreeEvents2 = By.xpath("//h2[@class='largeHeading' and text()='Free Seminars']");
	By MenuPage = By.xpath("//i[contains(@class,'icon appyicon-sort-down')]");
	By Menucross = By.xpath("//a[contains(@class,'close')]");
	By M_Events = By.xpath("//*[@class='events-navs']/ul[1]/li[1]");
	By MyBooking = By.xpath("//*[@onclick='Appyscript.customeventMyBooking()']");
	By upcoming = By.xpath("//*[@class='customevent-tab tabs-click']//a[1]");
	By Attended = By.xpath("//*[@class='customevent-tab tabs-click']//a[2]");
	By ReBook = By.xpath("//*[@class='tabs']/div[2]/ul[1]/li[1]/div[3]/a[1]");
	By Review = By.xpath("//*[@class='tabs']/div[2]/ul[1]/li[1]/div[3]/a[2]");
	By Review2 = By.id("star2");
	By Review5 = By.id("star5");
	By ReviewField = By.id("reviewTextArea");
	By M_bookmarks = By.id("menubookmark"); 
	By PostRvw = By.xpath("//*[@class='tabs']/div[2]/ul[1]/li[1]/div[3]/a[2]");
	By PostRvwCnfrm = By.xpath("//div[contains(@class,'review-btn-wrapper')]");
	By B_music_a_r = By.xpath("//*[@class='events-list']/li[1]/div[2]");
	By BookmarksRemove = By.xpath("//*[@class='right']//a[contains(@onclick,'Appyscript.remBookmark')]");
	public By MenuLinks = By.xpath("//div[contains(@class,'events-navs')]");
	static By heading = By.xpath("//div[@class='navbar']/div[2]/div[2]");

	public AppypieCustomEvent(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean identifyCEPageOpen(){
		boolean CEContent = false;
		WebElement element_CE = ElementWait.waitForOptionalElement(driver, pagelink, 30);
		if (element_CE!=null && element_CE.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			element_CE.click();
			CEContent = true;
		}else {
			Logger.info("Custom Events page not working or not in flow of the page");
		}
		return CEContent;
	}

	public boolean CEheader() {
		boolean header = false;
		String  page = ElementWait.waitForOptionalElement(driver, header_gettext, 20).getText();
		Logger.info("Inner Page header is " + page);
		return header;
	}


	public String identifyHeaderValue(){
		String Htext = null;
		WebElement Value = ElementWait.waitForOptionalElement(driver, header_gettext, 30);
		if (Value!=null && Value.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			Htext=Value.getText();
			System.out.println("Get Text:  " + Htext);

		}else {
			Logger.info("Header value not present");
		}
		return Htext;
	}


	public boolean identifymapOpen() {
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
		boolean mapopen = false;
		WebElement openmap = ElementWait.waitForOptionalElement(driver, map, 20);
		if (openmap!=null && openmap .isDisplayed()){
			openmap.click();
			mapopen = true;
		}else {
			Logger.info("Map not working or not in flow of the page");
		}
		return mapopen;
	}

	public boolean clickmapbackbtn() {
		boolean mapbk=false;
		WebElement btn2 = ElementWait.waitForOptionalElement(driver, mapbckbtn, 20);
		if (btn2 != null && btn2.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			btn2.click();
			mapbk = true;
		}else {
			Logger.info("back button on map page is not visible");
		}
		return mapbk;
	}


	public boolean clickmapaddress(){
		boolean isAddressVisible=false;
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
		WebElement btn3 = ElementWait.waitForOptionalElement(driver, map_addressback_btn, 20);
		if (btn3 != null && btn3.isDisplayed() ){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			btn3.click();
			isAddressVisible=true;
		}else {
			Logger.info("map address link is not visible");
		}
		return isAddressVisible;
	}

	public boolean identifyfilterOpen() {
		boolean element_filter = false;
		WebElement filteridentify = ElementWait.waitForOptionalElement(driver, filter, 20);
		if (filteridentify != null && filteridentify.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			filteridentify.click();
			element_filter = true;
		}else {
			Logger.info("Filter not working or not in flow of the page");
		}
		
		return element_filter;
	}



	public boolean clickfilterbackbtn() {
		boolean filterBack=false;
		WebElement fbckbtn = ElementWait.waitForOptionalElement(driver, filterback, 20);
		if (fbckbtn != null && fbckbtn.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			fbckbtn.click();
			filterBack= true;
		}else {
			Logger.info("back button on filter page is not working");
		}
		return filterBack;

	}

	public boolean opendatefield() {
		boolean dateField=false;
		WebElement element_date = ElementWait.waitForOptionalElement(driver, filterdate, 20);
		if (element_date != null && element_date.isDisplayed()) {
			element_date.click();
			dateField = true;
		} else {
			Logger.info("filter date field not clikable");
		}
		return dateField;

	}

	public void clickdatefield() {
		driver.context("NATIVE_APP");
		WebElement click_date = ElementWait.waitForOptionalElement(driver, datefld_natv, 20);
		if (datefld_natv != null) {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + click_date.getLocation().x + ")");
			click_date.click();
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.info("filter date field not clikable");
		}

	}

	public void Fltr_Apply() {
		WebElement apply = ElementWait.waitForOptionalElement(driver, fltr_apply_btn, 20);
		if (apply != null) {
			apply.click();
		} else {
			Logger.info("set date field not clikable");
		}
	}

	public boolean isserchpageOpen() {
		boolean srchcontent = false;
		WebElement checkserch = ElementWait.waitForOptionalElement(driver, header_search, 20);
		if (checkserch !=null &&checkserch .isDisplayed()){
			checkserch.click();
			srchcontent = true;
		}
		else {
			Logger.info("Search page not visible on app");
		}
		return srchcontent;
	}

	public boolean serch_cancel_button(){
		boolean btn=false;
		WebElement cancel_s = ElementWait.waitForOptionalElement(driver, cross_search, 20);
		if (cancel_s != null && cancel_s.isDisplayed()) {
			cancel_s.click();
			btn =true;
		} else {
			Logger.info("croos button on serch page not visible");
		}
		return btn;

	}

	public boolean Enter_on_search() {
		boolean search=false;
		WebElement Search_e = ElementWait.waitForOptionalElement(driver, Typserch, 20);
		if (Typserch != null) {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Search_e.getLocation().x + ")");
			Search_e.click();
			Search_e.sendKeys("mumbai");
			search =true;
		} else {
			Logger.info("serch page not visible");
		}
		return search;

	}


	public boolean click_REsult()  {
		boolean isRsltOpen=false;
		WebElement click_r = ElementWait.waitForOptionalElement(driver, click_on_search_reslt, 20);
		if (click_on_search_reslt != null) {
			click_r.click();
			isRsltOpen=true;

		} else {
			Logger.info("serch result not visible");
		}
		return isRsltOpen;

	}

	public boolean mumbai_serc_reslt() {
		boolean sercresult=false;
		WebElement mumbai_serc = ElementWait.waitForOptionalElement(driver, resultpage, 20);
		if (resultpage != null) {
			mumbai_serc.click();
			sercresult=true;
		} else {
			Logger.info("serch result not visible");
		}
		return sercresult;
	}


	public boolean Serchhome() {
		boolean homesrch = false;
		WebElement Search_h = ElementWait.waitForOptionalElement(driver, home_searc, 20);
		if (Search_h != null && Search_h.isDisplayed()) {
			Search_h.click();
			homesrch = true;
		} else {
			Logger.info("Home search not working");
		}
		return homesrch;

	}

	public boolean Enterhmsrc() {
		boolean hmsrc=false;
		WebElement entermsr = ElementWait.waitForOptionalElement(driver, m_search, 20);
		if (entermsr != null && entermsr.isDisplayed()) {
			entermsr.click();
			entermsr.sendKeys("Comedy");
			hmsrc =true;
		} else {
			Logger.info("Comedy serch result not visible");
		}
		return hmsrc;
	}
	

	public boolean clickcomedy() {
		boolean cmdy =false;
		WebElement comedy = ElementWait.waitForOptionalElement(driver, comedypage, 20);
		if (comedy != null && comedy.isDisplayed()) {
			comedy.click();
			cmdy = true;
		} else {
			Logger.info("Comedy link not clikable");
		}
		return cmdy;
	}


	public boolean identifySubCat() {
		boolean SubCatContent = false;
		try { 
			WebElement element_sub = ElementWait.waitForOptionalElement(driver, Clk_subcategory, 30);
			Thread.sleep(2000);
			if (element_sub !=null && element_sub.isDisplayed()){
				element_sub.click();
				SubCatContent = true;
			}else {
				Logger.info("Subcategory link mot clickable");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return SubCatContent;

	}

	public boolean veriftbookmarks() {
		boolean mark=false;
		try {
			WebElement bookmark = ElementWait.waitForOptionalElement(driver, Bookmarks, 30);
			Thread.sleep(2000);
			if (bookmark != null) {
				bookmark.click();
				mark = true;
			} else {
				Logger.info("Bookmarks not present in the app or flow is not main Menu");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return mark;
	}

	public boolean veriftAR_Rehman() {
		boolean Rehman = false;
		try {
			WebElement AR_Rehman = ElementWait.waitForOptionalElement(driver, Music_A_r, 30);
			Thread.sleep(2000);
			if (AR_Rehman != null) {
				Thread.sleep(2000);
				AR_Rehman.click();
				Rehman = true;
			}
			else {
				Logger.info("Bookmarks not present in the app or flow is not main Menu");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Rehman;
	}

	public boolean verifybookmarks_alert() {
		boolean alert=false;
		try {
			WebElement bookmarks_alt = ElementWait.waitForOptionalElement(driver, Bookmarks_ok, 20);
			Thread.sleep(2000);
			if (bookmarks_alt != null) {
				bookmarks_alt.click();
				alert=true;
			} else {
				Logger.info("Error occurs on bookmarks ok button");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return alert;
	}

	public boolean verifyRating(){
		boolean ratng=false;
		WebElement ratingPage = ElementWait.waitForOptionalElement(driver, Rating, 20);
		if (ratingPage != null && ratingPage.isDisplayed()){
			ratingPage.click();
			ratng = true;
		}else {
			Logger.info("Rating not clikable");
		}
		return ratng;

	}

	public boolean verifymap_d(){
		boolean vrfymap= false;
		WebElement map_d = ElementWait.waitForOptionalElement(driver, map_on_description, 20);
		if (map_d != null && map_d.isDisplayed())
		{
			map_d.click();
		vrfymap = true;
		}else {
			Logger.info("map not clikable");
		}
		return vrfymap;

	}

	public boolean verifyshare(){
		boolean shre=false;
		WebElement share_d = ElementWait.waitForOptionalElement(driver, share, 20);
		if (share_d != null && share_d.isDisplayed()){
			share_d.click();
			shre = true;
		}else {
			Logger.info("share not clikable");
		}
		return shre;

	}

	public boolean Shareback() throws InterruptedException {
		boolean sbtn = false;
		driver.context("NATIVE_APP");
		WebElement shareoption = ElementWait.waitForOptionalElement(driver, sharelistNative_gettext, 10);
		if (shareoption != null && shareoption.isDisplayed()) {
			driver.navigate().back();
			Thread.sleep(2000);
			PageElement.changeContextToWebView(driver);
			sbtn = true;
		}else {
			System.out.println("share back not woring in native");
		}
		return sbtn;
	}


	public boolean verify_termscondition(){
		boolean T_C = false;
		WebElement termscondition = ElementWait.waitForOptionalElement(driver, Terms_conditions, 20);
		if (termscondition != null && termscondition.isDisplayed()){
			termscondition.click();
			T_C = true;
		}else {
			Logger.info("share not clikable");
		}
		return T_C;

	}


	public boolean verifyBookbutton(){
		boolean btn = false;
		WebElement Bookbutton = ElementWait.waitForOptionalElement(driver, Book_botton, 20);
		if (Bookbutton != null && Bookbutton.isDisplayed()){
			Bookbutton.click();
			btn = true;
		}else {
			Logger.info("share not clikable");
		}
		return btn;

	}

	public boolean verifyBookBtnReviewPage(){
		boolean ReviewPAge=false;
		WebElement BookReviewPage = ElementWait.waitForOptionalElement(driver, Booking_ReviewPage, 20);
		if (BookReviewPage != null && BookReviewPage.isDisplayed()){
			BookReviewPage.click();
			ReviewPAge=true;
		}else {
			Logger.info("share not clikable");
		}
		return ReviewPAge;

	}

	public boolean verify_address(){
		boolean ads=false;
		WebElement address_clk = ElementWait.waitForOptionalElement(driver, Clk_address, 20);
		if (address_clk != null && address_clk.isDisplayed()){
			address_clk.click();
		ads = true;
		}else {
			Logger.info("Address not clikable");
		}
		return ads;

	}

	public boolean verify_classic(){
		boolean classc = false;
		WebElement classic_tkt = ElementWait.waitForOptionalElement(driver, Classic, 20);
		if (classic_tkt != null && classic_tkt.isDisplayed()){
			classic_tkt.click();
			classc = true;
		}	else {
			Logger.info("classic_tkt not clikable");
		}
		return classc;

	}
	public boolean verify_gold(){
		boolean gld = false;
		WebElement gold_tkt = ElementWait.waitForOptionalElement(driver, Gold, 20);
		if (gold_tkt != null && gold_tkt.isDisplayed()){
			gold_tkt.click();
			gld = true;
		}else {
			Logger.info("gold_tkt not clikable");
		}
		return gld;
	}

	public boolean verify_plattinum(){
		boolean plt=false;
		WebElement plattinum_tkt = ElementWait.waitForOptionalElement(driver, Platinum, 20);
		if (plattinum_tkt != null && plattinum_tkt.isDisplayed()){
			plattinum_tkt.click();
			plt = true;
		}else {
			Logger.info("plattinum_tkt not clikable");
		}
		return plt;
	}

	public boolean verify_Ticket(){
		boolean tickt=false;
		Actions action = new Actions(driver);
		WebElement Ticket = ElementWait.waitForOptionalElement(driver, clk_tkt_num, 20);
		if (Ticket != null && Ticket.isDisplayed()){
			action.doubleClick(Ticket).perform();
			action.doubleClick(Ticket).perform();
			tickt = true;
		}else {
			Logger.info("plattinum_tkt not clikable");
		}
		return tickt;
	}

	public boolean verify_continue(){
		boolean vrfycntny =false;
		WebElement continuebtn = ElementWait.waitForOptionalElement(driver, clk_continue, 20);
		if (continuebtn != null){
			continuebtn.click();
			vrfycntny = true;
		}	else {
			Logger.info("Continue button not clikable");
		}
		return vrfycntny;
	}


	public boolean verify_PromoApplybtn(){
		boolean apply=false;
		WebElement PromoApplybtn = ElementWait.waitForOptionalElement(driver, promo_apply, 20);
		if (PromoApplybtn != null){
			PromoApplybtn.click();
			apply = true;
		}else {
			Logger.info("promo button not clikable");
		}
		return apply;
	}

	public boolean verify_promo(){
		boolean entrprmo=false;

		WebElement promo = ElementWait.waitForOptionalElement(driver, promocode, 20);
		if (promo != null){
			promo.click();
			promo.sendKeys("123456");
			entrprmo = true;
		}else {
			Logger.info("promo button not clikable");
		}
		return entrprmo;
	}



	public boolean verify_MakePYMT(){
		boolean PYMT=false;
		WebElement MakePYMT = ElementWait.waitForOptionalElement(driver, makepayment, 20);
		if (MakePYMT != null){
			MakePYMT.click();
			PYMT = true;
		}else {
			Logger.info("makepayment button not clikable");
		}
		return PYMT;
	}

	public boolean verify_GuestLogin(){
		boolean GLgn= false;
		WebElement GuestLogin = ElementWait.waitForOptionalElement(driver, G_Login, 20);
		if (GuestLogin != null){
			GuestLogin.click();
			GLgn = true;
		}else {
			Logger.info("Guest login button not clikable");
		}
		return GLgn;
	}

	public boolean verify_ConfirmPayment(){
		boolean payment=false;
		WebElement ConfirmPayment = ElementWait.waitForOptionalElement(driver, cnfrm_pyment, 20);
		if (ConfirmPayment != null){
			ConfirmPayment.click();
		payment = true;
		}	else {
			Logger.info("cnfrm_pyment button not clikable");
		}
		return payment;
	}

	public boolean verify_Paypal(){
		boolean vrfyPay=false;
		WebElement PayPal_click = ElementWait.waitForOptionalElement(driver, Paypal, 20);
		if (PayPal_click != null){
			PayPal_click.click();
			vrfyPay = true;
		}else {
			Logger.info("Paypal button not clikable");
		}
		return vrfyPay;
	}

	public boolean verifyPAYatCon(){
		boolean conter=false;
		WebElement PAYatCon = ElementWait.waitForOptionalElement(driver, Payatcounter, 20);
		if (PAYatCon != null){
			PAYatCon.click();
			conter = true;
		}else {
			Logger.info("Pay at Counter button not clikable");
		}
		return conter;
	}

	public boolean verify_Stripe(){
		boolean isStripeAvailable=false;
		WebElement Stripe_click = ElementWait.waitForOptionalElement(driver, Stripe, 20);
		if (Stripe_click != null){
			Stripe_click.click();
			isStripeAvailable=true;
		}else {
			Logger.info("Stripe button not clikable");
		}
		return isStripeAvailable;
	}
	public boolean verify_Payatcounter_confirmBtn(){
		boolean confirmBtn=false;
		WebElement Payatcounter_cnf = ElementWait.waitForOptionalElement(driver, Payatcounter_confirm, 20);
		if (Payatcounter_cnf != null){
			Payatcounter_cnf.click();
			confirmBtn = true;
		}else {
			Logger.info("Pay at counter button not clikable");
		}
		return confirmBtn;
	}

	public boolean verify_AddToCalender(){
		boolean callender=false;
			WebElement AddToCalender  = ElementWait.waitForOptionalElement(driver, AddTo_Calender, 20);
			if (AddToCalender != null && AddToCalender.isDisplayed() ){
				AddToCalender.click();
				callender=true;	
			}else {
			}
			return callender;
		
	}

	public void verify_AddGallery(){
		try {
			Thread.sleep(3000);
			TouchAction action = new TouchAction(driver); 
			WebElement AddToGall  = ElementWait.waitForOptionalElement(driver, Add_to_gallery, 20);
			if (AddToGall != null){
				action.longPress(AddToGall).moveTo(AddToGall).release().perform();
				AddToGall.click();
			}else {
				Logger.info("Add To Gallery button not clikable");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}


/*	public boolean isGuestLoginPageOpen(AppiumDriver<MobileElement> driver) {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, G_Login, 10);
		if (login != null && login.isDisplayed()) {
			open = true;
		}
		return open;
	}
*/


	public boolean verify_F_Confirm(){
		boolean confrim=false;
		WebElement F_Confirm  = ElementWait.waitForOptionalElement(driver, FinalConfirm, 20);
		if (F_Confirm != null){
			F_Confirm.click();
			confrim=true;
		}else {
			Logger.info("BAck to home button not clikable");
		}
		return confrim;
	}

	public boolean identifyFreeSeminarOpen(){
		boolean Free_s = false;
		WebElement free = ElementWait.waitForOptionalElement(driver, FreeEvents, 20);
		if (free.isDisplayed()){
			free.click();
			Free_s = true;
		}else {
			System.out.println("Free seminar not clickable");
		}return Free_s;
	}

	public boolean identifyMenuOpen(){
		boolean Menu_P = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, MenuPage, 20);
		if (menu !=null && menu.isDisplayed()){
			menu.click();
			Menu_P = true;
		}else {
			Logger.info("Menu page not opens up");
		}return Menu_P;
	}

	public boolean verifyMenuCrossBtn(){
		boolean  crossBtn =false;
		WebElement MenuCrossBtn = ElementWait.waitForOptionalElement(driver, Menucross, 20);
		if (Menucross != null){
			MenuCrossBtn.click();
			crossBtn =true;
		}else {
			Logger.info("Menu cross button not clikable");
		}
		return crossBtn;
	}

	public boolean verifyMenuEvents(){
		boolean Events=false;
		WebElement MEvents = ElementWait.waitForOptionalElement(driver, M_Events, 20);
		if (MEvents != null){
			MEvents.click();
			Events=true;
		}else {
			Logger.info("Menu Events button not clikable");
		}
		return Events;
	}

	public boolean verifyMyBooking(){
		boolean MyBking=false;
		WebElement MBooking = ElementWait.waitForOptionalElement(driver, MyBooking, 20);
		if (MBooking != null){
			MBooking.click();
			MyBking =true;
		}else {
			Logger.info("My Booking link not clikable");
		}
		return MyBking;
	}

	public boolean verifyUpcoming(){
		boolean Upcoming= false;
		WebElement MUpcoming = ElementWait.waitForOptionalElement(driver, upcoming, 20);
		try {
			Thread.sleep(2000);
			if (upcoming != null){

				MUpcoming.click();
				Upcoming=true;
			}else {
				Logger.info("upcoming button not clikable");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Upcoming;
	}

	public boolean verifyAttended(){
		boolean aatendent=false;
		WebElement MAttended = ElementWait.waitForOptionalElement(driver, Attended, 20);
		if (MAttended != null){
			MAttended.click();
			aatendent=true;
		}else {
			Logger.info("Attended link not clikable");
		}
		return aatendent;
	}
	
	public boolean verifyPostReview(){
		boolean Reviewbtn=false;
		WebElement PostReview = ElementWait.waitForOptionalElement(driver, PostRvw, 20);
		if (PostReview != null){
			PostReview.click();
			Reviewbtn=true;
		}else {
			Logger.info("Attended link not clikable");
		}
		return Reviewbtn;
	}

	
	public boolean WriteReview() {
		boolean write=false;
		WebElement enterReview = ElementWait.waitForOptionalElement(driver, ReviewField, 20);
		if (enterReview != null && enterReview.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			enterReview.click();
			enterReview.sendKeys("Nice Show By A R");
			write = true;
		}else {
			Logger.info("Enter review field not visible");
		}
		return write;
	}
	
	public boolean clickReview5() {
		boolean review=false;
		WebElement review5 = ElementWait.waitForOptionalElement(driver, Review5, 20);
		if (review5 != null && review5.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			review5.click();
			review=true;
		}else {
			Logger.info("Reivew5 button not working");
		}
		return review;
	}
	
	public boolean VerifyPostReviewBtn() {
		boolean postReviewBtn=false;
		WebElement reviewCnfrm = ElementWait.waitForOptionalElement(driver, PostRvwCnfrm, 20);
		if (reviewCnfrm != null && reviewCnfrm.isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
			reviewCnfrm.click();
			postReviewBtn=true;
		}else {
			Logger.info("Reivew5 button not working");
		}
		return postReviewBtn;
	}
	
	public boolean verifyReBook(){
		boolean RBook=false;
		WebElement ReBuk = ElementWait.waitForOptionalElement(driver, ReBook, 20);
		if (ReBuk != null && ReBuk.isDisplayed()){
			ReBuk.click();
			RBook=true;
		}else {
			Logger.info("Rebook link not clikable");
		}
		return RBook;
	}

	public boolean verifyMenuBookmarks(){
		boolean menuBookMarks=false;
		WebElement MenuBookmarks = ElementWait.waitForOptionalElement(driver, M_bookmarks, 20);
		if (MenuBookmarks != null){
			MenuBookmarks.click();
			menuBookMarks = true;
		}else {
			Logger.info("Bookmarks link not clikable");
		}
		return menuBookMarks;
	}

	public boolean verifyBookmarksopen(){
		boolean openBkmarks=false;
		WebElement BookmarkspageOpen = ElementWait.waitForOptionalElement(driver, B_music_a_r, 20);
		if (BookmarkspageOpen != null){
			BookmarkspageOpen.click();
			openBkmarks=true;
		}else {
			Logger.info("Bookmarks page link not clikable");
		}
		return openBkmarks;
	}
	
	public boolean verifyBookmarksBack(){
		boolean BookmarksBack=false;
		WebElement BookmarkspageBack = ElementWait.waitForOptionalElement(driver, Bookmarks_Back, 20);
		if (BookmarkspageBack != null && BookmarkspageBack.isDisplayed()){
			BookmarkspageBack.click();
			BookmarksBack=true;
		}else {
			Logger.info("Bookmarks page link not clikable");
		}
		return BookmarksBack;
	}


	public boolean verifyMenuBookmarksRemove(){
		boolean removeBookmarks=false;
		WebElement BookmarksRemv = ElementWait.waitForOptionalElement(driver, BookmarksRemove, 20);
		if (BookmarksRemv != null){
			BookmarksRemv.click();
			removeBookmarks=true;
		}	else {
			Logger.info("Bookmarks remove link not clikable");
		}
		return removeBookmarks;
	}
	public boolean getListofLink(By link){
		boolean AvailableLink = false;
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
		WebElement listpresent = ElementWait.waitForOptionalElement(driver, getPageItem, 20);
		if(listpresent!=null){
			List<MobileElement> allSuggestions = driver.findElements(link);
			for (WebElement suggestion : allSuggestions) {
				System.out.println("***************Available link on page*************");
				System.out.println(suggestion.getText());
				System.out.println("***************Above are the availbale links*************");
			}
			AvailableLink= true;
		}
		
		else{
			Logger.info("List is not present");
		}
		return AvailableLink;
	}

}