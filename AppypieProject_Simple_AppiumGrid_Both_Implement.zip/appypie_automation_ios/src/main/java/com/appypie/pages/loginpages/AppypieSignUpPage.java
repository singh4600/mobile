package com.appypie.pages.loginpages;

import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.FileHandler;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieSignUpPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	public static int userValue = 0;

	By fname = By.xpath("//*[@id='fname']");
	By email = By.xpath("//*[@id='emailId']");
	By pno = By.xpath("//*[@id='pNo']");
	By pass = By.xpath("//*[@id='pass']");
	By cpass = By.xpath("//*[@id='cpass']");
	By gender = By.xpath("//select[@placeholder='Gender  *']");
	By country = By.xpath("//select[@placeholder='Country']");
	By state = By.xpath("//input[@type='text'][@name='state']");
	By check = By.xpath("//input[@type='checkbox'][@id='1']");
	By list = By.xpath("//select[@placeholder='List box']");
	By text = By.xpath("//textarea[@name='textarea']");
	By radio = By.xpath("//input[@name='Radio'][@id='1']");
	By signUp = By.xpath("//a[contains(@onclick,'Appyscript.addUser')]");

	By countryCode = By
			.xpath("//input[contains(@onclick,'Appyscript.popupPage')][contains(@onclick,'login-counrtyCode')]");
	By cCodeList = By.xpath("//li[contains(@onclick,'selectedCountrylogin')]");
	By backfromList = By.xpath("//a[@class='link back']");

	By pwdSuggestions = By.xpath("//li[contains(@class,'password-view')]");
	By pwdType = By.xpath("//input[@id='pass']/following-sibling::em[@class='password-type']");
	

	public AppypieSignUpPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isSignUpPageOpen() {
		boolean open = false;
		WebElement signUpPage = ElementWait.waitForOptionalElement(driver, email, 20);
		if (signUpPage != null) {
			open = true;
		}
		return open;
	}

	public void enterName() {
		PageElement.sendKey(driver, fname, "ActiveUser" + String.valueOf(getUserValue()));
	}

	public void entervalidEmail() {
		PageElement.sendKey(driver, email, "a" + userValue + "@" + userValue + ".com");
	}

	public void enterInvalidEmail() {
		PageElement.sendKey(driver, email, "test@.com");
	}

	public void enterPhone() {
		PageElement.sendKey(driver, pno, String.valueOf(1000000+new Random().nextInt(9000000)));
	}

	public void enterPassword() {
		PageElement.sendKey(driver, pass, "12345678");
	}

	public void shortPassword() {
		PageElement.sendKey(driver, pass, "123456");
	}

	public void enterWrongConfirmPassword() {
		PageElement.sendKey(driver, cpass, "1234567");
	}

	public void enterConfirmPassword() {
		PageElement.sendKey(driver, cpass, "12345678");
	}

	public void selectGender() {
		PageElement.selectByValue(driver, gender, "Male");
	}

	public void enterState() {
		PageElement.sendKey(driver, state, "UttarPradesh");
	}

	public void selectCountry() {
		PageElement.selectByValue(driver, country, "India");
	}

	public void selectCheckBox() {
		WebElement checkBox = ElementWait.waitForOptionalElement(driver, check, 10);
		if (checkBox != null && !checkBox.isSelected()) {
			checkBox.click();
		}
	}

	public void enterText() {
		PageElement.sendKey(driver, text, "SignUp form is tested for automation purpose");
	}

	public void selectList() {
		PageElement.selectByValue(driver, list, "list1");
	}

	public void clickRadio() {
		WebElement radioBtn = ElementWait.waitForOptionalElement(driver, radio, 10);
		if (radioBtn != null) {
			radioBtn.click();
		}
	}

	public void submitSignUp() {
		WebElement submit = ElementWait.waitForOptionalElement(driver, signUp, 10);
		if (submit != null) {
			submit.click();
		}
	}

	public int getUserValue() {
		userValue = FileHandler.fileReader("LoginValue");
		return userValue + 1;
	}

	public void setUserValue() {
		FileHandler.fileWriter("LoginValue", userValue);
	}

	public boolean isCountryCodeFieldExist() {
		boolean exist = false;
		WebElement cCode = ElementWait.waitForOptionalElement(driver, countryCode, 20);
		if (cCode != null) {
			exist = true;
		}
		return exist;
	}

	public void openCountryCodeList() {
		driver.findElement(countryCode).click();
	}

	public boolean isCountryListOpen() {
		boolean exist = false;
		WebElement cCode = ElementWait.waitForOptionalElement(driver, cCodeList, 10);
		if (cCode != null) {
			exist = true;
		}
		return exist;
	}

	public void backFromcCodeList() {
		driver.findElement(backfromList).click();
	}

	public boolean isPasswordSuggestionOpen() {
		boolean open = false;
		WebElement suggestions = ElementWait.waitForOptionalElement(driver, pwdSuggestions, 10);
		if (suggestions != null && suggestions.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String getPasswordType() {
		String type = "";
		WebElement pwd = ElementWait.waitForOptionalElement(driver, pwdType, 10);
		if (pwd != null && pwd.isDisplayed()) {
			type = pwd.getText();
		}
		return type;
	}
}
