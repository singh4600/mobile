package com.appypie.pages.loginpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieForgetPwdPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By mailId = By.id("forpasid");
	By resetPwd = By.xpath("//a[contains(@onclick,'Appyscript.forgotPassword')]");

	public AppypieForgetPwdPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isForgetPwdPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, mailId, 20);
		if (page != null) {
			open = true;
		}
		return open;
	}

	public void resetPwd(String mail) {
		PageElement.sendKey(driver, mailId, mail);
	}

	public void submitResetPwd() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, resetPwd, 5);
		if (btn != null) {
			btn.click();
		}

	}

}
