package com.appypie.pages.OrderFoodPages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class PaymentOptionsPage {
	PageElement pageutil;

	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");

	public By Stripelink=By.xpath("//*[contains(@class,'payment-nav tabs-click')]/a[3]");
	public By paywithCClink=By.xpath("//*[contains(@class,'payment-nav tabs-click')]/a[2]");
	public By CODlink=By.xpath("//*[contains(@class,'payment-nav tabs-click')]/a[1]");
	public By confirmBtn=By.xpath("//*[contains(@id,'tabcod')]/a");
	public By call=By.xpath("//*[contains(@id,'paymentTabs')]//div[2]/a");
	public By callok=By.id("button1");

	//---------Get Text Event------------------------------------------------------
	//public By _gettext=By.xpath("");

	public By codMessage_gettext=By.xpath("//*[contains(@id,'tabcod')]/p");
	public By paywithCCmessage_gettext=By.xpath("//*[contains(@id,'tabobp')]/p");
	public By creditCardThroughStripeMessage_gettext=By.xpath("//*[contains(@id,'creditCardThroughStripe')]/p");

	
	//-------------------------------------------------------------------------------
	public PaymentOptionsPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
		pageutil=new PageElement();
	}
	


}
