package com.appypie.pages.FoodCourt;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class OrderPreview {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By checkoutbtn= By.xpath("//*[contains(@onclick,'foodCourtPayment')]");

	public By wallet= By.xpath("//*[contains(@label,'Cash on Delivery')]");
	public By CreditCard= By.xpath("//*[contains(@label,'orders@mobuherbals.com')]");
	public By PayPalExpress= By.xpath("//*[contains(@label,'PayPal Express')]");
	public By phone= By.xpath("//*[contains(@label,'Pay with credit card over the phone')]");
	public By callme= By.xpath("//*[@id='tabobp']/a");
	public By Stripe= By.xpath("//*[contains(@label,'Credit Card via Stripe Payment Gateway')]");
	public By confirm_btn= By.xpath("//*[@id='tabcod']/a");

	public By continueOrderingBtn= By.xpath("//*[contains(@onclick,'gotoHome')]");

	//--------------------------------Get Text----------------------------
	//public By  _getText=By.xpath("");

	public By  orderPreview_getText=By.xpath("//*[contains(@class,'food-Order orer-confirm')]");

	public By payatHotelHeading_gettext=By.xpath("//*[@id='tabcod']/p");
	public By CreditCardviaPayPal_gettext=By.xpath("//*[@id='creditCardThroughPaypal']/p");
	public By PayPalExpress_gettext=By.xpath("//*[@id='tabpaypal']/p");
	public By Paywithcreditcard_gettext=By.xpath("//*[@id='tabobp']/p");
	public By Stripe_gettext=By.xpath("//*[@id='creditCardThroughStripe']/p");

	public By  thanksPage_getText=By.xpath("//*[contains(@class,'food-Order orer-confirm')]");

	public By getsharebyItem=By.className("android.widget.TextView");
	
	
	public By  orderconfirmationHeading_getText=By.xpath("//*[@class='food-Order orer-confirm']/div[1]/h3");
	public By  orderconfirmationDetails_getText=By.xpath("//*[@class='food-Order orer-confirm']/div[2]");
	public By  oderIDPaymentType_getText=By.xpath("//*[@class='food-Order orer-confirm']/div[3]/h3");
	public By  productNamePayment_getText=By.xpath("//*[@class='food-Order orer-confirm']/div[4]//li");
	public By  billingPickUpAddress_getText=By.xpath("//*[@class='food-Order orer-confirm']/div[5]/li");
	public By  continueOrderingBtnthnakspage=By.xpath("//*[contains(@onclick,'gotoHome')]");	
	

	public OrderPreview(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}




}