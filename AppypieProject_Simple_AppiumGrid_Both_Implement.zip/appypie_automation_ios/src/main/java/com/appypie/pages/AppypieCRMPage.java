package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieCRMPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By crmHeader = By.xpath("//div[@class='navbar']//div[text()='CRM']");
	By zoho = By.xpath("//a[@data-identifire='zoho']");
	By salesForce = By.xpath("//a[@data-identifire='salesforce']");

	public AppypieCRMPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isCRMPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, crmHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openCRMs(String type) {
		WebElement url = null;
		if (type.equals("zoho")) {
			url = ElementWait.waitForOptionalElement(driver, zoho, 20);
		} else {
			url = ElementWait.waitForOptionalElement(driver, salesForce, 20);
		}
		if (url != null && url.isDisplayed()) {
			url.click();
		} else {
			Logger.info(type + " CRM url doesn't exist");
		}

	}

}
