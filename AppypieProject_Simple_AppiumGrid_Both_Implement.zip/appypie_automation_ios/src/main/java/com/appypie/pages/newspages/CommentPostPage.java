package com.appypie.pages.newspages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class CommentPostPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By postBtn = By.xpath("//div[contains(@onclick,'Appyscript.DonePastComment')]");
	By commentBox = By.xpath("//textarea[@id='text']");
	By comment = By.xpath("//div[@class='user-comments']/ul/li/p");
	By postDate = By.xpath("//div[@class='user-comments']/ul/li/div/small");
	By userName = By.xpath("//div[@class='user-comments']/ul/li/div/span");

	public CommentPostPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isCommentPostPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, postBtn, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isCommentBoxDisplayed() {
		boolean display = false;
		WebElement box = ElementWait.waitForOptionalElement(driver, commentBox, 10);
		if (box != null && box.isDisplayed()) {
			display = true;
		}
		return display;
	}

	public void postComment() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, postBtn, 20);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

	public void writeComment(String data) {
		PageElement.sendKey(driver, commentBox, data);
	}

	public String getComment() {
		String text = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, comment, 20);
		if (element != null && element.isDisplayed()) {
			text = element.getText();
		}
		return text;
	}

	public String getUserName() {
		String text = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, userName, 20);
		if (element != null && element.isDisplayed()) {
			text = element.getText();
		}
		return text;
	}

	public String getPostDate() {
		String text = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, postDate, 20);
		if (element != null && element.isDisplayed()) {
			text = element.getText();
		}
		return text;
	}

	public String getCurrentDate() {
		SimpleDateFormat sdfDate = new SimpleDateFormat("MMM/dd/yyyy hh:mm a");
		sdfDate.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date now = new Date();
		String strDate = sdfDate.format(now);
		return strDate;
	}
	
	public boolean isPreviousCommentsExist(){
		boolean exist= false;
		List<WebElement> posts= ElementWait.waitForAllOptionalElements(driver, comment, 10);
		if(posts.size()>1){
		exist=true;
		}
		return exist;
	}

}
