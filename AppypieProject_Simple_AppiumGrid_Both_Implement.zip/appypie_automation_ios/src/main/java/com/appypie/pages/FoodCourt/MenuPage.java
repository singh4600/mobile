package com.appypie.pages.FoodCourt;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

public class MenuPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger = Log.createLogger();
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");

	 public By closeMenulink= By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");
	 public By mainMenulink= By.xpath("//*[text() ='Main Menu']");
	 public By myAccountlink= By.xpath("//*[text() ='My Account']");
	 public By favoritelink= By.xpath("//*[text() ='Favorite']");
	 public By offeredlink= By.xpath("//*[text() ='Offered']");
	 public By myOrderlink= By.xpath("//*[text() ='My Orders']");
	 public By cartlink= By.xpath("//*[text() ='Cart']");
	 public By logoutlink= By.xpath("//*[text() ='Logout']");
	 
	 
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	 public By usename_gettext=By.xpath("//*[@id ='userName']");
	 public By address_gettext=By.xpath("//*[@id ='userLocation']");
	 public By menuList_gettext=By.xpath("//*[@class ='leftMenu']/li");
	 	public By searchMenuItem=By.xpath("//*[@class='searchBx']//*[@id='foodtxtSearch']");
	 

	
	

	// ------------------For Default Method-----------------
	public By AlertHeader_gettext = By.xpath("//*[@class='modal-title']");
	public By AlertText_gettext = By.xpath("//*[@class='modal-text']");
	public By AlertOkButton = By.xpath("//*[@class='modal-button modal-button-bold']");
	public By BackButton = By.xpath("//*[@class='link back']");
	public By BackButtonNative = By.id("icon1_button");

	public By BackButtonNativeforsigngoogle = By.className("android.widget.ImageButton");

	public By getListItem = By.xpath("//*[contains(@class,'appypie-list')]");
	public By header_gettext = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	public By header_gettext_native = By.id("text_Tittle");

	public MenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}

	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext) {
		try {
			String gettextmessage = ElementWait.waitForOptionalElement(driver, gettext, 50).getText();
			Logger.info("Inner Page Text is :" + gettextmessage);
			return gettextmessage;
		} catch (Exception e) {
			System.out.println("Error getting text:  " + e);
		}
		return runningTest1;
	}

	public void IfAlertpresent() throws InterruptedException {
		boolean alert = false;
		alert = driver.findElements(By.xpath("//*[@class='modal-title']")).size() != 0;
		if (alert) {
			System.out.println("Alert is present");
			getPagetext(driver, AlertHeader_gettext);
		
			Boolean alerttext=IselementPresent(AlertText_gettext);
			if (alerttext) {
				getPagetext(driver, AlertText_gettext);
			}
			else{
				System.out.println("Alert text Message is not present.");
			}
			AlertOkButtonMethod();
		} else {
			System.out.println("Alert is Not present");
		}
	}


	public void AlertOkButtonMethod() throws InterruptedException {
		WebElement open = ElementWait.waitForOptionalElement(driver, AlertOkButton, 50);
		if (open != null && open.isDisplayed()) {
			open.click();
			TimeUnit.SECONDS.sleep(2);
		} else {
			System.out.println("Alert Ok Button is not present ");
		}
	}

	public void swipingHorizontal() throws InterruptedException {
		driver.context("NATIVE_APP");
		TimeUnit.SECONDS.sleep(2);

		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);

			// Find swipe start and end point from screen's with and height.
			// Find startx point which is at right side of screen.
			int startx = (int) (size.width * 0.70);
			// Find endx point which is at left side of screen.
			int endx = (int) (size.width * 0.30);
			// Find vertical point where you wants to swipe. It is in middle of
			// screen height.
			int starty = size.height / 2;
			// System.out.println("startx = " + startx + " ,endx = " + endx + "
			// , starty = " + starty);
			// Swipe from Right to Left.
			driver.swipe(startx, starty, endx, starty, 300);
			TimeUnit.SECONDS.sleep(2);

			/*
			 * //Swipe from Left to Right. driver.swipe(endx, starty, startx,
			 * starty, 3000); Thread.sleep(2000);
			 */
		} catch (Exception e) {
			System.out.println("Errpr in swipingHorizontal()");
		}
		PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);

	}

	public void SwipetopTobottom() throws InterruptedException {
		driver.context("NATIVE_APP");
		TimeUnit.SECONDS.sleep(2);
		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);
			// Find swipe start and end point from screen's with and height.
			// Find starty point which is at bottom side of screen.
			int starty = (int) (size.height * 0.80);
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle
			// of screen width.
			int startx = size.width / 2;
			// System.out.println("starty = " + starty + " ,endy = " + endy + "
			// , startx = " + startx); // ye wala h ================
			// Swipe from Bottom to Top.
			// driver.swipe(startx, starty, startx, endy, 3000);
			TimeUnit.SECONDS.sleep(3);
			// Swipe from Top to Bottom.
			driver.swipe(startx, endy, startx, starty, 3000);
			TimeUnit.SECONDS.sleep(3);
		} catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);
	}

	public void SwipeBottomToTop() throws InterruptedException {
		// driver.context("NATIVE_APP");
		TimeUnit.SECONDS.sleep(2);
		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);
			// Find swipe start and end point from screen's with and height.
			// Find starty point which is at bottom side of screen.
			int starty = (int) (size.height * 0.80);
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle
			// of screen width.
			int startx = size.width / 2;
			// System.out.println("starty = " + starty + " ,endy = " + endy + "
			// , startx = " + startx); // ye wala h ================
			// Swipe from Bottom to Top.
			driver.swipe(startx, starty, startx, endy, 3000);
			TimeUnit.SECONDS.sleep(3);
			// Swipe from Top to Bottom.
			// driver.swipe(startx, endy, startx, starty, 3000);
			TimeUnit.SECONDS.sleep(3);
		} catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		// PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);
	}

	// =====================================================================================

	// ---------------------------Methods--------------------------------------------------s
	public void BackButtonNative(By link) throws InterruptedException {

		driver.context("NATIVE_APP");

		WebElement open = ElementWait.waitForOptionalElement(driver, link, 20);
		if (open != null && open.isDisplayed()) {
			open.click();
			TimeUnit.SECONDS.sleep(2);
		} else {
			System.out.println("Native Back Button is not present ");
		}
		PageElement.changeContextToWebView(driver);
	}

	public boolean Openlinks(By link) throws InterruptedException {
		boolean links = false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			linkpresent.click();
			TimeUnit.SECONDS.sleep(3);
			links = true;
		} else {
			System.out.println(("Link is not present"));
		}
		return links;
	}

	public boolean TextField(By link, String entertext) {
		boolean links = false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			links = true;
			linkpresent.sendKeys(entertext);
			try {
				driver.hideKeyboard();
			} catch (Exception e) {
				System.out.println("hideKeyboard()");
			}
		} else {
			System.out.println(("Link is not present"));
		}
		return links;
	}

	public String Getactualtext(By gettext) {
		String Actualtext = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, gettext, 20);
		if (element != null && element.isDisplayed()) {
			Actualtext = element.getText();
			System.out.println("Get Text:  " + Actualtext);
		}
		return Actualtext;
	}

	public boolean IselementPresent(By textvalue) throws InterruptedException {
		boolean text = false;
		WebElement textpresent = ElementWait.waitForOptionalElement(driver, textvalue, 20);
		if (textpresent != null && textpresent.isDisplayed()) {
			text = true;
			TimeUnit.SECONDS.sleep(2);
		} else {
			System.out.println(("Link is not present"));
		}
		return text;
	}

	public String printExceptionTrace(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}

/*	public void getListofLink(By link) throws InterruptedException {
		TimeUnit.SECONDS.sleep(3);
		System.out.println("To check and get share by links in the phone.");
		WebElement textpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (textpresent != null && textpresent.isDisplayed()) {

			List<MobileElement> allSuggestions = driver.findElements(link);
			for (WebElement suggestion : allSuggestions) {
				System.out.println("List By Items:   " + suggestion.getText());
				System.out.println("-----------------------------------------");
			}
			TimeUnit.SECONDS.sleep(3);

		} else {
			System.out.println("list not present");

		}
	}*/
	public boolean getListofLink(By link) throws InterruptedException {
		boolean text = false;
		TimeUnit.SECONDS.sleep(2);
		List<MobileElement> listpresent = driver.findElements(link);
		if(listpresent!=null){
			List<MobileElement> allSuggestions = driver.findElements(link);
			for (WebElement suggestion : allSuggestions) {
				System.out.println(suggestion.getText());
				System.out.println("--------------------------");
			}
			TimeUnit.SECONDS.sleep(3);
			text = true;
		}
		else{
			System.out.println("List is not present");
		}
		return text;


	}

	
	public void countryselect() throws InterruptedException{
	try{
		driver.context("NATIVE_APP");
	driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("+ "new UiSelector().text(\"India\"));")).click();
	PageElement.changeContextToWebView(driver);
	}
	catch (Exception e) {
		System.out.println("India is not present");
	}
		
	}
	
	
}
