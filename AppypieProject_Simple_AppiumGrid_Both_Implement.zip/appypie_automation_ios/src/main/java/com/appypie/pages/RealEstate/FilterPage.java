package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class FilterPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By sellTab= By.xpath("//*[contains(@class,'tabs')]/a[1]");
	public By rentTab= By.xpath("//*[contains(@class,'tabs')]/a[2]");
	public By distanceNative= By.xpath("//*[@bounds='[280,498][372,572]']");
	public By princeNative= By.xpath("//*[@bounds='[241,863][333,937]']");
	public By listedBylink= By.xpath("//*[contains(@class,'real-estate filter-page')]/div[6]");
	public By ownercheckbox= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertyownertye')]//li[1]");
	public By ownercheckbox_P= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertyownertye')]/ul[1]/li[1]");
	public By builderCheckbox= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertyownertye')]//li[2]");
	public By builderCheckbox_P= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertyownertye')]/ul[1]/li[2]");
	public By brokerCheckbox= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertyownertye')]//li[3]");
	public By brokerCheckbox_P= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertyownertye')]/ul[1]/li[3]");
	public By propertyType= By.xpath("//*[contains(@class,'real-estate filter-page')]/div[7]");
	public By villachCheckbox= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertytype')]/ul[1]/li[1]");
	public By hostelCheckbox= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertytype')]/ul[1]/li[2]");
	public By apartimentCheckbox= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox propertytype')]/ul[1]/li[3]/i[2]");
	public By bedRooms= By.xpath("//*[contains(@class,'selecter filterbed')]/span[2]");
	public By bathRoom= By.xpath("//*[contains(@class,'selecter filterbath')]/span[2]");
	
	public By amenities= By.xpath("//*[contains(@class,'real-estate filter-page')]/div[11]");
	public By sunTerrace= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox amentfilter')]/ul[1]/li[22]");
	
	public By applyBtn= By.xpath("//*[contains(@onclick,'filterdata')]");
	
	public By slider= By.xpath("//android.view.View[@index='2']");
	public By leftSliderDistance = By.xpath("//*[contains(@class,'real-estate filter-page')]/div[2]//div[@class='noUi-handle'][@data-handle='0']");
	public By rightSliderDistance = By.xpath("//*[contains(@class,'real-estate filter-page')]/div[2]//div[@class='noUi-handle'][@data-handle='1']");
	
	public By leftSliderPrice = By.xpath("//*[contains(@class,'real-estate filter-page')]/div[5]//div[@class='noUi-handle'][@data-handle='0']");
	public By rightSliderPrice = By.xpath("//*[contains(@class,'real-estate filter-page')]/div[5]//div[@class='noUi-handle'][@data-handle='1']");
	
	public By distanceBAR= By.xpath("//*[@id='slider']");
	public By priceBAR= By.xpath("//*[@id='sliderprice']");
	
	//-----------sort By------------------------------------
	 public By recentAddedRediobtn= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox')]/ul/li[4]/input");
	 public By priceHtoLRediobtn= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox')]/ul/li[3]/input");
	 public By priceLtoHRediobtn= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox')]/ul/li[2]/input");
	 public By distanceRediobtn= By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox')]/ul/li[1]/input");
	 public By applyBtnsortBy= By.xpath("//*[contains(@onclick,'sortingdata')]");

	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	 public By sortBylist_gettext=By.xpath("//*[contains(@class,'checklist amenities-list listrow toggleBox')]/ul/li");




	public FilterPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
	

}