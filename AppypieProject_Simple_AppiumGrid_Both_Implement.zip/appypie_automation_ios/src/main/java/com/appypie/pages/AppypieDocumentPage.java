package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieDocumentPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	public By gDrive = By.xpath("//a[contains(@onclick,'Appyscript.DocumentGdriveopenpage')]");
	//public By  = By.xpath("");
	public By gettingStarted= By.xpath("//*[contains(@class,'dc_list')]/li[1]");
	public By i_gettingStartedHeader= By.xpath("//XCUIElementTypeStaticText[@name='Getting started']");
	public By i_BackBtngettingStartedHeader= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeButton");
	public By TEST= By.xpath("//*[contains(@class,'dc_list')]/li[2]");
	public By i_headerTEST= By.xpath("//XCUIElementTypeStaticText[@name='TESt']");
	public By i_BackBtnTEST= By.xpath("//XCUIElementTypeStaticText[@name='TESt']//preceding-sibling::XCUIElementTypeButton");
	public By oneDrive = By.xpath("//a[contains(@onclick,'Appyscript.DocumentOnedriveaccesToken')]");

	public By search = By.id("docsearchid2");
	public By gridViewBtn = By.xpath("//span[contains(@onclick,'Appyscript.dcGridView')]");
	public By gdata1 = By.xpath("//ul[contains(@class,'dc_list')]/li[1]");
	public By gdata2 = By.xpath("//ul[contains(@class,'dc_list')]/li[2]");
	public By gdata3 = By.xpath("//ul[contains(@class,'dc_list')]/li[3]");
	public By gdata4 = By.xpath("//ul[contains(@class,'dc_list')]/li[4]");

	public By listView = By.xpath("//ul[contains(@class,'dc_list')]");
	public By gridView = By.xpath("//ul[contains(@class,'dc_list') and contains(@class,'dc_list_view')]");

	public AppypieDocumentPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isDocumentPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, gDrive, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openGoogleDrive() {
		WebElement page = ElementWait.waitForOptionalElement(driver, gDrive, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		}
	}

	public void openOneDrive() {
		WebElement page = ElementWait.waitForOptionalElement(driver, oneDrive, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		}
	}
	
	public void openDriveContent() {
		WebElement data = ElementWait.waitForOptionalElement(driver, gdata1, 20);
		if (data != null && data.isDisplayed()) {
			data.click();
		}
	}

	public boolean isDriveOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, search, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickGridView() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, gridViewBtn, 20);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}
	
	public boolean isGridViewDisplayed(){
		boolean display = false;
		WebElement view = ElementWait.waitForOptionalElement(driver, gridView, 20);
		if (view != null && view.isDisplayed()) {
			display = true;
		}
		return display;	
	}
	
	public void typeSearchKeyWord(String data){
		PageElement.sendKey(driver, search, data);	
	}
	
	public boolean isOnKeyUpSearchWorking(){
	 boolean success= false;
	 WebElement data= ElementWait.waitForOptionalElement(driver, gdata1, 20);
	 if(data!=null && !data.isDisplayed()){
		 String value= data.getAttribute("style");
		 success= true;
	 }
	 return success;
	}
      
}
