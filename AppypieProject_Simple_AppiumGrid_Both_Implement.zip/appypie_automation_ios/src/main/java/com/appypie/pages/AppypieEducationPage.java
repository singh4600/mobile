package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieEducationPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By dictionary = By.xpath("//a[@data-identifire='Dictionary']");
	By search = By.id("search");
	By searchtn = By.xpath("//a[contains(@onclick,'SearchDictionary')]");
	By searchResult = By.xpath("//div[@id='result']/h2");

	By khanAcad = By.xpath("//a[@data-identifire='khanAcademy']");
	By khanHome = By.id("KhanForm");
	By khanCat = By.id("KhanSelect");
	By khanSearch = By.id("search_KhanAcademyCat");
	By khanSearchBtn = By.xpath("//a[contains(@onclick,'Appyscript.khanacademySearch')]");

	By khanResult = By.xpath("//div[@data-page='education-khanAcademyDetail']");
	By alertText = By.id("message");
	By alertOk = By.id("button1");

	public AppypieEducationPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isEducationPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, dictionary, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openEducation(String type) {
		WebElement edu = null;
		if (type.equals("dict")) {
			edu = ElementWait.waitForOptionalElement(driver, dictionary, 10);
		} else {
			edu = ElementWait.waitForOptionalElement(driver, khanAcad, 10);
		}
		if (edu != null && edu.isDisplayed()) {
			edu.click();
		}
	}

	public boolean isDictionaryOpen() {
		boolean open = false;
		WebElement dict = ElementWait.waitForOptionalElement(driver, search, 20);
		if (dict != null && dict.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void typeSearchKeyWord(String type, String data) {
		if (type.equals("dict")) {
			PageElement.sendKey(driver, search, data);
		} else {
			PageElement.sendKey(driver, khanSearch, data);
		}
	}

	public void pressSearchBtn(String type) {
		WebElement btn = null;
		if (type.equals("dict")) {
			btn = ElementWait.waitForOptionalElement(driver, searchtn, 10);
		} else {
			btn = ElementWait.waitForOptionalElement(driver, khanSearchBtn, 10);
		}
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

	public boolean isResultDisplayed(String type) {
		boolean display = false;
		WebElement result = null;
		if (type.equals("dict")) {
			result = ElementWait.waitForOptionalElement(driver, searchResult, 20);
		} else {
			result = ElementWait.waitForOptionalElement(driver, khanResult, 20);
		}
		if (result != null && result.isDisplayed()) {
			display = true;
		}
		return display;
	}

	public boolean isKhanAcadOpen() {
		boolean open = false;
		WebElement khan = ElementWait.waitForOptionalElement(driver, khanHome, 30);
		if (khan != null && khan.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void selectCategoryInkhanAcad(String value) {
		PageElement.selectByValue(driver, khanCat, value);
	}

	public String getEduAlertText() {
		String text = "";
		driver.context("NATIVE_APP");
		WebElement alert = ElementWait.waitForOptionalElement(driver, alertText, 10);
		if (alert != null && alert.isDisplayed()) {
			text = alert.getAttribute("text");
			closeEduAlert();
		}
		PageElement.changeContextToWebView(driver);
		return text;
	}

	public void closeEduAlert() {
		WebElement ok = ElementWait.waitForOptionalElement(driver, alertOk, 10);
		if (ok != null && ok.isDisplayed()) {
			ok.click();
		}
	}
}
