package com.appypie.pages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieStorePage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	By Storelink= By.xpath("//a[@data-productid='ecommerce']"); //click store module
	By subcategorylink= By.xpath("//ul[contains(@class,'categories-list dataProduct')]"); // click on sub category link
	By dirtCartlink= By.xpath("//i[@class='icon-cart cursor-pointer']");
	By searchlink= By.xpath("//a[contains(@class,'icon-search')]"); // click on search link
	By detailproductcameralink= By.xpath("//li[contains(@productid,'340777')]");
	By detailproductphonelink= By.xpath("//li[contains(@productid,'340776')]");
	By addtocartcarmera_phonelink= By.xpath("//div[@class='swiper-slide product-swiper-slide swiper-slide-active']//div[@class='product-button']/a"); 

	By backbuttononDirectCart= By.xpath("//a[@class='link back']");
	By backbuttononsubcategory= By.xpath("//a[@class='link back']");
	By backbuttononProductDetail= By.xpath("//div[@class='navbar-inner navbar-on-center']//a[@class='link back']");

	By BackButtonCartPage= By.xpath("//div[@class='navbar-inner navbar-on-center']//a[@class='link back']");
	By BackButtonorderdetailPage= By.xpath("//div[@class='navbar-inner navbar-on-center']//a[@class='link back']");
	By checkoutlink= By.xpath("//a[contains(@onclick,'proceedToPaydetails')]");
	By checkincreaseproductlink= By.xpath("//*[@class='add']"); 
	By checkdecreaseproductlink= By.xpath("//*[@class='less']");
	By checkcouponcodecartpage= By.xpath("//*[@id='couponCode']");
	By checkcouponcodeapplybuttoncartpage= By.xpath("//a[@class='apply arial mediumContent']");
	By checkdeleteproductlink= By.xpath("//*[@class='delete']");

	By name= By.id("bfname"); // fist name
	By Telephone= By.id("bpNo"); // mobile no
	By Email= By.id("email"); // email id
	By Address= By.id("bAddress"); // address
	By City= By.id("bCity"); // city
	By State= By.id("bState"); // state
	By Zip= By.id("bZip"); // zip
	By Country= By.id("bCountry"); // country
	//By Deliveryaddresscheckbox= By.id("show_billing_address"); // billing address
	By paynowlink= By.xpath("//a[contains(@onclick,'ecommercePayment')]");
	By Confirmpaynowlink= By.xpath("//a[contains(@class,'BtText arial mediumContent')]");
	By ContinueShoppinglink= By.xpath("//a[contains(@onclick,'ClearHistryHomePage')]");


	By Menulink=By.xpath("//a[@class='link menu-down']"); // click on menu link
	By AppHomelink=By.xpath("//a[contains(@onclick,'Appyscript.clickHome')]");   // click on home link   
	By Myshoplink=By.xpath("//i[@class='icon-indent-left']");  // click on my shop link
	By cartlink=By.xpath("//i[@class='icon-cart']");  // click on cart link
	By loginlink=By.xpath("//a[contains(@onclick,'Appyscript.loginPage')]");  // click on Login/SignUp link
	
	By home=By.xpath("//*[@id='menuservice']/ul/li[1]/a"); // click on menu link
	By myshop=By.xpath("//*[contains(text(),'My Shop')]");   // click on home link   
	By cart=By.xpath("//*[contains(text(),'Cart')]");  // click on my shop link 
	By featuredProduct=By.xpath("//*[contains(text(),'Featured Products')]");  // click on cart link
	By offer=By.xpath("//*[contains(text(),'Offers')]");  // click on Login/SignUp link  
	By Login_Signup=By.xpath("//*[@id='menuservice']/ul/li[6]/a");  // click on Login/SignUp link
	By logout=By.xpath("//*[contains(text(),'Logout')]");  // click on Login/SignUp link
	
	By Singuplink=By.xpath("//a[contains(@onclick,'signup')]"); // click on sign up link
	By fullnametext=By.xpath("//*[@id='fname']");  // enter on name
	By Emailtext=By.xpath("//*[@id='emailId']"); // enter emailid
	By phonetext=By.xpath("//*[@id='pNo']"); // enter phone no.
	By passwordtext=By.xpath("//*[@id='pass']"); //enter password
	By conformpasswordtext=By.xpath("//*[@id='cpass']"); // enter conform password
	By Signupbutton=By.xpath("//a[contains(@onclick,'Appyscript.addUser')]"); // click on submit sigup button.

	By username=By.xpath("//*[@id='loginid']"); // enter username
	By password=By.xpath("//*[@id='loginpass']"); // enter password
	By LoginBtn=By.xpath("//li[@class='login-btn']"); // click on Login button.

	static SoftAssert softassert;
	//By Page= By.xpath("");

	public AppypieStorePage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}

	public void openStorePage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, Storelink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Store page is not present in main menu");
		}
	}
//----------------------------Menu page---------------------------------------------------

	
	public void HomeLinkMenuPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, home, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Home link is not present in main menu");
		}
	}

	public void MyShopLinkMenuPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, myshop, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("My Shop link is not present in main menu");
		}
	}
	
	public void CartLinkMenuPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, cart, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Cart link is not present in main menu");
		}
	}
	
	public void FeatureproductlinkmenuPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, featuredProduct, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Featured Product link is not present in main menu");
		}
	}
	
	public void OfferLinkMenuPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, offer, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Offer link is not present in main menu");
		}
	}
	
	public void LoginSignupLinkMenuPage() throws InterruptedException{	
		try{
		WebElement open= ElementWait.waitForOptionalElement(driver, Login_Signup, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Login_Signup link is not present in main menu");
		}
		}catch (Exception e) {

		WebElement open1= ElementWait.waitForOptionalElement(driver, logout, 50);
		if(open1!=null && open1.isDisplayed()){
			open1.click();
		}
		else{
			softassert.fail("Login_Signup link is not present in main menu");
		}	
	}		
		
	}
	
	

//----------------------------------------------------------------------------------------
	//-------------------Login/signup----------------------------
	public void RegisteredUser(){
		WebElement Emailtext= ElementWait.waitForOptionalElement(driver, username, 40);
		if(Emailtext!=null && Emailtext.isDisplayed()){
			Emailtext.sendKeys("prince@appypie.com");
			driver.navigate().back();}
		else{
			softassert.fail("username page is not present in main menu");
		}
		
		WebElement Passwordtext= ElementWait.waitForOptionalElement(driver, password, 40);
		if(Passwordtext!=null && Passwordtext.isDisplayed()){
			Passwordtext.sendKeys("12345678");
			driver.navigate().back();}
		else{
			softassert.fail("password page is not present in main menu");
		}
		
		WebElement Loginbtn= ElementWait.waitForOptionalElement(driver, LoginBtn, 40);
		if(Loginbtn!=null && Loginbtn.isDisplayed()){
			Loginbtn.click();}
		else{
			softassert.fail("LoginBtn page is not present in main menu");
		}
		
	}
	
	public void RegistrationUser() throws InterruptedException{
		TimeUnit.SECONDS.sleep(5);
		WebElement signupopen= ElementWait.waitForOptionalElement(driver, Singuplink, 40);
		if(signupopen!=null && signupopen.isDisplayed()){
			signupopen.click();}
		else{
			softassert.fail("Sign up now page is not present in main menu");
		}
		
		WebElement Fullnametxt= ElementWait.waitForOptionalElement(driver, fullnametext, 40);
		if(Fullnametxt!=null && Fullnametxt.isDisplayed()){
			Fullnametxt.sendKeys("anurag");}
		else{
			softassert.fail("Fullnametxt page is not present in main menu");
		}
		
		WebElement Emailtxt= ElementWait.waitForOptionalElement(driver, Emailtext, 40);
		if(Emailtxt!=null && Emailtxt.isDisplayed()){       
			Emailtxt.sendKeys("prince@appypie.com");}
		else{
			softassert.fail("Emailtxt page is not present in main menu");
		}
		
		WebElement phonetxt= ElementWait.waitForOptionalElement(driver, phonetext, 40);
		if(phonetxt!=null && phonetxt.isDisplayed()){
			phonetxt.sendKeys("9540198626");}
		else{
			softassert.fail("phonetxt page is not present in main menu");
		}
		
		WebElement passwordtxt= ElementWait.waitForOptionalElement(driver, passwordtext, 40);
		if(passwordtxt!=null && passwordtxt.isDisplayed()){
			passwordtxt.sendKeys("12345678");}
		else{
			softassert.fail("passwordtxt page is not present in main menu");
		}
		
		WebElement Confpasstxt= ElementWait.waitForOptionalElement(driver, conformpasswordtext, 40);
		if(Confpasstxt!=null && Confpasstxt.isDisplayed()){
			Confpasstxt.sendKeys("12345678");}
		else{
			softassert.fail("conformpasswordtext page is not present in main menu");
		}
		
		WebElement sigupsubmitbtn= ElementWait.waitForOptionalElement(driver, Signupbutton, 40);
		if(sigupsubmitbtn!=null && sigupsubmitbtn.isDisplayed()){
			sigupsubmitbtn.click();
			TimeUnit.SECONDS.sleep(5);
			boolean alert=false;
			alert=driver.findElements(By.xpath("//div[@class='modal-text']")).size()!=0;
			if(alert){
				System.out.println("Alert is present :"+driver.findElement(By.xpath("//div[@class='modal-text']")).getText());
				driver.findElement(By.xpath("//span[@class='modal-button modal-button-bold']")).click();
				driver.findElement(By.xpath("//*[@class='link back']")).click();
			}
			else
				System.out.println("Alert Not persent");
		}
		else{
			softassert.fail("sign-up submit button page is not present in main menu");
		}
	}
	

//----------------------------------------------------------------------------------------	
	public void backbuttondirectcartpage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, backbuttononDirectCart, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Back Button on Direct cart page is not present");
		}
	}


	public void opensubcategorylink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, subcategorylink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("sub-category link page is not present in main menu");
		}
	}

	public void backbuttonSubCategorypage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, backbuttononsubcategory, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Back Button on sub category page is not present");
		}
	}

	public void opendetailproductcameralink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, detailproductcameralink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("detail product camera link page is not present in main menu");
		}
	}

	public void opendetailproductphonelink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, detailproductphonelink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("detail product Phone link page is not present in main menu");
		}
	}


	public void backbuttonProductDetailpage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, backbuttononProductDetail, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Back Button on Product details page is not present");
		}
	}

	public void openaddtocartcarmera_phonelink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, addtocartcarmera_phonelink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("addtocartcarmera_phonelink page is not present in main menu");
		}
	}

	public void BackButtonCartPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, BackButtonCartPage, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Back Button on Cart page is not present");
		}
	}

	public void IncreaseproductCartPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, checkincreaseproductlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Increase product button on Cart page is not present");
		}
	}

	public void DecreaseproductCartPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, checkdecreaseproductlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Decrease product button on Cart page is not present");
		}
	}

	public void checkCouponcodecartpage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,checkcouponcodecartpage , 50);
		if(open!=null && open.isDisplayed()){
			open.sendKeys("abcde");
		}
		else{
			softassert.fail("Check Coupon code on Cart page is not present");
		}
	}

	public void checkCouponcodeApplybuttoncartpage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,checkcouponcodeapplybuttoncartpage , 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(5);
			String msg=driver.findElement(By.xpath("//div[@class='modal-text']")).getText();
			if(msg.equalsIgnoreCase("Invalid Coupon")){
				System.out.println("Invalid coupon");
				driver.findElement(By.xpath("//*[@class='modal-button modal-button-bold']")).click();
			}
			else
				System.out.println("coupon ia apply");
		}
		else{
			softassert.fail("Check Coupon code on Cart page is not present");
		}
	}

	public void DeleteProductOnCartpage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, checkdeleteproductlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Decrease product button on Cart page is not present");
		}
	}


	public void opencheckoutlink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, checkoutlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("checkoutlink page is not present in main menu");
		}
	}



	public void BackButtonorderdetailPage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, BackButtonorderdetailPage, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Back Button on Cart page is not present");
		}
	}



	public void Orderaddressdetail() throws InterruptedException{

		WebElement nametext= ElementWait.waitForOptionalElement(driver, name, 40);
		if(nametext!=null && nametext.isDisplayed()){
			nametext.clear();
			nametext.sendKeys("anurag");
			driver.navigate().back();
		}
		else{
			softassert.fail("name page is not present in main menu");
		}

		WebElement Emailtext= ElementWait.waitForOptionalElement(driver, Email, 40);
		if(Emailtext!=null && Emailtext.isDisplayed()){
			Emailtext.clear();
			Emailtext.sendKeys("anurag@yopmail.com");
			driver.navigate().back();
		}
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}

		WebElement Telephonetext= ElementWait.waitForOptionalElement(driver, Telephone, 40);
		if(Telephonetext!=null && Telephonetext.isDisplayed()){
			Telephonetext.clear();
			Telephonetext.sendKeys("9540198626");
			driver.navigate().back();}
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}


		WebElement Addresstext= ElementWait.waitForOptionalElement(driver, Address, 40);
		if(Addresstext!=null && Addresstext.isDisplayed()){
			Addresstext.clear();
			Addresstext.sendKeys("anurag");
			driver.navigate().back();
		}
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}

		WebElement Citytext= ElementWait.waitForOptionalElement(driver, City, 40);
		if(Citytext!=null && Citytext.isDisplayed()){
			Citytext.clear();
			Citytext.sendKeys("noida");
			driver.navigate().back();
		}                              
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}

		WebElement Statetext= ElementWait.waitForOptionalElement(driver, State, 40);
		if(Statetext!=null && Statetext.isDisplayed()){
			Statetext.clear();
			Statetext.sendKeys("UTTAR PRADESH");
			driver.navigate().back();
		}                                                                            
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}

		WebElement Ziptext= ElementWait.waitForOptionalElement(driver, Zip, 40);
		if(Ziptext!=null && Ziptext.isDisplayed()){
			Ziptext.clear();
			Ziptext.sendKeys("203010");
			driver.navigate().back();
		}
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}

		WebElement Countrytext= ElementWait.waitForOptionalElement(driver, Country, 40);
		if(Countrytext!=null && Countrytext.isDisplayed()){
			WebElement mySelectElement = driver.findElement(By.id("bCountry"));
			Select dropdown= new Select(mySelectElement);
			dropdown.selectByVisibleText("India");
			TimeUnit.SECONDS.sleep(5);
		}
		else{
			softassert.fail("opencheckout page is not present in main menu");
		}

		/*	WebElement Paynow= ElementWait.waitForOptionalElement(driver, paynowlink, 20);
		if(Paynow!=null && Paynow.isDisplayed()){
			TimeUnit.SECONDS.sleep(5);
			Paynow.click();
			//  driver.navigate().back();
		}
		else{
			softassert.fail("Pay now page is not present in main menu");
		}*/
	}

	public void checkPaynowButtononorderdetailpage() throws InterruptedException{
		WebElement Paynow= ElementWait.waitForOptionalElement(driver, paynowlink, 20);
		if(Paynow!=null && Paynow.isDisplayed()){
			TimeUnit.SECONDS.sleep(5);
			Paynow.click();
		}
		else{
			softassert.fail("Pay now page is not present in main menu");
		}
	}

	public void Confirmpaynowlinkorderdetailpage() throws InterruptedException{
		WebElement Paynow= ElementWait.waitForOptionalElement(driver, Confirmpaynowlink, 20);
		if(Paynow!=null && Paynow.isDisplayed()){
			TimeUnit.SECONDS.sleep(5);
			Paynow.click();
		}
		else{
			softassert.fail("Confirm pay now link is not present in main menu");
		}
	}

	public void ContinueShoppinglinkorderdetailpage() throws InterruptedException{
		WebElement Paynow= ElementWait.waitForOptionalElement(driver, ContinueShoppinglink, 20);
		if(Paynow!=null && Paynow.isDisplayed()){
			TimeUnit.SECONDS.sleep(5);
			Paynow.click();
		}
		else{
			softassert.fail("Continue Shopping link is not present in main menu");
		}
	}

	public void opencheckmenulink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, Menulink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("checkout menu link page is not present");
		}
	}
	public void BacktoStorehomepage() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, Myshoplink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			softassert.fail("Store Home page is not present");
		}
	}

	public void opencheckDirectCartlink() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, dirtCartlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();

		}
		else{
			softassert.fail("Direct Cart link page is not present");
		}
	}


}