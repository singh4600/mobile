package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class HotelDetailPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By deluxRoom_link= By.xpath("//*[@class='hotel-list-select']/li[1]/div[2]/span[2]");
	public By viewAll_deluxRoom_link= By.xpath("//*[contains(@class,'facility-description')]/ul/li[1]/div[1]//*[contains(@onclick,'Appyscript.viewallaminitieshotel')]");
	public By Ok_btn_viewAll_popup= By.xpath("//*[contains(@class,'modal-button modal-button-bold')]");
	public By listFacilityrightarrow_link=By.xpath("//*[contains(@class,'swiper-button-next')]");
	public By listFacilityLeftarrow_link=By.xpath("//*[contains(@class,'swiper-button-prev icon-left-open')]]");
	public By backpageBtn= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	public By sharelink=By.xpath("//*[contains(@onclick,'sharegoteldetails')]");
	public By likelink= By.xpath("//*[contains(@class,'more-icon-sh')]/a[1]");
	public By ownerlink= By.xpath("//*[contains(@class,'hotelowner')]");
	public By ownerCloselink= By.xpath("//*[contains(@class,'close-picker iconz-remove')]");
	public By ownerImglink= By.xpath("//*[contains(@class,'hostedBy')]/img");
	public By accomodationDetailslink= By.xpath("//*[contains(@onclick,'Appyscript.hotelpolicypage')]");
	public By closedBtn_accomodationDetails= By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");
	public By mapOpenlink= By.xpath("//*[contains(@onclick,'accommodation-fullmap')]");
	public By close_Maplink= By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By hotelName_gettext=By.xpath("//*[contains(@id,'hoteldetail')]//*[contains(@class,'category-detail')]");
	public By ownerDescription_gettext=By.xpath("//*[contains(@class,'content-block')]");
	public By listFacility_gettext=By.xpath("//*[contains(@class,'facility-type')]/div");
	public By offerHeading_gettext=By.xpath("//*[contains(@class,'offer-off')]");
	public By hotelDescription_gettext=By.xpath("//*[contains(@class,'facility-description')]");
	public By honerName_gettext=By.xpath("//*[contains(@class,'hName')]");
	public By listoomType_gettext=By.xpath("//*[contains(@class,'room-type-description')]");
	public By checkInTime_gettext=By.xpath("//*[contains(@class,'checkIn')]");
	public By checkOutTime_gettext=By.xpath("//*[contains(@class,'checkOut')]");
	public By getsharebyItem_native=By.className("android.widget.TextView");
	public By amenities_viewAll_Heading_gettext=By.xpath("//*[contains(@class,'modal-title custompopupalign')]");
	public By amenities_viewAll_list_gettext=By.xpath("//*[contains(@class,'allamini')]");
	public By accomodationDetails_heading_gettext= By.xpath("//*[contains(@class,'hotel-list-wrp')]/h2");
	public By accomodationDetailsDescription_gettext=By.xpath("//*[contains(@id,'accommodation_details')]");
	


	public HotelDetailPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}