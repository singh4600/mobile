package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieGooglePlusPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	By googlePage = By.xpath("//a[@data-productid='googleplus']");
	By googleUrl = By.xpath("//a[@class='appypie-list'][@data-page='googleplus']");
	By invalidUrl = By.xpath("//a[@class='appypie-list'][@data-page='googleplus'][@data-index='1']");
	By feeds = By.className("tweet-user");
	By viewButton = By.xpath("//a[contains(@onclick,'Appyscript.openWebView')]");
	By webview = By.id("text_Tittle");
	By nativebackbtn = By.id("icon1_button");
	
	By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='Shah Rukh Khan']");

	public AppypieGooglePlusPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openGooglePlusPage() {
		WebElement googleOpen = ElementWait.waitForOptionalElement(driver, googlePage, 20);
		if (googleOpen != null && googleOpen.isDisplayed())
			googleOpen.click();
		else {
			Logger.error("facebook page is not present in main menu");
		}
	}

	public boolean identifyGooglePlusOpen() {
		boolean open = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, googleUrl, 20);
		if (url != null && url.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openGooglePlusUrl() {
		WebElement url = ElementWait.waitForOptionalElement(driver, googleUrl, 20);
		url.click();
	}

	public boolean clickInvalidUrl() throws NullPointerException {
		WebElement url = ElementWait.waitForOptionalElement(driver, invalidUrl, 20);
		url.click();
		return PageElement.checkNoDataOptionInUrl(driver);
	}

	public boolean checkGooglePlusFeeds() {
		boolean feed = false;
		WebElement element_feeds = ElementWait.waitForOptionalElement(driver, feeds, 20);
		if (element_feeds != null && element_feeds.isDisplayed()) {
			feed = true;
		} else {
			Logger.error("Feeds are not present in the Google+ url");
		}
		return feed;
	}

	public boolean clickViewButton() throws InterruptedException {
		boolean open = false;
		WebElement view = null;
		Thread.sleep(4000);
		WebElement viewbtn = ElementWait.waitForOptionalElement(driver, viewButton, 20);
		if (viewbtn != null && viewbtn.isDisplayed()) {
			viewbtn.click();
			Thread.sleep(1000);
			driver.context("NATIVE_APP");
			if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				view = ElementWait.waitForOptionalElement(driver, webview, 20);
				if (view != null && view.isDisplayed()) {
					open = true;
					Thread.sleep(3000);
					driver.findElement(nativebackbtn).click();
				} else {
					Logger.error("Google+ url is not open in native after clicking on view button from feed");
				}
			} else {
				view = ElementWait.getIosNativeElement(driver, i_nativeView, 20);
				if (view != null) {
					open = true;
					Thread.sleep(3000);
					PageElement.tapOnScreen(driver, 0.04, 0.04);
				} else {
					Logger.error("Google+ Url is not open in native after clicking on view button from feed in ios");
				}
			}
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.error("view button is not displayed on the Google+ feeds");
		}
		return open;
	}
}
