package com.appypie.pages.datingpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DatingMenuPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By profileImg = By.id("menuprofile");
	By userName = By.id("userName");
	By userId = By.id("userLocation");
	By closeMenu = By.xpath("//a[contains(@class,'editProfilebutton')]");
	By home = By.xpath("//a[contains(@onclick,'Appyscript.datingmainmenu')]");
	By mainMenu = By.xpath("//a[@data-page='dating-find']");
	By myProfile = By.xpath("//a[contains(@onclick,'Appyscript.datingProfile')]");
	By myMatch = By.xpath("//a[contains(@onclick,'Appyscript.datingMatchProfile')]");
	By messages = By.xpath("//a[contains(@onclick,'Appyscript.datingchatProfile')]");
	By notification = By.xpath("//a[contains(@onclick,'Appyscript.datingnotification')]");
	By setting = By.xpath("//a[@data-page='dating-setting']");
	By tc = By.xpath("//a[contains(@onclick,'Appyscript.datingtc')]");
	By privacyPolicy = By.xpath("//a[contains(@onclick,'Appyscript.datingpp')]");
	By logout = By.xpath("//a[contains(@onclick,'Appyscript.AppLogout')]");

	By tcPage = By.xpath("//h1[contains(text(),'Terms')]");
	By privacyPolicyPage = By.xpath("//h1[contains(text(),'Privacy Policy')]");

	public DatingMenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isDatingMenuOpen() {
		boolean open = false;
		WebElement menu = ElementWait.waitForOptionalElement(driver, profileImg, 10);
		if (menu != null && menu.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isTcPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, tcPage, 10);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isPrivacyPolicyPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, privacyPolicyPage, 10);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String getProfileName() {
		String user = "";
		WebElement profile = ElementWait.waitForOptionalElement(driver, userName, 10);
		if (profile != null && profile.isDisplayed()) {
			user = profile.getText();
		} else {
			Logger.info("user profile name is not displayed");
		}
		return user;
	}
	

	public String getprofileEmail() {
		String id = "";
		WebElement profileId = ElementWait.waitForOptionalElement(driver, userId, 10);
		if (profileId != null && profileId.isDisplayed()) {
			id = profileId.getText();
		} else {
			Logger.info("user profile email is not displayed");
		}
		return id;
	}

	public void clickHome() {
		WebElement menuHome = ElementWait.waitForOptionalElement(driver, home, 10);
		if (menuHome != null && menuHome.isDisplayed()) {
			menuHome.click();
		} else {
			Logger.info("home icon is not displayed");
		}
	}

	public void clickMainMenu() {
		WebElement menu = ElementWait.waitForOptionalElement(driver, mainMenu, 10);
		if (menu != null && menu.isDisplayed()) {
			menu.click();
		} else {
			Logger.info("mainMenu icon is not displayed");
		}
	}

	public void clickMyProfile() {
		WebElement profile = ElementWait.waitForOptionalElement(driver, myProfile, 10);
		if (profile != null && profile.isDisplayed()) {
			profile.click();
		} else {
			Logger.info("myProfile icon is not displayed");
		}
	}

	public void clickMyMatches() {
		WebElement match = ElementWait.waitForOptionalElement(driver, myMatch, 10);
		if (match != null && match.isDisplayed()) {
			match.click();
		} else {
			Logger.info("myMatch icon is not displayed");
		}
	}

	public void clickMessages() {
		WebElement msg = ElementWait.waitForOptionalElement(driver, messages, 10);
		if (msg != null && msg.isDisplayed()) {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", msg);
			msg.click();
		} else {
			Logger.info("messages icon is not displayed");
		}
	}

	public void clickNotifications() {
		WebElement notify = ElementWait.waitForOptionalElement(driver, notification, 10);
		if (notify != null && notify.isDisplayed()) {
			notify.click();
		} else {
			Logger.info("notification icon is not displayed");
		}
	}

	public void clicksetting() {
		WebElement profileSetting = ElementWait.waitForOptionalElement(driver, setting, 10);
		if (profileSetting != null && profileSetting.isDisplayed()) {
			profileSetting.click();
		} else {
			Logger.info("profileSetting icon is not displayed");
		}
	}

	public void clickTermCond() {
		WebElement profiletc = ElementWait.waitForOptionalElement(driver, tc, 10);
		if (profiletc != null && profiletc.isDisplayed()) {
			profiletc.click();
		} else {
			Logger.info("profile t&c icon is not displayed");
		}
	}

	public void clickPrivacyPolicy() {
		WebElement policy = ElementWait.waitForOptionalElement(driver, privacyPolicy, 10);
		if (policy != null && policy.isDisplayed()) {
			policy.click();
		} else {
			Logger.info("privacy policy icon is not displayed");
		}
	}

	public void profileLogOut() {
		WebElement logoutIcon = ElementWait.waitForOptionalElement(driver, logout, 10);
		if (logoutIcon != null && logoutIcon.isDisplayed()) {
			logoutIcon.click();
		} else {
			Logger.info("logout icon is not displayed");
		}
	}

	public void closeMenu() {
		WebElement close = ElementWait.waitForOptionalElement(driver, closeMenu, 10);
		if (close != null && close.isDisplayed()) {
			close.click();
		} else {
			Logger.info("closeMenu icon is not displayed");
		}
	}

}
