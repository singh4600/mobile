package com.appypie.pages;

import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class NavigationPage extends TestSetup{
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger = Log.createLogger();
	By webView = By.className("android.webkit.WebView");
	By tc = By.xpath("//*[@id='termscondition']");
	By eventPage = By.xpath("//a[@data-productid='event']");
	static By permissionmsg = By.id("com.android.packageinstaller:id/permission_message");
	static By allowPermission = By.id("com.android.packageinstaller:id/permission_allow_button");
	static By i_permission = By.id("Allow");
	static String i_allow="Allow";
	public static By i_permissionCameraOther = By.xpath("//XCUIElementTypeButton[@name=\"OK\"]");
	public static String mainWebView;

	public NavigationPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void navigateToPage() {
		try {
			Logger.info("2");
			Logger.info("Splash loaded successfully");
			//Logger.info("Current context is : " + driver.getContext());
			verifyrunTimePermissions(driver);
			if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				WebElement view = ElementWait.waitForOptionalElement(driver, webView, 200);
				Logger.info(" web view is " + view);
			}else{
				Thread.sleep(700);
			}
			Set<String> contextNames = driver.getContextHandles();
			for (String contextName : contextNames) {
				System.out.println(contextName);
				if (contextName.contains("WEBVIEW")) {
					Logger.info(contextName);
					try {
						driver.context(contextName);
					}
					catch (Exception e) {
						try{
							Set<String> contextname = driver.getContextHandles();
							for (String contextname2 : contextname) {
								System.out.println(contextname2); //prints out something like NATIVE_APP \n WEBVIEW_1
								driver.context("WEBVIEW_com.snappy.appypie");
								System.out.println(contextname2);
							}
						}catch (Exception e1) {
							System.out.println("Error in Before Method :: "+e1);
						}
					}
					Logger.info(" webview starts loading");
				}                                     
			}
			if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				windowsLog(driver);
			}
			Logger.info(" Loaded WebView is : " + driver.getContext());
			mainWebView=driver.getContext();
			Logger.info(" webview successfully loaded");
			/*WebElement termCond = ElementWait.waitForOptionalElement(driver, tc, 10);
			Thread.sleep(500);
			if (termCond != null && termCond.isDisplayed()) {
				termCond.click();
				Logger.info(" terms condition page exist in the app and clicked successfully");
				Thread.sleep(1000);
			}*/
			Logger.info("End of Splash loading");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.error("App is taking more time than expected to be loaded or app crash on splash" + e.getMessage(),e);
		}
	}

	private static void windowsLog(AppiumDriver<MobileElement> driver) {
		String winHandleBefore = driver.getWindowHandle();
		Set<String> tmp = driver.getWindowHandles();
		System.out.print("App Windows :  ");
		for (String window : tmp) {
			System.out.print("  " + window + " ; ");
		}
		System.out.println("\n Old Window : " + winHandleBefore);
		String newWindows = (String) tmp.toArray()[tmp.size() - 1];
		System.out.println("Window to switch : " + newWindows);
		driver.switchTo().window(newWindows);
	}

	public static void verifyrunTimePermissions(AppiumDriver<MobileElement> driver) {
			try {
				By msg,allow;
				if (globledeviceName.equals("iPhone")) {
					msg = i_permission;
					allow = i_permission;
				} else {
					msg = permissionmsg;
					allow = allowPermission;
				}
				while (true) {
					WebElement permission = ElementWait.waitForOptionalElement(driver, msg, 20);
					if (permission != null && permission.isDisplayed()) {
						driver.findElement(allow).click();
						Thread.sleep(1000);
					} else {
						break;
					}
				}
			} catch (Exception e) {
				Logger.error("exception occurs while handling run time permissions", e);
			}
		}
		


public static void WebViewManage(AppiumDriver<MobileElement> driver) {
	Set<String> contextNames = driver.getContextHandles();
	for (String contextName : contextNames) {
		System.out.println(contextNames); //prints out something like NATIVE_APP \n WEBVIEW_1
		driver.context(contextName);
		System.out.println(contextNames);
	}	
}

public static void verifyrunTimePermissionsCamera(AppiumDriver<MobileElement> driver) {
	try {
		By msg,allow;
		if (TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
			msg = i_permissionCameraOther;
			allow = i_permission;
		} else {
			msg = permissionmsg;
			allow = allowPermission;
		}
		while (true) {
			WebElement permission = ElementWait.waitForOptionalElement(driver, msg, 20);
			if (permission != null && permission.isDisplayed()) {
				driver.findElement(allow).click();
				Thread.sleep(1000);
			} else {
				break;
			}
		}
	} catch (Exception e) {
		Logger.error("exception occurs while handling run time permissions", e);
	}


}

@Override
public void pageSetUp() {
	// TODO Auto-generated method stub

}


}
