package com.appypie.pages.Photo;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class PhotoPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By openPhotoModule= By.xpath("//a[@data-productid='photo']");
	public By backBtnHomePage= By.xpath("//*[@class='link back bottomBack']");
	public By clickFacebook= By.xpath("//*[@data-identifire='facebook']"); 
	public By FBphotoOpen= By.xpath("//*[contains(@class,'photo-gallery')]/a[1]");

	public By backBtnPhoto= By.xpath("//*[contains(@onclick,'closeAppypiegalary')]");

	public By clickFlickr= By.xpath("//*[@data-identifire='flickr']");
	public By photoStremTAB= By.xpath("//*[contains(@class,'photo-tabs arial mediumContent')]/a[1]");
	public By setTAB= By.xpath("//*[contains(@class,'photo-tabs arial mediumContent')]/a[2]");
	public By firstsetlink= By.xpath("//*[contains(@class,'photo-sets')]/a[1]");
	public By firstphotopenFirstSet= By.xpath("//*[contains(@class,'photo-gallery')]/a[1]");

	public By flickrphotoOpen= By.xpath("//*[contains(@class,'photo-gallery')]/a[1]");
	public By showMorelink= By.xpath("//*[contains(@class,'show-more')]");

	public By clickPinterest= By.xpath("//*[@data-identifire='pinterest']");
	public By clickInstagram= By.xpath("//*[@data-identifire='instagram']");
	public By like_gettext= By.xpath("//*[@class='row']/div[1]/a/i");
	public By comment_gettext= By.xpath("//*[@class='row']/div[2]/a/i");
	public By loadMore= By.xpath("//*[@id='loadMoreBTn']");

	public By clickCustom= By.xpath("//*[@data-identifire='customalbum']");

	public By image360link= By.xpath("//*[@data-identifire='photo360album']");

	public By myGallerylink= By.xpath("//*[@data-identifire='gallery']");
	public By addphotolink= By.xpath("//*[contains(@class,'editButton')]/span");
	public By cameralink= By.xpath("//*[contains(@onclick,'Appyscript.customphotocaptureimagecamera')]");
	public By i_cameraclick= By.xpath("//XCUIElementTypeButton[@name=\"PhotoCapture\"]");
	public By i_cameraCancle= By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	public By i_galleryPermissionOk= By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	public By gallerylink= By.xpath("//*[contains(@onclick,'Appyscript.customphotogallery')]");
	public By tab= By.className("android.view.View");
	public By i_tab= By.xpath("//XCUIElementTypeOther[@name=\"Appy Pie Projects\"]//XCUIElementTypeImage");
	
	public By spamopen= By.xpath("//*[contains(@onclick,'Appyscript.customphotosaveshare')]");
	public By reportAsSpam= By.xpath("//*[contains(@class,'actions-modal-group')]/div[1]");
	public By cancel= By.xpath("//*[contains(@class,'actions-modal-group')]/div[2]");
	
	
	public By clickselectphoto=By.xpath("//android.widget.ImageView[@index='0']");
	public By clickuploadOkbutton=By.xpath("//android.widget.TextView[@text='OK']");
	
	public By addcomment= By.xpath("//*[@id='customcaptiontext']");
	public By send= By.xpath("//*[contains(@onclick,'Appyscript.uploadcustomphoto')]");
	

	public By clickOneDrive= By.xpath("//*[@data-identifire='onedrive']");

	public By clickbackBtncommanforAll= By.xpath("//div[@class='left sliding']");

	public By backBtnhomepage= By.xpath("//div[@class='left sliding']");

	public By backBtnopenphotofacebookpage= By.xpath("//a[contains(@onclick,'closeAppypiegalary')]");
	public By backBtnFlickr= By.xpath("//div[@class='left sliding']");
	public By backBtnPinterest= By.xpath("//div[@class='left sliding']");
	public By backBtnInstagram= By.xpath("//div[@class='left sliding']");
	public By backBtnCustom= By.xpath("//div[@class='left sliding']");
	public By backBtnOneDrive= By.xpath("//div[@class='left sliding']");
	public By backBtnonedriverpage= By.xpath("//*[@class='link back ']");
	public By backBtnonedriveopenphoto= By.xpath("//div[@class='navbar']/div[2]/div");



	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By fbuser_gettext=By.xpath("//*[contains(@class,'header-NO')]/h1");
	public By fbPhotoCount_gettext=By.xpath("//*[contains(@class,'header-NO')]/span");

	public By flickrUser_gettext=By.xpath("//*[contains(@class,'header-NO')]/h1");
	public By flickCount_gettext=By.xpath("//*[contains(@class,'header-NO')]/span");

	


	public PhotoPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}