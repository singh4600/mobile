package com.appypie.pages.FoodCourt;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

public class CheckOutPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger = Log.createLogger();
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath(""); 

	public By name_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bfname']"); // fist name
	public By Telephone_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bpNo']"); // mobile no
	public By Email_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bemail']"); // email id
	public By Address_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bAddress']"); // address
	public By City_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bCity']"); // city
	public By State_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bState']"); // state
	public By Zip_textfield= By.xpath("//*[@id='foodcourtBilling']/*[@id='bZip']"); // zip
	public By Country_textfield= By.xpath("//*[@id='foodcourtBilling']//*[@id='bCountry']"); // country
	public By Deliveryaddresscheckbox= By.xpath("//*[@id='billingAddress']//*[contains(@class,'showBillingAddress')]"); // billing address
	public By confirmbtn= By.xpath("//*[@id='billingAddress']/div[3]/a"); // confirm button.
	public By clickAlertOKpopupmessagebtn=By.xpath("//span[@class='modal-button modal-button-bold']");
	public By clickViewStoreTimingsbtn=By.xpath("//*[@class='billing-address tab']//*[@class='view-store arial mediumContent']"); // view store timings button
	public By clickViewStoreTimingsclosebtn=By.xpath("//div[@class='form-view']/a"); //

	public By DeliveryTAB= By.xpath("//div[@class='tabViewall']/a"); //

	public By PickupTAB= By.xpath("//div[@class='tabmyCollection']/a"); //
	
	public By selectAddressPickup_link= By.id("pickAddress");
	public By selectaddressRadioBtnNative_link= By.xpath("//android.widget.CheckedTextView[@index='1']");
	public By pickUpTime_link= By.xpath("//*[@name='pickCurrentTime']");
	public By instructionsPickup_textlink= By.xpath("//*[@name='pickCurrentTime']");
	public By confirmPickup_btn = By.xpath("//*[contains(@id,'picup')]/a[2]");

	public By time_droplist = By.xpath("//*[@id='dTime']");
	public By time_native = By.id("time_header");
	public By time_hour_native = By.xpath("//*[@selected='true']");
	
	public By pmNative=By.xpath("//android.widget.CheckedTextView[@index='1']");
	public By time=By.xpath("//*[@content-desc='10']");
	public By time_Set_btn_native = By.xpath("//android.widget.Button[@index='2']");

	public By ViewStoretimepickupTAB= By.xpath("//*[@id='picup']/a[1]"); //
	public By InstructionsPickUpTAB= By.xpath("//*[@id='pickInstruction']"); //
	public By ConfirmBtnPickUpTAB= By.xpath("//*[@id='picup']/a[2]"); //
	public By ContinueOrderingbtn= By.xpath("//*[contains(@onclick,'foodGoToHomePage')]"); //
	public By viewStoreTimingbtn= By.xpath("//*[@id='billingAddress']/div[3]/div[3]/a"); 

	
	public By adressclick= By.xpath("//*[@id='pickAddress']"); 
	public By adressclickHbride= By.xpath("//*[@id='roledata']");
	public By selectaddressNative= By.xpath("//*[@index='1']"); 
	public By estimatedDeliverytime= By.xpath("//*[@id='picup']//*[@class='timeInput']"); 
	public By estimatedDeliverytime2= By.xpath("//*[@name='pickCurrentTime']"); 
	public By viewStoreTimingPickupTab= By.xpath("//*[@id='picup']//a[1]"); 
	public By selectDeliveryDate= By.xpath("//*[@value='Select Preferred delivery date' and contains(@onclick,'opencalenderfoodcourt')]"); 
	//public By selectDateNative= By.xpath("//android.view.View[@content-desc='']");
	public By doneSelectDeliveryDate= By.xpath("//*[contains(@onclick,'foodcourtdateselect')]");
	//public By = By.xpath("");
	
	public By instructionsPickUpTAB= By.xpath("//*[@id='pickInstruction']"); 
	public By billingAddressCheckBoxPickUpTAb= By.xpath("//*[contains(@onclick,'foodCourtProfileCheckboxPickup')]");

	public By usernameBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bfname']");
	public By phoneNoBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bpNo']");
	public By emailAddressBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bemail']");
	public By addressBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bAddress']");
	public By cityBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bCity']");
	public By stateBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bState']");
	public By zipBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bZip']");
	public By countryBillingAddress=By.xpath("//*[@id='foodcourtBillingpickup']//*[@id='bcountryTry']");
	public By confirmBtnBillingAddress=By.xpath("//*[@class='billing-address tab']/a[2]");
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	
	public By selectAddressNative_gettext=By.xpath("//android.widget.CheckedTextView[@index='0']");

	

	public By Genopentime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[1]/li/div[1]");
	public By Genclosetime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[1]/li/div[2]");
	public By storetimingheadertitle_gettext=By.xpath("//*[@id='foodPopup']/div/h2[2]");
	public By Customeopentime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[2]/li/div[1]");
	public By Customerclosetime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[2]/li/div[2]");

	public By PaymentDetailsHeading_gettext=By.xpath("//*[@id='billingAddress']/div[7]/h2");
	public By Subtotal_gettext=By.xpath("//*[@class='payment-details']//*[@id='subtotalecom']/span");
	public By Discount_gettext=By.xpath("//*[@class='payment-details']//li[@id='discountecom']/span");  
	public By Delivery_gettext=By.xpath("//*[@class='payment-details']//*[@id='deliverychargeecom']/span");
	public By Tax_gettext=By.xpath("//*[@class='payment-details']//*[@id='taxecomecom']/span");
	public By Tip_gettext=By.xpath("//*[@class='payment-details']//*[@id='tipcharge']/span");
	public By GrandTotal_gettext=By.xpath("//*[@class='payment-details']//*[@id='gtotal']/span");
	public By ThankyouHeading_gettext=By.xpath("//*[@class='thankyou']/h1");
	public By Thankyoupagemessage_gettext=By.xpath("//*[@class='thankyou']//p[1][@id='mess']");
	public By ThankyoupageOrdermessage_gettext=By.xpath("//*[@class='thankyou']//p[2][@id='mess']");
	
	public By openingTime_gettext=By.xpath("//*[@class='time-view']/h2[1]");
	public By openingTimeList_gettext=By.xpath("//*[@class='time-view']/ul[1]/li/div");
	
	public By customerServingTiming_gettext=By.xpath("//*[@class='time-view']/h2[2]");
	public By customerServingTimingList_gettext=By.xpath("//*[@class='time-view']/ul[2]/li/div");

	public By orderPreviewHeading_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[1]/h3");
	public By itemHeading_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[2]");
	public By itemName_PaymentDetails_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[3]//li");
	public By billingAddressHeading_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]/h3[1]");
	public By namebilling_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[1]");
	public By mobilebilling_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[2]");
	public By emailIDbilling_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[3]");
	public By billingAddress_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[4]");
	public By pickUpAddressHeading_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]/h3[2]");
	public By namepickUp_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[5]");
	public By mobilepickUp_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[6]");
	public By emailidpickUp_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[7]");
	public By pickUpAddress_gettext=By.xpath("//*[contains(@class,'food-Order orer-confirm')]/div[4]//li[8]");
	public By checkoutAgain=By.xpath("//*[contains(@onclick,'foodCourtPayment')]");
	public By i_countryBillingAddress=By.xpath("//*[@id='foodcourtBilling']//*[@id='bCountry']//*[@id='IN']");
	
	

	// ------------------For Default Method-----------------
	public By AlertHeader_gettext = By.xpath("//*[@class='modal-title']");
	public By AlertText_gettext = By.xpath("//*[@class='modal-text']");
	public By AlertOkButton = By.xpath("//*[@class='modal-button modal-button-bold']");
	public By BackButton = By.xpath("//*[@class='link back']");
	public By BackButtonNative = By.id("icon1_button");

	public By BackButtonNativeforsigngoogle = By.className("android.widget.ImageButton");

	public By getListItem = By.xpath("//*[contains(@class,'appypie-list')]");
	public By header_gettext = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	public By header_gettext_native = By.id("text_Tittle");
	
	
	
	// --------click Date field(Prince)-----------------------------------
	public By pickup_date = By.id("PICKUPdate");
	public By delebiry_date = By.id("ddate");
	public By set_date = By.xpath("//div[@class='picker-calendar-day picker-calendar-day-today']/following-sibling::div[1]");
	public By set_date_Weekend = By.xpath("//div[@class='picker-calendar-day picker-calendar-day-today picker-calendar-day-weekend']/following-sibling::div[1]");
	public By date = By.xpath("//div[@onclick='foodcourtdateselect()']");

	public CheckOutPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}

	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext) {
		try {
			String gettextmessage = ElementWait.waitForOptionalElement(driver, gettext, 50).getText();
			Logger.info("Inner Page Text is :" + gettextmessage);
			return gettextmessage;
		} catch (Exception e) {
			System.out.println("Error getting text:  " + e);
		}
		return runningTest1;
	}

	public void IfAlertpresent() throws InterruptedException {
		boolean alert = false;
		alert = driver.findElements(By.xpath("//*[@class='modal-title']")).size() != 0;
		if (alert) {
			System.out.println("Alert is present");
			getPagetext(driver, AlertHeader_gettext);

			Boolean alerttext=IselementPresent(AlertText_gettext);
			if (alerttext) {
				getPagetext(driver, AlertText_gettext);
			}
			else{
				System.out.println("Alert text Message is not present.");
			}
			AlertOkButtonMethod();
		} else {
			System.out.println("Alert is Not present");
		}
	}


	public void AlertOkButtonMethod() throws InterruptedException {
		WebElement open = ElementWait.waitForOptionalElement(driver, AlertOkButton, 50);
		if (open != null && open.isDisplayed()) {
			open.click();
			TimeUnit.SECONDS.sleep(2);
		} else {
			System.out.println("Alert Ok Button is not present ");
		}
	}

	public void swipingHorizontal() throws InterruptedException {
		driver.context("NATIVE_APP");
		TimeUnit.SECONDS.sleep(2);

		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);

			// Find swipe start and end point from screen's with and height.
			// Find startx point which is at right side of screen.
			int startx = (int) (size.width * 0.70);
			// Find endx point which is at left side of screen.
			int endx = (int) (size.width * 0.30);
			// Find vertical point where you wants to swipe. It is in middle of
			// screen height.
			int starty = size.height / 2;
			// System.out.println("startx = " + startx + " ,endx = " + endx + "
			// , starty = " + starty);
			// Swipe from Right to Left.
			driver.swipe(startx, starty, endx, starty, 300);
			TimeUnit.SECONDS.sleep(2);

			/*
			 * //Swipe from Left to Right. driver.swipe(endx, starty, startx,
			 * starty, 3000); Thread.sleep(2000);
			 */
		} catch (Exception e) {
			System.out.println("Errpr in swipingHorizontal()");
		}
		PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);

	}

	public void SwipetopTobottom() throws InterruptedException {
		driver.context("NATIVE_APP");
		TimeUnit.SECONDS.sleep(2);
		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);
			// Find swipe start and end point from screen's with and height.
			// Find starty point which is at bottom side of screen.
			int starty = (int) (size.height * 0.80);
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle
			// of screen width.
			int startx = size.width / 2;
			// System.out.println("starty = " + starty + " ,endy = " + endy + "
			// , startx = " + startx); // ye wala h ================
			// Swipe from Bottom to Top.
			// driver.swipe(startx, starty, startx, endy, 3000);
			TimeUnit.SECONDS.sleep(3);
			// Swipe from Top to Bottom.
			driver.swipe(startx, endy, startx, starty, 3000);
			TimeUnit.SECONDS.sleep(3);
		} catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);
	}

	public void SwipeBottomToTop() throws InterruptedException {
		// driver.context("NATIVE_APP");
		TimeUnit.SECONDS.sleep(2);
		try {
			// Get the size of screen.
			size = driver.manage().window().getSize();
			// System.out.println(size);
			// Find swipe start and end point from screen's with and height.
			// Find starty point which is at bottom side of screen.
			int starty = (int) (size.height * 0.80);
			// Find endy point which is at top side of screen.
			int endy = (int) (size.height * 0.20);
			// Find horizontal point where you wants to swipe. It is in middle
			// of screen width.
			int startx = size.width / 2;
			// System.out.println("starty = " + starty + " ,endy = " + endy + "
			// , startx = " + startx); // ye wala h ================
			// Swipe from Bottom to Top.
			driver.swipe(startx, starty, startx, endy, 3000);
			TimeUnit.SECONDS.sleep(3);
			// Swipe from Top to Bottom.
			// driver.swipe(startx, endy, startx, starty, 3000);
			TimeUnit.SECONDS.sleep(3);
		} catch (Exception e) {
			System.out.println("Error in SwipetopTobottom method");
		}
		// PageElement.changeContextToWebView(driver);
		TimeUnit.SECONDS.sleep(2);
	}

	// =====================================================================================

	// ---------------------------Methods--------------------------------------------------s
	public void BackButtonNative(By link) throws InterruptedException {

		driver.context("NATIVE_APP");

		WebElement open = ElementWait.waitForOptionalElement(driver, link, 20);
		if (open != null && open.isDisplayed()) {
			open.click();
			TimeUnit.SECONDS.sleep(2);
		} else {
			System.out.println("Native Back Button is not present ");
		}
		PageElement.changeContextToWebView(driver);
	}

	public boolean Openlinks(By link) throws InterruptedException {
		boolean links = false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			linkpresent.click();
			TimeUnit.SECONDS.sleep(2);
			links = true;
		} else {
			System.out.println(("Link is not present"));
		}
		return links;
	}

	public boolean TextField(By link, String entertext) {
		boolean links = false;
		WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
		if (linkpresent != null && linkpresent.isDisplayed()) {
			links = true;
			linkpresent.clear();
			linkpresent.sendKeys(entertext);
			try {
				driver.hideKeyboard();
			} catch (Exception e) {
				System.out.println("hideKeyboard()");
			}
		} else {
			System.out.println(("Link is not present"));
		}
		return links;
	}

	public String Getactualtext(By gettext) {
		String Actualtext = "";
		WebElement element = ElementWait.waitForOptionalElement(driver, gettext, 20);
		if (element != null && element.isDisplayed()) {
			Actualtext = element.getText();
			System.out.println("Get Text:  " + Actualtext);
		}
		return Actualtext;
	}

	public boolean IselementPresent(By textvalue) throws InterruptedException {
		boolean text = false;
		WebElement textpresent = ElementWait.waitForOptionalElement(driver, textvalue, 20);
		if (textpresent != null && textpresent.isDisplayed()) {
			text = true;
			TimeUnit.SECONDS.sleep(2);
		} else {
			System.out.println(("Link is not present"));
		}
		return text;
	}

	public String printExceptionTrace(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}

	public boolean getListofLink(By link) throws InterruptedException {
		boolean text = false;
		TimeUnit.SECONDS.sleep(2);
		List<MobileElement> listpresent = driver.findElements(link);
		if(listpresent!=null){
			List<MobileElement> allSuggestions = driver.findElements(link);
			for (WebElement suggestion : allSuggestions) {
				System.out.println(suggestion.getText());
				System.out.println("--------------------------");
			}
			TimeUnit.SECONDS.sleep(3);
			text = true;
		}
		else{
			System.out.println("List is not present");
		}
		return text;


	}


	public void countryselect() throws InterruptedException{
			//driver.context("NATIVE_APP");
			driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("+ "new UiSelector().text(\"India\"));")).click();
			//PageElement.changeContextToWebView(driver);
	}
	
	public void Actionclick(By link) throws InterruptedException{
		WebElement element = ElementWait.waitForOptionalElement(driver, link, 20);
		if (element != null && element.isDisplayed()) {
			Actions action = new Actions(driver);
			action.moveToElement(element).click().perform();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Link is not Present");
		}
		
	}
	
	public void GetDate(){
			
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
	}



}
