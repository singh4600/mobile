package com.appypie.pages.OrderFoodPages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class MenuPage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	CommanClassforOrderFood comm;
	//--------click Event-----------------------------------
	//public By =By.xpath("");
	
	public By closeMenu=By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");
	public By publicMenulink=By.xpath("//a[@class='link menu-down']");
	public By homelink=By.xpath("//a[contains(@onclick,'Appyscript.clickHome')]"); // click on menu link
	
	public By myshoplink=By.xpath("//*[contains(text(),'My Shop')]");   // click on home link   
	public By cartlink=By.xpath("//*[text() ='Cart']");  // click on my shop link 
	public By offerzonelink=By.xpath("//*[contains(text(),'Offer Zone')]");
	public By myOrderlink=By.xpath("//*[contains(text(),'My Orders')]");
	public By myAccountlink=By.xpath("//*[contains(text(),'My Account')]");
	public By wishlistlink=By.xpath("//*[contains(text(),'WishList')]");
	public By TClink=By.xpath("//*[contains(text(),'Terms and Conditions')]");
	public By PPlink=By.xpath("//*[contains(text(),'Privacy Policy')]");
	
	
	public By featuredProduct=By.xpath("//*[contains(text(),'Offer Zone')]");  // click on cart link
	public By offerproduct=By.xpath("//a[contains(@onclick,'foodFeaturedOffered')]");  // click on Login/SignUp link  
	public By loginlink=By.xpath("//*[contains(text(),'Login')]");  // click on Login/SignUp link
	
	public By Emailfield=By.id("loginid");
	public By passwordfield=By.id("loginpass");
	public By loginbutton=By.xpath("//li[@class='login-btn']");


	//-------------------my Order----------------------------------------
	public By myorderFirst=By.xpath("//*[@class='myOrders']/div[1]/div[1]/a");
	public By deliveryAddress_myorder=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[3]/a");
	public By deliveryAddress_GetText_myorder=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[3]/div[1]//p");
	public By billingAddress_myOrder=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[2]/a");
	public By billingAddress_gettext_myorder=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[2]/div[1]//p");
	public By oderDetais_myorder=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[1]/a");
	public By orderDetailsList_getxt=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[1]/div[1]//li");
	public By viewItemBtn=By.xpath("//*[@class='myOrders']/div[1]/div[1]/div[1]/div[1]//*[contains(@onclick,'foodViewOrderedItems')]");
	public By viewItemlistgetText_myorder=By.xpath("//*[@class='view-product-attribute']/li");
	public By postReview_myorder=By.xpath("//*[@class='view-product-attribute']/li[5]/a[1]");
	public By reorder_myOrder=By.xpath("//*[@class='view-product-attribute']/li[5]/a[2]");
	


	//---------Get Text Event----------------------------
	//public By _gettext=By.xpath("");
	
	public By userName_gettext=By.xpath("//*[@id='userName']");
	public By address_gettext=By.xpath("//*[@id='userLocation']");
	public By menuList_gettext=By.xpath("//*[contains(@class,'leftMenu')]/li/a");
	public By MyShop_gettext=By.xpath("//*[contains(text(),'My Shop')]");
	public By Cart_gettext=By.xpath("//*[text() ='Cart']");
	public By OfferZone_gettext=By.xpath("//*[contains(text(),'Offer Zone')]");
	public By MyOrders_gettext=By.xpath("//*[contains(text(),'My Orders')]");
	public By MyAccount_gettext=By.xpath("//*[contains(text(),'My Account')]");
	public By WishList_gettext=By.xpath("//*[contains(text(),'WishList')]");
	public By Logout_gettext=By.xpath("//*[text() ='Logout']");
	public By Login_gettext=By.xpath("//*[contains(text(),'Login')]");
	//--------------------------------
	public MenuPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}
	
	public void logout(){
		boolean logout=false;
		logout=driver.findElements(By.xpath("//*[text() ='Logout']")).size()!=0;
		if(logout){
			System.out.println("User is already login");
			driver.findElement(By.xpath("//*[text() ='Logout']")).click();
		}
		else {
			System.out.println("User is not login");
		}
	}
	
	
	public void login() throws InterruptedException{	
		boolean loggeduser=false;
		loggeduser=driver.findElements(By.xpath("//*[contains(text(),'Login')]")).size()!=0;
		if(loggeduser){
			System.out.println("User Not Login please Login First");
			driver.findElement(loginlink).click();
			driver.findElement(Emailfield).sendKeys("appypie2016@gmail.com");
			driver.findElement(passwordfield).sendKeys("12345678");
			driver.findElement(loginbutton).click();
		}else {
			System.out.println("User is already Login");
		}
	}
	

	
/*	public void Menu() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, Menulink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
		}
		else{
			System.out.println("Menu link is not present ");
		}
	}*/

	public void GetMenulistbeforelogin() throws InterruptedException{	
		
		System.out.println("To check Menu options list.");
		List<MobileElement> allSuggestions = driver.findElements(By.xpath("//*[@id='menuservice']/ul/li/a"));      
        for (WebElement suggestion : allSuggestions)
        {
        System.out.println(suggestion.getText());
        }
        
	}
	
	public void GetMenulistafterlogin() throws InterruptedException{	
			login();
			System.out.println("To check Menu options list.");
			List<MobileElement> allSuggestions = driver.findElements(By.xpath("//*[@id='menuservice']/ul/li/a"));      
	        for (WebElement suggestion : allSuggestions)
	        {
	        System.out.println(suggestion.getText());
	        }
		
	}
	
}
