package com.appypie.pages.directoryHyperLocalpages;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class FilterResultPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By filterIcon = By.xpath("//i[contains(@class,'icon iconz-filter')]");
	By location = By.xpath("//i[contains(@class,'iconz-location-3')]");
	By googleMap = By.xpath("//android.view.View[@content-desc='Google Map']");

	public FilterResultPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public List<Boolean> isFilterResultPageOpen() {
		boolean open = false;
		boolean noData=false;
		List<Boolean> list= new ArrayList<Boolean>();
		WebElement icon = ElementWait.waitForOptionalElement(driver, location, 20);
		if (icon != null) {
			open = true;
		} else {
			noData = PageElement.checkNoDataOptionInUrl(driver);
		}
		list.add(0,open);
		list.add(1,noData);
		return list;
	}

	public void clickOnLocation() {
		WebElement loc = ElementWait.waitForOptionalElement(driver, location, 20);
		if (loc != null && loc.isDisplayed()) {
			loc.click();
		} else {
			Logger.info("Location icon is not visible on filter Result page");
		}
	}
           
	public boolean isMapOpen(String i_value) throws InterruptedException {
		boolean open = false;
		driver.context("NATIVE_APP");
		Thread.sleep(3000);
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
		WebElement map = ElementWait.waitForOptionalElement(driver, googleMap, 20);
		if (map != null && map.isDisplayed()) {
			open = true;
			Thread.sleep(2000);
			driver.navigate().back();
		} else {
			PageElement.verifyNativePageStillOpen(driver);
			Logger.info("Google Map is not Open from filter result page");
		}
		}else{
			open=PageElement.isContentOpenInNative(driver, i_value);
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
}
