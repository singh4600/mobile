package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DirectoryCouponPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	By couponPage= By.xpath("//div[@class='navbar']//div[text()='coupon test']");
	By couponPageP= By.xpath("//div[@class='flipper']/div[1]/h1[1]");
	By shareBtn= By.xpath("//a[contains(@onclick,'openShareCoupon')]");
	
	public DirectoryCouponPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}
	
	public boolean isCouponPageOpen() {
		boolean open = false;
		WebElement page= ElementWait.waitForOptionalElement(driver, couponPageP, 20);
		if (page!=null && page.isDisplayed()) {
			open = true;
		} 
		return open;
	}
	
	public void openSharefromCoupon(){
		WebElement share= ElementWait.waitForOptionalElement(driver, shareBtn, 10);
		if(share!=null && share.isDisplayed()){
			share.click();
		}
	}

}
