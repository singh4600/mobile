package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieChatBotPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By msgContainer = By.id("btn-input");
	By chatbotopen = By.xpath("//*[contains(@class,'appyicon-chat-bots')]");
	By sendBtn = By.id("btn-chat");

	By msg = By.xpath("//div[@class='chat']/div[2]//div[@class='msg']/p");
	By msgtime = By.xpath("//div[@class='chat']/div[2]//span[contains(@class,'chat-time')]");

	By reply = By.xpath("//div[@class='chat']/div[3]//div[@class='msg']/p");
	By replyTime = By.xpath("//div[@class='chat']/div[2]//span[contains(@class,'chat-time')]");
	
	By hyperLinkreply = By.xpath("//div[@class='chat']/div[3]//div[@class='msg']/p/a");

	
	public AppypieChatBotPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isChatBotPageOpen() {
		boolean open= false;
		WebElement page= ElementWait.waitForOptionalElement(driver, chatbotopen, 20);
		if(page!=null && page.isDisplayed()){
			open= true;
		}
		return open;	
	}

	
	public void typeMsg(String data) {
		PageElement.sendKey(driver, msgContainer, data);
	}

	public void sendMsg() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, sendBtn, 5);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

	public String getMsg() {
		String text = null;
		WebElement question = ElementWait.waitForOptionalElement(driver, msg, 20);
		if (question != null && question.isDisplayed()) {
			text = question.getText();
		}
		return text;
	}
	
	public String getReply() {
		String text = null;
		WebElement answer = ElementWait.waitForOptionalElement(driver, reply, 20);
		if (answer != null && answer.isDisplayed()) {
			text = answer.getText();
		}
		return text;
	}
	
	public String getMsgTime() {
		String text = null;
		WebElement time = ElementWait.waitForOptionalElement(driver, msgtime, 20);
		if (time != null && time.isDisplayed()) {
			text = time.getText();
		}
		return text;
	}
	
	public String getReplyTime() {
		String text = null;
		WebElement time = ElementWait.waitForOptionalElement(driver, replyTime, 30);    
		if (time != null && time.isDisplayed()) {
			text = time.getText();
		}
		return text;
	}
	
	public boolean isHyperLinkExistInReply() {
		boolean exist= false;
		WebElement link= ElementWait.waitForOptionalElement(driver, hyperLinkreply, 20);
		if(link!=null && link.isDisplayed()){
			exist= true;
		}
		return exist;	
	}
	
	public void openHyperLinkInReply() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, hyperLinkreply, 5);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

}
