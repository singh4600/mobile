package com.appypie.pages.SocialNetwork;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.tests.SocialNetworkTest;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SocialNetworkPage {

	private static final Logger Logger= Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	CommanClassSocialNetwork comm;
	SoftAssert s_assert = new SoftAssert();

	public By opensocialnetworkmodule= By.xpath("//a[@data-productid='socialnetwork']");
	public By clicksearch= By.xpath("//*[@id='socialusersearch']");
	public By clickwhatyourmindtext= By.xpath("//*[@id='statusbox']");
	public By clickPrivateCheckBox= By.xpath("//*[contains(@class,'public_condition')]/label[1]");
	public By clickstatus= By.xpath("//li[@class='active']");

	public By clickphotos= By.xpath("//li[@id='socialimage']");
	public By clickaddphotolink=By.xpath("//li[contains(@onclick,'Appyscript.Socialactionshee')]");
	public By clickgallerylink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[2]");
	public By i_openCameraRoll=By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell");
	public By i_selectPhoto=By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeImage[1]"); //XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeCell[1]/XCUIElementTypeImage[1]
	public By i_Done=By.xpath("//XCUIElementTypeButton[@name=\"Done\"]");
	public By i_=By.xpath("");
	
	public By clickcameralink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[1]");
	public By clickcameraphotoNative=By.className("android.widget.ProgressBar");
	public By i_clickcameraphotoNative=By.xpath("//XCUIElementTypeButton[@name=\"PhotoCapture\"]");
	public By i_UsePhotocameraphotoNative=By.xpath("//XCUIElementTypeButton[@name=\"Use Photo\"]");

	public By clickCanclePhotoVideoOnStatus=By.xpath("//*[contains(@onclick,'Appyscript.SocialRemovepic')]");

	public By clickAlertOKpopupmessagebtn=By.xpath("//span[@class='modal-button modal-button-bold']");

	public By clickselectphoto=By.xpath("//android.widget.ImageView[@index='0']");
	public By clickuploadOkbutton=By.xpath("//android.widget.TextView[@text='OK']");
	
	

	public By clickvideos= By.xpath("//li[@id='socialvideo']");
	public By clickaddvideolink=By.xpath("//li[contains(@id,'addsocialvideo')]");
	public By clickvideogallerylink=By.xpath("//*[@class='modal-buttons modal-buttons-3 modal-buttons-vertical']/span[2]");
	

	public By clickmenuNative=By.xpath("//android.widget.ImageButton[@index='0']");
	public By clickmenulistNative=By.className("android.widget.TextView");

	
	public By clickvideoOptionNative=By.xpath("//android.widget.TextView[@text='Videos']");
	public By clickselectvideoNative=By.xpath("//android.widget.ImageView[@index='0']");	
	public By clickselectvideoNative1=By.xpath("//android.widget.ImageView[@index='0']");
	public By playstopvideoNative=By.xpath("//android.widget.ImageButton[@index='1']");
	public By playvideoonpost=By.xpath("//div[@class='masonry']/div[1]/div[2]//*[contains(@onclick,'Appyscript.opensocialvideoplayer')]");
	
	

	public By clickpost= By.xpath("//a[contains(@onclick,'Appyscript.Socialsendtoserver')]");
	public By clickdeletmenu= By.xpath("//*[@class='masonry']/div[1]/div[1]/div[2]/a");
	public By clickdeletepost= By.xpath("//*[contains(@onclick,'Appyscript.socialdeletepost')]");
	public By clicklikepost= By.xpath("//a[contains(@onclick,'Appyscript.SocialLike')]");
	public By clicksharepost= By.xpath("//a[contains(@onclick,'Appyscript.socialsharingimage')]");

	public By clickcommentpost= By.xpath("//*[@id='sociappostappend']/div[1]//ul[@class='post-share arial']/li[3]/a"); 
	public By commentEnter=By.xpath("//*[@id='spostcomment']");
	public By commentSent=By.xpath("//*[contains(@onclick,'Appyscript.Socialcomment')]");
	public By commentmenu=By.xpath("//*[contains(@id,'scomment')]/li[1]/div[1]/div[2]/div[1]/a");
	public By deleteComment=By.xpath("//*[contains(@onclick,'Appyscript.socialdeletecomment')]");
	
	
	
	public By clickbackbuttoncomment= By.xpath("//*[@class='link back']"); 

	public By clickmenu= By.xpath("//a[contains(@class,'link menu-down')]");  // first build : //a[contains(@class,'navs')]
	public By clickhome= By.xpath("//*[text()='Home']");
	public By clickmainmenu= By.xpath("//*[text()='Main Menu ']");
	public By clicktag= By.xpath("//*[text()='Tags']");
	
	public By taglist=By.xpath("//*[@id='tagstream']/div/h1/a");
	public By openTag=By.xpath("//*[@id='tagstream']/div[1]/ul/li[1]/a");
	public By searchTag=By.xpath("//*[@id='socialtagsearch']");
	public By tagMenu=By.xpath("//*[@class='post-ban']/a");
	public By deleteTag=By.xpath("//*[contains(@onclick,'Appyscript.socialdeletepost')]");
	
	public By clickmyprofile= By.xpath("//*[text()='My Profile']");
	public By clickblockuser= By.xpath("//*[text()='Blocked Users']");
	public By clicklogout= By.xpath("//*[text() ='Logout']");
	public By closedMenupage= By.xpath("//*[contains(@class,'editProfilebutton')]");

	public By username=By.xpath("//*[@id='loginid']");
	public By password=By.xpath("//*[@id='loginpass']");
	public By LoginBtn=By.xpath("//*[@onclick='Appyscript.login();']");
	public By Acceptandcontinue=By.xpath("//a[@class='arial mediumContent']");
	
	//----------------------myprofile page
	public By statuslinkMP=By.xpath("//*[contains(@class,'streamList')]/li[1]");
	public By likeLinkMP=By.xpath("//*[contains(@class,'streamList')]/li[2]");
	public By cameralinkMP=By.xpath("//*[contains(@class,'streamList')]/li[3]");
	public By settinglinkMP=By.xpath("//*[contains(@class,'streamList')]/li[4]");
	public By deleteMenuMP=By.xpath("//*[contains(@class,'autoslidetab')]/div[1]/div[1]/div[1]//*[contains(@id,'socialmypost')]/div[1]//*[contains(@class,'post-ban')]");
	public By deletePostMP=By.xpath("//*[contains(@onclick,'Appyscript.socialdeletepost')]");
	public By cameraphotoMP=By.xpath("//*[contains(@class,'streambxList ')]/li/a");
	public By likecameralinkMP=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-container')]/ul//*[contains(@onclick,'Appyscript.SocialindividualLike')]");
	public By sharelinkcameraMP=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-container')]/ul//*[contains(@onclick,'Appyscript.socialsharingimage')]");
	public By commentlikCameraMP=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-container')]/ul//*[contains(@onclick,'Appyscript.SocialNetComment')]");
	public By editprofilelikSettingMP=By.xpath("//*[contains(@onclick,'Appyscript.SocialEditProfileSetting')]");
	public By emialNotificationlinkSettingMP=By.xpath("//*[contains(@onclick,'Appyscript.SocialNotificationSetting')]");
	public By logoutlinkSettingMP=By.xpath("//*[contains(@onclick,'Appyscript.AppLogout')]");
	//public By =By.xpath("");
	public By usernameEditProfile=By.xpath("//*[@id='socialname']");
	
	public By genderEditProfile=By.xpath("//*[@id='socialgender']");
	public By gendernative=By.xpath("//android.widget.CheckedTextView[@index='1']");
		public By genderPublicCheckBox=By.xpath("//*[@id='gendershowsocial']");
	
	public By dateEditProfile=By.xpath("//*[contains(@class,'setting-list setting-form')]/li[3]");
	public By datenative=By.xpath("//android.widget.Button[@index='2']");
	public By datePublicCheckBox=By.xpath("//*[@id='datedobshowsocial']");
	
	public By countryEditProfile=By.xpath("//*[@id='socialcountry']");
	public By countrynative=By.xpath("");
	public By countryPublicCheckBox=By.xpath("//*[@id='countryshowsocial']");
	
	public By phoneEditProfile=By.xpath("//*[@id='socialphone']");
	public By phonePublicCheckBox=By.xpath("//*[@id='phoneshowsocial']");
	
	public By biographyEditProfile=By.xpath("//*[@id='socialbiography']");
	public By biographyPublicCheckBox=By.xpath("//*[@id='bioshowsocial']");
	
	public By saveEditProfile=By.xpath("//*[contains(@onclick,'Appyscript.Socialprofileupdate')]");
	public By clickNative=By.xpath("//android.widget.CheckedTextView[@index='0']");
	public By clickdateNative=By.xpath("//android.widget.Button[@index='2']");
	
	//----------------------------search------------------------------------------
	public By searchEnter=By.xpath("//*[@id='socialusersearch']");
	public By userTAB=By.xpath("//*[contains(@class,'newsTand-MobileTab arial')]/div[1]");
	public By postTAB=By.xpath("//*[contains(@class,'newsTand-MobileTab arial')]/div[2]");
	public By follow_UnfollowBtn=By.xpath("//*[contains(@onclick,'Appyscript.socialfollowusers')]");
	public By userclick=By.xpath("//*[contains(@id,'socialsearcheduser')]/li[1]/div[1]/div[1]//a[contains(@onclick,'Appyscript.Socialuserprofiles')]");
	public By followersTAB=By.xpath("//*[contains(@class,'follow_grid arial')]/li[1]/a");
	public By followingTAB=By.xpath("//*[contains(@class,'follow_grid arial')]/li[2]/a");
	public By editTAB=By.xpath("//*[contains(@id,'socialuserstab')]/ul[1]/li[1]");
	public By postCount_gettext=By.xpath("//*[contains(@id,'tabs1')]//h1");
	public By likeTAB=By.xpath("//*[contains(@id,'socialuserstab')]/ul[1]/li[2]");
	public By cameraTAB=By.xpath("//*[contains(@id,'socialuserstab')]/ul[1]/li[3]");
	public By UserTAB=By.xpath("//*[contains(@id,'socialuserstab')]/ul[1]/li[4]");
	
	public By user_get_search=By.xpath("//*[@id='userName']");
	public By totalPost=By.xpath("//*[contains(@id,'streampostcount2')]");
	public By openblockmenu=By.xpath("//*[contains(@id,'socialmypost2')]/div[1]//*[contains(@class,'post-ban')]/a");
	public By blockUser=By.xpath("//*[contains(@onclick,'Appyscript.socialblockuser')]");
	public By repot=By.xpath("//*[contains(@class,'list-block')]/ul/li[2]/a");
	public By unblock=By.xpath("//*[contains(@onclick,'Appyscript.socialunblockuser')]");
	public By unblockMenuPage=By.xpath("//*[@class='SearchResult']/li[1]//*[contains(@onclick,'Appyscript.socialunblockuser')]");
	public By i_videos=By.name("Videos");
	public By i_choose=By.name("Choose");
	public By i_closeVideo=By.name("//XCUIElementTypeButton[@name=\"Done\"]\r\n");
	
	//---------------Edit notification----------------
	public By followsme=By.xpath("//*[contains(@class,'setting-list setting-form')]/li[1]//label");
	public By commentsmypost=By.xpath("//*[contains(@class,'setting-list setting-form')]/li[2]//label");
	public By likemypost=By.xpath("//*[contains(@class,'setting-list setting-form')]/li[3]//label");
	public By emaillist=By.xpath("//*[contains(@class,'setting-list setting-form')]/li");
	
	public By logout=By.xpath("//*[contains(@onclick,'Appyscript.socialnetworlogout')]");
	
	//------------------------------------------------------------------------------------
	public By getUsernameMP=By.xpath("//*[@id='userName']");
	public By getFollowersMP=By.xpath("//*[contains(@class,'follow_grid')]/li[1]/a");
	public By getFollowingMP=By.xpath("//*[contains(@class,'follow_grid')]/li[2]/a");
	public By getStatusPostCountMp=By.xpath("//*[@id='streampostcount']");
	public By getPostUserNameMP=By.xpath("//*[contains(@class,'autoslidetab')]/div[1]/div[1]/div[1]//*[contains(@id,'socialmypost')]/div[1]//*[contains(@class,'post-title')]/a");
	public By getPostTimeMP=By.xpath("//*[contains(@class,'autoslidetab')]/div[1]/div[1]/div[1]//*[contains(@id,'socialmypost')]/div[1]//*[contains(@class,'post-time')]");
	public By getlikePostTitleListMP=By.xpath("//*[contains(@id,'socialmypostlike')]//*[contains(@class,'post-title')]");
	public By getlikeposttextMP=By.xpath("//*[contains(@id,'socialmypostlike')]//*[contains(@class,'post-feed')]");
	public By getlikecountMP=By.xpath("//*[contains(@id,'socialmypostlike')]/div[1]/div[1]//*[contains(@class,'post-history arial')]/a[1]/span");
	public By getcommentcountMP=By.xpath("//*[contains(@id,'socialmypostlike')]/div[1]/div[1]//*[contains(@class,'post-history arial')]/a[2]/span");
	public By getsettinglistMP=By.xpath("//*[contains(@class,'setting-list arial')]/li");
	public By getcameraUserNameMP=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-title')]/a");
	public By getcameraPostTimeMP=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-title')]//*[contains(@class,'post-time')]");
	public By getcameraPostTextMP=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-container')]//*[contains(@class,'post-feed')]/p");
	public By getcameraLikecount=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-container')]//*[contains(@class,'post-history  arial')]/a[1]/span");
	public By getcameracommentcount=By.xpath("//*[contains(@class,'views')]/div[3]/div[2]//*[contains(@data-page,'socialnetwork-Post')]//*[contains(@class,'post-container')]//*[contains(@class,'post-history  arial')]/a[2]/span");
	public By getsharelistcameraMP=By.className("android.widget.TextView");
	public By i_cancelBtn = By.xpath("//*[@name='Cancel']");
	
	//------------------------------------------------------------------------------------------------------
	public By getHeaderSocialNetworkpage=By.xpath("//div[@class='navbar']/div[2]/div[2]");  // verify header title 
	//public By get=By.xpath("");
	public By getMenuList=By.xpath("//*[@id='menuservice']/ul/li/a");
	public By getUserwhopost=By.xpath("//*[@class='masonry']/div[1]/div[1]/div[1]/a"); 
	public By getPostTime=By.xpath("//*[@class='masonry']/div[1]/div[1]/div[1]/div[2]");
	public By getPost=By.xpath("//div[@class='masonry']/div[1]/div[2]/p");
	public By newlyPostOpen=By.xpath("//div[@class='masonry']/div[1]/div[2]/div/img");
	
	public By photomenuOpen=By.xpath("//android.widget.ImageButton[@index='2']");
	public By save=By.xpath("//android.widget.TextView[@index='0']");
	public By share=By.xpath("//android.widget.TextView[@index='1']");
	public By cancel=By.xpath("//android.widget.TextView[@index='2']");
	
	public By i_photomenuOpen=By.xpath("//XCUIElementTypeButton[@name=\"threedot\"]");
	public By i_save=By.xpath("//XCUIElementTypeButton[@name=\"Save\"]");
	public By i_share=By.xpath("//XCUIElementTypeButton[@name=\"Share\"]");
	public By i_shareCancle=By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	public By i_cancel=By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	//public By =By.xpath("//*[@id='']");
	
	public By getLike=By.xpath("//div[@class='masonry']/div[1]/div[3]/a/span");
	public By getComment=By.xpath("//div[@class='masonry']/div[1]/div[3]/a[2]/span");

	public By getUsernamemenu= By.xpath("//*[contains(@id,'socialusername')]");
	public By getmenu= By.xpath("//a[contains(@class,'navs')]");
	public By gethome= By.xpath("//a[contains(@onclick,'Appyscript.datingmainmenu')]");
	public By getmainmenu= By.xpath("//*[@id='menuservice']/ul/li[2]/a");
	public By gettag= By.xpath("//*[@id='menuservice']/ul/li[3]/a");
	public By getPostedtag=By.xpath("//*[contains(@class,'page-title')]/a");
	public By getPostedtagcount=By.xpath("//*[contains(@class,'page-title')]/span");

	
	public By getmyprofile= By.xpath("//*[@id='menuservice']/ul/li[4]/a");
	public By getblockuser= By.xpath("//*[@id='menuservice']/ul/li[5]/a");
	public By getlogout= By.xpath("//a[contains(@onclick,'Appyscript.AppLogout')]");

	public By getAlertHeadertitle=By.xpath("//div[@class='modal-title']");
	public By getAlertpopupmessage=By.xpath("//div[@class='modal-text']");
	
	


	static SoftAssert softassert;
	public SocialNetworkPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;	
		comm=new CommanClassSocialNetwork(driver);
	}

	public void Login() {
		Boolean UN=comm.IselementPresent(username);
		if (UN) {
			try{
				Boolean email=comm.TextField(username, "appypie2016@gmail.com");
			}catch (Exception e) {
				System.out.println("email is Not present");
			}
			try{
				Boolean pass=comm.TextField(password, "12345678");
			}catch (Exception e) {
				System.out.println("password is Not present");
			}
			try{
				Boolean login=comm.Openlinks(LoginBtn);
			}catch (Exception e) {
				System.out.println("Login button is Not present");
			}

			try{
				driver.findElement(Acceptandcontinue).click();
			}catch (Exception e) {
				System.out.println("Accept and continue is Not present");
			}
		
			SocialNetworkPage sn=new SocialNetworkPage(driver);
			Boolean socialNetwork1=comm.IselementPresent(sn.opensocialnetworkmodule);
			if (socialNetwork1) 
				comm.Openlinks(sn.opensocialnetworkmodule);
			else {
				System.out.println("Again Module list is not open after login");
			}
			try{
				driver.findElement(Acceptandcontinue).click();
			}catch (Exception e) {
				System.out.println("Accept and continue is Not present");
			}
		
		}else{
			System.out.println("User is already Login");
		}

	}

}

