package com.appypie.pages.Taxi;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BookingPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	public By pagelink = By.xpath("//a[@data-productid='taxi-ride']");
	public By login = By.xpath("//*[@text='Login']");
	public By i_signIn = By.xpath("//XCUIElementTypeButton[@name='SIGN IN']");
	public By i_email = By.xpath("//XCUIElementTypeTextField[@value='Email ID*']");
	public By i_pwd = By.xpath("//XCUIElementTypeSecureTextField[@value='Password*']");
	public By i_signInBtn = By.xpath("//XCUIElementTypeButton[@name='SIGN IN']");
	
	public By whereToo = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/etDropAdd') and @text='Where to?']");
	public By i_whereToo = By.xpath("//*[contains(@name,'Where to?')]");
	public By pickup = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/etPickupAddress') and @text='Pickup Location']");
	public By i_pickup = By.xpath("//XCUIElementTypeTextField[@value='Where to?']");
	public By dropOff = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/etDropoffAddress') and @text='Where To?']");
	public By i_dropOff = By.xpath("//XCUIElementTypeTextField[@value='Where to?']");
	public By crossPickup = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/img_clear_PickUP') and @index='1']");
	public By i_crossPickup = By.xpath("");
	public By crossWhereToo = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/img_clear_Drop') and @index='1']");
	public By i_crossWhereToo = By.xpath("");
	public By selectLocation = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/recyclerView') and @index='2']");
	public By i_selectLocation = By.xpath("//XCUIElementTypeStaticText[contains(@value,'Noida City Centre')]");
	public By i_getBookingID = By.xpath("//XCUIElementTypeStaticText[contains(@name,'BOOKING ID')]");
	
	public By i_gettaxiDetails = By.xpath("//XCUIElementTypeOther[3]//XCUIElementTypeStaticText");
	public By i_getbookingID = By.xpath("//XCUIElementTypeStaticText[contains(@name,'BOOKING ID')]");
	public By i_gettollFare = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Toll Fare')]");
	public By i_getTax = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Tax')]");
	public By i_gettotalFare = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Total Fare')]");
	public By i_gettotalDiscount = By.xpath("//XCUIElementTypeStaticText[contains(@name,'Total Discount')]");
	public By i_getPickup_Drop_Duration = By.xpath("//XCUIElementTypeApplication[@name=\"SuperAppypie\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText");
	public By i_submitReview = By.xpath("//XCUIElementTypeButton[@name=\"Submit Review\"]");
	public By i_EnterReview = By.xpath("//XCUIElementTypeApplication[@name=\"SuperAppypie\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTextView");
	public By i_DoneReview = By.xpath("//XCUIElementTypeNavigationBar[@name=\"RATE YOUR DRIVER\"]/XCUIElementTypeButton");

	public By promo = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/promocedenewtext') and @text='Promo Code']");
	public By enter_promo = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/et_promoCode') and @text='Enter Promo Code']");
	public By cancel_promo = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/cancel_promo') and @text='CANCEL']");
	public By apply_promo = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/apply_promo') and @text='APPLY']");
	public By cab = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/four_cars_button')]");
	public By cabDetails = By.xpath("//android.widget.LinearLayout");
	public By cabDone_btn = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/btn_done')] ");

	public By pymnt = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/card_info') and @text='Select Payment Method']");
	public By i_selectpaymentMethod = By.xpath("//XCUIElementTypeButton[@name=\"Select Payment Method\"]");
	public By cross_pymnt = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/payment_cancel')]");
	public By card_pymnt = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/payment_card')]");
	public By cash_pymnt = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/payment_cash')]");
	public By i_cash_pymnt = By.xpath("//XCUIElementTypeButton[@name='CASH']");
	//public String i_cash_pymnt = "CASH"; //XCUIElementTypeButton[@name="CASH"]
	public By card_not_found_message = By.xpath("//*[contains(@resource-id,'android:id/message')]");
	public By card_not_found_alert = By.xpath("//*[contains(@resource-id,'android:id/button2') and @text='OK']");
	public By backCardPage = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/login_back_button')]");
	public By rqestDriver = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/request_pick_up_here') and @text='Request Driver']");
	public By i_rqestDriver = By.xpath("//XCUIElementTypeButton[@name=\"REQUEST DRIVER\"]");
	public By i_minet = By.xpath("//XCUIElementTypeStaticText[contains(@name,'MIN')]");

	public By onTheWay = By.xpath("//android.widget.Button[@index='2']");
	public By arived = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/driver_on_the_way') and @text='DRIVER REACHED']");
	public By journay = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/driver_on_the_way') and @text='JOURNEY STARTED']");
	
	public By recpt = By.xpath("//android.widget.TextView[@text='Reciept' and @index='1']");
	public By bookingID = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/invoice_booking_id')]");
	public By tollFare = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/toll_fare')]");
	public By tollPrice = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/txt_fare')]");
	public By discount = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/discount_fare')]");
	public By pickupLocation = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/invoice_pickup_location')]");
	public By dropoffLocation = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/invoice_dropoff_location')]");
	public By duration = By.xpath("//android.widget.RelativeLayout[@index='0']");
	public By dstnce = By.xpath("//android.widget.RelativeLayout[@index='1']");
	public By avgSpeed = By.xpath("//android.widget.RelativeLayout[@index='2']");
	
	public By rate = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/invoice_driver_rating') and @index='1']");
	public By submitRevw = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/paymentdone')]");


	public By loginSignup = By.xpath("//android.widget.TextView[@text='Register']");
	public By address_selection = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/address_textview') and @text='Noida Special Economy Zone Block A Phase-2 Noida Uttar Pradesh India']");
	public By Dropoff_address_selection = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/location_name') and @text='Noida City Centre']");



	
	public By option = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/driver_arrow')]");
	public By share = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/btn_share_eta')]");
	public By call = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/contact_driver')]");
	public By cancel = By.xpath("//android.widget.Button[@index='2']");
	public By cancelText = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/etCancelRide')]");
	public By sbmit = By.xpath("//android.widget.Button[@index='1']");
	
	public By cancelTextMessge = By.xpath("//*[contains(@resource-id,'android:id/message')]");
	public By cancelOk = By.xpath("//*[contains(@resource-id,'android:id/button2')]");
	
	public BookingPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}


	public boolean promoCodeText(String Text){
		boolean code = false;
		WebElement off = ElementWait.waitForOptionalElement(driver, enter_promo, 20);
		off.sendKeys(Text);
		code = true;
		return code;
	}


	public boolean backPayment(){
		boolean back = false;
		WebElement openlinks = ElementWait.waitForOptionalElement(driver, backCardPage, 20);
		if (openlinks != null && openlinks.isDisplayed()) {
			openlinks.click();
		}
		back=true;
		return back;
	}


	public boolean whereToo(){
		boolean where = false;
		WebElement openlinks = ElementWait.waitForOptionalElement(driver, whereToo, 20);
		openlinks.click();
		openlinks.click();
		where=true;
		return where;
	}



	public boolean addressCross(){
		boolean cross = false;
		WebElement crossLink = ElementWait.waitForOptionalElement(driver, crossPickup, 20);
		crossLink.click();
		cross=true;
		return cross;
	}

	public boolean addressmessage(){
		boolean add = false;
		WebElement alert = ElementWait.waitForOptionalElement(driver, card_not_found_message, 20);
		if (alert != null && alert.isDisplayed()) {
			add=true;

		}
		return add;
	}

	
	public boolean isSharePresent(){
		boolean sharefeature = false;
		WebElement shareLink = ElementWait.waitForOptionalElement(driver, share, 20);
		if (shareLink != null && shareLink.isDisplayed()) {
			sharefeature=true;

		}
		return sharefeature;
	}
	
	
	public boolean isCallPresent(){
		boolean callfeature = false;
		WebElement callLink = ElementWait.waitForOptionalElement(driver, call, 20);
		if (callLink != null && callLink.isDisplayed()) {
			callfeature=true;

		}
		return callfeature;
	}
	
	public boolean cancelMessage(String Text){
		boolean message = false;
		WebElement cancl = ElementWait.waitForOptionalElement(driver, cancelText, 20);
		cancl.sendKeys(Text);
		message = true;
		return message;
	}
	
	
	public boolean enterLocation(){
		boolean cross = false;
		WebElement enter = ElementWait.waitForOptionalElement(driver, dropOff, 20);
		enter.click();
		enter.sendKeys("Noida");
		cross = true;
		return cross;
	}






	public boolean pickUpAddressField(){
		boolean address = false;
		WebElement addressLink = ElementWait.waitForOptionalElement(driver, selectLocation, 20);
		try {
			Thread.sleep(3000);

			String str=addressLink.getText();
			System.out.println(str);
			String[] s=str.split("\n");
			System.out.println(s.length);
			//addressLink.clear();
			for(int i=0;i<s.length;i++)
			{
				if(s[i].equalsIgnoreCase("Appy pie"))
				{
					addressLink.sendKeys(s[i]);
					addressLink.click();
				}
				else {
					System.out.println("address not visible by searching on pickup field");
				}

			}


		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return address;
	}


	public boolean selectOptionWithText(String textToSelect) {
		boolean address = false;

		try {
			WebElement autoOptions = ElementWait.waitForOptionalElement(driver, selectLocation, 20);

			List<WebElement> optionsToSelect = autoOptions.findElements(By.id("com.snappy.appypie:id/location_name"));
			for(WebElement option : optionsToSelect){
				if(option.getText().equals(textToSelect)) {
					System.out.println("Selected: "+textToSelect);
					option.click();
					break;
				}
			}

			address=true;

		} catch (NoSuchElementException e) {
			System.out.println(e.getStackTrace());
		}
		catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
		return address;
	}


	public String GetPassengerText(By getText)  {
		String text = null;
		WebElement availableText = ElementWait.waitForOptionalElement(driver, getText, 20);
		if (availableText != null && availableText.isDisplayed()) {
			try {
				Thread.sleep(2000);
				text = availableText.getText();
				System.out.println("Text:  " + text);

			} catch (InterruptedException e) {
				e.printStackTrace();
				e.getMessage();
			}
		}
		return text;
	}






	public boolean Openlinks(By link)  {
		boolean links = false;
		try{
			Thread.sleep(2000);
			WebElement linkpresent = ElementWait.waitForOptionalElement(driver, link, 20);
			if (linkpresent != null && linkpresent.isDisplayed()) {
				linkpresent.click();
				TimeUnit.SECONDS.sleep(4);
				links = true;
			} else {
				System.out.println(link+"  Link is not present");
			}
		}
		catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
			e.getMessage();
		}
		return links;
	}

	public boolean isLogindisplaying() {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, loginSignup, 20);
		if (login != null && login.isDisplayed()) {
			open = true;
		}
		return open;
	}


}
