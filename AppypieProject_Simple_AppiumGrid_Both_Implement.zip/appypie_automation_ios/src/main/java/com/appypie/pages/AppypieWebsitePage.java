package com.appypie.pages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;

public class AppypieWebsitePage extends TestSetup{

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	//========================================================================================================
	public By websiteFolder= By.xpath("//a[@data-productidentifier='folder_1505909801985_71']");
	public By insidewebsitePage = By.xpath("//a[@data-productidentifier='website_1505396076719_21--folder_1505909801985_71']");
	public By i_insidewebsitePageHeader = By.xpath("//a[@data-productidentifier='website_1505396076719_21--folder_1505909801985_71']");
	public By outsidewebsitePage = By.xpath("//a[@data-productidentifier='website_1490278621516_21--folder_1505909801985_71']");
	public By websiteUrls = By.xpath("//a[@class='appypie-list'][@data-page='website']");
	public By outSideAppwebsiteUrl = By.xpath("//a[@class='appypie-list'][@data-page='website'][@data-index='0']");
	public By outSideAppwebsiteUrlInvalid = By.xpath("//a[@class='appypie-list'][@data-page='website'][@data-index='2']");
	public By webview = By.id("text_Tittle");
	public By insideAppInvalid = By.xpath("//android.view.View[@content-desc='Webpage not available']");
	public By outsideAppHeader = By.id("com.android.chrome:id/url_bar");
	
	//public By  = By.xpath("");
	// ***** locator for ios*****
	public By i_insideUrl = By.xpath("//XCUIElementTypeStaticText[@name='Website3']");
	public By i_outsideHeader = By.id("URL");
	
	
	//========================================================================================================
	public By i_websiteFolder= By.xpath("//*[@data-productid='folder']");
	public By  i_insideWebsite= By.xpath("//*[@data-productidentifier='website_1520418496578_21--folder_1520418311459_71']");
	public By  i_OutsideWebsite= By.xpath("//*[@data-productidentifier='website_1520418550097_21--folder_1520418311459_71']");
	public By website1= By.xpath("//*[text()='Website']//preceding-sibling::span//following-sibling::i");
	public By iback= By.xpath("//XCUIElementTypeButton[@name='Return to CreatedApp']");
	public String i_backBtn_ReturntoCreatedApp="Return to CreatedApp";
	public By website2= By.xpath("//*[text()='Website2']//preceding-sibling::span//following-sibling::i");
	public By i_back_website3= By.xpath("");
	public By websiteInvalid= By.xpath("//*[text()='WebsitInvalid']//preceding-sibling::span//following-sibling::i");
	public By i_back_website= By.xpath("");

	
	

	public static String PageName = "";
	List<WebElement> urlelements;
	List<Object> insideAppData;

	public AppypieWebsitePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openwebsiteFolder() {
		WebElement folder = ElementWait.waitForOptionalElement(driver, websiteFolder, 20);
		if (folder != null) {
			folder.click();
		} else {
			Logger.info("Website folder is not open");
		}
	}

	public void openwebsitePage(String type) {
		WebElement element_websitePage = null;
		if (type.equals("inside")) {
			element_websitePage = ElementWait.waitForOptionalElement(driver, insidewebsitePage, 20);
		} else {
			element_websitePage = ElementWait.waitForOptionalElement(driver, outsidewebsitePage, 20);
		}
		if (element_websitePage != null) {
			PageName = element_websitePage.findElement(By.xpath(".//span")).getText();
			element_websitePage.click();
		} else {
			Logger.info("Website page is not present in the app or flow is not main Menu");
		}
	}

	public boolean identifywebsiteOpen() {
		boolean websiteContent = false;
		WebElement element_urlList = ElementWait.waitForOptionalElement(driver, outsidewebsitePage, 20);
		if (element_urlList != null && element_urlList.isDisplayed())
			websiteContent = true;
		else
			Logger.info("Website URL'S are not found on page or Website page is not open");
		return websiteContent;
	}


	public boolean outsideAppOpenWebsiteUrls(String urlNumber) throws InterruptedException {
		boolean urlbar = false;
		WebElement linkHeader = null;
		WebElement url=null;
		if(urlNumber.equals("one"))
		url = ElementWait.waitForOptionalElement(driver, outSideAppwebsiteUrl, 20);
		else
		url = ElementWait.waitForOptionalElement(driver, outSideAppwebsiteUrlInvalid, 20);
		url.click();
		Thread.sleep(2000);
		driver.context("NATIVE_APP");
		if (!globledeviceName.equals("iPhone")) {
			linkHeader = ElementWait.waitForOptionalElement(driver, outsideAppHeader, 20);
			if (linkHeader != null && linkHeader.isDisplayed()) {
				urlbar = true;
				driver.navigate().back();
				Thread.sleep(1000);
			} else {
				Logger.info("Website url is not open");
			}
		} else {
			linkHeader = ElementWait.getIosNativeElement(driver, i_outsideHeader, 10);
			if (linkHeader != null) {
				urlbar = true;
				Thread.sleep(3000);
				driver.findElementByName("Return to SuperAppypie").click();
			} else {
				Logger.error("Website Url is not open in native after clicking on view button from feed in ios");
			}
			
			
			
		}
		PageElement.changeContextToWebView(driver);
		return urlbar;
	}

	@Override
	public void pageSetUp() {
		// TODO Auto-generated method stub
		
	}

}
