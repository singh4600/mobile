package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ClaimFormPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By comment = By.xpath("//div[@class='directory-claim']//textarea[@id='text']");
	By submitBtn = By.xpath("//div[contains(@onclick,'Appyscript.sendclaim')]");

	public ClaimFormPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isClaimFormOpen() {
		boolean open = false;
		WebElement submit = ElementWait.waitForOptionalElement(driver, submitBtn, 20);
		if (submit != null && submit.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Claim form is not open");
		}
		return open;
	}

	public void writeComment(String text) {
		PageElement.sendKey(driver, comment, text);
	}

	public void submitClaimForm() {
		driver.findElement(submitBtn).click();
	}
}
