package com.appypie.pages.ECommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EcommPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");

	public By openEcommerceModule= By.xpath("//a[@data-productid='eecommerce']");
	public By openEtsylink= By.xpath("//a[@data-identifire='etsy']");
	public By openShopifylink= By.xpath("//a[@data-identifire='shopify']");
	public By openWooCommercelink= By.xpath("//a[@data-identifire='wooCommerce']");
	public By openMagentolink= By.xpath("//a[@data-identifire='magento']");
	public By openVolusionlink= By.xpath("//a[@data-identifire='volusion']");
	public By openBigCommercelink= By.xpath("//a[@data-identifire='bigCommerce']");
	public By openOSCommerecelink= By.xpath("//a[@data-identifire='osCommerce']");
	public By openprestashoplink= By.xpath("//a[@data-identifire='prestaShop']");
	public By opensquerespacelink= By.xpath("//a[@data-identifire='squareSpace']");
	public By openAmeriCommercelink= By.xpath("//a[@data-identifire='ameriCommerce']");
	public By openAmazonlink= By.xpath("//a[@data-identifire='amazon']");
	public By openEbaylink= By.xpath("//a[@data-identifire='ebay']");
	public By openAppypiecustomelink= By.xpath("//a[@data-identifire='customStore']");
	public By clickbackbuttonHomepage= By.xpath("//a[@class='link back bottomBack']");



	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	

	public EcommPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}