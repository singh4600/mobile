package com.appypie.pages.OrderFoodPages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class Pickup {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	Dimension size;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");
	
	
	public By name_textfield= By.xpath("//*[@id='foodorderBillingpickup']//*[@id='bfname']"); // fist name
	public By Telephone_textfield= By.xpath("//*[@id='foodorderBillingpickup']/*[@id='bpNo']"); // mobile no
	public By Email_textfield= By.xpath("//*[@id='foodorderBillingpickup']/*[@id='bemail']"); // email id
	public By Address_textfield= By.xpath("//*[@id='foodorderBillingpickup']/*[@id='bAddress']"); // address
	public By City_textfield= By.xpath("//*[@id='foodorderBillingpickup']/*[@id='bCity']"); // city
	public By State_textfield= By.xpath("//*[@id='foodorderBillingpickup']/*[@id='bState']"); // state
	public By Zip_textfield= By.xpath("//*[@id='foodorderBillingpickup']/*[@id='bZip']"); // zip
	public By Country_textfield= By.xpath("//*[@id='foodorderBillingpickup']//*[@id='bcountryTry']//*[@id='bCountry']"); // country
	
	//---------------------------------------------------
	public Pickup(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}
	
	
		}
