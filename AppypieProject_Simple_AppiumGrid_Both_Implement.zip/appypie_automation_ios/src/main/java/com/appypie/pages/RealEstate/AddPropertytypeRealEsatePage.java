package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AddPropertytypeRealEsatePage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By nextlink= By.xpath("//*[contains(@onclick,'Appyscript.realestateAddListingLocation')]");
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By propertyTypelist_gettext=By.xpath("//*[contains(@id,'propertylistreal')]/li");
	


	public AddPropertytypeRealEsatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}