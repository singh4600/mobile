package com.appypie.pages.directoryHyperLocalpages;

import java.util.concurrent.TimeUnit;

import org.apache.fop.area.Page;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class HyperLocalRequestQuoteForm {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By timing = By.className("timing");
	By timeselect = By.xpath("//input[contains(@onclick,'Appyscript.set_time')]");
	By timeselect1 = By.xpath("//li[contains(@class,'timing')]/span[1]/input[1]");
	By jobLocation = By.id("address");
	By description = By.id("discription");
	By submitQuery = By.xpath("//button[contains(@onclick,'Appyscript.sendrequestHyperLocal')]");
	By specificDateSpan = By.xpath("//li[@class='timing']/span[3]/input");
	By dateTime = By.id("dtime");
	By remoteJob= By.id("jobremotely");

	public HyperLocalRequestQuoteForm(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isRequestQuotePageOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement page = ElementWait.waitForOptionalElement(driver, timing, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Request quote page is not open");
		}
		return open;
	}

	public void clickTiming() {
		WebElement radio = ElementWait.waitForOptionalElement(driver, timeselect1, 30);
			if (radio != null && !radio.isSelected()) {
				radio.click();
			}
	}
	
	public void clickremoteJobCheckBox() {
		WebElement box = ElementWait.waitForOptionalElement(driver, remoteJob, 10);
		if (box != null && !box.isSelected()) {
			box.click();
		}
	}

	public void clickSpecificDateOption() {
		PageElement.locateClickableElement(driver, specificDateSpan);
	}

	public boolean isDateTimeVisible() {
		boolean visible = false;
		WebElement dt = ElementWait.waitForOptionalElement(driver, dateTime, 5);
		if (dt != null && dt.isDisplayed()) {
			visible = true;
		}
		return visible;
	}

	public void EnterLocation() {
		PageElement.sendKey(driver, jobLocation, "5th Avenue");
	}

	public void EnterDescription() {
		PageElement.sendKey(driver, description, "for testing purpose");
	}

	public void submitQuery() {
		PageElement.locateClickableElement(driver, submitQuery);
	}

//***************************Prince
	 public void scrollUp() {
		  driver.context("NATIVE_APP");
		  try {
		   TimeUnit.SECONDS.sleep(3);
		   Dimension dimens = driver.manage().window().getSize();
		   System.out.println(dimens);
		   int x = (int) (dimens.getWidth() * 0.5);
		   System.out.println(x);
		   int startY = (int) (dimens.getHeight() * 0.5);
		   System.out.println(startY);
		   int endY = (int) (dimens.getHeight() * 0.2);
		   System.out.println(endY);
		    for (int i=0;i<10;i++)
		   driver.swipe(x, endY , x, startY, 800);
		  } catch (InterruptedException e) {
		   System.out.println("scroller not working");
		   e.printStackTrace();
		   e.getMessage();
		  }
		  
		  PageElement.changeContextToWebView(driver);
		  }
	
	
}
