package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class PayatHotelConfirmPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	
	public By PayAtHotel= By.xpath("//*[contains(@label,'Pay At Hotel')]");
	public By CreditCardviaPayPal= By.xpath("//*[contains(@label,'Credit Card via PayPal Payment Gateway')]");
	public By PayPalExpress= By.xpath("//*[contains(@label,'PayPal Express')]");
	public By Paywithcreditcard= By.xpath("//*[contains(@label,'Pay with credit card over the phone')]");
	public By Stripe= By.xpath("//*[contains(@label,'Stripe')]");
	public By confirm_btn= By.xpath("//*[@id='tabcod']/a");
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By payatHotelHeading_gettext=By.xpath("//*[@id='tabcod']/p");
	public By CreditCardviaPayPal_gettext=By.xpath("//*[@id='creditCardThroughPaypal']/p");
	public By PayPalExpress_gettext=By.xpath("//*[@id='tabpaypal']/p");
	public By Paywithcreditcard_gettext=By.xpath("//*[@id='tabobp']/p");
	public By Stripe_gettext=By.xpath("//*[@id='creditCardThroughStripe']/p");
	
	
	



	public PayatHotelConfirmPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}