package com.appypie.pages.Taxi;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class TaxiDriver {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;


	public By signIn = By.xpath("//android.widget.Button[@index='0']");
	public By register = By.xpath("//android.widget.Button[@index='1']");

	public By emailTaxi = By.xpath("//android.widget.LinearLayout[@index=0]/android.widget.EditText[@index='1']");
	public By pwdTaxi = By.xpath("//android.widget.LinearLayout[@index=1]/android.widget.EditText[@index='1']");
	public By loginBtnTaxi = By.xpath("//android.widget.TextView[@index='0']");
	public By cariD = By.xpath("//android.widget.LinearLayout[@index=2]/android.widget.EditText[@index='1']");
	
	public String passengerapp="Super Taxi";
	public String driverapp="Automate Driver";
	public By openPassenger = By.xpath("//com.android.systemui[@index='0']/com.android.systemui[@index=0]");
	public By openDriver = By.xpath("//com.android.systemui[@index='0']/com.android.systemui[@index=1]");

	public String accept = "com.app.driverautomate:id/accept_button";
	public String ihaveArrived="com.app.driverautomate:id/ihavearrived";
	public String beginJourney="com.app.driverautomate:id/ihavearrived";
	public String passengerDropped="com.app.driverautomate:id/passengerdroped";
	public String finish="com.app.driverautomate:id/finish_button";
	
	
	public boolean isLogindisplaying() {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, register, 20);
		if (login != null && login.isDisplayed()) {
			open = true;
		}
		else {
			Logger.info("register button not displaying");
		}
		return open;
	}


	public void loginIntoPageNative(AppiumDriver<MobileElement> driver, String email, String password, String id) {
		
		try {
			PageElement.sendKey(driver, emailTaxi, email);
			PageElement.sendKey(driver, pwdTaxi, password);
			PageElement.sendKey(driver, cariD, id);
			Thread.sleep(3000);
			PageElement.locateClickableElement(driver, loginBtnTaxi);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
			e.getMessage();
		}
		
	}


}
