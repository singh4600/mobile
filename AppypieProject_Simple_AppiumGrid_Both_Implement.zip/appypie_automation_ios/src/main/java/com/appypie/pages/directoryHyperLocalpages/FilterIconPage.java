package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class FilterIconPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By filterPage = By.xpath("//h3[text()='Sort By']");
	By lowerRange = By.id("rangeValue1");
	By upperRange = By.id("rangeValue2");
	By leftSlider = By.xpath("//div[@class='noUi-handle'][@data-handle='0']");
	By rightSlider = By.xpath("//div[@class='noUi-handle'][@data-handle='1']");
	By kmBtn = By.xpath("//div[@id='distance-slider-tab']//a[text()='KM']");
	By mileBtn = By.xpath("//div[@id='distance-slider-tab']//a[text()='Miles']");
	//By distanceSearch = By.xpath("//div[@id='tab1']//div[@class='hyper-gray-wrapper']");
	By distanceSearch = By.xpath("//div[@id='tab1']//button[contains(@onclick,'AndFilterData')][contains(@onclick,'filter')]");
	//By ratingSearch = By.xpath("//div[@id='tab2']//div[@class='hyper-gray-wrapper']");
	By ratingSearch = By.xpath("//div[@id='tab2']//button[contains(@onclick,'AndFilterData')][contains(@onclick,'filter')]");
	By ratingIcon = By.xpath("//a[@href='#tab2']");
	By distanceIcon = By.xpath("//a[@href='#tab1']");
	By resetBtn = By.xpath("//*[contains(@onclick,'hl_resetFilter')]");
	By stars = By.xpath("//input[@type='checkbox'][@id='1']");
	public By starCheckbox = By.xpath("//div[@class='pull-right']//label[@for='3']");
	public By starCheckbox1 = By.xpath("//div[@class='pull-right']//label[@for='1']");
	public By starCheckbox2 = By.xpath("//div[@class='pull-right']//label[@for='2']");
	By ratingTab = By.id("hl_star1");
	By ratingTabP = By.xpath("//*[contains(@class,'ratingList')]");
	// ********* Locators for hyperlocal*********************
	By hl_rightSlider = By.xpath("//div[@id='hyperlocalDistanceGet']//div[@class='noUi-handle'][@data-handle='1']");
	By hl_rightSlider1 = By.xpath("//div[@id='hyperlocalDistanceGet']//div[@class='noUi-handle'][@data-handle='0']");
	By hl_upperRange = By.id("hyperDistValue2");
	By priceIcon = By.xpath("//a[@href='#tab3']");
	By priceSearch = By.xpath("//div[@id='tab3']//button[contains(@onclick,'AndFilterData')][contains(@onclick,'filter')]");
	By upperPrice = By.id("hyperPriceValue2");
	By price_rightSlider = By.xpath("//div[@id='hyperlocalPriceGet']//div[@class='noUi-handle'][@data-handle='1']");
	
	
	// ********* Locators for Distance(Prince)*********************
	By distanceAllBtn = By.xpath("//div[@class='filter-page bodypan']/div[1]/ul[1]/a[1]");
	By distanceCustom = By.xpath("//div[@class='filter-page bodypan']/div[1]/ul[1]/a[2]");
	By distanceDirectory = By.xpath("//div[@id='dirctoryrangGet']");
	By distanceDirectoryN = By.xpath("android.view.View[contains(@resource-id,'distance-slider')]");
	By filterBtn = By.xpath("//*[contains(@onclick,'hl_filterData')]");
	By dstance = By.id("hyperlocalDistanceGet");
	By price = By.id("hyperlocalPriceGet");
	By Avabity_Today = By.xpath("//a[@value='Today']");
	By Avabity_Tomorrow = By.xpath("//a[@value='Tomo']");
	By Avabity_Custom = By.xpath("//a[@value='Custom']");
	By Avabity_Any = By.xpath("//a[@value='Any']");
	By scroller = By.xpath("//div[@id='hyperlocalPriceGet']/div[1]/div[1][@style='left: 52.7536%;']");
	By star1 = By.id("hl_star1");
	By star2 = By.id("hl_star2");
	By star3 = By.id("hl_star3");
	By star4 = By.id("hl_star4");
	By star5 = By.id("hl_star5");

	
	public FilterIconPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}


	//-------------------Prince(start)----------	
	public boolean clickDistanceAll() {
		boolean distanceAll=false;
		WebElement distance = ElementWait.waitForOptionalElement(driver, distanceAllBtn, 20);
		if (distance != null) {
			distance.click();

			distanceAll=true;
		} else {
			Logger.info("Distance All is not visible on filter tab in Hyperlocal page");
		}
		return distanceAll;
	}


	public boolean clickCustom() {
		boolean verifyCustomDistance=false;
		WebElement distance = ElementWait.waitForOptionalElement(driver, distanceCustom, 20);
		if (distance != null && distance.isDisplayed()) {
			distance.click();
			verifyCustomDistance=true;
		} else {
			Logger.info("Distance custom is not visible on filter tab in Hyperlocal page");

		}
		return verifyCustomDistance;
	}

	public boolean clickFilter() {
		boolean verifyfilter=false;

		WebElement filter = ElementWait.waitForOptionalElement(driver, filterBtn, 20);
		if (filter != null && filter.isDisplayed()) {
			
			try {
				filter.click();
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			verifyfilter=true;
		} else {
			Logger.info("Filter button is not visible on filter tab in Hyperlocal page");

		}
		return verifyfilter;
	}



	public boolean isFilterPageOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement filter = ElementWait.waitForOptionalElement(driver, resetBtn, 20);
		if (filter != null) {
			open = true;
		} else {
			Logger.error("Filter page is not open upon clicking filter icon from directory home page");
		}
		return open;
	}


	public boolean scrollSeakBar()
	{
		boolean scroll=false;
		try {
			
			WebElement seek_bar = ElementWait.waitForOptionalElement(driver, dstance , 20);
			int start=seek_bar.getLocation().getX();
			System.out.println(start);
			int end=seek_bar.getSize().getWidth();
			System.out.println(end);
			int y=seek_bar.getLocation().getY();
			System.out.println(y);
			driver.context("NATIVE_APP");
			TouchAction action=new TouchAction(driver);
			Thread.sleep(3000);
			action.press(start,y).moveTo(end-200,y).release().perform();
			scroll=true;
			PageElement.changeContextToWebView(driver);

		} catch (Exception e) {
			e.getMessage();
		}
		return scroll;

	}
	
	
	
	public boolean scrollPriceSeakBar()
	{
		boolean scroll_PriceList=false;
		try {
			WebElement price_seek_bar = ElementWait.waitForOptionalElement(driver, price , 20);
			System.out.println("********Verifying price sickBar*********");
			int startP=price_seek_bar.getLocation().getX();
			System.out.println(startP);
			int endP=price_seek_bar.getSize().getWidth();
			System.out.println(endP);
			Thread.sleep(2000);
			int y_Point=price_seek_bar.getLocation().getY();
			System.out.println(y_Point);
			driver.context("NATIVE_APP");
			Thread.sleep(2000);
			TouchAction act=new TouchAction(driver);
			act.press(startP,y_Point).moveTo(endP+400,y_Point).release().perform();
			scroll_PriceList=true;
			PageElement.changeContextToWebView(driver);

		} catch (Exception e) {
			e.getMessage();
		}
		return scroll_PriceList;

	}
	
	public boolean clickAny(){
		boolean Abalbilty_Any=false;
		WebElement any = ElementWait.waitForOptionalElement(driver, Avabity_Any, 20);
		if (any != null && any.isDisplayed() ) {
			any.click();
			Abalbilty_Any=true;
		} else {
			Logger.info("Any link not clicable under Availability");
		}
		return Abalbilty_Any;

	}



	public boolean clickCustomAvability(){
		boolean CustomAvability =false;
		WebElement Custom = ElementWait.waitForOptionalElement(driver, Avabity_Custom, 20);
		if (Custom != null && Custom.isDisplayed() ) {
			Custom.click();
			CustomAvability=true;
		} else {
			Logger.info("Custom link not clicable under Availability");
		}
		return CustomAvability;

	}



	public boolean clickTomorrow(){
		boolean AbalbiltyTomrow= false;
		WebElement tomorrow = ElementWait.waitForOptionalElement(driver, Avabity_Tomorrow, 20);
		if (tomorrow != null && tomorrow.isDisplayed() ) {
			tomorrow.click();
			AbalbiltyTomrow=true;
		} else {
			Logger.info("Tomorrow link not clicable under Availability");
		}
		return AbalbiltyTomrow;

	}

	public boolean clickToday(){
		boolean AbalbiltyToday= false;
		WebElement today = ElementWait.waitForOptionalElement(driver, Avabity_Today, 20);
		if (today != null && today.isDisplayed() ) {
			today.click();
			AbalbiltyToday=true;
		} else {
			Logger.info("Today link not clicable under Availability");
		}
		return AbalbiltyToday;
	}

	public boolean clickStar(){
		boolean clickONstar= false;
		WebElement str = ElementWait.waitForOptionalElement(driver, star5, 20);
		if (str != null && str.isDisplayed() ) {
			str.click();
			clickONstar=true;
		} else {
			Logger.info("Today link not clicable under Availability");
		}
		return clickONstar;
	}



	
//--------------------Prince(end)--------------------	
	
	
	
	
	public boolean isFilterPageOpenDirectory() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement filter = ElementWait.waitForOptionalElement(driver, filterPage, 20);
		if (filter != null) {
			open = true;
		} else {
			Logger.error("Filter page is not open upon clicking filter icon from directory home page");
		}
		return open;
	}

	public void openRatingTab() {
		WebElement rating = ElementWait.waitForOptionalElement(driver, ratingIcon, 20);
		if (rating != null) {
			rating.click();
		} else {
			Logger.info("Rating field is not visible on filter tab in directory page");
		}
	}

	public void openDistanceTab() {
		WebElement distance = ElementWait.waitForOptionalElement(driver, distanceIcon, 20);
		if (distance != null) {
			distance.click();
		} else {
			Logger.info("Distance field is not visible on filter tab in directory page");
		}
	}
	
	public void openPriceTab() {
		WebElement price = ElementWait.waitForOptionalElement(driver, priceIcon, 20);
		if (price != null) {
			price.click();
		} else {
			Logger.info("price field is not visible on filter tab ");
		}
	}

	public void moveDistanceSlider(String page, int x, int y) {
		WebElement slider = null;
		if (page.equals("dir"))
			slider = ElementWait.waitForOptionalElement(driver, rightSlider, 20);
		else if (page.equals("hyperlocal"))
			slider = ElementWait.waitForOptionalElement(driver, hl_rightSlider, 20);
		else
			slider = ElementWait.waitForOptionalElement(driver, price_rightSlider, 20);
		if (slider != null && slider.isDisplayed()) {
			driver.context("NATIVE_APP");
			TouchAction action = new TouchAction(driver);
			action.tap(x, y).perform();
			PageElement.changeContextToWebView(driver);
		}
	}

	public void clickKm() {
		WebElement km = ElementWait.waitForOptionalElement(driver, kmBtn, 20);
		if (km != null && km.isDisplayed()) {
			km.click();
		}
	}

	public void clickRating(By link) {
		WebElement rate = ElementWait.waitForOptionalElement(driver, link, 20);
		if (rate != null && rate.isDisplayed()) {
			rate.click();
		}
	}
	
	public void clickRating1() {
		WebElement rate = ElementWait.waitForOptionalElement(driver, starCheckbox, 20);
		if (rate != null && rate.isDisplayed()) {
			rate.click();
		}
	}
	


	public void clickMiles() {
		WebElement miles = ElementWait.waitForOptionalElement(driver, mileBtn, 20);
		if (miles != null && miles.isDisplayed()) {
			miles.click();
		}
	}

	public String getRangeValue(String page) throws InterruptedException {
		Thread.sleep(1000);
		if (page.equals("dir"))
			return ElementWait.waitForOptionalElement(driver, upperRange, 20).getText();
		else if (page.equals("price"))
			return ElementWait.waitForOptionalElement(driver, upperPrice, 20).getText();
		else
			return ElementWait.waitForOptionalElement(driver, hl_upperRange, 20).getText();
	}

	public boolean isRatingTabOpen() {
		boolean open = false;
		WebElement tab = ElementWait.waitForOptionalElement(driver, ratingTabP, 20);
		if (tab != null && tab.isDisplayed()) {
			open = true;
		} else {
			Logger.error("Rating tab is not displayed uponclicking rating icon on filter list in directory");
		}
		return open;
	}

	public void clickSearch(String identifier) {
		WebElement serach = null;
		if (identifier.equals("distance")) {
			serach = ElementWait.waitForOptionalElement(driver, distanceSearch, 20);
		} else if (identifier.equals("rating")) {
			serach = ElementWait.waitForOptionalElement(driver, ratingSearch, 20);
		} else {
			serach = ElementWait.waitForOptionalElement(driver, priceSearch, 20);
		}
		if (serach != null) {
			serach.click();
		} else {
			Logger.error("Serach button is not displayed on :" + identifier + ":tab");
		}
	}

	public int getNumeralRange(String str) {
		int value = 0;
		if (str.contains("Miles")) {
			value = Integer.parseInt(str.substring(0, str.indexOf("Mi")));
		} else if (str.contains("USD")) {
			value = Integer.parseInt(str.substring(0, str.indexOf("USD")));
		} else {
			value = Integer.parseInt(str.substring(0, str.indexOf("KM")));
		}
		// Logger.info(" value is :"+value);
		return value;
	}

	
}
