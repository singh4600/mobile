package com.appypie.pages.Store;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class StorePage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	CommanClassStore comm;
	SoftAssert s_assert = new SoftAssert();
	
	// --------Default-----------------------------------
	// public By = By.xpath("");
	public By username1=By.xpath("//*[@id='loginid']");
	public By password1=By.xpath("//*[@id='loginpass']");
	public By LoginBtn1=By.xpath("//*[contains(@class,'appypie-login login-page')]/ul/li[5]");
	public By Acceptandcontinue=By.xpath("//a[@class='arial mediumContent']");
	public By backbtn= By.xpath("//*[contains(@class,'link back')]");
	
	

	public By sortBylink= By.xpath("//*[@class='view view-main']/div[2]/div[2]//*[contains(@class,'categories theme-4')]/div[4]//*[contains(@id,'searchpopupval')]");
	public By LHlinknativ= By.xpath("//*[@index='1']");
	public By i_LHlinknativ= By.xpath("//*[@class='view view-main']/div[2]/div[2]//*[contains(@class,'categories theme-4')]/div[4]//*[contains(@id,'searchpopupval')]/option[2]");
	public By HLlinknativ= By.xpath("//*[@index='2']");
	public By i_HLlinknativ= By.xpath("//*[@class='view view-main']/div[2]/div[2]//*[contains(@class,'categories theme-4')]/div[4]//*[contains(@id,'searchpopupval')]/option[3]");
	public By populatitylinknativ= By.xpath("//*[@index='3']");
	public By i_populatitylinknativ= By.xpath("//*[@class='view view-main']/div[2]/div[2]//*[contains(@class,'categories theme-4')]/div[4]//*[contains(@id,'searchpopupval')]/option[3]");
	
	public By sortBylistNative_gettext=By.className("android.widget.CheckedTextView");
	public By i_sortBylistNative_gettext=By.xpath("//*[@class='view view-main']/div[2]/div[2]//*[contains(@class,'categories theme-4')]/div[4]//*[contains(@id,'searchpopupval')]/option");
	
	public By electroniclinkTAB= By.xpath("//*[contains(@class,'categories-swiper')]//li[1]");
	public By housinglinkTAB= By.xpath("//*[contains(@class,'categories-swiper')]//li[2]");
		
	public By Storelink= By.xpath("//a[@data-productid='ecommerce']"); //click store module
	public By subcategorylink= By.xpath("//*[contains(@onclick,'Appyscript.ecomSubcatProductList')]"); // click on sub category link
	public By productlinkonMainPage= By.xpath("//*[contains(@class,'swiper-slide infinite-scroll swiper-slide-active')]/ul/li[2]/div[1]/img");
	public By lcdDroplist= By.xpath("//*[contains(@name,'customOptions')]");
	public By lcdlistnative= By.className("android.widget.CheckedTextView");
	public By i_lcdlistnative= By.xpath("//*[contains(@name,'customOptions')]/option");
	public By lcdcolournative= By.xpath("//*[@index='1']");
	public By i_lcdcolournative= By.xpath("//*[contains(@name,'customOptions')]/option[2]");
	public By addtocartlink= By.xpath("//div[@class='swiper-slide product-swiper-slide swiper-slide-active']//div[@class='product-button']/a");
	public By likeBtn= By.xpath("//*[contains(@onclick,'Appyscript.ecomAddRemoveProductWishlist')]");
	public By shareBtn= By.xpath("//*[contains(@onclick,'storeShareProduct')]");
	public By commentBtn= By.xpath("//*[contains(@class,'comment popupToPage')]");
	public By more_lessBtn= By.xpath("//*[@id='footer-nav']/a[4]");
	//public By = By.xpath("");
	
	public By dirtCartlink= By.xpath("//i[@class='icon-cart cursor-pointer']");
	public By searchlink= By.xpath("//*[contains(@class,'search-box')]/a"); // click on search link
	public By searchTextlink= By.xpath("//*[contains(@class,'search-box')]//*[contains(@onclick,'ecomtxtSearch')]");
	public By detailproductcameralink= By.xpath("//*[contains(@class,'productList dataProduct')]/li[2]//*[contains(@onclick,'Appyscript.ecomProductDetail')]");
	public By detailproductphonelink= By.xpath("//*[contains(@class,'productList dataProduct')]/li[3]//*[contains(@onclick,'Appyscript.ecomProductDetail')]");
	public By addtocartcarmera_phonelink= By.xpath("//*[@id='addtocartid']"); 

	public By backbuttononDirectCart= By.xpath("//a[@class='link back']");
	public By backbuttononsubcategory= By.xpath("//a[@class='link back']");
	public By backbuttononProductDetail= By.xpath("//div[@class='navbar-inner navbar-on-center']//a[@class='link back']");

	public By BackButtonCartPage= By.xpath("//div[@class='navbar-inner navbar-on-center']//a[@class='link back']");
	public By BackButtonorderdetailPage= By.xpath("//div[@class='navbar-inner navbar-on-center']//a[@class='link back']");
	public By checkoutlink= By.xpath("//a[contains(@onclick,'proceedToPaydetails')]");
	public By checkincreaseproductlink= By.xpath("//*[@class='add']"); 
	public By checkdecreaseproductlink= By.xpath("//*[@class='less']");
	public By checkcouponcodecartpage= By.xpath("//*[@id='couponCode']");
	public By checkcouponcodeapplybuttoncartpage= By.xpath("//a[@class='apply arial mediumContent']");
	public By checkdeleteproductlink= By.xpath("//*[@class='delete']");

	public By name= By.id("bfname"); // fist name
	public By Telephone= By.id("bpNo"); // mobile no
	public By Email= By.id("email"); // email id
	public By Address= By.id("bAddress"); // address
	public By City= By.id("bCity"); // city
	public By State= By.id("bState"); // state
	public By Zip= By.id("bZip"); // zip
	public By Country= By.id("bCountry"); // country
	public By i_Country= By.xpath("//*[@id='billing']//*[@id='bCountry']//*[text()='India']");
	
	//public By Deliveryaddresscheckbox= By.id("show_billing_address"); // billing address
	public By shippingAddressDifferentCheckBox= By.xpath("//*[contains(@onclick,'ecomProfileCheckbox')]");
	public By username_shippingAddress= By.xpath("//*[@id='sfname']");
	public By phoneNo_shippingAddress= By.xpath("//*[@id='spNo']");
	public By address_shippingAddress= By.xpath("//*[@id='ssAddress']");
	public By city_shippingAddress= By.xpath("//*[@id='sCity']");
	public By state_shippingAddress= By.xpath("//*[@id='sState']");
	public By zip_shippingAddress= By.xpath("//*[@id='sZip']");
	public By country_shippingAddress= By.xpath("//*[@id='sCountry']");
	public By i_country_shippingAddress= By.xpath("//*[@id='sCountry']//*[text()='India']");
	public By update_shippingAddress= By.xpath("//*[@id='shipping']/a");
	
	
	
	public By paynowlink= By.xpath("//a[contains(@onclick,'ecommercePayment')]");
	public By Confirmpaynowlink= By.xpath("//*[@class='pages ']/div[2]//*[@id='tabcod']//*[contains(@onclick,'Appyscript.paymentRegistrationInfo')]");
	public By ContinueShoppinglink= By.xpath("//*[contains(@onclick,'ClearHistryHomePage')]");
	
	public By ContinueShoppinglink_gettext=By.xpath("//*[contains(@class,'thankyou')]//p");
	
	public By paypal= By.xpath("//*[@label='PayPal Express']");
	public By paypal_gettext=By.xpath("//*[@id='tabpaypal']/p");
	
	public By pc= By.xpath("//*[@label='Pay with credit card over the phone']");
	public By pc_gettext=By.xpath("//*[@id='tabobp']/p");
	
	public By cc= By.xpath("//*[@label='Credit Card via Stripe Payment Gateway']");
	public By cc_gettext=By.xpath("//*[@id='tabstripe']/form/p");
	
	public By cod= By.xpath("//*[@label='Cash on Delivery']");
	public By cod_gettext=By.xpath("//*[@id='tabcod']/p");
	
	

	


	public By Menulink=By.xpath("//a[@class='link menu-down']"); // click on menu link
	public By loginlink= By.xpath("//*[text() =' Login/Signup']");
	public By menulist_gettext=By.xpath("//*[@class='leftMenu']/li");
	public By searchMenuItem=By.xpath("//*[@class='searchBx']//*[@id='ecomtxtSearch']");
	
	public By username_gettext=By.xpath("//*[@id ='userName']");
	public By address_gettext=By.xpath("//*[@id ='userLocation']");
	public By closemenu= By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");

	public By home=By.xpath("//*[@id='menuservice']/ul/li[1]/a"); // click on menu link
	public By myshop=By.xpath("//*[text() ='My Shop']");   // click on home link   
	public By cart=By.xpath("//*[text() ='Cart']");  // click on my shop link 
	public By featuredProduct=By.xpath("//*[text() ='Featured Products']");  // click on cart link
	public By offer=By.xpath("//*[text() ='Offers ']");  // click on Login/SignUp link  
	public By myorder= By.xpath("//*[text() ='My Orders']");
	public By myaccount= By.xpath("//*[text() ='My Account']");
	public By wishlist= By.xpath("//*[text() =' WishList']");
	public By termconditions= By.xpath("//*[text() ='Terms and Conditions']");
	public By privacypolicy= By.xpath("//*[text() ='Privacy Policy']");
	
	//-------------my order--------------
	public By oderHeading_MyOrder_gettext=By.xpath("//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[1]/a");
	public By oderDetailslist_MyOrder_gettext=By.xpath("//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[1]/div//li");
	public By viewItemsBtn_MyOrderlink=By.xpath("//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[1]/div//li[10]/a");
	public By postReviewBtn=By.xpath("//*[contains(@class,'view-product-attribute')]/li[4]/a[1]");
	public By reorderBtn=By.xpath("//*[contains(@class,'view-product-attribute')]/li[4]/a[2]");
	public By cancelBtn=By.xpath("//*[contains(@class,'view-product-attribute')]/li[4]/a[3]");
	public By billingaddressTAB=By.xpath("//*[contains(@class,'myOrders')]//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[2]/a");
	public By billingaddressTAB_gettext=By.xpath("//*[contains(@class,'myOrders')]//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[2]/div[1]//p");
	public By shippingaddressTAB=By.xpath("//*[contains(@class,'myOrders')]//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[3]/a");
	public By shippingaddressTAB_gettext=By.xpath("//*[contains(@class,'myOrders')]//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[3]/div[1]//p");
	public By orderDetailsTAB=By.xpath("//*[contains(@class,'myOrders')]//*[contains(@class,'accordion-list')]/div[1]/div[1]/div[1]/a");
	
	public By Singuplink=By.xpath("//a[contains(@onclick,'signup')]"); // click on sign up link
	public By fullnametext=By.xpath("//*[@id='fname']");  // enter on name
	public By Emailtext=By.xpath("//*[@id='emailId']"); // enter emailid
	public By phonetext=By.xpath("//*[@id='pNo']"); // enter phone no.
	public By passwordtext=By.xpath("//*[@id='pass']"); //enter password
	public By conformpasswordtext=By.xpath("//*[@id='cpass']"); // enter conform password
	public By Signupbutton=By.xpath("//a[contains(@onclick,'Appyscript.addUser')]"); // click on submit sigup button.

	public By username=By.xpath("//*[@id='loginid']"); // enter username
	public By password=By.xpath("//*[@id='loginpass']"); // enter password
	public By LoginBtn=By.xpath("//li[@class='login-btn']"); // click on Login button.
	public By closedMenu=By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");
	
	public By Emailfield=By.id("loginid");
	public By passwordfield=By.id("loginpass");
	public By loginbutton=By.xpath("//li[@class='login-btn']");
	public By closeMenu=By.xpath("//*[contains(@class,'close icon-cancel link close-popup')]");
	
	//-----------------------------------------------gettext---------------------------------------------
	public By getHeaderstorepage=By.xpath("//div[@class='navbar']/div[2]/div[2]");  // verify header title 
	//public By _gettext=By.xpath("");
	
	public By getmenulist=By.xpath("//ul[@class='leftMenu']/li");
	public By gethome=By.xpath("//*[@id='menuservice']/ul/li[1]/a"); // click on menu link
	public By getmyshop=By.xpath("//*[@id='menuservice']/ul/li[2]/a");   // click on home link   //*[@id="menuservice"]/ul/li[2]/a/text()
	public By getcart=By.xpath("//*[@id='menuservice']/ul/li[3]/a");  // click on my shop link //*[@id="menuservice"]/ul/li[3]/a/text()
	public By getfeaturedProduct=By.xpath("//*[@id='menuservice']/ul/li[4]/a");  // click on cart link  //*[@id="menuservice"]/ul/li[4]/a/text()
	public By getoffer=By.xpath("//*[@id='menuservice']/ul/li[5]/a");  // click on Login/SignUp link  //*[@id="menuservice"]/ul/li[5]/a/text()
	public By getLogin_Signup=By.xpath("//*[@id='menuservice']/ul/li[6]/a");  // click on Login/SignUp link   //*[@id="menuservice"]/ul/li[6]/a/text()

	public By getmaincategory=By.xpath("//li[contains(@class,'swiper-slide active')]/a"); // verify main category
	public By getsubcategory=By.xpath("//h3[contains(@class,'arial mediumContent')]");
	
	public By subcatgProductlist_gettext=By.xpath("//*[contains(@class,'productList dataProduct')]/li//*[contains(@class,'discription_box')]");
	public By getHeaderSubcatogerypage= By.xpath("//div[@class='navbar']/div[2]/div[2]"); 
	public By getcameraproductname= By.xpath("//li[contains(@productid,'340777')]/div/div/div[1]/h1"); 
	public By getpricecameraproduct=By.xpath("//li[contains(@productid,'340777')]/div/div/div[1]/div/div");
	public By getaddToCartTextcameraproduct=By.xpath("//li[contains(@productid,'340777')]/div/div/div[2]/a");

	public By getphoneproductname= By.xpath("//li[contains(@productid,'340776')]/div/div/div[1]/h1");
	public By getpricephoneproduct=By.xpath("//li[contains(@productid,'340776')]/div/div/div[1]/div/div");
	public By getaddToCartTextphoneproduct=By.xpath("//li[contains(@productid,'340776')]/div/div/div[2]/a");

	public By getHeaderinaddtocartpage = By.xpath("//div[@class='navbar-inner navbar-on-center']//div[@class='topHeader']");
	public By getproductnameinaddtocartpage = By.xpath("//div[@class='swiper-slide product-swiper-slide swiper-slide-active']//div[@class='wrap']/div/h3"); 
	public By getproductPriceinaddtocartpage = By.xpath("//div[@class='swiper-slide product-swiper-slide swiper-slide-active']//div[@class='wrap']/div//span[@id='productPrice']");

	public By getHeadercartpage = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	public By getproductnamecartpage=By.xpath("//*[@id='user_tab1']//h3[@class='arial largeHeading']"); //*[@id="user_tab1"]//h3[@class="arial largeHeading"]
	public By getpricecartpage=By.xpath("//*[@id='orderQuantityprice']/big");
	public By getproductquantitycartpage=By.xpath("//*[@id='qty1']");
	public By getSubtotalAmount=By.xpath("//*[@id='subtotalecom']/span");
	public By getGrandTotalAmount=By.xpath("//*[@id='gtotal']/span");
	public By getTotalpayableAmount=By.xpath("//*[@id='grandTotal']/span");
	public By getContinueShopping=By.xpath("//android.view.View[@content-desc='Continue Shopping']");
	public By i_getContinueShopping=By.xpath("//*[text()='Continue Shopping']");
	public By cartlinkafterContinueShopping=By.xpath("//*[@class='navbar']/div[2]//*[contains(@onclick,'Appyscript.ecomAddToCartProduct')]");
	
	public By getquantityafter_increase_decrease=By.xpath("//*[@id='qty1']");

	public By getorderdetailheaderPage= By.xpath("//div[@class='navbar']/div[2]/div[2]");

	public By getsubcategoryitems=By.xpath("//h1[contains(@class,'title arial mediumContent')]"); // verify subcategory item name
	public By getquantity=By.xpath("//*[@id='quantity']");  // verify item quanity
	public By getchooseIteam=By.xpath("//ul[@class='Storeing-select  multiselect')]/li[2]"); // verify  selected choose item
	public By getDone= By.xpath("//a[@class='Storeing-done']"); // verify done button after select selected item
	public By getproductName=By.xpath("//*[@id='productName']"); // verify item name after done button
	public By getproductNameincheckout=By.xpath("//*[@id='user_tab1']/div/div/div/h3"); // verify Item name on checkout page
	public By getproductcolourincheckout=By.xpath("//*[@id='user_tab1']/div/div/div/div[1]");

	public By getHeaderOrderDetailpage = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	public By getname= By.id("bfname"); // fist name
	public By getTelephone= By.id("bpNo"); // mobile no
	public By getEmail= By.id("email"); // email id
	public By getAddress= By.id("bAddress"); // address
	public By getCity= By.id("bCity"); // city
	public By getState= By.id("bState"); // state
	public By getZip= By.id("bZip"); // zip
	public By getCountry= By.id("bCountry"); // country
	public By paynowlink1= By.xpath("//a[contains(@onclick,'ecommercePayment')]"); // confirm button.
	public By getHeaderConfirmpaynow = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	public By getHeaderContinueShopping = By.xpath("//div[@class='navbar']/div[2]/div");
	
	
	
//-------------------------------------------------------------------------------------------------------------
	static SoftAssert softassert;
	//By Page= By.xpath("");

	public StorePage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
		comm=new CommanClassStore(driver);
	}
	
	public void Login() throws InterruptedException{
		Boolean UN=comm.IselementPresent(username);
		if (UN) {
			Boolean email=comm.TextField(username, "prince@appypie.com");
			s_assert.assertTrue(email, "Email field is not enter value");

			Boolean pass=comm.TextField(password, "12345678");
			s_assert.assertTrue(pass, "Pass field is not enter value");

			Boolean login=comm.Openlinks(LoginBtn1);
			s_assert.assertTrue(login, "login field is not click ");
		
			try{
				driver.findElement(Acceptandcontinue).click();
			}catch (Exception e) {
				System.out.println("Accept and continue is Not present");
			}
		}else{
			System.out.println("User is already Login");
		}
	}
		public void login() throws InterruptedException{	
			boolean loggeduser=false;
			loggeduser=driver.findElements(loginlink).size()!=0;
			if(loggeduser){
				System.out.println("User Not Login please Login First");
				driver.findElement(loginlink).click();
				driver.findElement(Emailfield).sendKeys("prince@appypie.com");
				driver.findElement(passwordfield).sendKeys("12345678");
				driver.findElement(loginbutton).click();
			}else {
				System.out.println("User is already Login");
			}
			
//----------------------------Menu page---------------------------------------------------
		}

}