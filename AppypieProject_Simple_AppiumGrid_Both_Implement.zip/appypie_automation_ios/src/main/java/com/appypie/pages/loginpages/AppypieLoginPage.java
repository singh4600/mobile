package com.appypie.pages.loginpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieLoginPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By email = By.xpath("//*[@id='loginid']");
	By pwd = By.xpath("//*[@id='loginpass']");
	By login = By.xpath("//a[text()='Login']");
	By signupnow = By.xpath("//a[contains(@onclick,'Appyscript.popupPage')][contains(@onclick,'signup')]");
	By forgetPwd = By.xpath("//a[contains(@onclick,'Appyscript.popupPage')][contains(@onclick,'forgot-password')]");
	By fbLogin = By.xpath("//a[contains(@onclick,'Appyscript.loginWithFacebook')]");
	By fbMail= By.xpath("//*contains[@id,'login_email");

	By menu = By.className("iconz-option-vertical");
	By logout = By.xpath("//a[contains(@onclick,'Appyscript.allLogout')]");

	public AppypieLoginPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isLoginPageOpen() {
		boolean open = false;
		WebElement loginPage = ElementWait.waitForOptionalElement(driver, login, 20);
		if (loginPage != null) {
			open = true;
		}
		return open;
	}

	public void login(String mail, String password) {
		PageElement.sendKey(driver, email, mail);
		PageElement.sendKey(driver, pwd, password);
		PageElement.locateClickableElement(driver, login);
	}

	public void openSignUpPage() {
		WebElement signUp = ElementWait.waitForOptionalElement(driver, signupnow, 10);
		if (signUp != null) {
			signUp.click();
		} else {
			Logger.error("sinupnow textis not visisble on login page");
		}
	}

	public void openforgetPwdPage() {
		WebElement forget = ElementWait.waitForOptionalElement(driver, forgetPwd, 10);
		if (forget != null) {
			forget.click();
		} else {
			Logger.error("forget your password text is not visisble on login page");
		}
	}

	public void openfbLoginPage() {
		WebElement fb = ElementWait.waitForOptionalElement(driver, fbLogin, 10);
		if (fb != null) {
			fb.click();
		} else {
			Logger.error("sign in with facebook options is not visisble on login page");
		}
	}
	
	public boolean isFBOpen() throws InterruptedException {
		boolean open= false;
		driver.context("NATIVE_APP");
		Thread.sleep(2000);
		WebElement fb = ElementWait.waitForOptionalElement(driver, fbMail, 20);
		if (fb != null && fb.isDisplayed()) {
		 open= true;
		 Thread.sleep(1000);
		 driver.navigate().back();
		} else {
			Logger.error("Facebook page is not open from login page");
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}

	public void logout() {
		try {
			PageElement.locateClickableElement(driver, menu);
			PageElement.locateClickableElement(driver, logout);
				Thread.sleep(1000);
		} catch (Exception ex) {
			Logger.error("Exception occurs on app menu screen" + ex.getMessage(), ex);
		}
	}
}
