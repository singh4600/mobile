package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieEreaderPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By ereaderfolder = By.xpath("//a[@data-productidentifier='folder_1497524227191_71'][@data-productid='folder']");
	By insideaAppfile = By.xpath("//a[@data-productidentifier='ereader_1506664539501_39--folder_1497524227191_71']");
	By thirdpartyfile = By.xpath("//a[@data-productidentifier='ereader_1497524267703_39--folder_1497524227191_71']");

	By ereaderPage = By.xpath("//ul[@class='main2']/li");
	By nativePdf = By.id("pv_pdfView");
	By nativeEpub = By.className("android.view.View");

	public AppypieEreaderPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openEreaderFolder() {
		WebElement folder = ElementWait.waitForOptionalElement(driver, ereaderfolder, 20);
		if (folder != null && folder.isDisplayed()) {
			folder.click();
		} else {
			Logger.info("Ereaderfolder not exist in main menu");
		}
	}

	public boolean isEreaderFolderOpen() {
		boolean open = false;
		WebElement folder = ElementWait.waitForOptionalElement(driver, insideaAppfile, 20);
		if (folder != null && folder.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openEreaderPage(String type) throws NullPointerException {
		By filetype = null;
		if (type.equals("inside"))
			filetype = insideaAppfile;
		else
			filetype = thirdpartyfile;
		WebElement page = ElementWait.waitForOptionalElement(driver, filetype, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		} else {
			Logger.info("Ereader page not exist in main menu");
		}
	}

	public boolean isEreaderPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, ereaderPage, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openFile(String name) {
		By file_name = By.xpath("//ul[@class='main2']//li[@name='" + name + "']");
		WebElement file = ElementWait.waitForOptionalElement(driver, file_name, 20);
		if (file != null && file.isDisplayed()) {
			file.click();
		} else {
			Logger.info(name + " File is not present or located");
		}
	}

	public boolean isFileOpenInNative(String fileType) throws InterruptedException {
		boolean open = false;
		WebElement file = null;
		driver.context("NATIVE_APP");
		if (fileType.equals("pdf")) {
			file = ElementWait.waitForOptionalElement(driver, nativePdf, 20);
		} else {
			file = ElementWait.waitForOptionalElement(driver, nativeEpub, 20);
		}
		if (file != null && file.isDisplayed()) {
			open = true;
			Thread.sleep(2000);
			driver.navigate().back();
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}
}
