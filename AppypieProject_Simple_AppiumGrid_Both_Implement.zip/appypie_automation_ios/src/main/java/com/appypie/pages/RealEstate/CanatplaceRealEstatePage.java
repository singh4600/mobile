package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class CanatplaceRealEstatePage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;

	
	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By fav= By.xpath("//*[contains(@class,'real-estate-cat-listing ')]//*[contains(@class,'like-btn')]");
	public By nextImagelink= By.xpath("//*[contains(@class,'swiper-button-next')]");
	public By imgOpenlink= By.xpath("//*[contains(@class,'real-estate-cat-listing swiper-wrapper')]");
	public By backbtnAfterImgOpenlink= By.xpath("//*[contains(@onclick,'closeAppypiereal();')]");
	public By calllink= By.xpath("//*[contains(@class,'real-estate-addons detailIcon')]//*[contains(@onclick,'callreal')]");
	public By maplink= By.xpath("//*[contains(@class,'real-estate-addons detailIcon')]//*[contains(@onclick,'movetomap')]");
	public By readmorelink= By.xpath("//*[contains(@id,'showmorecheck')]");
	public By sendInquirybtn= By.xpath("//*[contains(@onclick,'Appyscript.opensendenquiry')]");
	public By rating_Reviewlink= By.xpath("//*[contains(@id,'reviewadd')]");
	public By claimpropertylink= By.xpath("//*[contains(@id,'claimid')]");
	public By claimMessageTextlink= By.xpath("//*[contains(@id,'claimmessage')]");
	public By claimBtnlin= By.xpath("//*[contains(@onclick,'claimproperty')]");
	public By backbtnClaimPage= By.xpath("//*[contains(@class,'close link')]");
	public By nextBtn= By.xpath("//*[contains(@class,'swiper-container swiper-realestate swiper-container-horizontal')]/div[4]");
	public By video= By.xpath("//*[contains(@class,'swiper-slide swiper-slide-active')]");
	public By addresslink= By.xpath("//*[contains(@class,'detail-listing arial mediumContent')]/li[1]");
	
	public By hyperlink= By.xpath("//*[contains(@class,'propSection')]/p/a");

	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By forRent_place_gettext=By.xpath("//*[contains(@class,'inner-container')]");
	public By amentieslist_gettext=By.xpath("//*[contains(@class,'amenties')]/div/ul/li/div");
	public By propertyDetailslist_gettext=By.xpath("//*[contains(@class,'detail-box')]/ul/li");
		public By propertyDescription_gettext=By.xpath("//*[contains(@class,'propSection')]/div[1]/div[1]//span");
	
	
	



	public CanatplaceRealEstatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}