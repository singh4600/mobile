package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MyBookingsPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By backBtn= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	public By upComingTABlink= By.xpath("//*[contains(@class,'tabs swiper-wrapper hotel-autoheight')]/li[1]");
	public By cancelBtnUpcomingTABHotellink= By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li[1]//*[contains(@onclick,'Appyscript.hotelcancelbookingconfirm')]");
	public By completedTablink= By.xpath("//*[contains(@class,'tabs swiper-wrapper hotel-autoheight')]/li[2]");
	public By leaveReviewlink= By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li[1]//*[contains(@onclick,'Appyscript.hotelpostReview')]");
	public By rebooklink= By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li[1]//*[contains(@onclick,'Appyscript.hotelDetail')]");
	public By i_backBtnRebookPage= By.xpath("");
	public By cancelledTablink= By.xpath("//*[contains(@class,'tabs swiper-wrapper hotel-autoheight')]/li[3]");
	public By reebooklinkCanTAB= By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li[1]//*[contains(@onclick,'Appyscript.hotelDetail')]");
		
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By upComing_list_gettext=By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li");
	public By completed_list_gettext=By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li");
	public By cancelled_gettext=By.xpath("//*[contains(@class,'hotel-booking-history swiper-slide swiper-slide-active')]/li");
	
	

	public MyBookingsPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}