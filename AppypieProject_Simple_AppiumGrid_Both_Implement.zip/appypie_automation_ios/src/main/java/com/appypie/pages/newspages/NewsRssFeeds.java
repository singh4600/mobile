package com.appypie.pages.newspages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class NewsRssFeeds {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By newsRss = By.xpath("//a[@data-productidentifier='news_1507546157316_58']");
	By feeds = By.xpath("//li[contains(@onclick,'Appyscript.newsDetailsPageRss')]");
	By share = By.xpath("//li[contains(@onclick,'Appyscript.newsShare')]");
	By font = By.xpath("//li[contains(@onclick,'Appyscript.newsTextSize')]");

	public NewsRssFeeds(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openNewsWithRssFeeds() {
		WebElement news = ElementWait.waitForOptionalElement(driver, newsRss, 10);
		if (news != null && news.isDisplayed()) {
			news.click();
		}
	}

	public boolean isFeedsOpen() {
		boolean open = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, feeds, 20);
		if (url != null && url.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openRssFeeds() {
		WebElement list = ElementWait.waitForOptionalElement(driver, feeds, 10);
		if (list != null && list.isDisplayed()) {
			list.click();
		}
	}

	public void openFontpopUp() {
		WebElement option = ElementWait.waitForOptionalElement(driver, font, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public void openSharePopUp() {
		WebElement option = ElementWait.waitForOptionalElement(driver, share, 10);
		if (option != null && option.isDisplayed()) {
			option.click();
		}
	}

	public boolean isFeedDetailPageOpen() {
		boolean open = false;
		WebElement detail = ElementWait.waitForOptionalElement(driver, share, 20);
		if (detail != null && detail.isDisplayed()) {
			open = true;
		}
		return open;
	}

}
