package com.appypie.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieRSSPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By rssPage = By.xpath("//a[@data-productid='rss']");
	By rssUrls = By.xpath("//a[@class='appypie-list'][@data-page='rss'][@data-index='0']");
	By invalidUrl = By.xpath("//a[@class='appypie-list'][@data-page='rss'][@data-index='1']");
	By rssUrlsList = By.xpath("//ul[@class='list']//li[contains(@onclick,'Appyscript.BlogDetailsPage')]");
	By noData = By.className("msg-container");
	By listPage = By.xpath("//div[@class='blog-content']/h1/span");
	By heading = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	By loader = By.className("preloader-indicator-modal");
	By warning = By.xpath("//div[@class='modal-text']");
	By ok = By.xpath("//span[contains(@class,'modal-button')]");

	List<WebElement> urls;
	public String PageName = "";

	public AppypieRSSPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openRSSPage() {
		WebElement element_rssPage = ElementWait.waitForOptionalElement(driver, rssPage, 20);
		if (element_rssPage != null) {
			element_rssPage.click();
		} else {
			Logger.info("RSS page is not present in the app or flow is not main Menu");
		}
	}

	public boolean identifyRSSOpen() {
		boolean rssContent = false;
		WebElement element_rssList = ElementWait.waitForOptionalElement(driver, rssUrls, 20);
		if (element_rssList != null)
			rssContent = true;
		else
			Logger.info("RSS URL'S are not found on page or RSS URL page is not open");
		return rssContent;
	}

	public void openRssUrls() throws InterruptedException {
		Thread.sleep(2000);
		WebElement url = ElementWait.waitForOptionalElement(driver, rssUrls, 20);
		url.click();
	}

	public boolean getUrlListing() throws InterruptedException {
		boolean list = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, rssUrlsList, 20);
		if (url != null) {
			list = true;
		} else {
		  	checkNoDataOptionInUrl(url);
		}
		return list;
	}

	public boolean clickInvalidUrl() {
		WebElement url = ElementWait.waitForOptionalElement(driver, invalidUrl, 20);
		url.click();
		return checkNoDataOptionInUrl(url);
	}

	public boolean checkNoDataOptionInUrl(WebElement url) {
		boolean noDataIcon = false;
		WebElement element_noData = ElementWait.waitForOptionalElement(driver, noData, 20);
		if (element_noData != null) {
			Logger.info("RSS Url is not Correct: Error Pop up is visible on screen in the Url available at index:["
					+ url.getAttribute("data-index") + "]");
			PageElement.locateClickableElement(driver, ok);
			noDataIcon = true;
		} else {
			WebElement element_loader = ElementWait.waitForOptionalElement(driver, loader, 2);
			if (element_loader!=null)
				Logger.error("Loader is continuously Rotating while opening the Url available at index:["
						+ url.getAttribute("data-index") + "]");
			else
				Logger.error("Url listing page is not open in the Url named available at index:["
						+ url.getAttribute("data-index") + "]");
		}
		return noDataIcon;
	}

	public boolean getDates() throws InterruptedException {
		List<Long> dates = new ArrayList<Long>();
		boolean sort = false;
		List<WebElement> element_urllist = ElementWait.waitForAllOptionalElements(driver, rssUrlsList, 20);
		if (element_urllist != null && element_urllist.size() != 0) {
			Iterator<WebElement> itr = element_urllist.iterator();
			while (itr.hasNext()) {
				WebElement list = itr.next();
				List<WebElement> dateElements = list.findElements(By.xpath(".//div/span"));
				List<WebElement> heading = list.findElements(By.xpath(".//div/h4"));
				if (dateElements != null) {
					String date = dateElements.get(0).getText();
					// Logger.info(date);
					long milis = displaySeconds(date);
					dates.add(milis);
					if (milis == 0)
						Logger.info("Date Format is not correct or date is not parsed for url  having title["
								+ heading.get(0).getText() + "]");
				} else {
					if (heading.get(0).isDisplayed())
						Logger.info("Date Field is not present in the listings of url");
					else
						Logger.error("Driver is not able to locate the Date Fields ");
				}
			}
			if (dates.size() != 0) {
				sort = checkListSorted(dates);
			} else {
				Logger.info("Dates are not found for Url ");
			}
		} else {
			Logger.error("Feeds List is not displayed in the Rss Url");
		}
		return sort;
	}

	public long displaySeconds(String startEndDateTime) {
		SimpleDateFormat sourceFormat = new SimpleDateFormat("EEE MMM dd yyyy hh:mm:ss");
		long c = 0;
		try {
			Date t = (Date) sourceFormat.parse(startEndDateTime);
			System.out.println(t);
			c = t.getTime() / 1000;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println(Long.toString(c));
		return c;
	}

	public boolean checkListSorted(List<Long> dates) {
		boolean result = false;
		for (int i = 1; i < dates.size(); i++) {
			if (dates.get(i - 1).compareTo(dates.get(i)) != -1)
				result = true;
		}
		return result;
	}

	public List<Object> getUrlListingContent() throws Exception {
		List<Object> listContents = null;
		List<WebElement> listings = ElementWait.waitForAllOptionalElements(driver, rssUrlsList, 20);
		if (listings != null && listings.size() != 0) {
			listContents = new ArrayList<Object>();
			List<WebElement> imgList = listings.get(0).findElements(By.xpath(".//img"));
			List<WebElement> date = listings.get(0).findElements(By.xpath(".//div/span"));
			List<WebElement> heading = listings.get(0).findElements(By.xpath(".//div/h4"));
			List<WebElement> content = listings.get(0).findElements(By.xpath(".//div/div"));
			if (imgList.size() != 0) {
				try {
					boolean image = getImage(imgList.get(0));
					listContents.add(image);
				} catch (Exception e) {
					Logger.error("Exception occurs while verifying image having url  heading ["
							+ heading.get(0).getText() + "]", e);
					listContents.add(false);
				}
			} else {
				listContents.add(false);
			}

			if (date.size() != 0 && date.get(0).isDisplayed()) {
				listContents.add(date.get(0).getText());
			} else {
				listContents.add("ND");
			}

			if (heading.size() != 0 && heading.get(0).isDisplayed()) {
				listContents.add(heading.get(0).getText());
			} else {
				listContents.add("ND");
			}

			if (content.size() != 0 && content.get(0).isDisplayed()) {
				listContents.add(content.get(0).getText());
			} else {
				listContents.add("ND");
			}
		} else {
			Logger.error("Feeds List is not displayed in the Rss Url");
		}
		return listContents;
	}

	public boolean getImage(WebElement ImageFile) throws Exception {
		Boolean ImagePresent = false;
		if (ImageFile != null) {
			ImagePresent = (Boolean) ((JavascriptExecutor) driver).executeScript(
					"return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
					ImageFile);
			if (!ImagePresent)
				Logger.info("Image not displayed.");
			else
				Logger.info("Image displayed.");
		} else {
			Logger.info("Image tag is not present or images are hide from Backend");
		}
		return ImagePresent;
	}

}
