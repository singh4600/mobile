package com.appypie.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EventfulFeedsListPage {

	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger = Log.createLogger();
	By feeds = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')]");
	By eventbriteUpcomingfeeds = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@class='upcoming']");
	By eventbritePastfeeds = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@class='past']");
	By month = By.xpath(
			"//li[contains(@onclick,'Appyscript.eventDetail')][@data-index='0']//div[@class='eventTime']//span[@class='month']");
	By day = By.xpath(
			"//li[contains(@onclick,'Appyscript.eventDetail')][@data-index='0']//div[@class='eventTime']//span[@class='day']");
	By year = By.xpath(
			"//li[contains(@onclick,'Appyscript.eventDetail')][@data-index='0']//div[@class='eventTime']//span[@class='year']");
	By time = By.xpath(
			"//li[contains(@onclick,'Appyscript.eventDetail')][@data-index='0']//div[@class='eventTime']//span[@class='time']");
	By eventBriteUpcomingEvent = By.xpath("//a[@onclick='Appyscript.eventTabs(0)']");
	By eventBritePastEvent = By.xpath("//a[@onclick='Appyscript.eventTabs(1)']");
	By feedHeading = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@data-index='0']/h3");
	By eventBriteupcomingfeedHeading = By
			.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@class='upcoming']/h3");
	By eventBriteupcomingvenue = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@class='upcoming']/p");
	By eventBritepastfeedHeading = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@class='past']/h3");
	By eventBritepastvenue = By.xpath("//li[contains(@onclick,'Appyscript.eventDetail')][@class='past']/p");
	By faceBookEvent = By.xpath("//div[contains(@class,'event-list facebook')]/ul/li");
	By noData = By.className("msg-container");
	By loaderIcon = By.className("preloader-indicator-modal");

	By googleFeed = By.xpath("//div[contains(@class,'event-list google')]/ul/li");
	By month_google = By
			.xpath("//div[contains(@class,'event-list google')]/ul/li//div[@class='eventTime']//span[@class='month']");
	By day_google = By
			.xpath("//div[contains(@class,'event-list google')]/ul/li//div[@class='eventTime']//span[@class='day']");
	By year_google = By
			.xpath("//div[contains(@class,'event-list google')]/ul/li//div[@class='eventTime']//span[@class='year']");
	By time_google = By
			.xpath("//div[contains(@class,'event-list google')]/ul/li//div[@class='eventTime']//span[@class='time']");
	By feedHeading_google = By.xpath("//div[contains(@class,'event-list google')]/ul/li/h3");
	By google_calendar = By.xpath("//div[contains(@class,'event-list google')]/ul/li//i[@class='icon-calendar-4']");
	By google_info = By.xpath("//div[contains(@class,'event-list google')]/ul/li//i[@class='icon-info-circle']");
	By calendar_title = By.id("com.google.android.calendar:id/input");
	By cal_cancel = By.id("com.google.android.calendar:id/cancel");
	By discard = By.id("android:id/button2");
	By googleicon_title = By.id("text_Tittle");

	public EventfulFeedsListPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isFeedsExist(String eventType) {
		boolean exist = false;
		By type;
		if (eventType.equals("upcoming")) {
			type = eventbriteUpcomingfeeds;
		} else if (eventType.equals("past")) {
			type = eventbritePastfeeds;
		} else if (eventType.equals("facebook")) {
			type = faceBookEvent;
		} else if (eventType.equals("google")) {
			type = googleFeed;
		} else {
			type = feeds;
		}
		WebElement element_feeds = ElementWait.waitForOptionalElement(driver, type, 20);
		if (element_feeds != null && element_feeds.isDisplayed())
			exist = true;
		else
			Logger.info("Eventful feeds are not presence in the page");
		return exist;
	}

	public List<String> isDateExistOnFeeds(String url) {
		List<String> dates = new ArrayList<String>();
		By feed_day, feed_month, feed_year, feed_time;
		if (url.equals("google")) {
			feed_month = month_google;
			feed_day = day_google;
			feed_year = year_google;
			feed_time = time_google;
		} else {
			feed_month = month;
			feed_day = day;
			feed_year = year;
			feed_time = time;
		}
		dates.add(ElementWait.waitForOptionalElement(driver, feed_month, 20).getText());
		dates.add(driver.findElement(feed_day).getText());
		dates.add(driver.findElement(feed_year).getText());
		dates.add(driver.findElement(feed_time).getText());
		return dates;
	}

	public String getFeedHeading(String url) throws NullPointerException, NoSuchElementException {
		By feedHeader;
		String heading = null;
		if (url.equals("google")) {
			feedHeader = feedHeading_google;
		} else {
			feedHeader = feedHeading;
		}
		WebElement elem = ElementWait.waitForOptionalElement(driver, feedHeader, 20);
		if (elem != null && elem.isDisplayed()) {
			heading = elem.getText();
		}
		return heading;

	}

	public boolean openFeed(String eventType) {
		By type;
		boolean exist = false;
		if (eventType.equals("upcoming")) {
			type = eventbriteUpcomingfeeds;
		} else if (eventType.equals("past")) {
			type = eventbritePastfeeds;
		} else {
			type = feeds;
		}
		WebElement feedlist = ElementWait.waitForOptionalElement(driver, type, 20);
		if (feedlist != null && feedlist.isDisplayed()) {
			feedlist.click();
			exist = true;
		}
		return exist;
	}

	public boolean isEventBriteOpen() {
		boolean open = false;
		WebElement eventbrite = ElementWait.waitForOptionalElement(driver, eventBriteUpcomingEvent, 20);
		if (eventbrite != null && eventbrite.isDisplayed())
			open = true;
		return open;
	}

	public void clickUpcomingEvent() {
		WebElement upcomingeventIcon = ElementWait.waitForOptionalElement(driver, eventBriteUpcomingEvent, 20);
		upcomingeventIcon.click();
	}

	public void clickPastEvent() {
		WebElement pasteventIcon = ElementWait.waitForOptionalElement(driver, eventBritePastEvent, 20);
		pasteventIcon.click();
	}

	public String getEventBriteUpcomingFeedHeading() throws NullPointerException, NoSuchElementException {
		String heading = null;
		WebElement elem = ElementWait.waitForOptionalElement(driver, eventBriteupcomingfeedHeading, 10);
		if (elem != null && elem.isDisplayed()) {
			heading = elem.getText();
		}
		return heading;

	}

	public String getEventBriteUpcomingFeedVenue() throws NullPointerException, NoSuchElementException {
		String venue = null;
		WebElement elem = ElementWait.waitForOptionalElement(driver, eventBriteupcomingvenue, 10);
		if (elem != null && elem.isDisplayed()) {
			venue = elem.getText();
		}
		return venue;

	}

	public String getEventBritepastFeedHeading() throws NullPointerException, NoSuchElementException {
		String heading = null;
		WebElement elem = ElementWait.waitForOptionalElement(driver, eventBritepastfeedHeading, 10);
		if (elem != null && elem.isDisplayed()) {
			heading = elem.getText();
		}
		return heading;

	}

	public String getEventBritepastFeedVenue() throws NullPointerException, NoSuchElementException {
		String venue = null;
		WebElement elem = ElementWait.waitForOptionalElement(driver, eventBritepastvenue, 10);
		if (elem != null && elem.isDisplayed()) {
			venue = elem.getText();
		}
		return venue;

	}

	public boolean checkNoDataIcon() throws InterruptedException {
		boolean icon = false;
		WebElement element_noData = ElementWait.waitForOptionalElement(driver, noData, 10);
		if (element_noData != null && element_noData.isDisplayed()) {
			icon = true;
		}
		return icon;
	}

	public boolean CheckLoader() {
		boolean loader = false;
		WebElement element_loader = ElementWait.waitForOptionalElement(driver, loaderIcon, 20);
		if (element_loader != null && element_loader.isDisplayed()) {
			loader = true;
		}
		return loader;
	}

	public boolean openGoogleCalendar() throws InterruptedException {
		boolean open = false;
		WebElement cal = ElementWait.waitForOptionalElement(driver, google_calendar, 20);
		cal.click();
		Thread.sleep(2000);
		driver.context("NATIVE_APP");
		WebElement button = ElementWait.waitForOptionalElement(driver, cal_cancel, 20);
		if (button != null && button.isDisplayed()) {
			open = true;
			button.click();
			WebElement discard_button = ElementWait.waitForOptionalElement(driver, discard, 5);
			discard_button.click();
			Thread.sleep(2000);
			driver.navigate().back();
			// driver.context("WEBVIEW_com.snappy.appypie");
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.info("Calendar is not open in native from google feeds");
			// driver.context("WEBVIEW_com.snappy.appypie");
			PageElement.changeContextToWebView(driver);
		}
		return open;
	}

	public boolean openGoogleInfo() throws InterruptedException {
		boolean open = false;
		WebElement info = ElementWait.waitForOptionalElement(driver, google_info, 20);
		if (info != null && info.isDisplayed()) {
			info.click();
			Thread.sleep(2000);
			driver.context("NATIVE_APP");
			WebElement title = ElementWait.waitForOptionalElement(driver, googleicon_title, 30);
			if (title != null && title.isDisplayed()) {
				open = true;
				Thread.sleep(2000);
				driver.navigate().back();
				// driver.context("WEBVIEW_com.snappy.appypie");
				PageElement.changeContextToWebView(driver);
			} else {
				Logger.info("Detail is not open upon clicking on info icon on google page");
			}
		}
		return open;
	}

	public boolean openBookMyShow() throws InterruptedException {
		boolean open = false;
		By view = By.id("text_Tittle");
		driver.context("NATIVE_APP");
		Thread.sleep(2000);
		WebElement show = ElementWait.waitForOptionalElement(driver, view, 30);
		if (show != null && show.isDisplayed()) {
			open = true;
			Thread.sleep(2000);
			driver.navigate().back();
		}
		// driver.context("WEBVIEW_com.snappy.appypie");
		PageElement.changeContextToWebView(driver);
		return open;
	}

}
