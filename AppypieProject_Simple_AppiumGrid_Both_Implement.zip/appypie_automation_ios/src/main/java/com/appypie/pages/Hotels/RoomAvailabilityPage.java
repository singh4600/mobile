package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class RoomAvailabilityPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By adultsIncrement_btn= By.xpath("//*[contains(@class,'room-book-item-content')]/div[1]/div[2]/a[2]");
	public By adultsDecrement_btn= By.xpath("//*[contains(@class,'room-book-item-content')]/div[1]/div[2]/a[1]");
	public By childrenIncrement_btn= By.xpath("//*[contains(@class,'room-book-item-content')]/div[2]/div[2]/a[2]");
	public By childrenDrecement_btn= By.xpath("//*[contains(@class,'room-book-item-content')]/div[2]/div[2]/a[1]");
	public By checkAvaliability_btn= By.xpath("//*[contains(@onclick,'Appyscript.hotelcheckroomavailbility')]");
	public static String i_closeCalander="X";
	public By closeClenderNative= By.xpath("//*[@content-desc='X']");
	public By addRoom_link= By.xpath("//*[contains(@onclick,'hotelappendRoom')]");
	public By deleteaddRoom_link= By.xpath("//*[contains(@onclick,'removeHotelRoom')]");
	public By backpageBtn= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By checkInTime_click_gettext=By.xpath("//*[contains(@class,'checkIn no-fastclick')]");
	public By checkOutTime_click_gettext=By.xpath("//*[contains(@class,'checkOut no-fastclick')]");
	public By roomQty_gettext=By.xpath("//*[contains(@class,'room-qty-title')]");
	public By adultsCount_gettext=By.xpath("//*[contains(@class,'room-book-item-content')]/div[1]/div[2]/input");
	public By childrenCount_gettext=By.xpath("//*[contains(@class,'room-book-item-content')]/div[2]/div[2]/input");

	
	
	


	public RoomAvailabilityPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}