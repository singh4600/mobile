package com.appypie.pages.datingpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MyMatchPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By notification = By.xpath("//a[contains(@onclick,'Appyscript.datingnotification')]");
	By matchUser = By.xpath("//a[contains(@onclick,'Appyscript.datingchatProfiles')][@data-name='TestName']");
	By blockUser = By.xpath("//a[contains(@onclick,'Appyscript.datingchatProfiles')][@data-name='ActiveUser3']");
	By block = By.id("block507349");
	By search = By.xpath("//input[contains(@onkeyup,'datingMatchFilter')]");
	By profileDesc = By.xpath("//div[@class='profile-des']//h2[contains(@class,'user-name')]");

	public MyMatchPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isMyMatchPageOpen() {
		boolean open = false;
		WebElement match = ElementWait.waitForOptionalElement(driver, notification, 10);
		if (match != null && match.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public boolean isBlockUserExist() {
		boolean exist = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, blockUser, 10);
		if (user != null && user.isDisplayed()) {
			exist = true;
		}
		return exist;
	}

	public boolean isMatchedUserPresent() {
		boolean present = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, matchUser, 10);
		if (user != null && user.isDisplayed()) {
			present = true;
		}
		return present;
	}

	public void blockUser() {
		WebElement blockPartner = ElementWait.waitForOptionalElement(driver, block, 10);
		if (blockPartner != null && blockPartner.isDisplayed()) {
			String text = blockPartner.getText();
			if (text.toUpperCase().equals("block".toUpperCase()))
				blockPartner.click();
			else {
				Logger.info("user is already blocked");
			}
		} else {
			Logger.info("Match is not present for blocking");
		}
	}

	public boolean isUserBlocked() {
		boolean blocked = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, block, 10);
		if (user != null && user.isDisplayed()) {
			String text = user.getText();
			if (text.toUpperCase().equals("unblock".toUpperCase()))
				blocked = true;
		} else {
			Logger.info("Match is not present for blocking");
		}
		return blocked;
	}

	public void clickUser() {
		driver.findElement(matchUser).click();
	}

	public boolean isProfileDescOpen() {
		boolean page = false;
		WebElement desc = ElementWait.waitForOptionalElement(driver, profileDesc, 10);
		if (desc != null && desc.isDisplayed()) {
			String text = desc.getText();
			if (text.contains("TestName") && text.contains("28"))
				page = true;
		}
		return page;
	}
}
