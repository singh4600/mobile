package com.appypie.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieTestimonialPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By testimonials = By.xpath("//div[contains(@class,'testimonials')]//ul[@class='list ']/li");
	By testimonialHeader = By.xpath("//div[@class='navbar']//div[text()='Testimonials']");

	public AppypieTestimonialPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isTestimonialPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, testimonialHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public List<List<Object>> getAllTestimonialsDetails() {
		boolean startQuote = false;
		boolean endquote = false;
		String img = null;
		String content = "";
		String title = "";
		List<Object> values;
		List<List<Object>> details = new ArrayList<List<Object>>();
		List<WebElement> data = ElementWait.waitForAllOptionalElements(driver, testimonials, 20);
		if (data != null) {
			for (int i = 0; i < data.size(); i++) {
				values = new ArrayList<Object>();
				if (data.get(i).findElements(By.xpath(".//i[@class='before-quote']")).size() != 0) {
					startQuote = true;
					values.add(startQuote);
				}
				if (data.get(i).findElements(By.xpath(".//i[@class='after-quote']")).size() != 0) {
					endquote = true;
					values.add(endquote);
				}
				if (data.get(i).findElements(By.xpath("./img")).size() != 0) {
					img = data.get(i).findElement(By.xpath("./img")).getAttribute("src");
					values.add(img);
				}
				if (data.get(i).findElements(By.xpath("./p")).size() != 0) {
					content = data.get(i).findElement(By.xpath("./p")).getText();
					values.add(content);
				}
				if (data.get(i).findElements(By.xpath("./span")).size() != 0) {
					title = data.get(i).findElement(By.xpath("./span")).getText();
					values.add(title);
				}
				details.add(values);
			}
		}
		return details;
	}

}
