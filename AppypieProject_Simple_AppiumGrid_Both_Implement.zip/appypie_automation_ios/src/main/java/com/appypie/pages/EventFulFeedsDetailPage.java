package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EventFulFeedsDetailPage {
	
	private AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	By feedHeading= By.xpath("//div[@class='event-details-box']/h3");
	By feedContent= By.xpath("//div[@class='event-details']");
	By eventIcon= By.xpath("//a[contains(@onclick,'Appyscript.openWebView')][text()='Event']");
	By mapIcon= By.xpath("//a[contains(@onclick,'Appyscript.openMapView')][text()='Map']");
	By eventandMapNative= By.id("text_Tittle");
	By nativebackButton= By.id("icon1_button");
	
public EventFulFeedsDetailPage(AppiumDriver<MobileElement> driver){
	
	this.driver=driver;
}

public String isFeedDetaillOpen() throws NullPointerException{
	return PageElement.getPageHeader(driver); 
}

public String getFeedsHeading(){
	String heading="";
	WebElement element_feed= ElementWait.waitForOptionalElement(driver,feedHeading,20);
	if(element_feed!=null && element_feed.isDisplayed())
	heading= element_feed.getText();
	else{
	Logger.info("Feeds Heading is not present");	
	}
	return heading;
}


public String openFeedInNative(String icon)throws InterruptedException{
	String open="";
	if(icon=="Event"){
	openEventandMap(eventIcon);
	}
	if(icon=="Map"){
	openEventandMap(mapIcon);
	}
	Thread.sleep(2000);
	driver.context("NATIVE_APP");
	WebElement header= ElementWait.waitForOptionalElement(driver,eventandMapNative,30);
	if(header!=null && header.isDisplayed()){
	open=header.getAttribute("text");
	Thread.sleep(2000);
	}else{
	Logger.info("Feed is not open in native browser upon clicking on eevent Button");
	//driver.context("WEBVIEW_com.snappy.appypie");
	PageElement.changeContextToWebView(driver);
	}
	return open;	
}

public void openEventandMap(By icon){
	WebElement eventicon= ElementWait.waitForOptionalElement(driver,icon,10);
	if(eventicon!=null && eventicon.isDisplayed())
	eventicon.click();
	else{
	Logger.info("Event or map icon is not displayed");
	return;
	}
}


public boolean tapBackButtonInNative() throws InterruptedException{
	boolean back=false;
	WebElement backButton= ElementWait.waitForOptionalElement(driver,nativebackButton,10);
	if(backButton!=null && backButton.isDisplayed()){
	backButton.click();
	Thread.sleep(2000);
	//driver.context("WEBVIEW_com.snappy.appypie");
	PageElement.changeContextToWebView(driver);
	WebElement element_feed= ElementWait.waitForOptionalElement(driver,feedHeading,20);
	if(element_feed!=null && element_feed.isDisplayed()){
	back=true;	
	}
	}else{
	Logger.info("back button is not displayed on native when feeds is open in webview");
	driver.navigate().back();
	//driver.context("WEBVIEW_com.snappy.appypie");
	PageElement.changeContextToWebView(driver);
	}
	return back;
}

}
