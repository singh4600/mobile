package com.appypie.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieSheetPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By sheets = By.xpath("//a[@data-page='appsheets']");
	By searchBox = By.id("app_sheet_search");
	By searchBtn = By.xpath("//a[contains(@onclick,'filterSheetData')]");
	By floatingAddBtn = By.xpath("//a[contains(@onclick,'Appyscript.appypieAddList')]");
	By sheetRow = By.xpath("//div[contains(@onclick,'Appyscript.appypieDetailSheet(1)')]");
	By sheetFirstCell = By.xpath("//div[contains(@onclick,'Appyscript.appypieDetailSheet(1)')]/div[1]");
	By sheetSecondCell = By.xpath("//div[contains(@onclick,'Appyscript.appypieDetailSheet(1)')]/div[2]");
	By rowDetail = By.id("app_row_detail");
	By updateRow = By.xpath("//a[contains(@onclick,'appSheetUpdatePage')]");
	By deleteRow = By.xpath("//a[contains(@onclick,'saveSheetDataFromModal')]");

	By updateCell1 = By.xpath("//input[@name='name' and @id='0']");
	By updateCell2 = By.xpath("//input[@name='contact' and @id='1']");
	By updateCell3 = By.xpath("//input[@name='address' and @id='2']");
	By updateCell4 = By.xpath("//input[@name='brij' and @id='3']");
	By saveUpdate = By.xpath("//a[contains(@onclick,'saveSheetDataFromModal') and contains(@onclick,'update')]");
	By addRow = By.xpath("//a[contains(@onclick,'saveSheetDataFromModal') and contains(@onclick,'sheet_form')]");

	By allRows = By.xpath("//div[@id='app_sheet_row']//div[contains(@class,'zrq-row')]");

	By searchpage = By.xpath("//div[@class='navbar']//div[contains(text(),'Search Result')]");
	By searchData = By.xpath("//div[contains(@class,'page-on-center')]//div[@class='zrq-container']/div[2]/div[1]");

	public AppypieSheetPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isSheetPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, sheets, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openSheet() {
		WebElement page = ElementWait.waitForOptionalElement(driver, sheets, 20);
		if (page != null && page.isDisplayed()) {
			page.click();
		}
	}

	public boolean isSheetOpen() {
		boolean open = false;
		WebElement sheet = ElementWait.waitForOptionalElement(driver, floatingAddBtn, 20);
		if (sheet != null && sheet.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public String getFirstCellValue() {
		String value = "";
		WebElement cell1 = ElementWait.waitForOptionalElement(driver, sheetFirstCell, 5);
		if (cell1 != null && cell1.isDisplayed()) {
			value = cell1.getText();
		}
		return value;
	}

	public String getSecondCellValue() {
		String value = "";
		WebElement cell2 = ElementWait.waitForOptionalElement(driver, sheetSecondCell, 5);
		if (cell2 != null && cell2.isDisplayed()) {
			value = cell2.getText();
		}
		return value;
	}

	public void openAddRows() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, floatingAddBtn, 20);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}
	
	public void clickRows() {
		WebElement row = ElementWait.waitForOptionalElement(driver, sheetRow, 20);
		if (row != null && row.isDisplayed()) {
			row.click();
		}
	}

	public boolean isUpdaterowFormOpen() {
		boolean open = false;
		WebElement form = ElementWait.waitForOptionalElement(driver, updateCell1, 10);
		if (form != null && form.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isRowDetailsOpen() {
		boolean open = false;
		WebElement detail = ElementWait.waitForOptionalElement(driver, rowDetail, 20);
		if (detail != null && detail.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openUpdateRow() {
		WebElement update_btn = ElementWait.waitForOptionalElement(driver, updateRow, 20);
		if (update_btn != null && update_btn.isDisplayed()) {
			update_btn.click();
		}
	}

	public void deleteRow() {
		WebElement delete_btn = ElementWait.waitForOptionalElement(driver, deleteRow, 20);
		if (delete_btn != null && delete_btn.isDisplayed()) {
			delete_btn.click();
		}
	}

	public void updateFirstCell(String data) {
		PageElement.sendKey(driver, updateCell1, data);
	}

	public void updateSecondCell(String data) {
		PageElement.sendKey(driver, updateCell2, data);
	}

	public void updateThirdCell(String data) {
		PageElement.sendKey(driver, updateCell3, data);
	}

	public void updateFourthCell(String data) {
		PageElement.sendKey(driver, updateCell4, data);
	}

	public void saveUpdate() {
		WebElement save = ElementWait.waitForOptionalElement(driver, saveUpdate, 20);
		if (save != null && save.isDisplayed()) {
			save.click();
		}
	}
	
	public void saveNewRow() {
		WebElement save = ElementWait.waitForOptionalElement(driver, addRow, 20);
		if (save != null && save.isDisplayed()) {
			save.click();
		}
	}

	public int getSheetrowCount() {
		List<WebElement> rows = ElementWait.waitForAllOptionalElements(driver, allRows, 10);
		return rows.size();
	}

	public void enterSearchKeyword(String data) {
		PageElement.sendKey(driver, searchBox, data);
	}

	public void clickSearchBtn() {
		WebElement btn = ElementWait.waitForOptionalElement(driver, searchBtn, 10);
		if (btn != null && btn.isDisplayed()) {
			btn.click();
		}
	}

	public String getSearchData() {
		String text = "";
		WebElement search = ElementWait.waitForOptionalElement(driver, searchData, 10);
		if (search != null && search.isDisplayed()) {
			text = search.getText();
		}
		return text;
	}

	public boolean isSearchPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, searchpage, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}
	
	public void clickSheetLastRow() {
		List<WebElement> rows = ElementWait.waitForAllOptionalElements(driver, allRows, 10);
		if(rows.size()!=0){
		  rows.get(rows.size()-1).click();
		}
	}

}
