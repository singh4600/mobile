package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SendInquiryRealEstatePage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By nametext= By.xpath("//*[contains(@id,'nametxt')]");
	public By emailtext= By.xpath("//*[contains(@id,'emailtxt')]");
	public By phonetext= By.xpath("//*[contains(@id,'phonetxt')]");
	public By messagetext= By.xpath("//*[contains(@id,'message')]");
	public By yesBtn= By.xpath("//*[contains(text(),'Yes')]");
	public By NoBtn= By.xpath("//*[text()='No']");
	public By checkAvailabilityBtn= By.xpath("//*[contains(@class,'hyper-sent-btn')]");
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By requestInfoheading_gettext=By.xpath("//*[contains(@class,'add-details enquery_page')]/h3");
	public By message_gettext=By.xpath("//*[contains(@class,'terms arial arial')]");




	public SendInquiryRealEstatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}