package com.appypie.pages.FoodCourt;


import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class Cuisines_Filter_Sort {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By searchTextlink= By.xpath("//*[contains(@class,'search-view')]//*[contains(@placeholder,'Search')]");
	public By selectCuisinesAfterSearchlink= By.xpath("//*[contains(@id,'tab1')]//*[contains(@class,'dbListView')]/li[1]");
	public By doneBtnCuisines= By.xpath("//*[contains(@onclick,'getFilterHotal')]");
	public By resetBtnCuisines= By.xpath("//*[contains(@onclick,'serviceAPICallHotellist')]");
	
	 public By time15link= By.xpath("//*[contains(@class,'filter-box  filter-time')]/li[1]");
	 public By time30link= By.xpath("//*[contains(@class,'filter-box  filter-time')]/li[2]");
	 public By time45link= By.xpath("//*[contains(@class,'filter-box  filter-time')]/li[3]");
	 public By time60link= By.xpath("//*[contains(@class,'filter-box  filter-time')]/li[4]");
	 public By amount10link= By.xpath("//*[contains(@class,'filter-box  filter-price')]/li[1]");
	 public By amount30link= By.xpath("//*[contains(@class,'filter-box  filter-price')]/li[2]");
	 public By amount50link= By.xpath("//*[contains(@class,'filter-box  filter-price')]/li[3]");
	 public By doneBtnfilter= By.xpath("//*[contains(@onclick,'getFilterHotal')]");
	 
	 public By priceLH= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[1]");
	 public By priceHL= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[2]");
	 public By AZ= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[3]");
	 public By ZA= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[4]");
	 public By rating= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[5]");
	 public By open= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[6]");
	 public By closed= By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li[7]");
	 public By resetBtnsort= By.xpath("//*[contains(@onclick,'serviceAPICallHotellist')]");
	 
	 
	// --------GetText Event-----------------------------------
	//public By _get=By.xpath("");
	public By cuisineslist_get=By.xpath("//*[contains(@id,'tab1')]//*[contains(@class,'dbListView')]/li");
	
	public By estimatedTimeHedading_get=By.xpath("//*[contains(@class,'foodOrder-filter')]/div[1]//*[contains(@class,'foodOrder-detailTab')]/h2");
	public By estimatedTimeList_get=By.xpath("//*[contains(@class,'filter-box  filter-time')]/li");
	public By MinimumOrderAmountHeading_get=By.xpath("//*[contains(@class,'foodOrder-filter')]/div[2]//*[contains(@class,'foodOrder-detailTab')]/h2");
	public By MinimumOrderAmountList_get=By.xpath("//*[contains(@class,'filter-box  filter-price')]/li");

	public By sortlist_get=By.xpath("//*[contains(@class,'cuisine-row sort-for')]/ul/li");

	

	public Cuisines_Filter_Sort(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
	
		

}