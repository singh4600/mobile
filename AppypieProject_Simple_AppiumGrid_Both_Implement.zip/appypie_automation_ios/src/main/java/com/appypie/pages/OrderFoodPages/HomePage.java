package com.appypie.pages.OrderFoodPages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
public class HomePage {
	PageElement pageutil;

	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");

	public By nonVegTablink=By.xpath("//*[contains(@class,'categories-swiper')]//li[2]");
	public By sweetTablink=By.xpath("//*[contains(@class,'categories-swiper')]//li[1]");
	public By nonveglink=By.xpath("//*[@index='1']//li[1]//img[1]");

	public By FoodOrderlink= By.xpath("//a[@data-productid='foodordering']");  //order food TAB
	public By Menulink=By.xpath("//*[contains(@onclick,'foodordering-menu')]");
	public By Searchbuttonlink=By.xpath("//*[@class='icon-search']"); // search button.
	public By SearchTextlink=By.id("foodtxtSearch"); // search Text field	
	public By subcategorylink= By.xpath("//*[@index='0']//li[1]//*[@data-head='dry sweet']");  // Subcategory  
	public By mainproductlink=By.xpath("//*[@index='0']//li[2]//img[1]");
	
	public By ViewCartlink= By.xpath("//a[contains(@onclick,'Appyscript.foodcardview')]"); // view cart button.
	public By BackButtonlink= By.xpath("//*[@class='link back']"); 
	public By AlertOkButton=By.xpath("//*[@class='modal-button modal-button-bold']");

	//---------Get Text Event------------------------------------------------------
	//public By _gettext=By.xpath("");
	


	public By AlertHeader_gettext=By.xpath("//*[@class='modal-title']");
	public By AlertText_gettext=By.xpath("//*[@class='modal-text']");
	public By maincategory_gettext=By.xpath("//*[contains(@class,'categories-swiper')]//li[1]"); // verify main category
	public By subcategory_gettext=By.xpath("//*[contains(@class,'category')]//div[1]/h3");  // verify sub category
	//-------------------------------------------------------------------------------
	public HomePage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
		pageutil=new PageElement();
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}

	public void IfAlertpresent() throws InterruptedException{
		boolean alert= false;
		alert=driver.findElements(By.id("//*[@class='modal-title']")).size()!=0;
		if(alert){
			System.out.println("Alert is present");
			getPagetext(driver, AlertHeader_gettext);
			getPagetext(driver, AlertText_gettext);
			AlertOkButtonMethod();
		}
		else{
			System.out.println("Alert is Not present");
		}
	}

	public void FoodOrderModule() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, FoodOrderlink, 20);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Food Order link is not present ");
		}
	}

	public void Menu() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, Menulink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Menu link is not present ");
		}
	}

	public void Searchbutton() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, Searchbuttonlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Search button link is not present ");
		}
	}

	public void SearchText() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, SearchTextlink, 50);
		if(open!=null && open.isDisplayed()){
			open.clear();
			open.sendKeys("dry sweet");
			PageElement.tapDeviceOk((AndroidDriver<MobileElement>) driver);
		}
		else{
			System.out.println("Search Text link is not present ");
		}
	}

	public void Subcategory() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, subcategorylink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Subcategory link is not present ");
		}
	}

	public void ViewCart() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, ViewCartlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			try{
				BackButton();
			}catch (Exception e) {
				System.out.println("View cart page not open due to popup");
			}
			IfAlertpresent();
		}
		else{
			System.out.println("View Cart link is not present ");
		}
	}

	public void BackButton() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, BackButtonlink, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Back Button link is not present ");
		}
	}

	public void AlertOkButtonMethod() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver, AlertOkButton, 50);
		if(open!=null && open.isDisplayed()){
			open.click();
			TimeUnit.SECONDS.sleep(2);
		}
		else{
			System.out.println("Alert Ok Button is not present ");
		}
	}




}
