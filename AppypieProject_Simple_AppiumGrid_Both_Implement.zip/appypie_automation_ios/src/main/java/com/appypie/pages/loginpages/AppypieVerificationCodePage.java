package com.appypie.pages.loginpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieVerificationCodePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	By code= By.id("code");
	
	
	public AppypieVerificationCodePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}
	
	public boolean isEmailVerificationPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, code, 20);
		if (page != null) {
			open = true;
		}
		return open;
	}

}
