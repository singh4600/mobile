package com.appypie.pages;



import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypiePollPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	By pollpage = By.xpath("//a[@data-productid='polling']");
	By cancelResult = By.xpath("//a[contains(@onclick,'javascript:Appyscript.popupClose')]");
	By shareResult = By.xpath("//a[contains(@onclick,'javascript:Appyscript.shareCanvas')]");
	By result = By.xpath("//div[@class='bottom']//a[text()='Result']");
	By nextbtn = By.xpath("//div[@class='bottom']//a[@class='next icon-right-open']");
	By prevbtn = By.xpath("//div[@class='bottom']//a[@class='previous icon-left-open']");
	By audio = By.xpath("//a[contains(@onclick,'Appyscript.PlayPollVideo')]");
	By youtube = By.xpath("//a[contains(@onclick,'Appyscript.playYoutubeWatch')]");
	
	

	public AppypiePollPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openPollPage() {
		WebElement element_pollPage = ElementWait.waitForOptionalElement(driver, pollpage, 20);
		if (element_pollPage != null && element_pollPage.isDisplayed()) {
			element_pollPage.click();
		} else {
			Logger.info("poll page is not present in the app or flow is not main Menu");
		}
	}

	public boolean isPollPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, nextbtn, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Poll page is not open");
		}
		return open;
	}

	public void clickResultbtn() {
		WebElement resultBtn = ElementWait.waitForOptionalElement(driver, result, 10);
		if (resultBtn != null && resultBtn.isDisplayed()) {
			resultBtn.click();
		} else {
			Logger.info("Result button is not present in the poll page");
		}
	}

	public void clickNextBtn() {
		WebElement next = ElementWait.waitForOptionalElement(driver, nextbtn, 10);
		if (next != null && next.isDisplayed()) {
			next.click();
		} else {
			Logger.info("next button is not visible");
		}
	}

	public void clickprevBtn() {
		WebElement prev = ElementWait.waitForOptionalElement(driver, prevbtn, 10);
		if (prev != null && prev.isDisplayed()) {
			prev.click();
		} else {
			Logger.info("previous button is not visible");
		}
	}

	public boolean isPrevBtnDisplayed() {
		boolean visible = false;
		WebElement btn = ElementWait.waitForOptionalElement(driver, prevbtn, 20);
		if (btn != null && btn.isDisplayed()) {
			visible = true;
		} else {
			Logger.info("previous button is not visible");
		}
		return visible;
	}

	public boolean isResultPageOpen() {
		boolean open = false;
		WebElement result = ElementWait.waitForOptionalElement(driver, cancelResult, 20);
		if (result != null && result.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void clickCloseResult() {
		PageElement.locateClickableElement(driver, cancelResult);
	}

	public void clickShare() {
		WebElement share = ElementWait.waitForOptionalElement(driver, shareResult, 10);
		if (share != null && share.isDisplayed()) {
			share.click();
		} else {
			Logger.info("share button is not visible");
		}
	}

	public void clickAudio() {
		WebElement element_audio = ElementWait.waitForOptionalElement(driver, audio, 10);
		if (element_audio != null && element_audio.isDisplayed()) {
			element_audio.click();
		} else {
			Logger.info("audio is not visible on poll");
		}
	}

	public void clickYouTube() {
		WebElement video = ElementWait.waitForOptionalElement(driver, youtube, 10);
		if (video != null && video.isDisplayed()) {
			video.click();
		} else {
			Logger.info("youtube is not visible on poll");
		}
	}


}
