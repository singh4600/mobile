package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieMenuPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	public AppypieMenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openPage(String page) {
		try{
		By dataPage = By.xpath("//a[@data-productid='"+page+"']");
		
		WebElement data = ElementWait.waitForOptionalElement(driver, dataPage, 20);
		if (data != null && data.isDisplayed()) {
			data.click();
		}
		else {
			Logger.info(page + " page is not present in the app or flow is not main Menu");
		}
		}
		catch (Exception e) {
			Logger.info("Error occurs while opening the page" + e.getMessage());
			e.printStackTrace();
		}
	}

	public boolean isPageExist(String page) {
		boolean exist = false;
		By dataPage = By.xpath("//a[@data-productid='"+page+"']");
		WebElement element = ElementWait.waitForOptionalElement(driver, dataPage, 20);
		if (element != null) {
			exist = true;
		} else {
			Logger.info(page + "  page is not present in the app or flow is not main Menu");
		}
		return exist;
	}
}
