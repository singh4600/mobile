package com.appypie.pages.Taxi;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MenuPage {
	
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;
	
	public By home = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/title_bar_left_menu')]");
	public By home_menu = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='Home']");
	public By main_menu = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='Main Menu']");
	public By payment = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='Payment']");
	public By history = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='History']");
	public By profile = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='Profile']");
	public By support = By.xpath("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='Support']");
	public By logout = By.id("//*[contains(@resource-id,'com.snappy.appypie:id/button_menu_item') and @text='Logout']");
	

	
	public MenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}
	
	
	
	
	
	
	
	
}
