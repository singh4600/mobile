package com.appypie.pages.OrderFoodPages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class CheckOutPage {
	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	Dimension size;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");
	
	
	public By name_textfield= By.xpath("//*[@id='foodOrderBilling']//*[@id='bfname']"); // fist name
	public By Telephone_textfield= By.xpath("//*[@id='foodOrderBilling']/*[@id='bpNo']"); // mobile no
	public By Email_textfield= By.xpath("//*[@id='foodOrderBilling']/*[@id='bemail']"); // email id
	public By Address_textfield= By.xpath("//*[@id='foodOrderBilling']/*[@id='bAddress']"); // address
	public By City_textfield= By.xpath("//*[@id='foodOrderBilling']/*[@id='bCity']"); // city
	public By State_textfield= By.xpath("//*[@id='foodOrderBilling']/*[@id='bState']"); // state
	public By Zip_textfield= By.xpath("//*[@id='foodOrderBilling']/*[@id='bZip']"); // zip
	public By Country_textfield= By.xpath("//*[@id='foodOrderBilling']//*[@id='bcountryTry']//*[@id='bCountry']"); // country
	public By Deliveryaddresscheckbox= By.xpath("//*[contains(@onclick,'foodProfileCheckbox')]"); // billing address
	public By deliverASAPcheckbox=By.xpath("//*[contains(@onclick,'foodasapCheckbox')]");
	public By viewstoretimelink=By.xpath("//*[contains(@id,'deliveryTimececk')]/a");
	public By closeViewStroeTime=By.xpath("//*[contains(@id,'foodPopup')]//*[contains(@onclick,'Appyscript.openPopupFood')]");
	public By confirmbtn= By.xpath("//*[@id='billingAddress']/a"); // confirm button.
	public By clickAlertOKpopupmessagebtn=By.xpath("//span[@class='modal-button modal-button-bold']");
	public By clickViewStoreTimingsbtn=By.xpath("//*[@class='billing-address tab']//*[@class='view-store arial mediumContent']"); // view store timings button
	public By clickViewStoreTimingsclosebtn=By.xpath("//div[@class='form-view']/a"); //
	
	public By DeliveryTAB= By.xpath("//*[@class='tabViewall']/a"); //
	public By PickupTAB= By.xpath("//*[@class='tabmyCollection']/a"); //
	public By PickupTime= By.xpath("//div[@class='billing-address tab']/div"); //
	public By PickupTimesetbtn= By.xpath(""); //
	public By ViewStoretimepickupTAB= By.xpath("//*[@id='picup']/a[1]"); //
	public By InstructionsPickUpTAB= By.xpath("//*[@id='pickInstruction']"); //
	public By ConfirmBtnPickUpTAB= By.xpath("//*[@id='picup']/a[2]"); //
	public By ContinueOrderingbtn= By.xpath("//*[contains(@onclick,'foodGoToHomePage')]"); //
	
	public By deliveryCheckBox=By.xpath("//*[contains(@onclick,'foodProfileCheckbox')]");
	public By user_delivery=By.xpath("//*[@id='sfname']");
	public By phone_delivery=By.xpath("//*[@id='spNo']");
	public By address_delivery=By.xpath("//*[@id='ssAddress']");
	public By city_delivery=By.xpath("//*[@id='sCity']");
	public By state_delivery=By.xpath("//*[@id='sState']");
	public By zip_delivery=By.xpath("//*[@id='sZip']");
	public By country_delivery=By.xpath("//*[@id='sCountry']");
	
	//--------------delivery time set-------------
	public By time=By.xpath("//*[@id='deliveryTimececk']/input[1]");
	public By pmNative=By.xpath("//android.widget.CheckedTextView[@index='1']");
	public By timenative=By.xpath("//*[@content-desc='10']");
	public By time_Set_btn_native = By.xpath("//android.widget.Button[@index='2']");

	
	//---------Get Text Event----------------------------
	public By Storetime_gettext=By.xpath("//*[contains(@class,'form-view')]");
	public By headingStoretime_gettext=By.xpath("//*[contains(@class,'form-view')]//h2[1]");
	public By openingtime_gettext=By.xpath("//*[contains(@class,'form-view')]/ul[1]//div[1]");
	public By workingtime_gettext=By.xpath("//*[contains(@class,'form-view')]/ul[1]//div[2]");
	public By headingCustomeservingtime_gettext=By.xpath("//*[contains(@class,'form-view')]//h2[2]");
	public By openingHour_gettext=By.xpath("//*[contains(@class,'form-view')]//ul[2]//div[1]");
	public By workingHour_gettext=By.xpath("//*[contains(@class,'form-view')]//ul[2]//div[2]");
	
	public By AlertHeadertitle_gettext=By.xpath("//div[@class='modal-title']");
	public By Alertpopupmessage_gettext=By.xpath("//div[@class='modal-text']");

	public By Genopentime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[1]/li/div[1]");
	public By Genclosetime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[1]/li/div[2]");
	public By storetimingheadertitle_gettext=By.xpath("//*[@id='foodPopup']/div/h2[2]");
	public By Customeopentime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[2]/li/div[1]");
	public By Customerclosetime_gettext=By.xpath("//*[@id='foodPopup']/div/ul[2]/li/div[2]");
	
	public By PaymentDetailsHeading_gettext=By.xpath("//*[@id='billingAddress']/div[7]/h2");
	public By Subtotal_gettext=By.xpath("//*[@class='payment-details']//*[@id='subtotalecom']/span");
	public By Discount_gettext=By.xpath("//*[@class='payment-details']//li[@id='discountecom']/span");  
	public By Delivery_gettext=By.xpath("//*[@class='payment-details']//*[@id='deliverychargeecom']/span");
	public By Tax_gettext=By.xpath("//*[@class='payment-details']//*[@id='taxecomecom']/span");
	public By Tip_gettext=By.xpath("//*[@class='payment-details']//*[@id='tipcharge']/span");
	public By GrandTotal_gettext=By.xpath("//*[@class='payment-details']//*[@id='gtotal']/span");
	public By ThankyouHeading_gettext=By.xpath("//*[@class='thankyou']/h1");
	public By Thankyoupagemessage_gettext=By.xpath("//*[@class='thankyou']//p[1][@id='mess']");
	public By ThankyoupageOrdermessage_gettext=By.xpath("//*[@class='thankyou']//p[2][@id='mess']");
	
	//--------------------pickup--------------------
	public By time_gettext=By.xpath("//*[@id='totalDeliveryETA']");
	public By instructionText=By.xpath("//*[@id='pickInstruction']");
	public By billcheckbox=By.xpath("//*[contains(@onclick,'foodOrderProfileCheckboxPickup')]");
	public By viewstortimepickup=By.xpath("//*[contains(@class,'timeInput')]//*[contains(@class,'view-store arial mediumContent')]");

	
	//---------------------------------------------------
	public CheckOutPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
	}
	
	public static String verifyAttributevalue(AppiumDriver<MobileElement> driver, By getAttribute){
		Actual=ElementWait.waitForOptionalElement(driver,getAttribute,50).getAttribute("value");
		System.out.println("Actual value:  "+Actual);
		return Actual;
	}
	public static String getPagetext(AppiumDriver<MobileElement> driver, By gettext){
		try{
			String gettextmessage = ElementWait.waitForOptionalElement(driver,gettext,50).getText();
			Logger.info("Inner Page Text is :"+gettextmessage);
			return gettextmessage;
		}catch (Exception e) {
			System.out.println("Error getting text:  "+e);
		}
		return runningTest1;
	}

	public void UserDetail() {
		WebElement nametext= ElementWait.waitForOptionalElement(driver, name_textfield, 40);
		if(nametext!=null && nametext.isDisplayed()){
			nametext.clear();
			nametext.sendKeys("anurag");
			System.out.println("Name:  anurag");
			driver.navigate().back();}
		else{
			System.out.println("name page is not present in main menu");
		}

		WebElement Telephonetext= ElementWait.waitForOptionalElement(driver, Telephone_textfield, 40);
		if(Telephonetext!=null && Telephonetext.isDisplayed()){
			Telephonetext.clear();
			Telephonetext.sendKeys("9540198626");
			System.out.println("Mobile :  9540198626");
			driver.navigate().back();}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		WebElement Emailtext= ElementWait.waitForOptionalElement(driver, Email_textfield, 40);
		if(Emailtext!=null && Emailtext.isDisplayed()){
			Emailtext.clear();
			Emailtext.sendKeys("anurag@yopmail.com");
			System.out.println("Email : prince@appypie.com");
			driver.navigate().back();
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		WebElement Addresstext= ElementWait.waitForOptionalElement(driver, Address_textfield, 40);
		if(Addresstext!=null && Addresstext.isDisplayed()){
			Addresstext.clear();
			Addresstext.sendKeys("anurag");
			System.out.println("Address: Anurag");
			driver.navigate().back();
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		WebElement Citytext= ElementWait.waitForOptionalElement(driver, City_textfield, 40);
		if(Citytext!=null && Citytext.isDisplayed()){
			Citytext.clear();
			Citytext.sendKeys("noida");
			System.out.println("City:  Noida");
			driver.navigate().back();
		}                              
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		WebElement Statetext= ElementWait.waitForOptionalElement(driver, State_textfield, 40);
		if(Statetext!=null && Statetext.isDisplayed()){
			Statetext.clear();
			Statetext.sendKeys("UTTAR PRADESH");
			System.out.println("State:  Uttar pradesh");
			driver.navigate().back();
		}                                                                            
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		WebElement Ziptext= ElementWait.waitForOptionalElement(driver, Zip_textfield, 40);
		if(Ziptext!=null && Ziptext.isDisplayed()){
			Ziptext.clear();
			Ziptext.sendKeys("203010");
			System.out.println("Pin:  203010");
			driver.navigate().back();
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		WebElement Countrytext= ElementWait.waitForOptionalElement(driver, Country_textfield, 40);
		if(Countrytext!=null && Countrytext.isDisplayed()){
			WebElement mySelectElement = driver.findElement(By.xpath("//*[@id='foodOrderBilling']//*[@id='bcountryTry']//*[@id='bCountry']"));//*[@id="bCountry"]
			Select dropdown= new Select(mySelectElement);
			dropdown.selectByVisibleText("India");
			System.out.println("Country : INDIA");
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}

		/*	    WebElement Deliveryaddresscheckboxtext= ElementWait.waitForOptionalElement(driver, Deliveryaddresscheckbox, 40);
	    if(Deliveryaddresscheckboxtext!=null && Deliveryaddresscheckboxtext.isDisplayed()){
	    	Deliveryaddresscheckboxtext.click();
	    }
	    else{
	    System.out.println("opencheckout page is not present in main menu");
	    }*/

		WebElement confirmBtn= ElementWait.waitForOptionalElement(driver, confirmbtn, 20);
		if(confirmBtn!=null && confirmBtn.isDisplayed()){
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			confirmBtn.click();
			System.out.println("Click conformation button");
			//  driver.navigate().back();
		}
		else{
			System.out.println("confirmbtn page is not present in main menu");
		}
		/*	
	driver.findElement(name).sendKeys("anurag");
	driver.findElement(Telephone).sendKeys("9540198626");
	driver.findElement(Email).sendKeys("prince@appypie.com");
	driver.findElement(Address).sendKeys("nsez noida");
	driver.findElement(City).sendKeys("noida");
	driver.findElement(State).sendKeys("uttar pradesh");
	driver.findElement(Zip).sendKeys("201305");
	driver.findElement(Country).sendKeys("INDIA");*/                  
	}
	
	
	//---------------billing details----------------------

		public void cheoutpagewithoutfillanyinfo(){
			try{
			WebElement nametext= ElementWait.waitForOptionalElement(driver, name_textfield, 40);
			nametext.clear();
			WebElement Telephonetext= ElementWait.waitForOptionalElement(driver, Telephone_textfield, 40);
			Telephonetext.clear();
			WebElement Emailtext= ElementWait.waitForOptionalElement(driver, Email_textfield, 40);
			Emailtext.clear();
			WebElement Addresstext= ElementWait.waitForOptionalElement(driver, Address_textfield, 40);
			Addresstext.clear();
			WebElement Citytext= ElementWait.waitForOptionalElement(driver, City_textfield, 40);
			Citytext.clear();
			WebElement Statetext= ElementWait.waitForOptionalElement(driver, State_textfield, 40);
			Statetext.clear();
			WebElement Ziptext= ElementWait.waitForOptionalElement(driver, Zip_textfield, 40);
			Ziptext.clear();
			}
			catch (Exception e) {
				System.out.println("Errorn in form in cheout page."); 
			
			}
		}
		
		
		public void name(){
		WebElement nametext= ElementWait.waitForOptionalElement(driver, name_textfield, 40);
		if(nametext!=null && nametext.isDisplayed()){
			nametext.clear();
			nametext.sendKeys("anurag");
			System.out.println("Name:  anurag");
			driver.hideKeyboard();
			}
		else{
			System.out.println("name page is not present in main menu");
		}
		}
		public void telephone(){
		WebElement Telephonetext= ElementWait.waitForOptionalElement(driver, Telephone_textfield, 40);
		if(Telephonetext!=null && Telephonetext.isDisplayed()){
			Telephonetext.clear();
			Telephonetext.sendKeys("9540198626");
			System.out.println("Mobile :  9540198626");
			driver.hideKeyboard();
			}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}
		}
		
		public void email(){
		WebElement Emailtext= ElementWait.waitForOptionalElement(driver, Email_textfield, 40);
		if(Emailtext!=null && Emailtext.isDisplayed()){
			Emailtext.clear();
			Emailtext.sendKeys("anurag@yopmail.com");
			System.out.println("Email : prince@appypie.com");
			driver.hideKeyboard();
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}}
		
		
		public void address(){
		WebElement Addresstext= ElementWait.waitForOptionalElement(driver, Address_textfield, 40);
		if(Addresstext!=null && Addresstext.isDisplayed()){
			Addresstext.clear();
			Addresstext.sendKeys("anurag");
			System.out.println("Address: Anurag");
			driver.hideKeyboard();
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}}

		public void city(){
		WebElement Citytext= ElementWait.waitForOptionalElement(driver, City_textfield, 40);
		if(Citytext!=null && Citytext.isDisplayed()){
			Citytext.clear();
			Citytext.sendKeys("noida");
			System.out.println("City:  Noida");
			driver.hideKeyboard();
		}                              
		else{
			System.out.println("opencheckout page is not present in main menu");
		}}

		public void state(){
		WebElement Statetext= ElementWait.waitForOptionalElement(driver, State_textfield, 40);
		if(Statetext!=null && Statetext.isDisplayed()){
			Statetext.clear();
			Statetext.sendKeys("UTTAR PRADESH");
			System.out.println("State:  Uttar pradesh");
			driver.hideKeyboard();
		}                                                                            
		else{
			System.out.println("opencheckout page is not present in main menu");
		}}

		public void zip(){
		WebElement Ziptext= ElementWait.waitForOptionalElement(driver, Zip_textfield, 40);
		if(Ziptext!=null && Ziptext.isDisplayed()){
			Ziptext.clear();
			Ziptext.sendKeys("203010");
			System.out.println("Pin:  203010");
			driver.hideKeyboard();
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}}

		public void country() throws InterruptedException{
		WebElement Countrytext= ElementWait.waitForOptionalElement(driver, Country_textfield, 40);
		if(Countrytext!=null && Countrytext.isDisplayed()){
			WebElement mySelectElement = driver.findElement(By.id("bCountry"));
			Select dropdown= new Select(mySelectElement);
			dropdown.selectByVisibleText("India");
			System.out.println("Country : INDIA");
			TimeUnit.SECONDS.sleep(5);
		}
		else{
			System.out.println("opencheckout page is not present in main menu");
		}
		}

		public void confirmbutton() throws InterruptedException{
		WebElement confirmBtn= ElementWait.waitForOptionalElement(driver, confirmbtn, 20);
		if(confirmbtn!=null && confirmBtn.isDisplayed()){
			TimeUnit.SECONDS.sleep(5);
			confirmBtn.click();
			System.out.println("Click conformation button");
			//  driver.navigate().back();
		}
		else{
			System.out.println("confirmbtn page is not present in main menu");
		}}
	             
		public void AllPrice(){
			System.out.println("check subtotal");
			getPagetext(driver, Subtotal_gettext);
			System.out.println("check Discount");
			getPagetext(driver, Discount_gettext);
			System.out.println("check Delivery");
			getPagetext(driver, Delivery_gettext);
			System.out.println("check Tax");
			getPagetext(driver, Tax_gettext);
			System.out.println("check Tip");
			getPagetext(driver, Tip_gettext);
			System.out.println("check Grand Total");
			getPagetext(driver, GrandTotal_gettext);
			System.out.println("check Total Payable Amount");
			getPagetext(driver, GrandTotal_gettext);
		}
		
		public void clickViewStoreTimingsbtn() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,clickViewStoreTimingsbtn , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("View Store Timings btn button on Check out page is not present");
			}
		}
		
		public void clickViewStoreTimingsclosebtn() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,clickViewStoreTimingsclosebtn , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("View Store Timings btn button on Check out page is not present");
			}
		}
		
		public void clickDeliveryTAB() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,DeliveryTAB , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("Delivery TAB on Check out page is not present");
			}
		}
		
		public void clickPickupTAB() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,PickupTAB , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("Pickup TAB on Check out page is not present");
			}
		}
		
		public void clickPickupTime() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,PickupTime , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("Pickup Time on Check out page is not present");
			}
		}
		
		public void clickViewStoretimepickupTAB() throws InterruptedException{	
		WebElement open= ElementWait.waitForOptionalElement(driver,ViewStoretimepickupTAB , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("View Store time pickupT AB on Check out page is not present");
			}
		}
		
		public void clickInstructionsPickUpTAB() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,InstructionsPickUpTAB , 50);
				if(open!=null && open.isDisplayed()){
					open.sendKeys("Noida NSEZ Noida");
					driver.hideKeyboard();
				}
				else{
					System.out.println("Instructions PickUp TAB on Check out page is not present");
				}
			}

		public void clickConfirmBtnPickUpTAB() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,ConfirmBtnPickUpTAB , 50);
				if(open!=null && open.isDisplayed()){
					open.click();
					TimeUnit.SECONDS.sleep(2);
				}
				else{
					System.out.println("Confirm Btn PickUp TAB on Check out page is not present");
				}
			}
		
		public void userdetails() throws InterruptedException{
			cheoutpagewithoutfillanyinfo();
			driver.findElement(name_textfield).sendKeys("anurag");
			driver.findElement(Telephone_textfield).sendKeys("9540198626");
			driver.findElement(Email_textfield).sendKeys("prince@appypie.com");
			driver.findElement(Address_textfield).sendKeys("nsez noida");
			driver.findElement(City_textfield).sendKeys("noida");
			driver.findElement(State_textfield).sendKeys("uttar pradesh");
			driver.findElement(Zip_textfield).sendKeys("201305");
			driver.findElement(Country_textfield).sendKeys("INDIA");
			//scrollToBottom();
			driver.context("NATIVE_APP");
			try{
			Swipe();
			PageElement.changeContextToWebView(driver); 
			}catch (Exception e) {
				scrollToBottom();
				PageElement.changeContextToWebView(driver); 
			}
		}
		
		public void ContinueOrderingThanksyoupage() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,ContinueOrderingbtn , 50);
				if(open!=null && open.isDisplayed()){
					open.click();
					TimeUnit.SECONDS.sleep(2);
				}
				else{
					System.out.println("Confirm Btn PickUp TAB on Check out page is not present");
				}
			}
		
	//----------------------------------------------------------
		
		public void scrollToBottom() {
			WebElement element = driver.findElement(By.xpath("//View[@content-desc='Confirm']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
		}
		
		public void Swipe() throws InterruptedException{
			//Get the size of screen. 
			size = driver.manage().window().getSize(); 
			System.out.println(size); 
			//Find swipe start and end point from screen's with and height. 
			//Find starty point which is at bottom side of screen. 
			int starty = (int) (size.height * 0.80); 
			//Find endy point which is at top side of screen. 
			int endy = (int) (size.height * 0.20); 
			//Find horizontal point where you wants to swipe. It is in middle of screen width. 
			int startx = size.width / 2; 
			//System.out.println("starty = " + starty + " ,endy = " + endy + " , startx = " + startx); 
			//Swipe from Bottom to Top. 
			driver.swipe(startx, starty, startx, endy, 3000); 
			TimeUnit.SECONDS.sleep(3);
			//Swipe from Top to Bottom. 
			//driver.swipe(startx, endy, startx, starty, 3000); 
			TimeUnit.SECONDS.sleep(3);
			
			//-----------second method-----------
		    
		     /*   MobileElement listGroup = list.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
		                                + "new UiSelector().text(\" List item:25\"));"));
		     */ 
			
		}
		
		
		
		public void clickAlertOkBtn() throws InterruptedException{	
			WebElement open= ElementWait.waitForOptionalElement(driver,clickAlertOKpopupmessagebtn , 50);
			if(open!=null && open.isDisplayed()){
				open.click();
			}
			else{
				System.out.println("Alert Ok button button on Cart page is not present");
			}
		}
		
		}
