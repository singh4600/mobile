package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class RatingAndReviewPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By RatereviePage = By.xpath("//div[@class='filter-page']/div/h3");
	By rateStar = By.xpath("//div[@class='pull-left']//span[contains(@onclick,'Appyscript.starClk')]");
	By reviewBox = By.id("rnrTextArea");
	By submitReviewRate = By.xpath("//button[contains(@onclick,'Appyscript.submitReviewAndRating')]");

	// ********* Locators for hyperlocal*********************
	By hl_rsubmitReview = By.xpath("//button[contains(@onclick,'Appyscript.hyperlocalsubmitReviewAndRating')]");

	public RatingAndReviewPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isRatingAndReviewPageOpen(String page) {
		boolean open = false;
		WebElement ratePage;
		if (page.equals("dir"))
			ratePage = ElementWait.waitForOptionalElement(driver, RatereviePage, 20);
		else
			ratePage = ElementWait.waitForOptionalElement(driver, reviewBox, 20);
		if (ratePage != null && ratePage.isDisplayed()) {
				open = true;
		} else {
			Logger.info("RateAnd Review page is not open");
		}
		return open;
	}

	public void selectStars() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, rateStar, 5).click();
	}

	public void writeReview(String review) throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, reviewBox, 5).sendKeys(review);
	}

	public void submitReview(String page) {
		if (page.contains("dir"))
			ElementWait.waitForOptionalElement(driver, submitReviewRate, 5).click();
		else
			ElementWait.waitForOptionalElement(driver, hl_rsubmitReview, 5).click();
	}
}
