package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class UpdatePropertyRealEsatePage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By deletepropertylink= By.xpath("//*[contains(@onclick,'deleteproperty')]");
	public By updateListing= By.xpath("Appyscript.realestateupdateListing");

	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By real_estate_update_listings_gettext=By.xpath("//*[contains(@class,'real-estate update-listings')]/ul/li");



	public UpdatePropertyRealEsatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}