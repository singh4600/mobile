package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BookHotelPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By selectTitle= By.xpath("//*[contains(@id,'hotelguesttitle')]");
	public By selectTitle1= By.xpath("//*[contains(@id,'hotelguesttitle')]/option[2]");
	public By selectMr_Native_radio_btn= By.xpath("//android.widget.CheckedTextView[@index='1']");
	public By firstName_text= By.xpath("//*[contains(@id,'hotelguestfname')]");
	public By lastName_text= By.xpath("//*[contains(@id,'hotelguestlname')]");
	public By email_text= By.xpath("//*[contains(@id,'hotelguestemail')]");
	public By phone_text= By.xpath("//*[contains(@id,'hotelguestphone')]");
	public By payNow_btn= By.xpath("//*[contains(@onclick,'HotelPaymentMethod')]");




	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By guestName_gettext=By.xpath("//*[contains(@class,'hotel-form')]/div[1]/h2");
	public By contactDetails_gettext=By.xpath("//*[contains(@class,'hotel-form')]/div[2]/h2");
	public By Message_gettext=By.xpath("//*[contains(@class,'hotel-form')]/div[2]/p");
	public By selectTitleHeader_Native_gettext=By.xpath("//*[@index='0']");
	public By i_selectTitleHeader_Native_gettext1=By.className("XCUIElementTypePickerWheel");
	public String i_selectTitleHeader_Native_gettext="Mr.";

	public BookHotelPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}