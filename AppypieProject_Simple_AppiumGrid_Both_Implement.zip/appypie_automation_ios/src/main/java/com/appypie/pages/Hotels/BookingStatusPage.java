package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BookingStatusPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By addToCalendarlink=By.xpath("//*[contains(@onclick,'addtocalhotelevent')]");
	


	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By hotelBookingId_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[1]");
	public By hotelName_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[2]/h3");
	public By hoteladdress_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[2]/p");
	public By checkInTime_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[2]/div[1]/div[1]");
	public By checkOutTime_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[2]/div[1]/div[2]");
	public By roomDetailsHeading_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/h3");
	public By roomType_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/p[2]/span[1]");
	public By bookingStatus_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/p[2]/span[2]");
	public By roomsCount_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/p[5]/span[1]");
	public By occupancy_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/p[5]/span[2]");
	public By travellerDetails_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[4]/p");
	public By roomCost_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[5]/p[1]/span[2]");
	public By listBookingStatus_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li");
	






	public BookingStatusPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}