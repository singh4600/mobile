package com.appypie.pages.directoryHyperLocalpages;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class UpdateListingPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By deleteList = By.xpath("//a[contains(@onclick,'directoryPageDeleteMobile')]");
	By listName = By.xpath("//p[@class='hyper-comt-txt']/strong");
	By listSummary = By.xpath("//p[@class='hyper-comt-txt']/span");
	By list = By.xpath("//span[contains(@onclick,'Appyscript.updateListingDeatil')]");
	By addList_summary = By.xpath("//textarea[@id='summarySL']");
	By delete = By.xpath("//span[contains(@class,'modal-button modal-button-bold')]");
	By updateListBtn = By.xpath("//button[contains(@onclick,'addListingClick')][text()='Update listing']");

	// ****** locators for hyperlocal********
	By hl_list = By.xpath("//span[contains(@onclick,'Appyscript.updatePostJobDeatil')]");
	By hl_deleteList = By.xpath("//a[contains(@onclick,'hyperlocalPageDeleteMobile')]");
	By hl_title = By.xpath("//input[contains(@id,'jobTitle')]");
	By updateJob = By.xpath("//button[contains(@onclick,'addPostJobClick')]");

	public UpdateListingPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public List<Boolean> isUpdateListingPageOpen(String page) {
		boolean open = false;
		boolean noData = false;
		List<Boolean> info = new ArrayList<Boolean>();
		WebElement updateList;
		if (page.equals("dir"))
			updateList = ElementWait.waitForOptionalElement(driver, list, 20);
		else
			updateList = ElementWait.waitForOptionalElement(driver, hl_list, 20);
		if (updateList != null && updateList.isDisplayed()) {
			open = true;
		} else {
			noData = PageElement.checkNoDataOptionInUrl(driver);
		}
		info.add(open);
		info.add(noData);
		return info;
	}

	public void deleteListing(String page) {
		WebElement removeList;
		if (page.equals("dir"))
			removeList = ElementWait.waitForOptionalElement(driver, deleteList, 20);
		else
			removeList = ElementWait.waitForOptionalElement(driver, hl_deleteList, 20);
		if (removeList != null && removeList.isDisplayed()) {
			removeList.click();
		} else {
			Logger.info("remove list button is not displayed on listing");
		}
	}

	public void clickList(String page) {
		if (page.equals("dir"))
			driver.findElement(list).click();
		else
			driver.findElement(hl_list).click();
	}

	public String getListHeading() {
		return driver.findElement(listName).getText();
	}

	public String getListSummary() {
		return ElementWait.waitForOptionalElement(driver, listSummary, 20).getText();
	}

	public void clickDeleteButtonOnPopup() {
		driver.findElement(delete).click();
	}

	public void updateListHeading() {
		PageElement.sendKey(driver, addList_summary, "UpdateSummary");
	}
	
	public void updateJobTitle() {
		PageElement.sendKey(driver, hl_title, "UpdateJobAutomation");
	}

	public void submitUpdateListForm(String page) {
		if (page.equals("dir"))
			PageElement.locateClickableElement(driver, updateListBtn);
		else
			PageElement.locateClickableElement(driver, updateJob);
	}

}
