package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieReligiousPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By bible = By.xpath("//a[@data-identifire='bible']");
	By quran = By.xpath("//a[@data-identifire='quran']");
	By geeta = By.xpath("//a[@data-identifire='gita']");

	public AppypieReligiousPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isReligiousPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, geeta, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openReligiousBooks(String type) {
		WebElement book = null;
		if (type.equals("bible")) {
			book = ElementWait.waitForOptionalElement(driver, bible, 20);
		} else if (type.equals("Quran")) {
			book = ElementWait.waitForOptionalElement(driver, quran, 20);
		} else {
			book = ElementWait.waitForOptionalElement(driver, geeta, 20);
		}
		if (book != null && book.isDisplayed()) {
			book.click();
		}
	}
	
}
