package com.appypie.pages.FoodCourt;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class Offered {

	private static final Logger Logger= Log.createLogger();
	protected AppiumDriver<MobileElement> driver;



	//public By =By.xpath("");

	public By openOfferedProduct=By.xpath("//*[contains(@class,'pages ')]/div[2]//*[@class='food-Order']//li[1]/span[2]");
	

	//------------------------------------------------------------------------------------------------------

	//public By _get=By.xpath("");
	public By offeredList_get=By.xpath("//*[contains(@class,'pages ')]/div[2]//*[@class='food-Order']//li/span[2]");


	


	static SoftAssert softassert;
	public Offered(AppiumDriver<MobileElement> driver){
		this.driver= driver;	
	
	}

	

}

