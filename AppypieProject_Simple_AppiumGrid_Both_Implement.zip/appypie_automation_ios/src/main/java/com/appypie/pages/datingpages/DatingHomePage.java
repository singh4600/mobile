package com.appypie.pages.datingpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DatingHomePage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By keepSwipe = By.xpath("//button[contains(@onclick,'Appyscript.datingFind')]");
	By menu = By.xpath("//a[contains(@onclick,'Appyscript.popupPage')]");

	By matchPartnerdetail = By.xpath("//div[@id='people']//div[@class='person']/span/strong");
	By partner = By.xpath("//div[contains(@onclick,'Appyscript.viewuserProfile')]");
	By heartIcon = By.xpath("//div[@class='button yes']//span[@class='icon-heart-1']");

	By message = By.xpath("//a[contains(@onclick,'Appyscript.datingchatProfile')]");
	By notifications = By.xpath("//a[contains(@onclick,'Appyscript.datingnotification')]");
	By datingHeader = By.xpath("//div[@class='navbar']//div[text()='Dating']");
	

	public DatingHomePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isDatingHomePageOpen() {
		boolean open = false;
		WebElement date = ElementWait.waitForOptionalElement(driver, datingHeader, 20);
		if (date != null && date.isDisplayed()) {
			if (date.getText().equals("Dating")) {
				open = true;
			}
		}
		return open;
	}

	public boolean isPartnerSearchSuccess() {
		boolean success = false;
		WebElement match = ElementWait.waitForOptionalElement(driver, matchPartnerdetail, 20);
		if (match != null && match.isDisplayed()) {
			String detail = match.getText();
			if (detail.contains("TestName"))
				success = true;
		}
		return success;
	}

	public void acceptMatch() {
		PageElement.locateClickableElement(driver, heartIcon);
	}

	public void openProfile() {
		PageElement.locateClickableElement(driver, partner);
	}

	public void clickMessages() {
		PageElement.locateClickableElement(driver, message);
	}

	public void clickNotifications() {
		PageElement.locateClickableElement(driver, notifications);
	}

	public void clickSwipe() {
		PageElement.locateClickableElement(driver, keepSwipe);
	}

	public void clickMenu() {
		PageElement.locateClickableElement(driver, menu);
	}
}
