package com.appypie.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EventPage {
	By eventPage= By.xpath("//a[@data-productid='event']");
	By eventpageData=By.xpath("//a[@class='appypie-list'][@data-page='event']");
	By heading=  By.xpath("//div[@class='navbar']/div[2]/div[2]");
	
	
	
	private static final Logger Logger= Log.createLogger();
	
	protected AppiumDriver<MobileElement> driver;
	
	public EventPage(AppiumDriver<MobileElement> driver){
	this.driver=driver;		
}

public void openEventPage() throws InterruptedException{
  WebElement event= ElementWait.waitForOptionalElement(driver,eventPage,20);
  if(event!=null && event.isDisplayed()){
  ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+event.getLocation().x+")");
  event.click();
  }else{
  Logger.info("Event page is not present or not displayed in the app");
  }
}

public boolean isEventUrlExist(String identifire){
	By url= By.xpath("//a[@class='appypie-list'][@data-identifire='"+identifire+"']");
	Boolean exist=false;
	List<WebElement> eventfulList= ElementWait.waitForAllOptionalElements(driver, url,20);
	if(eventfulList!=null && eventfulList.size()!=0)
	exist=true;
	else
	Logger.info("eventful urls are not available in eventPage");
	return exist;	
	}

public String getPageHeader(){
	
	String Header = ElementWait.waitForOptionalElement(driver,heading,10).getText();
	Logger.info("Inner Page header is "+Header);
	return Header;
	}

public void clickEventurl(String identifire) throws InterruptedException{
	Thread.sleep(2000);
	By url= By.xpath("//a[@class='appypie-list'][@data-identifire='"+identifire+"']");
	WebElement eventpageelement=ElementWait.waitForOptionalElement(driver,url,20);
	eventpageelement.click();
}


}
