package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class LocationPage extends TestSetup{
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	public By searchOnLocation = By.xpath("//*[@name='weatherLocationDir']");
	By closeLocation = By.xpath("//a[contains(@class,'close icon-cancel')]");
	By locationTab = By.id("weatherListDir");
	By searchData = By.xpath("//ul[@id='weatherListDir']/li");
	By searchDataDirectory = By.xpath("//android.view.View[contains(@resource-id,'locationDir')]");
	By i_searchDataDirectory = By.xpath("//android.view.View[contains(@resource-id,'locationDir')]");

	public LocationPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean islocationOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement tab = ElementWait.waitForOptionalElement(driver, locationTab, 10);
		if (tab != null && tab.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Location tab is not open from directory home page");
		}
		return open;
	}

	public void closeLocationTab() {
		WebElement close = ElementWait.waitForOptionalElement(driver, closeLocation, 10);
		if (close != null && close.isDisplayed()) {
			close.click();
		} else {
			Logger.info("Close buton is not visible on location tab");
		}
	}

	public void typeSearchData(String data) {
		if (!globledeviceName.equals("iPhone")) {
			PageElement.sendKey(driver, searchDataDirectory, data);
		}
		else {
			PageElement.sendKey(driver, searchDataDirectory, data);
		}
		
	
	}
	
	public void typeSearchData1() {
		PageElement.locateClickableElement(driver, searchOnLocation);
	}

	public void typeLocationSearchData(String data1) {
		WebElement data = ElementWait.waitForOptionalElement(driver, searchOnLocation, 10);
		if (data != null &&data.isDisplayed()) {
			data.click();
			try {
				Thread.sleep(2000);
				data.sendKeys(data1);
			} catch (InterruptedException e) {
				e.getMessage();
				e.printStackTrace();
			}
			
		} else {
			Logger.info("location search not clikable");
		}
	}

	
	
	public boolean isSearchDataAvailable() {
		boolean present = false;
		WebElement data = ElementWait.waitForOptionalElement(driver, searchData, 10);
		if (data != null && data.isDisplayed()) {
			present = true;
		} else {
			Logger.info("No search data ia present");
		}
		return present;
	}

	public void ClickSearchData() {
		driver.findElement(searchData).click();
	}

	@Override
	public void pageSetUp() {
		// TODO Auto-generated method stub
		
	}

}
