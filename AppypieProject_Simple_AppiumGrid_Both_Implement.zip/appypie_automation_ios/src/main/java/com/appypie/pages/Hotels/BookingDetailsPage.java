package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BookingDetailsPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By bookNow_btn= By.xpath("//*[contains(@onclick,'Appyscript.hotelGuestDetail')]");
	public By backpageBtn= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	public By enterCouponcodeText=By.xpath("//*[contains(@id,'couponcodeapply')]");
	public By CouponcodeApplylink=By.xpath("//*[contains(@onclick,'hotelapplycoupon')]");
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By listBookingDetails_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li");
	public By hotelName_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[1]");
	public By ownerName_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[2]/div/div");
	public By checkInTime_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/div[1]/div[1]");
	public By checkOutTime_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[3]/div[1]/div[2]");
	public By roomType_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[4]");
	public By stayNightCount_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[5]");
	public By roomCount_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[6]");
	public By guestCount_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[7]");
	public By applyCoupon_gettext=By.xpath("//*[contains(@class,'hotelListCommen')]/li[8]/div");


	
	



	public BookingDetailsPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}