package com.appypie.pages.FoodCourt;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MyAccount {

	private static final Logger Logger= Log.createLogger();
	protected AppiumDriver<MobileElement> driver;



	//public By =By.xpath("");
	public By userNameContactInfo=By.xpath("//*[@id='cfname']");
	public By emailContactInfo=By.xpath("//*[@id='cemail']");
	public By phoneNoContactInfo=By.xpath("//*[@id='cpNo']");
	public By updateBtnContactInfo=By.xpath("//*[@id='contactInfo']//*[contains(@onclick,'foodcourtUpdateAccount')]");
	public By usernameBillingAddress=By.xpath("//*[@id='bfname']");
	public By phoneNoBillingAddress=By.xpath("//*[@id='bpNo']");
	public By addressBillingAddress=By.xpath("//*[@id='bAddress']");
	public By cityBillingAddress=By.xpath("//*[@id='bCity']");
	public By stateBillingAddress=By.xpath("//*[@id='bState']");
	public By zipBillingAddress=By.xpath("//*[@id='bZip']");
	public By countryBillingAddress=By.xpath("//*[@id='bcountryTry']");
	public By i_countryUpdateBillingAddress=By.xpath("//*[@id='bcountryTry']//*[@id='IN']");
	public By updateBtnBillingAddress=By.xpath("//*[@id='billing']//*[contains(@onclick,'foodcourtUpdateAccount')]");
	public By checkBoxDeliveryAddress=By.xpath("//*[contains(@onclick,'foodCourtProfileCheckbox')]");
	public By usernameDeliveryAddress=By.xpath("//*[@id='sfname']");
	public By phoneNoDeliveryAddress=By.xpath("//*[@id='spNo']");
	public By addressDeliveryAddress=By.xpath("//*[@id='ssAddress']");
	public By cityDeliveryAddress=By.xpath("//*[@id='sCity']");
	public By stateDeliveryAddress=By.xpath("//*[@id='sState']");
	public By zipDeliveryAddress=By.xpath("//*[@id='sZip']");
	public By countryDeliveryAddress=By.xpath("//*[@id='scountryTry']");
	public By i_countryDeliveryAddress=By.xpath("//*[@id='scountryTry']//*[@id='IN']");
	
	public By updateBtnDeliveryAddress=By.xpath("//*[@id='shipping']//*[contains(@onclick,'foodcourtUpdateAccount')]");
	public By instructionEnter=By.xpath("//*[@id='deliveryInstructionsText']");
	

	//------------------------------------------------------------------------------------------------------

	//public By _get=By.xpath("");
	public By userName_get=By.xpath("//*[@id='userName']");
	public By location_get=By.xpath("//*[@id='userLocation']");


	


	static SoftAssert softassert;
	public MyAccount(AppiumDriver<MobileElement> driver){
		this.driver= driver;	
	
	}

	

}

