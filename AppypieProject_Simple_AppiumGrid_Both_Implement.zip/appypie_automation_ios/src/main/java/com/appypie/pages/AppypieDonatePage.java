package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieDonatePage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;


	By donateUrls = By.xpath("//a[contains(@onclick,'Appyscript.commanPage')]");

	public AppypieDonatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isDonatePageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, donateUrls, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openDonateUrl() {
		WebElement url = ElementWait.waitForOptionalElement(driver, donateUrls, 10);
		if (url != null && url.isDisplayed()) {
			url.click();
		}
	}
}
