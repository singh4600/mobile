package com.appypie.pages.datingpages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MessagesPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By chatUser = By.xpath("//li[contains(@onclick,'Appyscript.datingChat')][@data-name='TestName']");
	By chatmsginput = By.id("messageInput");
	By chatSend = By.id("send");

	By receiver = By.xpath("//li[contains(@onclick,'Appyscript.datingChat')][contains(@onclick,'ChatUser')]");
	By msgCounter = By.xpath("//li[contains(@onclick,'Appyscript.datingChat')][contains(@onclick,'ChatUser')]//a[contains(@class,chat-icon)]//span[@class='count']");
    By message= By.xpath("//div[@id='appypie-chat']/div//div[@class='bubble']");
    By msgHeader = By.xpath("//div[@class='navbar']//div[text()='Messages']");
	public MessagesPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isMessagePageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, msgHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public boolean isUserPresent() {
		boolean present = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, chatUser, 10);
		if (user != null && user.isDisplayed()) {
			present = true;
		}
		return present;
	}

	public void openChatWindow(String type) {
		if (type.equals("sender"))
			driver.findElement(chatUser).click();
		else
			driver.findElement(receiver).click();
	}

	public boolean isChatPageOpen() {
		boolean open = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, chatSend, 10);
		if (user != null && user.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void typeMessage(String data) {
		PageElement.sendKey(driver, chatmsginput, data);
	}

	public void sendMessage() {
		PageElement.locateClickableElement(driver, chatSend);
	}

	public boolean isReceiverPresent() {
		boolean present = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, receiver, 10);
		if (user != null && user.isDisplayed()) {
			present = true;
		}
		return present;
	}

	public boolean isMessageCounterExist() {
		boolean counter = false;
		WebElement user = ElementWait.waitForOptionalElement(driver, msgCounter, 10);
		if (user != null && user.isDisplayed()) {
			counter = true;
		}
		return counter;
	}

	public String getMessage() {
		String text = "";
		List<WebElement> chatDetail = ElementWait.waitForAllOptionalElements(driver, message, 20);
		int size = chatDetail.size();
		if (size != 0) {
			text = chatDetail.get(size - 1).getText();
		}
		return text;
	}
}
