package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AddPropertyPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By apartmentlink= By.xpath("//*[@id='propertylistreal']/li[1]");
	public By nextBtn= By.xpath("//*[contains(@onclick,'Appyscript.realestateAddListingLocation')]");
	public By locationEnter= By.xpath("//*[contains(@id,'weatherGeocodeservicerealestatevalue')]");
	public By suggesstionlink= By.xpath("//*[contains(@id,'weatherListrealestate')]/li[1]");
	public By next1Btn= By.xpath("//*[contains(@onclick,'Appyscript.realestateAddListingDetails')]");
	public By sellProperty= By.xpath("//*[contains(@id,'sellproperty')]");
	public By rentoutproperty= By.xpath("//*[contains(@id,'rentproperty')]");
	public By Owner= By.xpath("//*[contains(@id,'ownr')]");
	public By builder= By.xpath("//*[contains(@id,'buldr')]");
	public By broker= By.xpath("//*[contains(@id,'delr')]");
	public By bedRooms= By.xpath("//*[contains(@class,'selecter bedrms')]/span[2]");
	public By bathrooms= By.xpath("//*[contains(@class,'selecter bathrms')]/span[2]");
	public By projectName= By.xpath("//*[contains(@id,'projectname')]");
	public By totalFloor= By.xpath("//*[contains(@id,'totalfloors')]");
	public By totalFloorNoNative= By.xpath("//*[@index='2']");
	public By i_totalFloorNoNative= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypePickerWheel/XCUIElementTypeAny[2]");
	
	public By propertyFloor= By.xpath("//*[@id='floors']");
	public By propertyFloorNoNative= By.xpath("//*[@index='2']");
	public By i_propertyFloorNoNative= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypePickerWheel/XCUIElementTypeAny[3]");
	public By phoneNo= By.xpath("//*[@id='phnnumber']");
	public By propertyArea= By.xpath("//*[@id='area']");
	public By sqmt= By.xpath("//*[@id='areaunit']");
	public By sqmtnative= By.xpath("//*[@index='1']");
	public By i_sqmtnative= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypePickerWheel/XCUIElementTypeAny[2]");
	public By reservedParking= By.xpath("//*[@id='parkingtype']");
	public By countparking= By.xpath("//*[@id='parking']");
	public By countparkingnONative= By.xpath("//*[@index='1']");
	public By i_countparkingnONative= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypePickerWheel/XCUIElementTypeAny[2]");
	public By next3= By.xpath("//*[contains(@onclick,'Appyscript.realestateAddListingMedia')]");
	public By expectedRent= By.xpath("//*[@id='rent']");
	public By deposit= By.xpath("//*[@id='deposit']");
	public By leaseDuration= By.xpath("//*[@id='leaseduratn']");
	public By leaseDurationtimeNative= By.xpath("//*[@index='1']");
	public By i_leaseDurationtimeNative= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypePickerWheel/XCUIElementTypeAny[2]");
	public By leaseDurationtext= By.xpath("//*[@id='month']");
	public By avaliability= By.xpath("//*[@id='availability']");
	public By avaliabilityNative= By.xpath("//*[@index='1']");
	public By i_avaliabilityNative= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypePickerWheel/XCUIElementTypeAny[2]");
	public By amenities= By.xpath("//*[@id='btnamenits']");
	public By amenitiesselectAll= By.xpath("//*[contains(@class,'checklist amenities-list')]/ul/li[1]");
	public By amenitiesdoneBtn= By.xpath("//*[contains(@onclick,'Appyscript.amenitiesDone')]");
	public By gallery= By.xpath("//*[contains(@class,'hyper-request-form')]/li[8]/div[1]/a[1]");
	public By video= By.xpath("//*[contains(@class,'hyper-request-form')]/li[8]/div[1]/a[2]");
	public By youtube= By.xpath("//*[contains(@class,'hyper-request-form')]/li[8]/div[1]/a[3]");
	public By uploadbtn= By.xpath("//*[contains(@id,'tab1')]//*[contains(@class,'foundadd')]//*[contains(@onclick,'addMoreClick3')]");
	public By gallerylink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[2]");
	public By cameralink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[1]");
	public By canclelink=By.xpath("//div[contains(@class,'modal-buttons modal-buttons-3 modal-buttons-vertical')]/span[3]");
	public By description= By.xpath("//*[contains(@id,'prprtydescrptn')]");
	public By doneBtn= By.xpath("//*[contains(@onclick,'Appyscript.realestateAddListingDone')]");
	
	public By editUpdateProperty= By.xpath("//*[contains(@class,'views')]/div[3]/div[2]/div[2]//li[1]//*[contains(@onclick,'Appyscript.realestateupdateListing')]");
	public By deleteUpdateProperty= By.xpath("//*[contains(@class,'views')]/div[3]/div[2]/div[2]//li[1]//*[contains(@onclick,'deleteproperty')]");
	public By yes= By.xpath("//*[contains(@class,'modal-buttons modal-buttons-2 ')]/span[1]");
	public By no= By.xpath("//*[contains(@class,'modal-buttons modal-buttons-2 ')]/span[2]");

	//*[contains(@class,'filter-page sell-Pro')]/div[1]/a[1]
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By addPropertyList_gettext=By.xpath("//*[@id='propertylistreal']/li");
	public By amenitieslist_gettext=By.xpath("//*[contains(@class,'checklist amenities-list')]/ul/li");



	public AddPropertyPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}