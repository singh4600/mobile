package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MenuPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By homelink= By.xpath("//*[contains(text(),' Home')]");
	public By mainMenulink= By.xpath("//*[contains(text(),'Main Menu')]");
	public By myBoookinglink= By.xpath("//*[contains(text(),' My Bookings')]");
	public By myFavoriteslink= By.xpath("//*[contains(text(),' My Favorites')]");
	public By offerslink= By.xpath("//*[contains(text(),'Offers')]");
	public By termsConditionslink= By.xpath("//*[contains(text(),'Terms & Conditions')]");
	public By privacypolicylink= By.xpath("//*[contains(text(),'Privacy Policy')]");
	
	
	
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By menuList_gettext=By.xpath("//*[contains(@class,'leftMenu')]/li");


	public MenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}