package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ShortByPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By cancellink= By.xpath("//*[contains(@class,'close  link close-popup')]");
	public By resetlink= By.xpath("//*[contains(@onclick,'Appyscript.hotelresetparamsearch')]");
	public By price_hightTolowlink= By.xpath("//*[contains(text(),' Price -- High to Low  ')]");
	public By price_lowTohighlink= By.xpath("//*[contains(text(),'Price -- Low to High  ')]");
	public By popularitylink= By.xpath("//*[contains(text(),' Popularity  ')]");
	public By offerlink= By.xpath("//*[contains(text(),'  Offers ')]");
	
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By sortBy_list_gettext=By.xpath("//*[contains(@class,'short-by-key')]/li");

	public ShortByPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}