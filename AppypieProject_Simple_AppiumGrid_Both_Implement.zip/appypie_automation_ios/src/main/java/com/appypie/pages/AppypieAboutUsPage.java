package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieAboutUsPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By aboutUsHeader = By.xpath("//div[@class='navbar']//div[text()='About Us']");
	By linkedIn = By.xpath("//a[contains(@onclick,'openWebViewAboutNative')]");
	By description = By.xpath("//div[@class='description']/p");
	By designation = By.xpath("//ul[@class='founderList']/li/h3");
	By founded = By.xpath("//span[@class='foundedicon']");
	By mission = By.xpath("//i[@class='iconz-target']/..");
	By vision = By.xpath("//i[@class='icon-compass']/..");
	By award = By.xpath("//i[@class='icon-award-2']/..");
	By deepLink = By.xpath("//a[contains(@href,'javascript:opendeeplinkpage')]");

	By skype = By.xpath("//a[contains(@onclick,'openSkypeAboutNative')]");
	By mail = By.xpath("//a[contains(@onclick,'openSendMailAboutNative')]");
	By call = By.xpath("//a[contains(@onclick,'openCallAboutNative')]");

	By nativeOptions = By.className("android.widget.FrameLayout");

	public AppypieAboutUsPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isAboutUsPageOpen() {
		boolean open = false;
		WebElement page = ElementWait.waitForOptionalElement(driver, aboutUsHeader, 20);
		if (page != null && page.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openOptionsOnPage(String option) {
		WebElement link = null;
		if (option.equals("linkedin")) {
			link = ElementWait.waitForOptionalElement(driver, linkedIn, 10);
		} else if (option.equals("call"))
			link = ElementWait.waitForOptionalElement(driver, call, 10);
		else if (option.equals("skype"))
			link = ElementWait.waitForOptionalElement(driver, skype, 10);
		else if (option.equals("mail"))
			link = ElementWait.waitForOptionalElement(driver, mail, 10);
		else if (option.equals("deeplink"))
			link = ElementWait.waitForOptionalElement(driver, deepLink, 10);
		if (link != null && link.isDisplayed()) {
			link.click();
		}
	}

	public boolean isFeatureOpenInNative(String type) throws InterruptedException {
		boolean open = false;
		driver.context("NATIVE_APP");
		Thread.sleep(1000);
		WebElement dialer = ElementWait.waitForOptionalElement(driver, nativeOptions, 20);
		if (dialer != null && dialer.isDisplayed()) {
			open = true;
			if (type.equals("mail")) {
				try {
					driver.hideKeyboard();
					Thread.sleep(1000);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			driver.navigate().back();
			Thread.sleep(1000);
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}

	public String getPageText(String section) {
		String text = null;
		WebElement content = null;
		if (section.equals("description"))
			content = ElementWait.waitForOptionalElement(driver, description, 10);
		else if (section.equals("designation"))
			content = ElementWait.waitForOptionalElement(driver, designation, 10);
		else if (section.equals("founded"))
			content = ElementWait.waitForOptionalElement(driver, founded, 10);
		else if (section.equals("mission"))
			content = ElementWait.waitForOptionalElement(driver, mission, 10);
		else if (section.equals("vision"))
			content = ElementWait.waitForOptionalElement(driver, vision, 10);
		else
			content = ElementWait.waitForOptionalElement(driver, award, 10);

		if (content != null && content.isDisplayed()) {
			text = content.getText();
		}
		return text;
	}

}
