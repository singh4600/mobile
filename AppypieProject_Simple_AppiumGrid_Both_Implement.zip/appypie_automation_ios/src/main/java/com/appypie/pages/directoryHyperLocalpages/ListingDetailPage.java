package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ListingDetailPage extends TestSetup{
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By bookmark = By.xpath("//a[contains(@id,'bookmark')]");
	By bookmarkStatus = By.xpath("//a[contains(@id,'bookmark')]/i");
	By mapOnListing = By.id("googleMap2907484");
	By submitEnquiry = By.xpath("//div[@data-id='2907484']//button[contains(@onclick,'Appyscript.openRequestFormAndFormBuilder')]");
	By claim = By.xpath("//div[@data-id='2907484']//button[contains(@onclick,'Appyscript.openRequestFormAndFormBuilder')]");
	
	By locationpopUp= By.xpath("//div[@class='innerlist']//a[contains(@onclick,'openpopupmap')][@headersinglemap='alpha 123']");
	
	By reviewOnList=By.xpath("//div[contains(@onclick,'Appyscript.directoryReviewRatingData')][@headervalreview='alpha 123']");
	By textOnList=By.xpath("//div[contains(@onclick,'Appyscript.checksinHeaderForWebView')][@header='alpha 123']");
	By textOnList1=By.xpath("//div[1]/ul[3]/li[2]/div/a");
	
	By callOnList=By.xpath("//div[@data-header='alpha']//div[contains(@onclick,'Appyscript.dialogListForCall')]");
	By mailOnList=By.xpath("//div[@data-header='alpha']//div[contains(@onclick,'Appyscript.sendMail')]");
	
	// ********* Locators for hyperlocal*********************
	By hl_mapOnListing = By.id("googleMaphyperLocal5937a19bbc1f4659b98b4567");
	By hl_submitEnquiry = By.xpath("//button[contains(@onclick,'Appyscript.sendRequestPageCall')]");
	By hl_youtube = By.xpath("//div[@class='swiper-slide swiper-slide-active']//img[contains(@onclick,'http://www.youtube.com')]");
	By title = By.id("text_Tittle");
	
	By hl_visit= By.xpath("//a[contains(@onclick,'Appyscript.openWebView')]");
	By hl_call= By.xpath("//a[contains(@onclick,'Appyscript.MakeCall')]");
	By hl_mail= By.xpath("//a[contains(@onclick,'contactUsListEvents')]");
	By hl_loc= By.xpath("//ul[@class='detailInfolist']//div[@class='innerlist']//a[contains(@onclick,'Appyscript.singlemap')]");
	
	By nativeCall= By.id("message");

	public ListingDetailPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isListingDetailPageOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement listPage = ElementWait.waitForOptionalElement(driver, bookmark, 20);
		if (listPage != null && listPage.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Directory listing page is not open upon clicking on listing");
		}
		return open;
	}          
     
	public void bookMarkList() {
		WebElement mark = ElementWait.waitForOptionalElement(driver, bookmarkStatus, 20);
		if (mark != null && mark.isDisplayed()) {
			String text = mark.getAttribute("class");
			if (text.equals("icon-bookmark-empty")) {
				mark.click();
			} else {
				Logger.info("listing is already bookmarked");
			}
		}
	}

	public void clickSendEnquiry(String page) {
		if (page.equals("dir"))
			driver.findElement(submitEnquiry).click();
		else
			driver.findElement(hl_submitEnquiry).click();
	}

	public boolean isSwiperWorking() {
		boolean exist = false;
		WebElement swiper = ElementWait.waitForOptionalElement(driver, hl_youtube, 10);
		if (swiper != null && swiper.isDisplayed()) {
			exist = true;
		}
		return exist;
	}

	public void clickYoutube() {
		driver.findElement(hl_youtube).click();
	}
	
	public void openLocationPopup(){
		WebElement loc= ElementWait.waitForOptionalElement(driver, locationpopUp, 5);{
			if(loc!=null && loc.isDisplayed()){
				loc.click();
			}
		}
	}
	
	public void openListOptions(String option) {
		WebElement element = null;
		if (option.equals("review"))
			element = ElementWait.waitForOptionalElement(driver, reviewOnList, 5);
		else if (option.equals("text"))
			if (!globledeviceName.equals("iPhone")) {
				element = ElementWait.waitForOptionalElement(driver, textOnList, 5);
			}
			else {
				element = ElementWait.waitForOptionalElement(driver, textOnList1, 5);
			}
		else if (option.equals("call"))
			element = ElementWait.waitForOptionalElement(driver, callOnList, 5);
		else
			element = ElementWait.waitForOptionalElement(driver, mailOnList, 5);
		if (element != null) {
			element.click();
		}
	}
	
	public void openHyperLocalJobOptions(String option) {
		WebElement element = null;
		if (option.equals("visit"))
			element = ElementWait.waitForOptionalElement(driver, hl_visit, 5);
		else if (option.equals("call"))
			element = ElementWait.waitForOptionalElement(driver, hl_call, 5);
		else if (option.equals("mail"))
			element = ElementWait.waitForOptionalElement(driver, hl_mail, 5);
		else
			element = ElementWait.waitForOptionalElement(driver, hl_loc, 5);
		if (element != null) {
			element.click();
		}
	}
	
	public boolean isCallfeatureWorkingOnHyperlocalJobListDetail() throws InterruptedException {
		boolean exist = false;
		driver.context("NATIVE_APP");
		Thread.sleep(2000);
		WebElement call = ElementWait.waitForOptionalElement(driver, nativeCall, 20);
		if (call != null && call.isDisplayed()) {
			exist = true;
			driver.navigate().back();
		}
		PageElement.changeContextToWebView(driver);
		return exist;
	}

	public boolean isYouTubeOpen(String i_text) throws InterruptedException {
		boolean open = false;
		WebElement header=null;
		driver.context("NATIVE_APP");
		Thread.sleep(2000);
		if(!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())){
	    header = ElementWait.waitForOptionalElement(driver, title, 20);
		if (header != null && header.isDisplayed()) {
			open = true;
			Thread.sleep(1000);
			driver.navigate().back();
		}
		}else{
			By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='" + i_text + "']");
			header = ElementWait.waitForOptionalElement(driver, i_nativeView, 30);
			if (header != null) {
				open = true;
				Thread.sleep(3000);
				PageElement.tapOnScreen(driver, 0.05, 0.05);
			} else {
				Logger.info("Youtube is not open in ios native");
			}
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}

	@Override
	public void pageSetUp() {
		// TODO Auto-generated method stub
		
	}
}
