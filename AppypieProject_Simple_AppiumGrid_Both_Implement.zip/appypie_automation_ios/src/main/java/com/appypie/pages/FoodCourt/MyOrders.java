package com.appypie.pages.FoodCourt;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class MyOrders {

	private static final Logger Logger= Log.createLogger();
	protected AppiumDriver<MobileElement> driver;



	//public By =By.xpath("");

	public By foodpandaPending=By.xpath("//*[contains(@class,'view view-main')]/div[2]/div[2]/div[1]/div[2]/div[1]");
	public By contactSuppot=By.xpath("//*[contains(@onclick,'Appyscript.call')]");
	public By contactSuppotP=By.xpath("//*[contains(@onclick,'Appyscript.getcontactsupport')]");

	//------------------------------------------------------------------------------------------------------

	//public By _get=By.xpath("");
	public By pendingStatus_get=By.xpath("//*[@id='pendingHeading']");
	public By completedStatus_get=By.xpath("//*[@id='completedHeading']");
	public By myOrderList_get=By.xpath("//*[contains(@class,'order-List')]/div[1]");
	public By time_get=By.xpath("//*[contains(@class,'innerbottomPan arial mediumContent')]");
	public By estimatedDeliveryTime_get=By.xpath("//*[contains(@class,'innerbottomPan arial mediumContent')]/p");

	


	static SoftAssert softassert;
	public MyOrders(AppiumDriver<MobileElement> driver){
		this.driver= driver;	
	
	}

	

}

