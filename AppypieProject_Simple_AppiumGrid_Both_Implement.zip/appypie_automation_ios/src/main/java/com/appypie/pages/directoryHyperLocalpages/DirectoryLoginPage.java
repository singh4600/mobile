package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DirectoryLoginPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By loginBtn = By.xpath("//a[text()='Login']");
	By pwd = By.xpath("//*[@id='loginpass']");
	By emailId = By.xpath("//*[@id='loginid']");
	
	By loginBtnN = By.xpath("//a[text()='Login']");
	By pwdN = By.xpath("//*[@id='loginpass']");
	By emailIdN = By.xpath("//*[@id='loginid']");

	public DirectoryLoginPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isDirectoryLoginOpen() throws InterruptedException {
		boolean open = false;
		Thread.sleep(1000);
		WebElement login = ElementWait.waitForOptionalElement(driver, emailId, 20);
		if (login != null) {
			open = true;
		}
		return open;
	}

	public void loginDirectory(String email, String password) {
		driver.findElement(emailId).sendKeys(email);
		driver.findElement(pwd).sendKeys(password);
		PageElement.locateClickableElement(driver, loginBtn);
		
		
		
	}

	public boolean isLoginSuccess() {
		return new HomePage(driver).isHomePageOpen();
	}
}
