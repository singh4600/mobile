package com.appypie.pages.directoryHyperLocalpages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AddListingPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By addList_category = By.xpath("//select[@id='dir_catid']");
	By addList_subcategory = By.xpath("//select[@id='dir_Subcatid']");
	By addList_heading = By.xpath("//input[@id='hedingSL']");
	By addList_summary = By.xpath("//textarea[@id='summarySL']");
	By addList_body = By.xpath("//textarea[@id='bodySL']");

	By addList_img = By.xpath("//a[@href='#tab1']");
	By addImg = By.xpath("//span[contains(@onclick,'addMoreClick2')]");
	By uploadImgpopup = By.xpath("//span[contains(@class,'modal-button')][text()='Upload from Gallery']");
	By canceluploadImgpopup = By.xpath("//span[contains(@class,'modal-button')][text()='Cancel']");

	By addList_youtube = By.xpath("//a[@href='#tab2']");
	By youTubeurl = By.xpath("//input[@id='youtubeUrl']");

	By addList_audio = By.xpath("//a[@href='#tab3']");
	By mediaRss = By.xpath("//a[@id='soundrss']");
	By mediaRssUrlHolder = By.id("soundrssData");
	By radioPls = By.xpath("//a[@id='rssradio']");
	By radioPlsUrlHolder = By.xpath("//input[@id='rssradioData']");
	By customAudio = By.xpath("//a[@id='customlist']");
	By customTrackNameHolder = By.xpath("//input[@id='customTrackNameData']");
	By customTrackDescriptionHolder = By.xpath("//input[@id='customTrackDescriptionData']");
	By customUrlHolder = By.xpath("//input[@id='customlistData']");

	By addList_pdf = By.xpath("//a[@href='#tab4']");
	By pdfNameHolder = By.xpath("//input[@id='pdfName0']");
	By pdfUrlHolder = By.xpath("//input[@id='pdfUrl0']");
	By addMorePdf = By.id("addDataPdf");
	By secondpdfNameHolder = By.xpath("//input[@id='pdfName1']");
	By secondpdfUrlHolder = By.xpath("//input[@id='pdfUrl1']");
	By closeMorePdf = By.xpath("//a[@id='deletePdf1']");

	By addList_url = By.xpath("//input[contains(@id,'urlData')]");
	By addList_addMoreUrl = By.id("addDataUrl");
	By addList_secondUrl = By.xpath("//input[@type='text'][@id='urlData1']");
	By addList_closeSecondUrl = By.xpath("//li[@id='urlliId1']/a[2]");

	By addList_email = By.xpath("//input[contains(@id,'emailData')]");
	By addList_addMoreemail = By.id("addDataEmail");
	By addList_secondemail = By.xpath("//input[@type='text'][@id='emailData1']"); 
	By addList_closeSecondemail = By.xpath("//a[@id='deleteEmail1']");

	By addList_phone = By.xpath("//input[contains(@id,'callData')]");
	By addList_addMorePhone = By.id("addDataCall");
	By addList_secondPhone = By.xpath("//input[@id='callData1']");
	By addList_closeSecondPhone = By.xpath("//a[@id='deletecall1']");

	By addList_Location = By.xpath("//a[@id='addSL']");
	By addList_MapCheckBox = By.id("chkSL");
	By addListBtn = By.xpath("//button[contains(@onclick,'addListingClick')]");

	public AddListingPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isAddListingPageOpen() {
		boolean open = false;
		WebElement cat= ElementWait.waitForOptionalElement(driver, addList_img, 20);
		if (cat!=null && cat.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Add Listing page is not open from directory main menu");
		}
		return open;
	}

	public boolean imageUploadinAddListing() throws InterruptedException {
		boolean open = false;
		WebElement img = ElementWait.waitForOptionalElement(driver, addList_img, 20);
		if (img != null && img.isDisplayed()) {
			img.click();
			WebElement imgUpload = ElementWait.waitForOptionalElement(driver, addImg, 20);
			if (imgUpload != null && imgUpload.isDisplayed()) {
				imgUpload.click();
				if (PageElement.getWarningTitle(driver).get(0).equals("Click here to upload image(s)")) {
					Logger.info("Image upload pop appears");
					open = true;
					PageElement.locateClickableElement(driver, canceluploadImgpopup);
					Thread.sleep(1000);
				}
			} else {
				Logger.error("Plus sign for image upload is not visible on add listing form");
			}
		} else {
			Logger.error("Upload image field is not visible on add listing form");
		}
		return open;
	}

	public boolean isYoutubeVideoUploadWorking() {
		boolean exist=false;
		WebElement video = ElementWait.waitForOptionalElement(driver, addList_youtube, 20);
		if (video != null && video.isDisplayed()) {
			video.click();
			WebElement uploadVideoUrl = ElementWait.waitForOptionalElement(driver, youTubeurl, 5);
			String text = uploadVideoUrl.getAttribute("placeholder");
			if (text.equals("Enter YouTube URL")) {
				exist=true;
			} else {
				Logger.error("Upload youtube url text field is not visible on add listing form");
			}
		} else {
			Logger.error("Upload youtube video field is not visible on add listing form");
		}
		return exist;
	}
	
	public void uploadYoutubeVideoinAddListing(String url){
		driver.findElement(youTubeurl).sendKeys(url);
	}

	public void clickAudioinListing() {
		WebElement audio = ElementWait.waitForOptionalElement(driver, addList_audio, 10);
		if (audio != null && audio.isDisplayed()) {
			audio.click();
		} else {
			Logger.error("Upload youtube video field is not visible on add listing form");
		}
	}

	public void clickMediaRssinListing() {
		WebElement rss = ElementWait.waitForOptionalElement(driver, mediaRss, 5);
		if (rss != null && rss.isDisplayed()) {
			rss.click();
		} else {
			Logger.error("MediaRSS field is not visible on add listing form");
		}
	}

	public boolean isMediaRssUrlHolderFieldExist() {
		boolean exist = false;
		WebElement rss_url = ElementWait.waitForOptionalElement(driver, mediaRssUrlHolder, 5);
		if (rss_url != null && rss_url.isDisplayed()) {
			String text = rss_url.getAttribute("placeholder");
			if (text.equals("Enter Media RSS URL"))
				exist = true;
		} else {
			Logger.error("MediaRSS url holder field is not visible upon clicking on mediaRSS audio");
		}
		return exist;
	}

	public void uploadMediaRSSUrlinAddListing(String url) {
		driver.findElement(mediaRssUrlHolder).sendKeys(url);

	}

	public void clickRadioPlsinListing() {
		WebElement radio = ElementWait.waitForOptionalElement(driver, radioPls, 5);
		if (radio != null && radio.isDisplayed()) {
			radio.click();
		} else {
			Logger.error("RadioPls audio field is not visible on add listing form");
		}
	}

	public boolean isRadioPlsUrlHolderFieldExist() {
		boolean exist = false;
		WebElement radio_url = ElementWait.waitForOptionalElement(driver, radioPlsUrlHolder, 5);
		if (radio_url != null && radio_url.isDisplayed()) {
			String text = radio_url.getAttribute("placeholder");
			if (text.equals("Enter Radio PLS URL"))
				exist = true;
		} else {
			Logger.error("RadioPls url holder field is not visible upon clicking on RadioPls audio");
		}
		return exist;
	}

	public void uploadRadioUrlinAddListing(String url) {
		driver.findElement(radioPlsUrlHolder).sendKeys(url);

	}

	public void clickcustomAudioinListing() {
		WebElement radio = ElementWait.waitForOptionalElement(driver, customAudio, 5);
		if (radio != null && radio.isDisplayed()) {
			radio.click();
		} else {
			Logger.error("Custom audio field is not visible on add listing form");
		}
	}

	public boolean isCustomUrlHolderFieldsExist() {
		boolean exist = false;
		String trackname = ElementWait.waitForOptionalElement(driver, customTrackNameHolder, 5)
				.getAttribute("placeholder");
		String trackdescription = ElementWait.waitForOptionalElement(driver, customTrackDescriptionHolder, 5)
				.getAttribute("placeholder");
		String trackurl = ElementWait.waitForOptionalElement(driver, customUrlHolder, 5).getAttribute("placeholder");
		if (trackname.equals("Track Name") && trackdescription.equals("Track Description")
				&& trackurl.equals("Enter Custom URL")) {
			exist = true;
		} else {
			Logger.error("Custom url holder fields is not visible upon clicking on Custom audio");
		}
		return exist;
	}

	public void uploadCustomUrlinAddListing(String name, String description, String url) {
		driver.findElement(customTrackNameHolder).sendKeys(name);
		driver.findElement(customTrackDescriptionHolder).sendKeys(description);
		driver.findElement(customUrlHolder).sendKeys(url);
	}

	public void clickUploadPdfinListing() {
		WebElement pdf = ElementWait.waitForOptionalElement(driver, addList_pdf, 5);
		if (pdf != null && pdf.isDisplayed()) {
			pdf.click();
		} else {
			Logger.error("Upload PDF filed field is not visible on add listing form");
		}
	}

	public boolean isPDFHolderFieldsExist() {
		boolean exist = false;
		WebElement pdfurl = ElementWait.waitForOptionalElement(driver, pdfUrlHolder, 5);
		WebElement pdfName = ElementWait.waitForOptionalElement(driver, pdfNameHolder, 5);
		if ((pdfurl != null && pdfurl.isDisplayed()) && (pdfName != null && pdfName.isDisplayed())) {
			exist = true;
		} else {
			Logger.error("PDf url holder fields is not visible upon clicking on PDF upload in add listing");
		}
		return exist;
	}

	public void clickAddMoreInPdf() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, addMorePdf, 5).click();
	}

	public boolean isSecondpdfHolderFieldExist() {
		boolean exist = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, secondpdfNameHolder, 5);
		WebElement pdfName = ElementWait.waitForOptionalElement(driver, secondpdfUrlHolder, 5);
		if ((url != null && url.isDisplayed()) && (pdfName != null && pdfName.isDisplayed())) {
			exist = true;
		}
		return exist;
	}

	public void clickCloseAddMoreInPdf() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, closeMorePdf, 5).click();
	}
	
	public void clickAddMoreInUrl() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, addList_addMoreUrl, 5).click();
	}

	public List<Object> isSecondUrlFieldExist() {
		boolean exist = false;
		String placeholder="";
		List<Object> list= new ArrayList<Object>();
		WebElement url = ElementWait.waitForOptionalElement(driver, addList_secondUrl, 5);
		if(url != null && url.isDisplayed()) {
			exist = true;
			placeholder=url.getAttribute("placeholder");
		}
		list.add(exist);
		list.add(placeholder);
		return list;
	}

	public void clickCloseAddMoreInUrl() throws NullPointerException, InterruptedException {
		
		ElementWait.waitForOptionalElement(driver, addList_closeSecondUrl, 20).click();
	}
	
	public void clickAddMoreInEmail() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, addList_addMoreemail, 5).click();
	}

	public List<Object> isSecondEmailFieldExist() {
		boolean exist = false;
		String placeholder="";
		List<Object> list= new ArrayList<Object>();
		WebElement url = ElementWait.waitForOptionalElement(driver, addList_secondemail, 5);
		if(url != null && url.isDisplayed()) {
			exist = true;
			placeholder=url.getAttribute("placeholder");
		}
		list.add(exist);
		list.add(placeholder);
		return list;
	}

	public void clickCloseAddMoreInEmail() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, addList_closeSecondemail, 5).click();
	}
	
	public void clickAddMoreInPhoneNo() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, addList_addMorePhone, 5).click();
	}

	public List<Object> isSecondPhoneNoFieldExist() {
		boolean exist = false;
		String placeholder="";
		List<Object> list= new ArrayList<Object>();
		WebElement url = ElementWait.waitForOptionalElement(driver, addList_secondPhone, 5);
		if(url != null && url.isDisplayed()) {
			exist = true;
			placeholder=url.getAttribute("placeholder");
		}
		list.add(exist);
		list.add(placeholder);
		return list;
	}

	public void clickCloseAddMoreInPhoneno() throws NullPointerException {
		ElementWait.waitForOptionalElement(driver, addList_closeSecondPhone, 5).click();
	}

	public void selectCategory() {
		PageElement.selectByValue(driver, addList_category, "alpha directory 789");
	}
	public void selectSubCategory() {
		try {
			WebElement item = ElementWait.waitForOptionalElement(driver, addList_subcategory,5);
			if (item != null) {
				Select element = new Select(item);
				element.selectByIndex(1);
			}
		} catch (Exception e) {
			Logger.error(" Exception occurs while searching the Drop down Value: " + e.getMessage(), e);
			throw (e);
		}
		
	}
	
	public void submitaddListForm(){
		driver.findElement(addListBtn).click();
	}
	
	public void fillFormforAddCategory() throws InterruptedException{
		selectCategory();
		Thread.sleep(3000);
		selectSubCategory();
		PageElement.sendKey(driver, addList_heading, "AutomationTest");
		PageElement.sendKey(driver, addList_summary, "Add listing in category");
		PageElement.sendKey(driver, addList_body, "New category is added in alpha directory 789 for testing purpose");
		clickAudioinListing();
	}
	
	public int getElementCount(String element) throws InterruptedException {
		Thread.sleep(1000);
		List<MobileElement> list;
		if (element.equals("url"))
			list = ElementWait.getAllElement(driver, addList_url);
		else if (element.equals("email"))
			list =ElementWait.getAllElement(driver, addList_email);
		else
			list= ElementWait.getAllElement(driver, addList_phone);
		return list.size();
	}
	
	
	//****************PRINCE(S)***************
		public void scrollDown() {
			driver.context("NATIVE_APP");
			try {
				TimeUnit.SECONDS.sleep(3);
				Dimension dimens = driver.manage().window().getSize();
				System.out.println(dimens);
				int x = (int) (dimens.getWidth() * 0.5);
				System.out.println(x);
				int startY = (int) (dimens.getHeight() * 0.5);
				System.out.println(startY);
				int endY = (int) (dimens.getHeight() * 0.2);
				System.out.println(endY);
				driver.swipe(x, startY, x, endY, 800);
			} catch (InterruptedException e) {
				System.out.println("scroller not working");
				e.printStackTrace();
				e.getMessage();
			}
			
			PageElement.changeContextToWebView(driver);
			}
		
		//****************PRINCE(E)***************	
	
	
}
