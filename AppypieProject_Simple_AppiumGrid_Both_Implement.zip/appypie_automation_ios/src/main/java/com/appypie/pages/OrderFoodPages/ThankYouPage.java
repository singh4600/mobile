package com.appypie.pages.OrderFoodPages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
public class ThankYouPage {
	PageElement pageutil;

	protected AppiumDriver<MobileElement> driver;
	private static final Logger Logger= Log.createLogger();
	static String Actual;
	static String runningTest1="error geting";
	SoftAssert s_assert = new SoftAssert();
	//--------click Event-----------------------------------
	//public By =By.xpath("");
	public By continueOrderingBtn=By.xpath("//*[contains(@onclick,'foodClearHistryHomePage')]");


	//---------Get Text Event------------------------------------------------------
	//public By _gettext=By.xpath("");
	public By heading_gettext=By.xpath("//*[contains(@class,'thankyou')]/h1");
	public By message_gettext=By.xpath("//*[contains(@class,'thankyou')]/p[1]");
	public By orderTime_gettext=By.xpath("//*[contains(@class,'thankyou')]/p[2]");
	


	
	//-------------------------------------------------------------------------------
	public ThankYouPage(AppiumDriver<MobileElement> driver){
		this.driver= driver;
		pageutil=new PageElement();
	}
	


}
