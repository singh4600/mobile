package com.appypie.pages.Hotels;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class RatingAndReviewPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By rating_1_Starlink= By.xpath("//*[contains(@class,'ratingList')]/li[1]//*[contains(@class,'pull-left')]/span[1]");
	public By rating_2_Starlink= By.xpath("//*[contains(@class,'ratingList')]/li[1]//*[contains(@class,'pull-left')]/span[2]");
	public By rating_3_Starlink= By.xpath("//*[contains(@class,'ratingList')]/li[1]//*[contains(@class,'pull-left')]/span[3]");
	public By rating_4_Starlink= By.xpath("//*[contains(@class,'ratingList')]/li[1]//*[contains(@class,'pull-left')]/span[4]");
	public By rating_5_Starlink= By.xpath("//*[contains(@class,'ratingList')]/li[1]//*[contains(@class,'pull-left')]/span[5]");
	public By reviewText= By.xpath("//*[contains(@class,'ratingList')]/li[2]//*[contains(@id,'rnrTextArea')]");
	public By submitBtn= By.xpath("//*[contains(@onclick,'Appyscript.hotelsubmitReviewAndRating')]");
	
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");


	
	
	//*[@id="59954e03bc1f4674d0f8cafe"]/text()
	

	public RatingAndReviewPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}