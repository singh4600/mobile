package com.appypie.pages.directoryHyperLocalpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DirectoryMainMenuPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By home = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.clickHome')]");
	By mainMenu = By.xpath("//ul[@class='leftMenu']//a[contains(text(),'Main Menu')]");
	By addListing = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.addListingData')]");
	By updateListing = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.updateListingList')]");
	By bookMark = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.showBookmarks()')]");
	By directoryLogin = By.xpath("//ul[@class='leftMenu']//a[@id='loginLogout']");
	By editProfile = By.xpath("//a[contains(@onclick,'Appyscript.serviceEditProfile')]");
	By editProfilefromImg = By.xpath("//span[@class='image']//img[contains(@onclick,'Appyscript.serviceEditProfile')]");

	By search = By.xpath("//input[contains(@id,'searchmenu')]");
	By search1 = By.xpath("//input[contains(@id,'textSearch')]");
	By closeSearchMenu = By.xpath("//div[@class='searchBxContainer']//a[contains(@class,'close icon-cancel')]");

	// ********* Locators for hyperlocal*********************

	By hl_maincat = By.xpath("//ul[@class='leftMenu']//a[contains(text(),' Main Category')]");
	By postJob = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.addListingDataPostJob')]");
	By updateJob = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.updateHyperlocalListingList')]");
	By hl_bookMark = By.xpath("//ul[@class='leftMenu']//a[contains(@onclick,'Appyscript.showHyperLocalBookmarks')]");

	
	public DirectoryMainMenuPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isMainMenuOpen(String page) throws InterruptedException {
		boolean open = false;
		WebElement menupage = null;
		Thread.sleep(1000);
		if (page.equals("directory")) {
			menupage = ElementWait.waitForOptionalElement(driver, bookMark, 20);
		} else {
			menupage = ElementWait.waitForOptionalElement(driver, hl_bookMark, 20);
		}
		if (menupage != null && menupage.isDisplayed()) {
			open = true;
		} else {
			Logger.info("Directory Menu is not open upon clicking menu icon on directory home page");
		}
		return open;
	}

	public void clickHome() {
		ElementWait.waitForOptionalElement(driver, home, 5).click();
	}

	public void clickMainMenu() {
		ElementWait.waitForOptionalElement(driver, mainMenu, 5).click();
	}

	public void clickAddListing() {
		ElementWait.waitForOptionalElement(driver, addListing, 5).click();
	}

	public void clickUpdateListing() {
		ElementWait.waitForOptionalElement(driver, updateListing, 10).click();
	}

	public void clickBookmark(String page) {
		if (page.contains("dir"))
			ElementWait.waitForOptionalElement(driver, bookMark, 5).click();
		else
			ElementWait.waitForOptionalElement(driver, hl_bookMark, 5).click();
	}

	public void clickDirectoryLogin() {
		ElementWait.waitForOptionalElement(driver, directoryLogin, 5).click();
	}

	public void clickUpdateProfile() {
		ElementWait.waitForOptionalElement(driver, editProfile, 5).click();
	}

	public void clickUpdateImage() throws InterruptedException {
		Thread.sleep(1000);
		ElementWait.waitForOptionalElement(driver, editProfilefromImg, 5).click();
	}

	public boolean isDirectoryLogin() {
		boolean login = false;
		String text = ElementWait.waitForOptionalElement(driver, directoryLogin, 5).getText();
		if (text.toUpperCase().contains("Logout".toUpperCase())) {
			login = true;
		}
		return login;
	}

	public void typeSearchData(String data) {
		PageElement.sendKey(driver, search1, data);
	}

	public void typeSearchDataDirectory(String data) {
		PageElement.sendKey(driver, search, data);
	}
	
	public void closeMainMenu() {
		WebElement close = ElementWait.waitForOptionalElement(driver, closeSearchMenu, 10);
		if (close != null && close.isDisplayed()) {
			close.click();
		} else {
			Logger.info("close button is not visible on Directory main menu");
		}
	}

	public void clickMainCategory() {
		ElementWait.waitForOptionalElement(driver, hl_maincat, 5).click();
	}

	public void clickupdateJob() {
		ElementWait.waitForOptionalElement(driver, updateJob, 5).click();
	}

	public void clickPostJob() {
		ElementWait.waitForOptionalElement(driver, postJob, 5).click();
	}

}
