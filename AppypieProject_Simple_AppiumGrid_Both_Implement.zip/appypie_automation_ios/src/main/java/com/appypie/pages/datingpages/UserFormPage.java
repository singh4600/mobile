package com.appypie.pages.datingpages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.LoginUtil;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;

public class UserFormPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By maleUser = By.id("male");
	By femaleUser = By.id("female");
	By dob = By.id("dob");
	By about = By.id("goal");
	By title = By.id("jobtitle");
	By maleSelect = By.xpath("//div[@id='mymale']//input[@value='male']");
	By km = By.id("datingkm");
	By mile = By.id("datingmi");
	By userage = By.id("rangeValue3");
	By userdistance = By.id("rangeValue2");
	By save = By.xpath("//button[contains(@onclick,'Appyscript.saveusersetting')]");
	By tc = By.xpath("//a[contains(@onclick,'Appyscript.eulaaccept')]");
	By next = By.xpath("//button[contains(@onclick,'Appyscript.datingNextFind')]");

	By ageSlider = By.xpath("//android.view.View[@resource-id='datingYearGet']");
	By distanceSlider = By.xpath("//android.view.View[@resource-id='datingDistanceGet']");

	public UserFormPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public boolean isRegistrationFormOpen() {
		boolean open = false;
		WebElement register = ElementWait.waitForOptionalElement(driver, maleUser, 20);
		if (register != null && register.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void enterdob(String data) {
		PageElement.sendKey(driver, dob, data);
	}

	public void identifyUser(String type) {
		if (type.equals("male"))
			PageElement.locateClickableElement(driver, maleUser);
		else
			PageElement.locateClickableElement(driver, femaleUser);
	}

	public void enterAboutMe(String data) {
		PageElement.sendKey(driver, about, data);
	}

	public void enterTitle(String data) {
		PageElement.sendKey(driver, title, data);
	}

	public void selectPartnerSex(String type) {
		PageElement.locateClickableElement(driver, maleSelect);
	}

	public void saveUserDetail() {
		PageElement.locateClickableElement(driver, save);
	}

	public void clickAcceptContinue() {
		WebElement accept = ElementWait.waitForOptionalElement(driver, tc, 10);
		if (accept != null && accept.isDisplayed()) {
			accept.click();
		}
	}

	public void clickNextOnProfileUpload() {
		WebElement submit = ElementWait.waitForOptionalElement(driver, next, 10);
		if (submit != null && submit.isDisplayed()) {
			submit.click();
		}
	}

	public void moveAgeSlider() throws InterruptedException {
		driver.context("NATIVE_APP");
		WebElement slider = driver.findElement(ageSlider);
		int height = slider.getSize().getHeight();
		int width = slider.getSize().getWidth();
		int tapX = slider.getLocation().getX() + (width / 4);
		int tapY = slider.getLocation().getY() + (height / 2);
		TouchAction tapCoordinates = new TouchAction(driver);
		tapCoordinates.tap(tapX, tapY).perform();
		Thread.sleep(1000);
		PageElement.changeContextToWebView(driver);
	}

	public void movedistanceSlider() throws InterruptedException {
		driver.context("NATIVE_APP");
		TouchAction tapCoordinates = new TouchAction(driver);
		Dimension size = driver.manage().window().getSize();
		int scrollX = (int) (size.width * .50);
		int scrollstartY = (int) (size.height * .80);
		int scrollendY = (int) (size.height * .40);
		driver.swipe(scrollX, scrollstartY, scrollX, scrollendY, 4000);
		Thread.sleep(1000);
		WebElement slider = driver.findElement(distanceSlider);
		int height = slider.getSize().getHeight();
		int width = slider.getSize().getWidth();
		int tapX = slider.getLocation().getX() + (width / 2);
		int tapY = slider.getLocation().getY() + (height / 2);
		tapCoordinates.tap(tapX, tapY).perform();
		Thread.sleep(1000);
		driver.context("WEBVIEW_com.snappy.appypie");
	}

}
