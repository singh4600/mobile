package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DeshboardRealEstatePage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();
	CommanRealEstate Comm;

	// --------Default-----------------------------------
	// public By = By.xpath("");
	public By username=By.xpath("//*[@id='loginid']");
	public By password=By.xpath("//*[@id='loginpass']");
	public By LoginBtn=By.xpath("//*[contains(@class,'appypie-login login-page')]/ul/li[5]");
	public By Acceptandcontinue=By.xpath("//a[@class='arial mediumContent']");
	public By backbtn= By.xpath("//*[contains(@class,'link back')]");
	// --------click Event-----------------------------------
	
	public By dreamHouselink= By.xpath("//*[contains(@class,'page-content arial mediumContent')]/a[2]");
	public By realEstateModulelink= By.xpath("//a[@data-productid='realestate']");
	public By menulink= By.xpath("//*[contains(@class,'link menu-down')]");
	public By filterBylink= By.xpath("//*[contains(@onclick,'realEstateFilters')]");
	public By sortBylink= By.xpath("//*[contains(@onclick,'sortingRealMainList')]");
	public By searchTextlink= By.xpath("//*[contains(@id,'serchinpt')]");
	public By searchlink= By.xpath("//*[contains(@class,'search-view')]");
	public By Favlink= By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@onclick,'addfav')]");
	public By sharelink= By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@onclick,'RealEstateShare')]");
	
	public By calllink= By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@onclick,'callreal')]");
	public By maplink= By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@onclick,'movetomap')]");
	public By location= By.xpath("//*[contains(@onclick,'Appyscript.showServicePageMapNewReal')]");
	public By OkNativeBtn= By.xpath("//android.widget.Button[@index='0']");
	public String i_cancelCallAcc= "Cancel";
	public By i_cancelCall= By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	public By i_backbtnhyperLink= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeButton");
	 
	
	public By firstPropertylink= By.xpath("//*[@id='landinglist']/li[1]//*[@class='click-area']");
	
	public By mapHeaderlink= By.xpath("//*[contains(@onclick,'Appyscript.showServicePageMapNewReal')]");
	 public By headersearchlink= By.xpath("//*[contains(@class,'topHeader')]/span");
	 public By enterlocation= By.xpath("//*[contains(@id,'reallocationsearch')]");
	 public By selectNoida= By.xpath("//*[contains(@id,'realestatelocation')]/li[1]");
	
	
//---------------------------------------------------------------------------------------------------------
	public By Homeshilalink= By.xpath("//*[contains(@class,'page-content arial mediumContent')]/a[1]");

	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By distance_km_gettext=By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@class,'distance-km arial mediumHeading')]");
	public By firstProperty_gettext=By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@class,'hyper-catNamebox')]");
	public By propertylist_gettext=By.xpath("//*[contains(@id,'landinglist')]/li//*[contains(@class,'hyper-catNamebox')]");
	public By forRent_gettext=By.xpath("//*[contains(@id,'landinglist')]/li[1]//*[contains(@class,'forSale')]");
	public By sharelistNative_gettext=By.className("android.widget.TextView");

	
	
	public By salePropertylink= By.xpath("//*[@id='landinglist']/li[3]");
	public By saleProperty_gettext=By.xpath("//*[contains(@id,'landinglist')]/li[3]//*[contains(@class,'hyper-catNamebox')]");
	
	public By salePropertylink1= By.xpath("//*[@id='landinglist']/li[2]");
	public By saleProperty_gettext1=By.xpath("//*[contains(@id,'landinglist')]/li[2]//*[contains(@class,'hyper-catNamebox')]");
	

	public DeshboardRealEstatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
		Comm=new CommanRealEstate(driver);
	}

	public void Login() throws InterruptedException{
		Boolean UN=Comm.IselementPresent(username);
		if (UN) {
			Boolean email=Comm.TextField(username, "prince@appypie.com");
			s_assert.assertTrue(email, "Email field is not enter value");

			Boolean pass=Comm.TextField(password, "12345678");
			s_assert.assertTrue(pass, "Pass field is not enter value");

			Boolean login=Comm.Openlinks(LoginBtn);
			s_assert.assertTrue(login, "login field is not click ");
		
			try{
				driver.findElement(Acceptandcontinue).click();
			}catch (Exception e) {
				System.out.println("Accept and continue is Not present");
			}
		}else{
			System.out.println("User is already Login");
		}

		

}
}