package com.appypie.pages;

import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.tests.basetest.TestSetup;
import com.appypie.util.ElementWait;
import com.appypie.util.Log;
import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieTwitterPage {

	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	By twitterPage = By.xpath("//a[@data-productid='twitter']");
	By twitterAccount = By.xpath("//a[@class='appypie-list'][@data-page='twitter']");
	By feeds = By.className("tweet-user");
	By invalidUrl = By.xpath("//a[@class='appypie-list'][@data-page='twitter'][@data-index='1']");
	By tweets = By.xpath("//div[@class='tweet-user-details']//div[@class='tweet']");
	By follower = By.xpath("//div[@class='tweet-user-details']//div[@class='follow']");
	By viewButton = By.xpath("//a[contains(@onclick,'Appyscript.followTwitter')]");
	By nativebackbtn = By.id("icon1_button");
	By webview = By.id("text_Tittle");

	// locator for ios
	By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='Twitter1']");

	public AppypieTwitterPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

	public void openTwitterPage() {
		WebElement open = ElementWait.waitForOptionalElement(driver, twitterPage, 20);
		if (open != null && open.isDisplayed())
			open.click();
		else {
			Logger.error("Twitter page is not present in main menu");
		}
	}

	public boolean identifyTwitterOpen() {
		boolean open = false;
		WebElement url = ElementWait.waitForOptionalElement(driver, twitterAccount, 20);
		if (url != null && url.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void openTwitterAccount() {
		WebElement url = ElementWait.waitForOptionalElement(driver, twitterAccount, 20);
		url.click();
	}

	public void clickInvalidUrl() throws NullPointerException {
		WebElement url = ElementWait.waitForOptionalElement(driver, invalidUrl, 20);
		if (url != null && url.isDisplayed()) {
			url.click();
		}
	}

	public String getFollowers() throws NullPointerException {
		return ElementWait.waitForOptionalElement(driver, follower, 20).getText();
	}

	public String getTweets() throws NullPointerException {
		return ElementWait.waitForOptionalElement(driver, tweets, 20).getText();
	}

	public boolean checkFeeds() {
		boolean feed = false;
		WebElement twfeeds = ElementWait.waitForOptionalElement(driver, feeds, 20);
		if (twfeeds != null && twfeeds.isDisplayed()) {
			feed = true;
		} else {
			Logger.error("Feeds are not present in the Twitter account");
		}
		return feed;
	}

	public boolean checkTwitterFeedInNative() throws InterruptedException {
		boolean open = false;
		WebElement view = null;
		Thread.sleep(4000);
		WebElement viewbtn = ElementWait.waitForOptionalElement(driver, viewButton, 20);
		if (viewbtn != null && viewbtn.isDisplayed()) {
			viewbtn.click();
			Thread.sleep(1000);
			driver.context("NATIVE_APP");
			if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				view = ElementWait.waitForOptionalElement(driver, webview, 20);
				if (view != null && view.isDisplayed()) {
					open = true;
					Thread.sleep(3000);
					driver.findElement(nativebackbtn).click();
				} else {
					Logger.error("Twitter feed is not open in native after clicking on view button from feed");
				}
			} else {
				view = ElementWait.getIosNativeElement(driver, i_nativeView, 20);
				if (view != null) {
					open = true;
					Thread.sleep(3000);
					PageElement.tapOnScreen(driver, 0.05, 0.05);
				} else {
					Logger.error("Twitter feed is not open in native after clicking on view button from feed in ios");
				}
			}
			PageElement.changeContextToWebView(driver);
		} else {
			Logger.error("view button is not displayed on the Twitter feeds");
		}
		return open;
	}
}
