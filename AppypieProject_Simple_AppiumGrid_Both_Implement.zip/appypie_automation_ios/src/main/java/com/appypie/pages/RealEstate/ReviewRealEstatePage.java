package com.appypie.pages.RealEstate;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ReviewRealEstatePage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;


	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By favlink= By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate']//*[contains(@onclick,'addfav')]");
	public By calllink= By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate']//*[contains(@onclick,'callreal')]");
	public By maplink= By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate']//*[contains(@onclick,'movetomap')]");
	public By reviewlink= By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate']//*[contains(@onclick,'reviewsubmit')]");
	public By star1link= By.xpath("//*[contains(@class,'pull-left')]/span[1]");
	public By star2link= By.xpath("//*[contains(@class,'pull-left')]/span[2]");
	public By star3link= By.xpath("//*[contains(@class,'pull-left')]/span[3]");
	public By star4link= By.xpath("//*[contains(@class,'pull-left')]/span[4]");
	public By star5link= By.xpath("//*[contains(@class,'pull-left')]/span[5]");
	public By editreviewtext= By.xpath("//*[contains(@id,'realestatereview')]");
	public By submitlink= By.xpath("//*[contains(@onclick,'submitreview')]");
	
	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By reviewsHeading_gettext=By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate']/h2");
	public By reviewlist_gettext=By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate-review']/ul/li/p");
	public By ratingStarList_gettext=By.xpath("//*[contains(@class,'pages ')]/div[2]//*[contains(@class,'page-content')]//*[@class='real-estate-review']/ul/li/p/span[2]/span");
	public By _gettext=By.xpath("");
	


	public ReviewRealEstatePage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
}