package com.appypie.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieTodoListPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	public By pagelink = By.xpath("//a[@data-productid='todolist']");
	public By header = By.xpath("//*[contains(@class,'navbar-inner navbar-on-center')]/div[1]/following-sibling::div[1]");
	public By pageList = By.xpath("//*[contains(@class,'page-content arial mediumContent hideBorder')]");
	public By shimlaTrip = By.xpath("//*[contains(@class,'page-content arial mediumContent hideBorder')]/a[1]");
	public By backButton = By.xpath("//*[@class='navbar-inner navbar-on-center']/div[1]/a");
	public By tripHeading = By.xpath("//h1[@class='arial largeHeading']");
	public By tripContent = By.id("todoSearchWrapper");
	public By selectCheckBox = By.xpath("//*[contains(@id,'todoSearchWrapper')]/li[1]/label[1]");
	public By editBox = By.xpath("//*[contains(@id,'todoSearchWrapper')]/li[1]/i[1]");
	public By commentBox = By.xpath("//ul[@id='todoSearchWrapper']/li[1]/i[2]");
	public By infoCancel = By.className("icon-cancel");
	public By popup_Heading = By.className("popHeading");
	public By ok = By.className("okbtn");
	public By textField = By.id("textbox");
	public By alertText = By.className("modal-text");
	public By popupBox = By.xpath("//*[contains(@id,'dialog-background')][@style='display: block;']");
	public By reset = By.xpath("//*[contains(@onclick,'resetTodolist')]");

	public By fitness = By.xpath("//*[contains(@class,'page-content arial mediumContent hideBorder')]/a[2]");




	public AppypieTodoListPage(AppiumDriver<MobileElement> driver) {

		this.driver = driver;
	}


	public boolean clickableLinks(By elements){
		boolean clickEvents=false;
		try {
			Thread.sleep(2000);
			WebElement clickONlinks=ElementWait.waitForOptionalElement(driver, elements, 20);
			clickONlinks.click();
			clickEvents = true;
		} catch (Exception e) {
			Logger.info("Click events not working on webElements");
		}

		return clickEvents;
	}


	public boolean isTodoListOpen(){
		boolean peageopen=false;
		String text = null;
		try {
			WebElement headerName = ElementWait.waitForOptionalElement(driver, header , 20);
			if (headerName!= null && headerName.isDisplayed()) {
				text =	headerName.getText();
				Logger.info("Text:" + text);
			}
			peageopen=true;

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			Logger.info("Header is getting null value");
		}
		return peageopen;

	}

	public String printAvailableText(By getText)  {
		String text = null;
		WebElement availableText = ElementWait.waitForOptionalElement(driver, getText, 20);
		if (availableText != null && availableText.isDisplayed()) {
			try {
				Thread.sleep(2000);
				text = availableText.getText();
				System.out.println("===================================");

				Logger.info("Text:" + text + "\n");
			} catch (InterruptedException e) {
				e.printStackTrace();
				e.getMessage();
				Logger.info("Selected Element is getting null value");
			}
		}
		return text;
	}	


	public boolean isCommentsBoxOpen(){
		boolean popupOpenforcomment=false;
		try {
			WebElement popupValue = ElementWait.waitForOptionalElement(driver, popupBox , 20);
			if (popupValue!= null && popupValue.isDisplayed()) {
				Logger.info("comment box is showing");
				popupOpenforcomment=true;
			}
			else {
				Logger.info("comment box not showing");
			}


		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}
		return popupOpenforcomment;

	}


	public boolean verifyCommentText(){
		boolean popupOpen=false;
		try {
			WebElement textArea = ElementWait.waitForOptionalElement(driver, textField , 20);
			if (textArea!= null && textArea.isDisplayed()) {

				textArea.click();
				textArea.sendKeys("Done");
			}
			popupOpen=true;

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			Logger.info("Header is getting null value");
		}
		return popupOpen;

	}


	public String verifyCommentWrittenText(){
		String text=null;
		try {
			WebElement textArea = ElementWait.waitForOptionalElement(driver, textField , 20);
			if (textArea!= null && textArea.isDisplayed()) {

				text = textArea.getAttribute("value");
				Logger.info("Text:" + text);
			}

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			Logger.info("Header is getting null value");
		}
		return text;
	}


	public boolean verifyCommentBox(){
		boolean box=false;
		try {
			WebElement comment = ElementWait.waitForOptionalElement(driver, editBox , 20);
			if (comment!= null && comment.isDisplayed()) {

				comment.click();
				box=true;
			}
			else {
				Logger.info("Comment already filled by user");
			}

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			Logger.info("Comment box not working");
		}
		return box;

	}

	
	public boolean usersComments(){
		boolean peageopen=false;
		
		WebElement headerName = ElementWait.waitForOptionalElement(driver, commentBox , 20);
		if (headerName!= null && headerName.isDisplayed()) {
			Logger.info("Comments are alrady added by usser");
			peageopen=true;
		}
		else {
			Logger.info("Comments are not added by usser");
		}
		
		return peageopen;

	}
	
	
	
}
