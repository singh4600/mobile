package com.appypie.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.appypie.util.ElementWait;
import com.appypie.util.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppypieCouponDirectoryPage {
	private static final Logger Logger = Log.createLogger();
	protected AppiumDriver<MobileElement> driver;

	public By pagelink = By.xpath("//a[@data-productid='coupondirectory']");
	By header = By.xpath("//*[contains(@class,'topHeader mediumHeaderBar verdana')]");
	public By pagelist = By.xpath("//*[contains(@class,'main-cat-listing clearfix no-fastclick')]");
	public By serch = By.id("btnSearch");
	public By serchText = By.xpath("//*[contains(@class,'off on')]");
	public By serchPagelist = By.xpath("//*[contains(@class,'cop_left0 cop_left0')]");
	public By clickONlist = By.xpath("//*[contains(@onclick,'CoupanDetailsdirectory')]");
	public By couponPageList = By.xpath("//*[contains(@class,'page-content arial mediumContent')]");
	public By couponPageListBack = By.xpath("//*[@class='navbar-inner navbar-on-center']/div[1]/a");
	public By bkmarks = By.xpath("//a[contains(@onclick,'Appyscript.coupondirectorybookemarkedlist')]");
	public By coponCollection = By.xpath("//ul[contains(@class,'main-cat-listing clearfix no-fastclick')]/li[1]");
	public By coponCollectionList = By.xpath("//*[contains(@class,'couponPageContainer')]/div[1]/ul[1]");
	public By madeCoupon = By.xpath("//ul[contains(@class,'main-cat-listing clearfix no-fastclick')]/li[2]");

	public By clouths = By.xpath("//*[contains(@class,'couponPageContainer')]/div[1]/ul[1]/li[1]");
	public By clouthsCoupons = By.xpath("//*[contains(@data-page,'coupondirectory-Subcategory')]/following-sibling::div[1]/div[2]/div[1]/div[1]/ul[1]");
	public By discount = By.xpath("//*[contains(@class,'frontInner')][@data-index='0']");
	public By couponBookmarks = By.xpath("//a[contains(@onclick,'addtobookmarkcoupondirectory')]");
	public By couponDetails = By.xpath("//*[contains(@class,'page-content arial mediumContent')]/div[1]/div[1]/div[1]/div[1]/div[1]");
	

	public By couponBkmarksclick = By.xpath("//*[@class='icon icon-bookmark-1']");
	public By couponBkmarksclick1 = By.xpath("//*[contains(@onclick,'addtobookmarkcoupondirectory') and //*[@class='icon icon-bookmark-empty']]");
	
	public By selectedBookmarks = By.xpath("//*[contains(@class,'couponPageContainerInside flip-container')]/div[1]/div[1]/h1[1]/a[1]");
	public By bookmarksAlert = By.xpath("//div[@class='modal-title']");
	public By alertMsg = By.xpath("//div[@class='modal-text']");

	public By info = By.xpath("//*[contains(@onclick,'couponCardFlipService')]");
	public By infoD = By.xpath("//*[contains(@class,'terms-text terms-text2 copDescription arial mediumContent')]");
	public By infoCross = By.xpath("//*[contains(@class,'couponPageContainerInside flip-container hover')]/div[1]/div[1]/following-sibling::div[1]/a[1]");
	public By share = By.xpath("//*[contains(@onclick,'cdiropenShareCoupon')]");
	public By sharelink=By.className("android.widget.TextView");
	
	
	public By shoesCoupons = By.xpath("//*[contains(@class,'couponPageContainer')]/div[1]/ul[1]/li[2]");
	public By reedem = By.xpath("//*[contains(@onclick,'Appyscript.cdircouponServiceStamp')]");
	public By couponHeader = By.xpath("//*[contains(@class,'navbar-inner navbar-on-center')]/div[2]");
	public By bug_getCouponList = By.className("loyalStemp");
	public By enterCode = By.id("redeempin");
	public By validate = By.xpath("//*[contains(@onclick,'coupanRedeemValuecdir')]");
	public By back = By.xpath("//*[contains(@onclick,'coupancancel')]");
	public By blankAlert = By.className("modal-text");
	public By invalidCodeAlert = By.className("modal-text");
	
	
	
	public By scrtch = By.xpath("//*[contains(@class,'frontInner')][@data-index='1']");
	public By scrtchus = By.xpath("//*[contains(@class,'frontInner')][@data-index='2']");
	public By exp = By.xpath("//*[contains(@class,'frontInner')][@data-index='3']");
	public By reedemScratchCoupon = By.xpath("//*[contains(@onclick,'cdircoupanRedeemShowMessage')]");
	public By redeemAlert = By.className("dropdown-overlay");
	public By cancel = By.xpath("//*[contains(@class,'modal modal-in')]/div[2]/span[1]");
	
	
	public AppypieCouponDirectoryPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}


	public boolean isCouponPageOpen(){
		boolean peageopen=false;

		try {
			WebElement headerName = ElementWait.waitForOptionalElement(driver, header , 20);
			if (headerName!= null && headerName.isDisplayed()) {
				headerName.getText();
			}
			peageopen=true;

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			Logger.info("Header is getting null value");
		}
		return peageopen;

	}


	public String printAvailableText(By getText)  {
		String text = null;
		WebElement availableText = ElementWait.waitForOptionalElement(driver, getText, 20);
		if (availableText != null && availableText.isDisplayed()) {
			try {
				Thread.sleep(2000);
				text = availableText.getText();
				System.out.println("===================================");

				Logger.info("Text:" + text + "\n");
			} catch (InterruptedException e) {
				e.printStackTrace();
				e.getMessage();
				Logger.info("Selected Element is getting null value");
			}
		}
		return text;
	}


	public boolean serchField(By Text, String value){
		boolean srch= false;
		WebElement sField = ElementWait.waitForOptionalElement(driver, Text, 20);
		try {
			if (sField!=null && sField.isDisplayed()) {
				Thread.sleep(2000);
				sField.click();
				sField.clear();
				sField.sendKeys(value);

			}

			srch=true;
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

		return srch;
	}

	public boolean isAlertPopupOpen(){
		boolean popup=false;
		String text = null;
		WebElement alertpopup = ElementWait.waitForOptionalElement(driver, bookmarksAlert , 20);
		if (alertpopup!=null && alertpopup.isDisplayed()) {

			text = alertpopup.getText();
			Logger.info("Text:" + text);

		}
		else {
			Logger.info("Coupon already selected for Bookmarks");
		}
		popup=true;
		return popup;

	}

	
	public boolean isBookmarksSelectd(By link){
		boolean bkmark=false;
		
		WebElement bookmarkicon = ElementWait.waitForOptionalElement(driver, link, 20);
		if (bookmarkicon != null && bookmarkicon.isDisplayed()){
			bkmark=true;
		}
		
		return bkmark;
	}
	

	
	
	
	public boolean couponCode(By enterCode, String text){
	 boolean code=false;
	 
	 WebElement textField = ElementWait.waitForOptionalElement(driver, enterCode, 20);
	 textField.click();
	 textField.sendKeys(text);
	 code=true;
	return code;
		
	}
	
	public boolean clickableLinks(By elements){
		boolean clickEvents=false;
		try {
			Thread.sleep(2000);
			WebElement clickONlinks=ElementWait.waitForOptionalElement(driver, elements, 20);
			clickONlinks.click();
			clickEvents = true;
		} catch (Exception e) {
			Logger.info("Click events not working on webElements");
		}

		return clickEvents;
	}

	
}
