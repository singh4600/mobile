package com.appypie.pages.Hotels;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.asserts.SoftAssert;

import com.appypie.util.PageElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DeshboardPage {
	PageElement pageutil;
	Dimension size;
	int count = 0;
	protected AppiumDriver<MobileElement> driver;
	static String Actual;
	static String runningTest1 = "error geting";
	SoftAssert s_assert = new SoftAssert();

	// --------click Event-----------------------------------
	// public By = By.xpath("");
	public By hotelmodulelink= By.xpath("//a[@data-productid='accommodation']");
	public By hiltonHotellink= By.xpath("//*[contains(@data-name,'Hilton Hotel')]//*[contains(@class,'category-detail')]");
	public By bungalowlink= By.xpath("//*[contains(@data-name,'BUNGALOW')]//*[contains(@class,'category-detail')]");
	public By sharmaHouselink= By.xpath("//*[contains(@data-name,'Sharma House')]//*[contains(@class,'category-detail')]");
	public By villaRochalink= By.xpath("//*[contains(@data-name,'Villa Rocha')]//*[contains(@class,'category-detail')]");
	public By username=By.xpath("//*[@id='loginid']");
	public By password=By.xpath("//*[@id='loginpass']");
	public By LoginBtn=By.xpath("//*[contains(@class,'appypie-login login-page')]/ul/li[5]");
	public By Acceptandcontinue=By.xpath("//a[@class='arial mediumContent']");
	public By shortBylink= By.xpath("//*[contains(@onclick,'accommodation-short-by')]");
	public By filterlink= By.xpath("//*[contains(@onclick,'Appyscript.hotelFilter')]");
	public By searchlink= By.xpath("//*[contains(@onclick,'hotelSearchToggle')]");
	public By anywherelink= By.xpath("//*[contains(@id,'hotelanywheredrop')]");
	public By searchNoida_text= By.xpath("//*[contains(@placeholder,'Search for...')]");
	public By noidaSelectlink= By.xpath("//*[contains(@class,'matching-bx')]/ul[1]/*[contains(@id,'noida')]");
	public By selectDatelink= By.xpath("//*[contains(@id,'hotelcalendar-range')]");
	public By DoneClenderBtn= By.xpath("//*[contains(@onclick,'searchcalhotel')]");
	public By guestlink= By.xpath("//*[contains(@id,'hotelanyguestdrop')]");
	public By menulink= By.xpath("//*[contains(@onclick,'accommodation-menu')]");
	public By backBtn_TCpage= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	public By backBtn_PPpage= By.xpath("//*[contains(@class,'link back icon icon-left-open-2')]");
	

	// ---------Get Text Event----------------------------
	// public By _gettext=By.xpath("");
	public By listofHotel_gettext=By.xpath("//*[contains(@class,'category-detail')]");
	public By currentMonth_gettext=By.xpath("//*[contains(@class,'current-month-value')]");
	public By messageRange_gettext=By.xpath("//*[contains(@id,'hotelrangeselect')]");
	public By TC_gettext=By.xpath("//*[(@class='bodypan')]");
	public By PP_gettext=By.xpath("//*[(@class='bodypan')]");
	
	

	public DeshboardPage(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		pageutil = new PageElement();
	}
	
	public void RegisteredUser() throws InterruptedException{
		driver.findElement(username).sendKeys("Prince@appypie.com");
		driver.hideKeyboard();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(password).sendKeys("12345678");
		driver.hideKeyboard();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(LoginBtn).click();
		TimeUnit.SECONDS.sleep(5);
		driver.findElement(Acceptandcontinue).click();
		TimeUnit.SECONDS.sleep(3);
	}
}