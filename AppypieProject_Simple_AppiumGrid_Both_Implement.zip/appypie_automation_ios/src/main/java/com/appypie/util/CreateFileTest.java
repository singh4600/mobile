package com.appypie.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class CreateFileTest {
	public static void main(String[] args) {
		Object[][] obj= null;
		int i = 0,j=0;
		int rowNum=1;
		int colNum=1;
		try {
			FileInputStream file = new FileInputStream(new File("/Users/pawan/Desktop/Appium_PageCompletion_Status.ods"));
			XSSFWorkbook book = new XSSFWorkbook(file);
			Sheet sheet = book.getSheetAt(0);
			rowNum= sheet.getLastRowNum();
			colNum=sheet.getRow(0).getLastCellNum();
			obj= new Object[rowNum][colNum];
			Iterator<Row> itr = sheet.iterator();
			while (itr.hasNext()) {
				Row row = (Row) itr.next();
				Iterator<Cell> cellIterator= row.iterator();
				while(cellIterator.hasNext()){
				Cell cell= (Cell)cellIterator.next();
				if(cell.getCellType()==Cell.CELL_TYPE_STRING){
					System.out.println(cell.getStringCellValue());
					obj[i][j]=cell.getStringCellValue();
				} else if (cell.getCellType()==Cell.CELL_TYPE_NUMERIC){
					System.out.println(cell.getNumericCellValue());
					obj[i][j]=cell.getNumericCellValue();
				}else{
					System.out.println(cell.getBooleanCellValue());
					obj[i][j]=cell.getBooleanCellValue();
				}
				j++;
			}
				i++;	
			}
			
   
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	
	

}
