package com.appypie.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class LoginServiceHandler {

	public static String updateUserSetting(TreeMap<String,Integer> map) {
		String status = "";
		StringBuilder input= new StringBuilder();

		try {

			URL url = new URL("http://snappy.appypie.com/webservices/AppuserSetting.php");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			
			input.append("{\"method\":\"changeSetting\",\"appId\":\"41b6f8247838\",\"updateList\":{");
			
			for(int i=0;i<map.size();i++){
				input.append("\""+map.keySet().toArray()[i]+"\":"+map.get(map.keySet().toArray()[i])+",");		
			}
            input.deleteCharAt(input.lastIndexOf(","));
            input.append("}}");
			OutputStream os = conn.getOutputStream();
			os.write(input.toString().getBytes());
			os.flush();
			System.out.println(HttpURLConnection.HTTP_CREATED);
			// if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
			// throw new RuntimeException("Failed : HTTP error code : " +
			// conn.getResponseCode());
			// }

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				status = output.substring(output.indexOf("status\":\"") + 9, output.lastIndexOf("\"}"));
			}
			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		return status;
	}
	
	
	
	public static String getSettingValues(List<String> list) {
		StringBuilder input= new StringBuilder();
		String response="";
		try {
			URL url = new URL("http://snappy.appypie.com/webservices/AppuserSetting.php");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");

			input.append("{\"method\":\"getSetting\",\"appId\":\"41b6f8247838\",\"getList\":\"");
			for(int i=0;i<list.size();i++){
				input.append(list.get(i)+",");		
			}
		    input.deleteCharAt(input.lastIndexOf(","));
		    input.append("\"}");
			OutputStream os = conn.getOutputStream();
			os.write(input.toString().getBytes());
			os.flush();  
			System.out.println(HttpURLConnection.HTTP_CREATED);
			// if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
			// throw new RuntimeException("Failed : HTTP error code : " +
			// conn.getResponseCode());
			// }

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				response=output;
//				System.out.println("value is "+response.charAt(response.indexOf("phone_country_code\":\"")+12));
//				int value=Integer.parseInt(String.valueOf(response.charAt(response.indexOf("phone_country_code\":\"")+21)));
//				System.out.println(value);
			}
			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		return response;
	}
	

	public static void main(String[] ar) {
//		TreeMap<String,Integer> map= new TreeMap<String,Integer>();
//		map.put("auto_aproval", 0);
//		map.put("phone_country_code", 0);
//		updateUserSetting(map);
		
		List<String> list= new ArrayList<String>();
		list.add("phone_country_code");
		list.add("email_verification");
		System.out.println(getSettingValues(list));
	}

}
