package com.appypie.util;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ElementWait {
	private static final Logger Logger = Log.createLogger();

	public static WebElement waitForOptionalElement(AppiumDriver<MobileElement> driver, By locator, int time) {
		WebElement element = null;
		int count = 0;
		int maxTries = 4;
		while (true) {
			try {
				
				//WebDriverWait wait = new WebDriverWait(driver, time);
				Wait<AppiumDriver<MobileElement>> wait= new FluentWait<AppiumDriver<MobileElement>>(driver).withTimeout(time, TimeUnit.SECONDS).pollingEvery(3,  TimeUnit.SECONDS);
				List<WebElement> elementList = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
				if (elementList.size() != 0) {
					element = elementList.get(0);
				}
				return element;
			} catch (StaleElementReferenceException e) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				Logger.info("Stale element occurs in geting the element while waiting, retry value: " + count + " :");
				if (++count == maxTries) {
					throw e;
				}
			} catch (TimeoutException ex) {
				Logger.error("Optional element is not found:"+ex.getMessage());
				return element;
			}
		}
	}

	public static List<WebElement> waitForAllOptionalElements(AppiumDriver<MobileElement> driver, By locator,int time) {
		List<WebElement> list = null;
		WebDriverWait wait = new WebDriverWait(driver, time);
		try {
			list = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
		} catch (Exception e) {
			Logger.error(" Set of  Optional elements not found: " + e.getMessage());
		}
		return list;
	}

	public static List<MobileElement> getAllElement(AppiumDriver<MobileElement> driver, By locator) {
		List<MobileElement> list = null;
		try {
			list = driver.findElements(locator);
		} catch (NoSuchElementException e) {
			Logger.error(" Exception occurs while searching for all the elements on the Page: " + e.getMessage(), e);
		}
		return list;
	}

	public static MobileElement getIosNativeElement(AppiumDriver<MobileElement> driver, By locator,int time) {
		MobileElement element = null;
		int count = 0;
		int maxtry = 2;
		WebDriverWait wait = new WebDriverWait(driver, time);
		while (true) {
			try {
				element=(MobileElement) wait.until(ExpectedConditions.presenceOfElementLocated(locator));
				return element;
			} catch (Exception e) {
				Logger.error(" Exception occurs while searching for all the elements on the Page: " + e.getMessage());
				if (++count == maxtry)
					return element;
			}
		}
	}

	public static WebElement until(ExpectedCondition<WebElement> elementToBeClickable) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
