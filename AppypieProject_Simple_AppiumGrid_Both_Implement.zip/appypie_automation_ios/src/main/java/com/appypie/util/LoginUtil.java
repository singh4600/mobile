package com.appypie.util;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class LoginUtil {

	private static final Logger Logger = Log.createLogger();
	static By loginBtn = By.xpath("//a[text()='Login']");
	static By pwd = By.xpath("//*[@id='loginpass']");
	static By emailId = By.xpath("//*[@id='loginid']");

	static By signupnow = By.linkText("Sign up Now");
	static By fname = By.xpath("//*[@id='fname']");
	static By email = By.xpath("//*[@id='emailId']");
	static By pno = By.xpath("//*[@id='pNo']");
	static By pass = By.xpath("//*[@id='pass']");
	static By cpass = By.xpath("//*[@id='cpass']");
	static By signup = By.xpath("//a[contains(.,'Sign Up')]");

	static By menu = By.className("iconz-option-vertical");
	static By logout = By.className("logout");

	public static String firstName = "";
	public static String mailId = "";
    public static int value=0;
    
    public static By emailTaxi = By.id("user_name");
    public static By pwdTaxi = By.id("password");
    public static By loginBtnTaxi = By.xpath("//android.widget.LinearLayout[contains(@resource-id,'com.snappy.appypie:id/login_btn') and @index='2']");
    
    static By loginSignup = By.xpath("//*[contains(@onclick,'Appyscript.askLogin')]");
    
	public static boolean isLoginPageOpen(AppiumDriver<MobileElement> driver) {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, emailId, 10);
		if (login != null && login.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public static void loginIntoPage(AppiumDriver<MobileElement> driver, String email, String password) throws InterruptedException {
		PageElement.sendKey(driver, emailId, email);
		PageElement.sendKey(driver, pwd, password);
		Thread.sleep(3000);
		PageElement.locateClickableElement(driver, loginBtn);
	}
	


	public static void signUp(AppiumDriver<MobileElement> driver) {
		PageElement.locateClickableElement(driver, signupnow);
	}

	public static boolean isSignUpOpen(AppiumDriver<MobileElement> driver) {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, fname, 10);
		if (login != null && login.isDisplayed()) {
			open = true;
		}
		return open;
	}

	public void logout(AppiumDriver<MobileElement> driver) {
		try {
			WebElement element_menu = ElementWait.waitForOptionalElement(driver, menu, 20);
			if (element_menu != null && element_menu.isDisplayed()) {
				element_menu.click();
				WebElement element_logout = ElementWait.waitForOptionalElement(driver, logout, 20);
				if (element_logout != null && element_logout.isDisplayed()) {
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element_logout.getLocation().x + ")");
					element_logout.click();
				} else {
					Logger.error("Logout button is not visible on the app menu");
				}
				Thread.sleep(1000);
			} else {
				Logger.info(" app menu screen doesn't appear or driver is not able to find app menu screen element");
			}
		} catch (Exception ex) {
			Logger.error("Exception occurs on app menu screen" + ex.getMessage(), ex);
		}
	}

	public static void registerUserForDating(AppiumDriver<MobileElement> driver) {
	    value = FileHandler.fileReader("UserValue") + 1;
		firstName = "ActiveUser" + String.valueOf(value);
		mailId = "a" + value + "@a" + value + ".com";
		FileHandler.fileWriter("UserValue",value);
		PageElement.sendKey(driver, fname, firstName);
		PageElement.sendKey(driver, email, mailId);
		PageElement.sendKey(driver, pass, "12345678");
		PageElement.sendKey(driver, cpass, "12345678");
		PageElement.locateClickableElement(driver, signup);
	}

//-------------------------PRINCE------------------------------------//	
	
	public static boolean isLogindisplaying(AppiumDriver<MobileElement> driver) {
		boolean open = false;
		WebElement login = ElementWait.waitForOptionalElement(driver, loginSignup, 20);
		if (login != null && login.isDisplayed()) {
			login.click();
			open = true;
		}
		return open;
	}
	
	public static void loginIntoPageNative(AppiumDriver<MobileElement> driver, String email, String password) throws InterruptedException {
		  PageElement.sendKey(driver, emailTaxi, email);
		  PageElement.sendKey(driver, pwdTaxi, password);
		  Thread.sleep(3000);
		  PageElement.locateClickableElement(driver, loginBtnTaxi);
		 }
//-------------------------PRINCE------------------------------------//	
}
