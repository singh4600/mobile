package com.appypie.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class FileHandler {
	private static final Logger Logger = Log.createLogger();
	
	public static int fileReader(String key){
		Properties prop = new Properties();
		InputStream input = null;
		int value=0;
		try {
			input = new FileInputStream("src/test/resources/Registration.properties");
			prop.load(input);
			
			value= Integer.parseInt(prop.getProperty(key));
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return value;
	}

	public static void fileWriter(String key,int value){
		Properties prop = new Properties();
		OutputStream output = null;

		try {
			output = new FileOutputStream("src/test/resources/Registration.properties");
			prop.setProperty(key, String.valueOf(value));

			// save properties to project root folder
			prop.store(output, null);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
		
	}
	
//	public static void main(String [] arr){
//		fileWriter(2);
//		System.out.println(fileReader());
//	}
}
