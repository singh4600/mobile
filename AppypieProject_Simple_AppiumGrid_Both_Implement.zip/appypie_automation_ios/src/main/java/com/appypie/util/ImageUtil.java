package com.appypie.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ImageUtil {
	
	static String destDir;
	
public static File takeScreenshot(AppiumDriver<MobileElement> driver,String filename) {
		  destDir = "screenshots";
		  driver.context("NATIVE_APP");
		  File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		  try {
		  new File(destDir).mkdirs();
		  String destFile = filename + ".png";
		  FileUtils.copyFile(scrFile, new File(destDir + "/" + destFile));
		  } catch (IOException e) {
		  e.printStackTrace();
		  }
		  PageElement.changeContextToWebView(driver);
		  return scrFile; 
	}


}
