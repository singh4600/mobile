package com.appypie.util;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Log {
	private static Logger LOGGER;
	private static final String FILENAME = "defaultlog";
	private static final String DATEANDTIMEFORMAT = "MM-dd-yyyy_hh.mm.ss";
	private static final InputStream LOGPROPERTTFILEPATH = Log.class.getClassLoader().getResourceAsStream("log4j.properties");//"log4j.properties";
	                                          
	private Log() {
	}

	static {
		try {
			String dateTime = DateAndTime
					.getFormattedCurrentDateAndTime(DATEANDTIMEFORMAT);
			String FileName = FILENAME + "-" + dateTime + ".log";
			File file = new File("logs/" + FileName);
			if (file.createNewFile()) {
				Properties props = new Properties();
				props.load(LOGPROPERTTFILEPATH);
				props.setProperty("log4j.appender.File.File", "logs/"
						+ FileName);
				LogManager.resetConfiguration();
				PropertyConfigurator.configure(props);
				System.out.println("Property log4j.appender.File.File = logs/"
						+ FileName);
			} else {
				System.out.println("File aready exists");
			}
		} catch (Exception ex) {
			throw new RuntimeException(
					"Exception in static method of Logger Class. ", ex);
		}

	}

	public static Logger createLogger() {
		if (LOGGER == null) {
			LOGGER = LogManager.getLogger(Log.class);
			return LOGGER;
		} else {
			return LOGGER;
		}
	}

}
