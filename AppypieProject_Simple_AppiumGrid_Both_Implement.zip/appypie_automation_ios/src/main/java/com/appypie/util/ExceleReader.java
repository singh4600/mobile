package com.appypie.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExceleReader {
	

	public static void ExcelReader() throws IOException{
		
		XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(new File("/Users/pawan/Downloads/Sample.xlsx")));
		Sheet sheet= workbook.getSheetAt(0);
		Iterator itr= sheet.iterator();
		while(itr.hasNext()){
			Row row= (Row)itr.next();
			System.out.println(row.getRowNum());
		}
	}
	
	public static void main(String [] ar){
		try {
			ExcelReader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
