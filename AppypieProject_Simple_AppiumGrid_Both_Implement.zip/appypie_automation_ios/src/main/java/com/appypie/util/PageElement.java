package com.appypie.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.appypie.pages.NavigationPage;
import com.appypie.tests.basetest.TestSetup;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.ios.IOSDriver;

public class PageElement extends TestSetup{
	
	
	static By heading = By.xpath("//div[@class='navbar']/div[2]/div[2]");
	static By menuheading = By.xpath("//div[@class='navbar']//div[contains(text(),'Automate')]");
	static By menuheading2 = By.xpath("//div[@class='navbar']//div[contains(text(),'App_Automation_by_Anurag')]");
	static By backbtn = By.xpath("//div[@class='navbar']/div[2]//a[@href='index'][contains(@class,'link back')]");
	static By noData = By.className("msg-container");
	static By loader = By.className("preloader-indicator-modal");
	static By warningTitle = By.className("modal-title");
	static By warningText = By.className("modal-text");
    static By cancel_OK =By.xpath("//span[contains(@class,'modal-button')][text()='Ok']");
	static By closeWarning = By.className("modal-buttons");
	static By cancelPopUp = By.xpath("//span[contains(@class,'modal-button')][text()='Cancel']");
	static By sharepopUp = By.className("android.widget.TextView");
	static By imgUpload = By.className("android.widget.FrameLayout");
	static By nativePageTitle = By.id("text_Tittle");
	static By progress = By.id("progressBar");
	static By CEBackbtn = By.xpath("//*[contains(@class, 'link back')]");
	public static By tc = By.id("termscondition");
	static By Bookmarks_ok = By.xpath("//*[@class='modal-button modal-button-bold']");
	
	public static By i_header_gettext_native = By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]//XCUIElementTypeStaticText");  
	public static By i_backbutton = By.xpath("//XCUIElementTypeApplication[@name='CreatedApp']//XCUIElementTypeButton");
	public static String iok="";
	public static By i_ok = By.xpath("//XCUIElementTypeButton[@name=\"OK\"]");
	public static By i_backbuttonFullPath = By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");
	public static By i_share = By.xpath("//XCUIElementTypeOther[@name='ActivityListView']");
	public static By i_Cancelshare = By.xpath("//XCUIElementTypeOther[@name='Cancel']");
	public static String i_cancel="Cancel";
	public static By i_Donebtn_Keyboard = By.xpath("//XCUIElementTypeButton[@name=\"Done\"]");
	public static String i_done="Done";
	public static By i_backbtnhyperLink= By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeButton");
	public static By i_cancelCall= By.xpath("//XCUIElementTypeButton[@name=\"Cancel\"]");
	public static By i_CameraRoll = By.xpath("//*[contains(@name,'Camera Roll')] ");
	public static By i_SelectFirstPhoto = By.xpath("//XCUIElementTypeCell[1]//XCUIElementTypeImage[1]");
	public static By i_selectPhoto=By.xpath("//XCUIElementTypeApplication[@name=\"CreatedApp\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[1]/XCUIElementTypeImage[1]"); //XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeCell[1]/XCUIElementTypeImage[1]
	public static By i_DoneBtn = By.xpath("//XCUIElementTypeButton[@name=\"Done\"]");
/*	public static By i_ = By.xpath("");
	public static By i_ = By.xpath("");
	public static By i_ = By.xpath("");*/

	public static String i_cameraRoll="Camera Roll";
	public static String i_cameraUsePhoto="Use Photo";
	public static By i_selectphoto=By.name("Camera Roll");
	public static String i_backtoApp="Return to CreatedApp";
	public static String i_image="Screenshot, Portrait, 27 September 2017, 15:48";
	public static By i_clickcameraphotoNative=By.xpath("//XCUIElementTypeButton[@name=\"PhotoCapture\"]");
	
	static By Emailfield=By.id("loginid");
	static By passwordfield=By.id("loginpass");
	static By loginbutton=By.xpath("//li[@class='login-btn']");
	static By Acceptandcontinue=By.xpath("//a[@class='arial mediumContent']");
	static By getsharebyItem_getlink=By.className("android.widget.TextView");

	private static final Logger Logger = Log.createLogger();

	public static String getPageHeader(AppiumDriver<MobileElement> driver) {
		String Header = ElementWait.waitForOptionalElement(driver, heading, 20).getText();
		Logger.info("Inner Page header is " + Header);
		return Header;
	}

	public static String getAppName(AppiumDriver<MobileElement> driver) {
		String Header = ElementWait.waitForOptionalElement(driver, menuheading, 20).getText();
		return Header;
	}
	
	//----Prince
	
	public static String getAppName2(AppiumDriver<MobileElement> driver) {
		String Header = ElementWait.waitForOptionalElement(driver, menuheading2, 20).getText();
		return Header;
	}
	
	 public static boolean tapCEBackButton(AppiumDriver<MobileElement> driver) {
		 boolean backbutton = false;
			WebElement back = driver.findElement(CEBackbtn);
				back.click();
			return backbutton;
			
		}
	 
	 public static boolean tapBackButtonP(AppiumDriver<MobileElement> driver){
			boolean backbutton2 = false;
			WebElement back2 = driver.findElement(backbtn);
			back2.click();
			return backbutton2;
		}
	 
	 public static boolean verifyAlert_Ok() {
		   boolean alert=false;
		   try {
		    WebElement bookmarks_alt = ElementWait.waitForOptionalElement(driver, Bookmarks_ok, 20);
		    Thread.sleep(2000);
		    if (bookmarks_alt != null) {
		     bookmarks_alt.click();
		     alert=true;
		    } else {
		     Logger.info("Error occurs on bookmarks ok button");
		    }
		   } catch (InterruptedException e) {
		    e.printStackTrace();
		   }
		   return alert;
		  }
//------------
	public static void tapBackButton(AppiumDriver<MobileElement> driver) throws InterruptedException {
		Thread.sleep(2000);
		WebElement back = driver.findElement(backbtn);
		//((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + back.getLocation().x + ")");
		back.click();
		
	}

	public static void backFromNaitvePage(AppiumDriver<MobileElement> driver) throws InterruptedException {
		driver.context("NATIVE_APP");
		driver.navigate().back();
		Thread.sleep(1000);
		changeContextToWebView(driver);
	}

	public static void locateClickableElement(AppiumDriver<MobileElement> driver, By locator) {
		WebElement element = ElementWait.waitForOptionalElement(driver, locator, 10);
		if (element != null && element.isDisplayed()) {
		//((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().x + ")");
			element.click();
		}
	}

	public static boolean checkNoDataOptionInUrl(AppiumDriver<MobileElement> driver) {
		boolean noDataIcon = false;
		WebElement element_noData = ElementWait.waitForOptionalElement(driver, noData, 20);
		if (element_noData != null && element_noData.isDisplayed()) {
			Logger.info(" No Data Icon is visible on screen  ");
			noDataIcon = true;
		} else {
			WebElement element_loader = ElementWait.waitForOptionalElement(driver, loader, 2);
			if (element_loader != null && element_loader.isDisplayed())
				Logger.error("Loader is continuously Rotating while opening the element");
			else
				Logger.error(" element is not open ");
		}
		return noDataIcon;
	}

	public static void checkForUnexpectedAlert(AppiumDriver<MobileElement> driver) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alt = driver.switchTo().alert();
				String text = alt.getText();
				Logger.info("The text on alert is: " + text);
				alt.dismiss();
			}
		} catch (TimeoutException e) {
			Logger.error("Unexpected Alert is not present :");
		}
	}

	public static List<Object> getWarningTitle(AppiumDriver<MobileElement> driver) throws InterruptedException {
		Thread.sleep(1000);
		List<Object> list = new ArrayList<Object>();
		String title = "";
		boolean open = false;
		WebElement warn_title = ElementWait.waitForOptionalElement(driver, warningTitle, 20);
		if (warn_title != null && warn_title.isDisplayed()) {
			title = warn_title.getText();
			open = true;
		} else {
			Logger.error("Warning popup doesn't appear");
		}
		list.add(title);
		list.add(open);
		return list;
	}

	public static String getWarningText(AppiumDriver<MobileElement> driver) {
		String text = "";
		WebElement warn_text = ElementWait.waitForOptionalElement(driver, warningText, 20);
		if (warn_text != null && warn_text.isDisplayed()) {
			text = warn_text.getText();
		} else {
			Logger.error("Warning popup doesn't appear");
		}
		return text;
	}

	public static void closeWarningSingleBtn(AppiumDriver<MobileElement> driver,String value) {
	    By cancel =By.xpath("//span[contains(@class,'modal-button')][text()='"+value+"']");
		locateClickableElement(driver, cancel);

	}

	public static void cancelPopup(AppiumDriver<MobileElement> driver) {
		locateClickableElement(driver, cancelPopUp);
	}

	public static void selectByValue(AppiumDriver<MobileElement> driver, By locator, String value) {
		try {
			WebElement item = ElementWait.waitForOptionalElement(driver, locator, 20);
			if (item != null) {
				Select element = new Select(item);
				element.selectByVisibleText(value);
			}
		} catch (Exception e) {
			Logger.error(" Exception occurs while searching the Drop down Value: " + e.getMessage(), e);
			throw (e);
		}
	}

	public static void sendKey(AppiumDriver<MobileElement> driver, By locator, String data) {
		try {
			WebElement element = ElementWait.waitForOptionalElement(driver, locator, 20);
			if (element != null) {
				//((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().x + ")");
				element.clear();
				element.sendKeys(data);
				if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
				driver.hideKeyboard();
				}
			} else {
				Logger.error("element is not present for entering the value ");
			}
		} catch (Exception e) {
			Logger.error(" Exception occurs while putting the text in the field: ", e);
		}
	}

	public static void tapDeviceOk(AppiumDriver<MobileElement> driver) throws InterruptedException  {
		driver.context("NATIVE_APP");
		if (!globledeviceName.equals("iPhone")) {
		AndroidDriver<MobileElement> driver1 = (AndroidDriver<MobileElement>) driver;
		driver1.pressKeyCode(AndroidKeyCode.ENTER);
		}else{
		//tapOnScreen(driver, .50, .50);	
		//tapOnScreen(driver, 281, 542);	
			try {
				Accessibilitylinks(i_done);
			}catch (Exception e) {
					System.out.println("error in click on Done Button on Ios App");
				}
		}
		changeContextToWebView(driver);
	}

	public static boolean checkSharePopUp(AppiumDriver<MobileElement> driver) throws InterruptedException {
		boolean open = false;
		WebElement shareoption = null;
		driver.context("NATIVE_APP");
		if (!TestSetup.deviceName.toUpperCase().contains("iPhone".toUpperCase())) {
			shareoption = ElementWait.waitForOptionalElement(driver, sharepopUp, 10);
			if (shareoption != null && shareoption.isDisplayed()) {
				driver.navigate().back();
				Thread.sleep(500);
				open = true;
			} else {
				Logger.error("Share pop up is not open upon clicking share btn on quiz result page");
			}
		} else {
			shareoption = ElementWait.waitForOptionalElement(driver, i_share, 10);
			if (shareoption != null) {
				Thread.sleep(1000);
				PageElement.tapOnScreen(driver, 0.04, 0.04);
				Thread.sleep(500);
				open = true;
			} else {
				Logger.error("Share pop up is not open upon clicking share btn on quiz result page in iPhone");
			}
		}
		changeContextToWebView(driver);
		return open;
	}

	public static void tapOnScreen(AppiumDriver<MobileElement> driver, double ratioX, double ratioY)
			throws InterruptedException {
		driver.context("NATIVE_APP");
		Dimension size = driver.manage().window().getSize();
		int x = (int) (size.width * ratioX);
		int y = (int) (size.width * ratioY);
		TouchAction tapCoordinates = new TouchAction(driver);
		tapCoordinates.tap(x, y).perform();
		Thread.sleep(1000);
		
		if (globledeviceName.equals("iPhone")) {
			try {
				List<MobileElement> els3 = (List<MobileElement>) driver.findElementsByXPath("//XCUIElementTypeButton[@name=\"Done\"]");
				els3.get(0).click();
				}
				catch (Exception e) {
					System.out.println("error in click on Done Button on Ios App");
				}
		}
		
		changeContextToWebView(driver);
	}

	public static void scrollPageVertically(AppiumDriver<MobileElement> driver, double x, double yStart, double yEnd,int time)
			throws InterruptedException {
		driver.context("NATIVE_APP");
		TouchAction tapCoordinates = new TouchAction(driver);
		Dimension size = driver.manage().window().getSize();
		int scrollstartY = (int) (size.height * yStart);
		int scrollX = (int) (size.width * x);
		int scrollendY = (int) (size.height * yEnd);
		driver.swipe(scrollX, scrollstartY, scrollX, scrollendY,time);
		Thread.sleep(1000);
		PageElement.changeContextToWebView(driver);
	}

	public static void verifyNativePageStillOpen(AppiumDriver<MobileElement> driver) throws InterruptedException {
		if (!driver.getContext().equals("NATIVE_APP")) {
			driver.context("NATIVE_APP");
			Thread.sleep(1000);
		}
		WebElement element = ElementWait.waitForOptionalElement(driver, nativePageTitle, 5);
		if (element != null && element.isDisplayed()) {
			driver.navigate().back();
			Thread.sleep(1000);
		}
		changeContextToWebView(driver);
	}

	public static void changeContextToWebView(AppiumDriver<MobileElement> driver) {
		
	
		if (!globledeviceName.equals("iPhone")) {
		Set<String> contextNames = driver.getContextHandles();
		for (String contextName : contextNames) {
				driver.context(contextName);
				System.out.println(contextName);
		
		}
		}
		
		else{
			try{

		  		 Set<String> contextNames = driver.getContextHandles();
				for (String contextName : contextNames) {
					System.out.println(contextNames); //prints out something like NATIVE_APP \n WEBVIEW_1
					driver.context(contextName);
					System.out.println(contextNames);
				}
			}catch (Exception e) {
				System.out.println("Error in Before Method :: "+e);
			}
		}
		
		
	}

	public static void changeContextToCurrentView(AppiumDriver<MobileElement> driver) {
		Set<String> contextNames = driver.getContextHandles();
		for (String contextName : contextNames) {
			if (!(contextName.equals(NavigationPage.mainWebView) || contextName.equals("NATIVE_APP"))) {
				driver.context(contextName);
			}
		}
	}
	
	public static void SwitchApp(String link) throws InterruptedException {
		if (!globledeviceName.equals("iPhone")) {
	AndroidDriver<MobileElement> driver1=(AndroidDriver<MobileElement>)driver;
	driver1.pressKeyCode(AndroidKeyCode.HOME);
	Thread.sleep(2000);
	driver1.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
	Thread.sleep(2000);
	driver.context("NATIVE_APP");
	Thread.sleep(2000);
	PageElement.Accessibilitylinks(link);
	Thread.sleep(2000);
		}
		else {
	/*		IOSDriver<MobileElement> driver2=(IOSDriver<MobileElement>)driver;
			driver2.pressKeyCode(AndroidKeyCode.HOME);
			Thread.sleep(2000);
			driver2.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
			Thread.sleep(2000);
			driver.context("NATIVE_APP");
			Thread.sleep(2000);
			PageElement.Accessibilitylinks(link);
			Thread.sleep(2000);*/
		}
	
	
	}
	

	public static String printExceptionTrace(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}

	public static boolean isContentOpenInNative(AppiumDriver<MobileElement> driver, String i_text) throws InterruptedException {
		boolean open = false;
		Boolean loading = false;
		WebElement header = null;
		driver.context("NATIVE_APP");
		if (!globledeviceName.equals("iPhone")) {
			loading = driver.findElements(progress).size() != 0;
			if (loading) {
				while (driver.findElements(progress).size() != 0) {
				}
				Thread.sleep(2000);
				System.out.println("user out the loding section");
			} else {
				System.out.println("content is loaded or the loader is not present");
			}
			header = ElementWait.waitForOptionalElement(driver, nativePageTitle, 5);
			if (header != null && header.isDisplayed()) {
				open = true;
				driver.navigate().back();
			}
		} else {
			By i_nativeView = By.xpath("//XCUIElementTypeStaticText[@name='" + i_text + "']");
			header = ElementWait.waitForOptionalElement(driver, i_nativeView, 30);
			if (header != null) {
				open = true;
				Thread.sleep(3000);
				PageElement.tapOnScreen(driver, 0.05, 0.05);
			} else {
				Logger.info("Content is not open in ios native");
			}
			
		
			
			
		}
		PageElement.changeContextToWebView(driver);
		return open;
	}

	public static void backFromIOSNative(AppiumDriver<MobileElement> driver) {
		driver.findElementByName("Return to SuperAppypie").click();
	}
	
	public static void searchMenu(AppiumDriver<MobileElement> driver,By link,String textsearch) {
		WebElement element = ElementWait.waitForOptionalElement(driver, link, 5);
		if (element != null && element.isDisplayed()) {
			driver.findElement(link).sendKeys(textsearch);
			}
		else {
			System.out.println("Search is not present on Menu Page");
		}
	}
	public static void login(AppiumDriver<MobileElement> driver,By link, String textemailID,String textpassword) {
		WebElement element = ElementWait.waitForOptionalElement(driver, link, 5);
		if (element != null && element.isDisplayed()) {
			System.out.println("User Not Login please Login First");
			driver.findElement(link).click();
			driver.findElement(Emailfield).sendKeys(textemailID);
			driver.findElement(passwordfield).sendKeys(textpassword);
			driver.findElement(loginbutton).click();
		
		}
		else {
			System.out.println("User is already Login");
		}
	}
	
	public static boolean Accessibilitylinks(String link)  {
		boolean links = false;
	try {
		driver.findElementByAccessibilityId(link).click();
		links=true;
	}catch (Exception e) {
		System.out.println("Error in AccessibilityId");
	}
		return links;
	}
	
	public static boolean AccessibilitylinksPresent(String link)  {
		boolean links = false;
	try {
		links=true;
	}catch (Exception e) {
		System.out.println("Error in AccessibilityId");
	}
		return links;
	}

	@Override
	public void pageSetUp() {
		// TODO Auto-generated method stub
		
	}
	
	public static void termCond() {
	try {
	Thread.sleep(500);
	WebElement termCond = ElementWait.waitForOptionalElement(driver, tc, 10);
	
	if (termCond != null && termCond.isDisplayed()) {
		termCond.click();
		Logger.info(" terms condition page exist in the app and clicked successfully");
		Thread.sleep(1000);
	}
	else {
		System.out.println("T & C is not present");
	}
	}catch (Exception e) {
		e.printStackTrace();
		Logger.error("T & C Error: " + e.getMessage(),e);
	}
	
	}
	
	public static boolean backFromNaitvePageTaxi(){
		   boolean back=false;
		   try {
		    driver.context("NATIVE_APP");
		    Thread.sleep(2000);
		    driver.navigate().back();
		    back=true;
		    changeContextToWebView(driver);
		   } catch (Exception e) {
		    e.printStackTrace();
		    e.getMessage();
		   }
		   return back;
		  }
	
  
}
