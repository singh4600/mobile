package com.appypie.exceptions;

import java.util.List;

import org.testng.IAlterSuiteListener;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;

public class TestClass implements IAlterSuiteListener {

	@Override
	public void alter(List<XmlSuite> suites) {
			
	}
	
//	
//	@DataProvider(name="test")
//	public Object[][] getData(){	
//	Object[][] data= new Object[2][2];
//		data[0][0]="event";
//		data[1][0]="event_new";
//		
//		data[0][1]="one";
//		data[1][1]="two";
//		return data;
//		
//	}
//	
//	@Test(dataProvider="test")
//	public void eventPageData(String data,String test){
//		System.out.println("value is :"+data);
//		System.out.println("value is :"+test);
//		
//	}

}
