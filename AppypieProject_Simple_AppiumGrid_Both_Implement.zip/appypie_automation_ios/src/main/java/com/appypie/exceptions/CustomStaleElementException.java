package com.appypie.exceptions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.StaleElementReferenceException;



public class CustomStaleElementException extends Exception {

	
    public static void main(String [] arr) throws InterruptedException{
    	System.out.println(new CustomStaleElementException().retry());
    }
    
    public static void throwException(){
    	throw new StaleElementReferenceException("Dom is not loaded");
    }
    
    int retry() throws InterruptedException {
    	int count = 0;
		int maxTries = 3;
    	while(true){
        try {
        	System.out.println("test method starts: "+count);
        	if(count<2)
    		throwException();
    		return count;
        } catch (RuntimeException  e) {
        	Thread.sleep(1000);
            if (++count >= maxTries) {
                throw e;  
            }
        }
    }
    }
}
